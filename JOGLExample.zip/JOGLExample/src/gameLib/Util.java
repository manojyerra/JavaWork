package gameLib;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

public class Util
{
	public static FloatBuffer floatBuffer(float[] arr, int len)
	{
		ByteBuffer byteBuf = ByteBuffer.allocateDirect(len * 4);
		byteBuf.order(ByteOrder.nativeOrder());
		FloatBuffer floatBuf = byteBuf.asFloatBuffer();
		floatBuf.put(arr, 0, len);
		floatBuf.position(0);

		return floatBuf;
	}
}
