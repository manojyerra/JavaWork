
import java.awt.BorderLayout;

import javax.media.opengl.GL;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLCanvas;
import javax.media.opengl.GLEventListener;
import javax.swing.JFrame;
import javax.swing.JPanel;

import com.sun.opengl.util.FPSAnimator;

import glLib.GLTexture;
import glLib.GLVertex;
import glLib.GLWrap;
import static glLib.GLWrap.*;

public class GLExample extends JPanel implements GLEventListener
{
   private static final int REFRESH_FPS = 60;
   final FPSAnimator animator;  // Used to drive display()

   private static final int WINDOW_WIDTH = 480;
   private static final int WINDOW_HEIGHT = 480;
   
   int textureID = 0;
   
   public GLExample() {
      GLCanvas canvas = new GLCanvas();
      this.setLayout(new BorderLayout());
      this.add(canvas, BorderLayout.CENTER);
      canvas.addGLEventListener(this);
      animator = new FPSAnimator(canvas, REFRESH_FPS, true);
      GLVertex.GetInstance().Init();      
   }

   public static void main(String[] args)
   {
      JFrame frame = new JFrame();
      final GLExample joglMain = new GLExample();
      frame.setContentPane(joglMain);
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
      frame.setVisible(true);
      joglMain.animator.start(); // start the animation loop
   }
   
   // Implement methods defined in GLEventListener
   @Override
   public void init(GLAutoDrawable drawable){}
   
   @Override
   public void display(GLAutoDrawable drawable)
   {
	   	GLWrap.gl = drawable.getGL();
   		
	   	if(textureID == 0)
	   		textureID = GLTexture.loadTexture("res/temp.png");
	   	
	   	//glViewport(0, 0, WINDOW_WIDTH, WINDOW_HEIGHT);
	   	glClearColor(1, 0, 0, 1);
		glMatrixMode(GL.GL_PROJECTION);
		glLoadIdentity();
		glOrtho(0, WINDOW_WIDTH, WINDOW_HEIGHT, 0, 0, 1);
		glMatrixMode(GL.GL_MODELVIEW);
		glLoadIdentity();
		
		float x = 100;
		float y = 100;
		float w = 100;
		float h = 200;
				
		GLVertex add = GLVertex.GetInstance();
		
		add.glBegin(GL.GL_TRIANGLES);
		add.glColor4f(1,0,0,1);
		add.glVertex3f(x, y, 0);
		add.glVertex3f(x+w, y, 0);
		add.glVertex3f(x, y+h, 0);
		add.glColor4f(0,1,0,1);
		add.glVertex3f(x+w, y, 0);
		add.glVertex3f(x, y+h, 0);
		add.glVertex3f(x+w, y+h, 0);
		
		add.glEnd();
		
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		
		GLTexture.DrawTexture(textureID, 100, 100, 200, 150);
   }
   
   @Override
   public void reshape(GLAutoDrawable drawable, int x, int y, int width, int height) {}

   @Override 
   public void displayChanged(GLAutoDrawable drawable, boolean modeChanged, boolean deviceChanged) {}
}
