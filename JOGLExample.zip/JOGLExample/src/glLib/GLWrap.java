package glLib;

import javax.media.opengl.*;

public class GLWrap
{
	public static GL gl;
	
	public static final int GL_FALSE = 0;
	public static final int GL_TRUE = 1;
	public static final int GL_BYTE = 5120;
	public static final int GL_UNSIGNED_BYTE = 5121;
	public static final int GL_SHORT = 5122;
	public static final int GL_UNSIGNED_SHORT = 5123;
	public static final int GL_INT = 5124;
	public static final int GL_UNSIGNED_INT = 5125;
	public static final int GL_FLOAT = 5126;
	public static final int GL_DOUBLE = 5130;
	public static final int GL_2_BYTES = 5127;
	public static final int GL_3_BYTES = 5128;
	public static final int GL_4_BYTES = 5129;
	public static final int GL_POINTS = 0;
	public static final int GL_LINES = 1;
	public static final int GL_LINE_LOOP = 2;
	public static final int GL_LINE_STRIP = 3;
	public static final int GL_TRIANGLES = 4;
	public static final int GL_TRIANGLE_STRIP = 5;
	public static final int GL_TRIANGLE_FAN = 6;
	public static final int GL_QUADS = 7;
	public static final int GL_QUAD_STRIP = 8;
	public static final int GL_POLYGON = 9;
	public static final int GL_MATRIX_MODE = 2976;
	public static final int GL_MODELVIEW = 5888;
	public static final int GL_PROJECTION = 5889;
	public static final int GL_TEXTURE = 5890;
	public static final int GL_POINT_SMOOTH = 2832;
	public static final int GL_POINT_SIZE = 2833;
	public static final int GL_POINT_SIZE_GRANULARITY = 2835;
	public static final int GL_POINT_SIZE_RANGE = 2834;
	public static final int GL_LINE_SMOOTH = 2848;
	public static final int GL_LINE_STIPPLE = 2852;
	public static final int GL_LINE_STIPPLE_PATTERN = 2853;
	public static final int GL_LINE_STIPPLE_REPEAT = 2854;
	public static final int GL_LINE_WIDTH = 2849;
	public static final int GL_LINE_WIDTH_GRANULARITY = 2851;
	public static final int GL_LINE_WIDTH_RANGE = 2850;
	public static final int GL_POINT = 6912;
	public static final int GL_LINE = 6913;
	public static final int GL_FILL = 6914;
	public static final int GL_CW = 2304;
	public static final int GL_CCW = 2305;
	public static final int GL_FRONT = 1028;
	public static final int GL_BACK = 1029;
	public static final int GL_POLYGON_MODE = 2880;
	public static final int GL_POLYGON_SMOOTH = 2881;
	public static final int GL_POLYGON_STIPPLE = 2882;
	public static final int GL_EDGE_FLAG = 2883;
	public static final int GL_CULL_FACE = 2884;
	public static final int GL_CULL_FACE_MODE = 2885;
	public static final int GL_FRONT_FACE = 2886;
	public static final int GL_POLYGON_OFFSET_FACTOR = 32824;
	public static final int GL_POLYGON_OFFSET_UNITS = 10752;
	public static final int GL_POLYGON_OFFSET_POINT = 10753;
	public static final int GL_POLYGON_OFFSET_LINE = 10754;
	public static final int GL_POLYGON_OFFSET_FILL = 32823;
	public static final int GL_COMPILE = 4864;
	public static final int GL_COMPILE_AND_EXECUTE = 4865;
	public static final int GL_LIST_BASE = 2866;
	public static final int GL_LIST_INDEX = 2867;
	public static final int GL_LIST_MODE = 2864;
	public static final int GL_NEVER = 512;
	public static final int GL_LESS = 513;
	public static final int GL_EQUAL = 514;
	public static final int GL_LEQUAL = 515;
	public static final int GL_GREATER = 516;
	public static final int GL_NOTEQUAL = 517;
	public static final int GL_GEQUAL = 518;
	public static final int GL_ALWAYS = 519;
	public static final int GL_DEPTH_TEST = 2929;
	public static final int GL_DEPTH_BITS = 3414;
	public static final int GL_DEPTH_CLEAR_VALUE = 2931;
	public static final int GL_DEPTH_FUNC = 2932;
	public static final int GL_DEPTH_RANGE = 2928;
	public static final int GL_DEPTH_WRITEMASK = 2930;
	public static final int GL_DEPTH_COMPONENT = 6402;
	public static final int GL_LIGHTING = 2896;
	public static final int GL_LIGHT0 = 16384;
	public static final int GL_LIGHT1 = 16385;
	public static final int GL_LIGHT2 = 16386;
	public static final int GL_LIGHT3 = 16387;
	public static final int GL_LIGHT4 = 16388;
	public static final int GL_LIGHT5 = 16389;
	public static final int GL_LIGHT6 = 16390;
	public static final int GL_LIGHT7 = 16391;
	public static final int GL_SPOT_EXPONENT = 4613;
	public static final int GL_SPOT_CUTOFF = 4614;
	public static final int GL_CONSTANT_ATTENUATION = 4615;
	public static final int GL_LINEAR_ATTENUATION = 4616;
	public static final int GL_QUADRATIC_ATTENUATION = 4617;
	public static final int GL_AMBIENT = 4608;
	public static final int GL_DIFFUSE = 4609;
	public static final int GL_SPECULAR = 4610;
	public static final int GL_SHININESS = 5633;
	public static final int GL_EMISSION = 5632;
	public static final int GL_POSITION = 4611;
	public static final int GL_SPOT_DIRECTION = 4612;
	public static final int GL_AMBIENT_AND_DIFFUSE = 5634;
	public static final int GL_COLOR_INDEXES = 5635;
	public static final int GL_LIGHT_MODEL_TWO_SIDE = 2898;
	public static final int GL_LIGHT_MODEL_LOCAL_VIEWER = 2897;
	public static final int GL_LIGHT_MODEL_AMBIENT = 2899;
	public static final int GL_FRONT_AND_BACK = 1032;
	public static final int GL_SHADE_MODEL = 2900;
	public static final int GL_FLAT = 7424;
	public static final int GL_SMOOTH = 7425;
	public static final int GL_COLOR_MATERIAL = 2903;
	public static final int GL_COLOR_MATERIAL_FACE = 2901;
	public static final int GL_COLOR_MATERIAL_PARAMETER = 2902;
	public static final int GL_NORMALIZE = 2977;
	public static final int GL_CLIP_PLANE0 = 12288;
	public static final int GL_CLIP_PLANE1 = 12289;
	public static final int GL_CLIP_PLANE2 = 12290;
	public static final int GL_CLIP_PLANE3 = 12291;
	public static final int GL_CLIP_PLANE4 = 12292;
	public static final int GL_CLIP_PLANE5 = 12293;
	public static final int GL_ACCUM_RED_BITS = 3416;
	public static final int GL_ACCUM_GREEN_BITS = 3417;
	public static final int GL_ACCUM_BLUE_BITS = 3418;
	public static final int GL_ACCUM_ALPHA_BITS = 3419;
	public static final int GL_ACCUM_CLEAR_VALUE = 2944;
	public static final int GL_ACCUM = 256;
	public static final int GL_ADD = 260;
	public static final int GL_LOAD = 257;
	public static final int GL_MULT = 259;
	public static final int GL_RETURN = 258;
	public static final int GL_ALPHA_TEST = 3008;
	public static final int GL_ALPHA_TEST_REF = 3010;
	public static final int GL_ALPHA_TEST_FUNC = 3009;
	public static final int GL_BLEND = 3042;
	public static final int GL_BLEND_SRC = 3041;
	public static final int GL_BLEND_DST = 3040;
	public static final int GL_ZERO = 0;
	public static final int GL_ONE = 1;
	public static final int GL_SRC_COLOR = 768;
	public static final int GL_ONE_MINUS_SRC_COLOR = 769;
	public static final int GL_SRC_ALPHA = 770;
	public static final int GL_ONE_MINUS_SRC_ALPHA = 771;
	public static final int GL_DST_ALPHA = 772;
	public static final int GL_ONE_MINUS_DST_ALPHA = 773;
	public static final int GL_DST_COLOR = 774;
	public static final int GL_ONE_MINUS_DST_COLOR = 775;
	public static final int GL_SRC_ALPHA_SATURATE = 776;
	public static final int GL_FEEDBACK = 7169;
	public static final int GL_RENDER = 7168;
	public static final int GL_SELECT = 7170;
	public static final int GL_2D = 1536;
	public static final int GL_3D = 1537;
	public static final int GL_3D_COLOR = 1538;
	public static final int GL_3D_COLOR_TEXTURE = 1539;
	public static final int GL_4D_COLOR_TEXTURE = 1540;
	public static final int GL_POINT_TOKEN = 1793;
	public static final int GL_LINE_TOKEN = 1794;
	public static final int GL_LINE_RESET_TOKEN = 1799;
	public static final int GL_POLYGON_TOKEN = 1795;
	public static final int GL_BITMAP_TOKEN = 1796;
	public static final int GL_DRAW_PIXEL_TOKEN = 1797;
	public static final int GL_COPY_PIXEL_TOKEN = 1798;
	public static final int GL_PASS_THROUGH_TOKEN = 1792;
	public static final int GL_FEEDBACK_BUFFER_POINTER = 3568;
	public static final int GL_FEEDBACK_BUFFER_SIZE = 3569;
	public static final int GL_FEEDBACK_BUFFER_TYPE = 3570;
	public static final int GL_SELECTION_BUFFER_POINTER = 3571;
	public static final int GL_SELECTION_BUFFER_SIZE = 3572;
	public static final int GL_FOG = 2912;
	public static final int GL_FOG_MODE = 2917;
	public static final int GL_FOG_DENSITY = 2914;
	public static final int GL_FOG_COLOR = 2918;
	public static final int GL_FOG_INDEX = 2913;
	public static final int GL_FOG_START = 2915;
	public static final int GL_FOG_END = 2916;
	public static final int GL_LINEAR = 9729;
	public static final int GL_EXP = 2048;
	public static final int GL_EXP2 = 2049;
	public static final int GL_LOGIC_OP = 3057;
	public static final int GL_INDEX_LOGIC_OP = 3057;
	public static final int GL_COLOR_LOGIC_OP = 3058;
	public static final int GL_LOGIC_OP_MODE = 3056;
	public static final int GL_CLEAR = 5376;
	public static final int GL_SET = 5391;
	public static final int GL_COPY = 5379;
	public static final int GL_COPY_INVERTED = 5388;
	public static final int GL_NOOP = 5381;
	public static final int GL_INVERT = 5386;
	public static final int GL_AND = 5377;
	public static final int GL_NAND = 5390;
	public static final int GL_OR = 5383;
	public static final int GL_NOR = 5384;
	public static final int GL_XOR = 5382;
	public static final int GL_EQUIV = 5385;
	public static final int GL_AND_REVERSE = 5378;
	public static final int GL_AND_INVERTED = 5380;
	public static final int GL_OR_REVERSE = 5387;
	public static final int GL_OR_INVERTED = 5389;
	public static final int GL_STENCIL_TEST = 2960;
	public static final int GL_STENCIL_WRITEMASK = 2968;
	public static final int GL_STENCIL_BITS = 3415;
	public static final int GL_STENCIL_FUNC = 2962;
	public static final int GL_STENCIL_VALUE_MASK = 2963;
	public static final int GL_STENCIL_REF = 2967;
	public static final int GL_STENCIL_FAIL = 2964;
	public static final int GL_STENCIL_PASS_DEPTH_PASS = 2966;
	public static final int GL_STENCIL_PASS_DEPTH_FAIL = 2965;
	public static final int GL_STENCIL_CLEAR_VALUE = 2961;
	public static final int GL_STENCIL_INDEX = 6401;
	public static final int GL_KEEP = 7680;
	public static final int GL_REPLACE = 7681;
	public static final int GL_INCR = 7682;
	public static final int GL_DECR = 7683;
	public static final int GL_NONE = 0;
	public static final int GL_LEFT = 1030;
	public static final int GL_RIGHT = 1031;
	public static final int GL_FRONT_LEFT = 1024;
	public static final int GL_FRONT_RIGHT = 1025;
	public static final int GL_BACK_LEFT = 1026;
	public static final int GL_BACK_RIGHT = 1027;
	public static final int GL_AUX0 = 1033;
	public static final int GL_AUX1 = 1034;
	public static final int GL_AUX2 = 1035;
	public static final int GL_AUX3 = 1036;
	public static final int GL_COLOR_INDEX = 6400;
	public static final int GL_RED = 6403;
	public static final int GL_GREEN = 6404;
	public static final int GL_BLUE = 6405;
	public static final int GL_ALPHA = 6406;
	public static final int GL_LUMINANCE = 6409;
	public static final int GL_LUMINANCE_ALPHA = 6410;
	public static final int GL_ALPHA_BITS = 3413;
	public static final int GL_RED_BITS = 3410;
	public static final int GL_GREEN_BITS = 3411;
	public static final int GL_BLUE_BITS = 3412;
	public static final int GL_INDEX_BITS = 3409;
	public static final int GL_SUBPIXEL_BITS = 3408;
	public static final int GL_AUX_BUFFERS = 3072;
	public static final int GL_READ_BUFFER = 3074;
	public static final int GL_DRAW_BUFFER = 3073;
	public static final int GL_DOUBLEBUFFER = 3122;
	public static final int GL_STEREO = 3123;
	public static final int GL_BITMAP = 6656;
	public static final int GL_COLOR = 6144;
	public static final int GL_DEPTH = 6145;
	public static final int GL_STENCIL = 6146;
	public static final int GL_DITHER = 3024;
	public static final int GL_RGB = 6407;
	public static final int GL_RGBA = 6408;
	public static final int GL_MAX_LIST_NESTING = 2865;
	public static final int GL_MAX_ATTRIB_STACK_DEPTH = 3381;
	public static final int GL_MAX_MODELVIEW_STACK_DEPTH = 3382;
	public static final int GL_MAX_NAME_STACK_DEPTH = 3383;
	public static final int GL_MAX_PROJECTION_STACK_DEPTH = 3384;
	public static final int GL_MAX_TEXTURE_STACK_DEPTH = 3385;
	public static final int GL_MAX_EVAL_ORDER = 3376;
	public static final int GL_MAX_LIGHTS = 3377;
	public static final int GL_MAX_CLIP_PLANES = 3378;
	public static final int GL_MAX_TEXTURE_SIZE = 3379;
	public static final int GL_MAX_PIXEL_MAP_TABLE = 3380;
	public static final int GL_MAX_VIEWPORT_DIMS = 3386;
	public static final int GL_MAX_CLIENT_ATTRIB_STACK_DEPTH = 3387;
	public static final int GL_ATTRIB_STACK_DEPTH = 2992;
	public static final int GL_CLIENT_ATTRIB_STACK_DEPTH = 2993;
	public static final int GL_COLOR_CLEAR_VALUE = 3106;
	public static final int GL_COLOR_WRITEMASK = 3107;
	public static final int GL_CURRENT_INDEX = 2817;
	public static final int GL_CURRENT_COLOR = 2816;
	public static final int GL_CURRENT_NORMAL = 2818;
	public static final int GL_CURRENT_RASTER_COLOR = 2820;
	public static final int GL_CURRENT_RASTER_DISTANCE = 2825;
	public static final int GL_CURRENT_RASTER_INDEX = 2821;
	public static final int GL_CURRENT_RASTER_POSITION = 2823;
	public static final int GL_CURRENT_RASTER_TEXTURE_COORDS = 2822;
	public static final int GL_CURRENT_RASTER_POSITION_VALID = 2824;
	public static final int GL_CURRENT_TEXTURE_COORDS = 2819;
	public static final int GL_INDEX_CLEAR_VALUE = 3104;
	public static final int GL_INDEX_MODE = 3120;
	public static final int GL_INDEX_WRITEMASK = 3105;
	public static final int GL_MODELVIEW_MATRIX = 2982;
	public static final int GL_MODELVIEW_STACK_DEPTH = 2979;
	public static final int GL_NAME_STACK_DEPTH = 3440;
	public static final int GL_PROJECTION_MATRIX = 2983;
	public static final int GL_PROJECTION_STACK_DEPTH = 2980;
	public static final int GL_RENDER_MODE = 3136;
	public static final int GL_RGBA_MODE = 3121;
	public static final int GL_TEXTURE_MATRIX = 2984;
	public static final int GL_TEXTURE_STACK_DEPTH = 2981;
	public static final int GL_VIEWPORT = 2978;
	public static final int GL_AUTO_NORMAL = 3456;
	public static final int GL_MAP1_COLOR_4 = 3472;
	public static final int GL_MAP1_INDEX = 3473;
	public static final int GL_MAP1_NORMAL = 3474;
	public static final int GL_MAP1_TEXTURE_COORD_1 = 3475;
	public static final int GL_MAP1_TEXTURE_COORD_2 = 3476;
	public static final int GL_MAP1_TEXTURE_COORD_3 = 3477;
	public static final int GL_MAP1_TEXTURE_COORD_4 = 3478;
	public static final int GL_MAP1_VERTEX_3 = 3479;
	public static final int GL_MAP1_VERTEX_4 = 3480;
	public static final int GL_MAP2_COLOR_4 = 3504;
	public static final int GL_MAP2_INDEX = 3505;
	public static final int GL_MAP2_NORMAL = 3506;
	public static final int GL_MAP2_TEXTURE_COORD_1 = 3507;
	public static final int GL_MAP2_TEXTURE_COORD_2 = 3508;
	public static final int GL_MAP2_TEXTURE_COORD_3 = 3509;
	public static final int GL_MAP2_TEXTURE_COORD_4 = 3510;
	public static final int GL_MAP2_VERTEX_3 = 3511;
	public static final int GL_MAP2_VERTEX_4 = 3512;
	public static final int GL_MAP1_GRID_DOMAIN = 3536;
	public static final int GL_MAP1_GRID_SEGMENTS = 3537;
	public static final int GL_MAP2_GRID_DOMAIN = 3538;
	public static final int GL_MAP2_GRID_SEGMENTS = 3539;
	public static final int GL_COEFF = 2560;
	public static final int GL_DOMAIN = 2562;
	public static final int GL_ORDER = 2561;
	public static final int GL_FOG_HINT = 3156;
	public static final int GL_LINE_SMOOTH_HINT = 3154;
	public static final int GL_PERSPECTIVE_CORRECTION_HINT = 3152;
	public static final int GL_POINT_SMOOTH_HINT = 3153;
	public static final int GL_POLYGON_SMOOTH_HINT = 3155;
	public static final int GL_DONT_CARE = 4352;
	public static final int GL_FASTEST = 4353;
	public static final int GL_NICEST = 4354;
	public static final int GL_SCISSOR_TEST = 3089;
	public static final int GL_SCISSOR_BOX = 3088;
	public static final int GL_MAP_COLOR = 3344;
	public static final int GL_MAP_STENCIL = 3345;
	public static final int GL_INDEX_SHIFT = 3346;
	public static final int GL_INDEX_OFFSET = 3347;
	public static final int GL_RED_SCALE = 3348;
	public static final int GL_RED_BIAS = 3349;
	public static final int GL_GREEN_SCALE = 3352;
	public static final int GL_GREEN_BIAS = 3353;
	public static final int GL_BLUE_SCALE = 3354;
	public static final int GL_BLUE_BIAS = 3355;
	public static final int GL_ALPHA_SCALE = 3356;
	public static final int GL_ALPHA_BIAS = 3357;
	public static final int GL_DEPTH_SCALE = 3358;
	public static final int GL_DEPTH_BIAS = 3359;
	public static final int GL_PIXEL_MAP_S_TO_S_SIZE = 3249;
	public static final int GL_PIXEL_MAP_I_TO_I_SIZE = 3248;
	public static final int GL_PIXEL_MAP_I_TO_R_SIZE = 3250;
	public static final int GL_PIXEL_MAP_I_TO_G_SIZE = 3251;
	public static final int GL_PIXEL_MAP_I_TO_B_SIZE = 3252;
	public static final int GL_PIXEL_MAP_I_TO_A_SIZE = 3253;
	public static final int GL_PIXEL_MAP_R_TO_R_SIZE = 3254;
	public static final int GL_PIXEL_MAP_G_TO_G_SIZE = 3255;
	public static final int GL_PIXEL_MAP_B_TO_B_SIZE = 3256;
	public static final int GL_PIXEL_MAP_A_TO_A_SIZE = 3257;
	public static final int GL_PIXEL_MAP_S_TO_S = 3185;
	public static final int GL_PIXEL_MAP_I_TO_I = 3184;
	public static final int GL_PIXEL_MAP_I_TO_R = 3186;
	public static final int GL_PIXEL_MAP_I_TO_G = 3187;
	public static final int GL_PIXEL_MAP_I_TO_B = 3188;
	public static final int GL_PIXEL_MAP_I_TO_A = 3189;
	public static final int GL_PIXEL_MAP_R_TO_R = 3190;
	public static final int GL_PIXEL_MAP_G_TO_G = 3191;
	public static final int GL_PIXEL_MAP_B_TO_B = 3192;
	public static final int GL_PIXEL_MAP_A_TO_A = 3193;
	public static final int GL_PACK_ALIGNMENT = 3333;
	public static final int GL_PACK_LSB_FIRST = 3329;
	public static final int GL_PACK_ROW_LENGTH = 3330;
	public static final int GL_PACK_SKIP_PIXELS = 3332;
	public static final int GL_PACK_SKIP_ROWS = 3331;
	public static final int GL_PACK_SWAP_BYTES = 3328;
	public static final int GL_UNPACK_ALIGNMENT = 3317;
	public static final int GL_UNPACK_LSB_FIRST = 3313;
	public static final int GL_UNPACK_ROW_LENGTH = 3314;
	public static final int GL_UNPACK_SKIP_PIXELS = 3316;
	public static final int GL_UNPACK_SKIP_ROWS = 3315;
	public static final int GL_UNPACK_SWAP_BYTES = 3312;
	public static final int GL_ZOOM_X = 3350;
	public static final int GL_ZOOM_Y = 3351;
	public static final int GL_TEXTURE_ENV = 8960;
	public static final int GL_TEXTURE_ENV_MODE = 8704;
	public static final int GL_TEXTURE_1D = 3552;
	public static final int GL_TEXTURE_2D = 3553;
	public static final int GL_TEXTURE_WRAP_S = 10242;
	public static final int GL_TEXTURE_WRAP_T = 10243;
	public static final int GL_TEXTURE_MAG_FILTER = 10240;
	public static final int GL_TEXTURE_MIN_FILTER = 10241;
	public static final int GL_TEXTURE_ENV_COLOR = 8705;
	public static final int GL_TEXTURE_GEN_S = 3168;
	public static final int GL_TEXTURE_GEN_T = 3169;
	public static final int GL_TEXTURE_GEN_MODE = 9472;
	public static final int GL_TEXTURE_BORDER_COLOR = 4100;
	public static final int GL_TEXTURE_WIDTH = 4096;
	public static final int GL_TEXTURE_HEIGHT = 4097;
	public static final int GL_TEXTURE_BORDER = 4101;
	public static final int GL_TEXTURE_COMPONENTS = 4099;
	public static final int GL_TEXTURE_RED_SIZE = 32860;
	public static final int GL_TEXTURE_GREEN_SIZE = 32861;
	public static final int GL_TEXTURE_BLUE_SIZE = 32862;
	public static final int GL_TEXTURE_ALPHA_SIZE = 32863;
	public static final int GL_TEXTURE_LUMINANCE_SIZE = 32864;
	public static final int GL_TEXTURE_INTENSITY_SIZE = 32865;
	public static final int GL_NEAREST_MIPMAP_NEAREST = 9984;
	public static final int GL_NEAREST_MIPMAP_LINEAR = 9986;
	public static final int GL_LINEAR_MIPMAP_NEAREST = 9985;
	public static final int GL_LINEAR_MIPMAP_LINEAR = 9987;
	public static final int GL_OBJECT_LINEAR = 9217;
	public static final int GL_OBJECT_PLANE = 9473;
	public static final int GL_EYE_LINEAR = 9216;
	public static final int GL_EYE_PLANE = 9474;
	public static final int GL_SPHERE_MAP = 9218;
	public static final int GL_DECAL = 8449;
	public static final int GL_MODULATE = 8448;
	public static final int GL_NEAREST = 9728;
	public static final int GL_REPEAT = 10497;
	public static final int GL_CLAMP = 10496;
	public static final int GL_S = 8192;
	public static final int GL_T = 8193;
	public static final int GL_R = 8194;
	public static final int GL_Q = 8195;
	public static final int GL_TEXTURE_GEN_R = 3170;
	public static final int GL_TEXTURE_GEN_Q = 3171;
	public static final int GL_VENDOR = 7936;
	public static final int GL_RENDERER = 7937;
	public static final int GL_VERSION = 7938;
	public static final int GL_EXTENSIONS = 7939;
	public static final int GL_NO_ERROR = 0;
	public static final int GL_INVALID_VALUE = 1281;
	public static final int GL_INVALID_ENUM = 1280;
	public static final int GL_INVALID_OPERATION = 1282;
	public static final int GL_STACK_OVERFLOW = 1283;
	public static final int GL_STACK_UNDERFLOW = 1284;
	public static final int GL_OUT_OF_MEMORY = 1285;
	public static final int GL_CURRENT_BIT = 1;
	public static final int GL_POINT_BIT = 2;
	public static final int GL_LINE_BIT = 4;
	public static final int GL_POLYGON_BIT = 8;
	public static final int GL_POLYGON_STIPPLE_BIT = 16;
	public static final int GL_PIXEL_MODE_BIT = 32;
	public static final int GL_LIGHTING_BIT = 64;
	public static final int GL_FOG_BIT = 128;
	public static final int GL_DEPTH_BUFFER_BIT = 256;
	public static final int GL_ACCUM_BUFFER_BIT = 512;
	public static final int GL_STENCIL_BUFFER_BIT = 1024;
	public static final int GL_VIEWPORT_BIT = 2048;
	public static final int GL_TRANSFORM_BIT = 4096;
	public static final int GL_ENABLE_BIT = 8192;
	public static final int GL_COLOR_BUFFER_BIT = 16384;
	public static final int GL_HINT_BIT = 32768;
	public static final int GL_EVAL_BIT = 65536;
	public static final int GL_LIST_BIT = 131072;
	public static final int GL_TEXTURE_BIT = 262144;
	public static final int GL_SCISSOR_BIT = 524288;
	public static final int GL_ALL_ATTRIB_BITS = 1048575;
	public static final int GL_PROXY_TEXTURE_1D = 32867;
	public static final int GL_PROXY_TEXTURE_2D = 32868;
	public static final int GL_TEXTURE_PRIORITY = 32870;
	public static final int GL_TEXTURE_RESIDENT = 32871;
	public static final int GL_TEXTURE_BINDING_1D = 32872;
	public static final int GL_TEXTURE_BINDING_2D = 32873;
	public static final int GL_TEXTURE_INTERNAL_FORMAT = 4099;
	public static final int GL_ALPHA4 = 32827;
	public static final int GL_ALPHA8 = 32828;
	public static final int GL_ALPHA12 = 32829;
	public static final int GL_ALPHA16 = 32830;
	public static final int GL_LUMINANCE4 = 32831;
	public static final int GL_LUMINANCE8 = 32832;
	public static final int GL_LUMINANCE12 = 32833;
	public static final int GL_LUMINANCE16 = 32834;
	public static final int GL_LUMINANCE4_ALPHA4 = 32835;
	public static final int GL_LUMINANCE6_ALPHA2 = 32836;
	public static final int GL_LUMINANCE8_ALPHA8 = 32837;
	public static final int GL_LUMINANCE12_ALPHA4 = 32838;
	public static final int GL_LUMINANCE12_ALPHA12 = 32839;
	public static final int GL_LUMINANCE16_ALPHA16 = 32840;
	public static final int GL_INTENSITY = 32841;
	public static final int GL_INTENSITY4 = 32842;
	public static final int GL_INTENSITY8 = 32843;
	public static final int GL_INTENSITY12 = 32844;
	public static final int GL_INTENSITY16 = 32845;
	public static final int GL_R3_G3_B2 = 10768;
	public static final int GL_RGB4 = 32847;
	public static final int GL_RGB5 = 32848;
	public static final int GL_RGB8 = 32849;
	public static final int GL_RGB10 = 32850;
	public static final int GL_RGB12 = 32851;
	public static final int GL_RGB16 = 32852;
	public static final int GL_RGBA2 = 32853;
	public static final int GL_RGBA4 = 32854;
	public static final int GL_RGB5_A1 = 32855;
	public static final int GL_RGBA8 = 32856;
	public static final int GL_RGB10_A2 = 32857;
	public static final int GL_RGBA12 = 32858;
	public static final int GL_RGBA16 = 32859;
	public static final int GL_CLIENT_PIXEL_STORE_BIT = 1;
	public static final int GL_CLIENT_VERTEX_ARRAY_BIT = 2;
	public static final long GL_ALL_CLIENT_ATTRIB_BITS = -1L;
	public static final long GL_CLIENT_ALL_ATTRIB_BITS = -1L;
	public static final int GL_VERTEX_ARRAY = 32884;
	public static final int GL_NORMAL_ARRAY = 32885;
	public static final int GL_COLOR_ARRAY = 32886;
	public static final int GL_INDEX_ARRAY = 32887;
	public static final int GL_TEXTURE_COORD_ARRAY = 32888;
	public static final int GL_EDGE_FLAG_ARRAY = 32889;
	public static final int GL_VERTEX_ARRAY_SIZE = 32890;
	public static final int GL_VERTEX_ARRAY_TYPE = 32891;
	public static final int GL_VERTEX_ARRAY_STRIDE = 32892;
	public static final int GL_NORMAL_ARRAY_TYPE = 32894;
	public static final int GL_NORMAL_ARRAY_STRIDE = 32895;
	public static final int GL_COLOR_ARRAY_SIZE = 32897;
	public static final int GL_COLOR_ARRAY_TYPE = 32898;
	public static final int GL_COLOR_ARRAY_STRIDE = 32899;
	public static final int GL_INDEX_ARRAY_TYPE = 32901;
	public static final int GL_INDEX_ARRAY_STRIDE = 32902;
	public static final int GL_TEXTURE_COORD_ARRAY_SIZE = 32904;
	public static final int GL_TEXTURE_COORD_ARRAY_TYPE = 32905;
	public static final int GL_TEXTURE_COORD_ARRAY_STRIDE = 32906;
	public static final int GL_EDGE_FLAG_ARRAY_STRIDE = 32908;
	public static final int GL_VERTEX_ARRAY_POINTER = 32910;
	public static final int GL_NORMAL_ARRAY_POINTER = 32911;
	public static final int GL_COLOR_ARRAY_POINTER = 32912;
	public static final int GL_INDEX_ARRAY_POINTER = 32913;
	public static final int GL_TEXTURE_COORD_ARRAY_POINTER = 32914;
	public static final int GL_EDGE_FLAG_ARRAY_POINTER = 32915;
	public static final int GL_V2F = 10784;
	public static final int GL_V3F = 10785;
	public static final int GL_C4UB_V2F = 10786;
	public static final int GL_C4UB_V3F = 10787;
	public static final int GL_C3F_V3F = 10788;
	public static final int GL_N3F_V3F = 10789;
	public static final int GL_C4F_N3F_V3F = 10790;
	public static final int GL_T2F_V3F = 10791;
	public static final int GL_T4F_V4F = 10792;
	public static final int GL_T2F_C4UB_V3F = 10793;
	public static final int GL_T2F_C3F_V3F = 10794;
	public static final int GL_T2F_N3F_V3F = 10795;
	public static final int GL_T2F_C4F_N3F_V3F = 10796;
	public static final int GL_T4F_C4F_N3F_V4F = 10797;
	public static final int GL_GLEXT_VERSION = 36;
	public static final int GL_UNSIGNED_BYTE_3_3_2 = 32818;
	public static final int GL_UNSIGNED_SHORT_4_4_4_4 = 32819;
	public static final int GL_UNSIGNED_SHORT_5_5_5_1 = 32820;
	public static final int GL_UNSIGNED_INT_8_8_8_8 = 32821;
	public static final int GL_UNSIGNED_INT_10_10_10_2 = 32822;
	public static final int GL_RESCALE_NORMAL = 32826;
	public static final int GL_TEXTURE_BINDING_3D = 32874;
	public static final int GL_PACK_SKIP_IMAGES = 32875;
	public static final int GL_PACK_IMAGE_HEIGHT = 32876;
	public static final int GL_UNPACK_SKIP_IMAGES = 32877;
	public static final int GL_UNPACK_IMAGE_HEIGHT = 32878;
	public static final int GL_TEXTURE_3D = 32879;
	public static final int GL_PROXY_TEXTURE_3D = 32880;
	public static final int GL_TEXTURE_DEPTH = 32881;
	public static final int GL_TEXTURE_WRAP_R = 32882;
	public static final int GL_MAX_3D_TEXTURE_SIZE = 32883;
	public static final int GL_UNSIGNED_BYTE_2_3_3_REV = 33634;
	public static final int GL_UNSIGNED_SHORT_5_6_5 = 33635;
	public static final int GL_UNSIGNED_SHORT_5_6_5_REV = 33636;
	public static final int GL_UNSIGNED_SHORT_4_4_4_4_REV = 33637;
	public static final int GL_UNSIGNED_SHORT_1_5_5_5_REV = 33638;
	public static final int GL_UNSIGNED_INT_8_8_8_8_REV = 33639;
	public static final int GL_UNSIGNED_INT_2_10_10_10_REV = 33640;
	public static final int GL_BGR = 32992;
	public static final int GL_BGRA = 32993;
	public static final int GL_MAX_ELEMENTS_VERTICES = 33000;
	public static final int GL_MAX_ELEMENTS_INDICES = 33001;
	public static final int GL_CLAMP_TO_EDGE = 33071;
	public static final int GL_TEXTURE_MIN_LOD = 33082;
	public static final int GL_TEXTURE_MAX_LOD = 33083;
	public static final int GL_TEXTURE_BASE_LEVEL = 33084;
	public static final int GL_TEXTURE_MAX_LEVEL = 33085;
	public static final int GL_LIGHT_MODEL_COLOR_CONTROL = 33272;
	public static final int GL_SINGLE_COLOR = 33273;
	public static final int GL_SEPARATE_SPECULAR_COLOR = 33274;
	public static final int GL_SMOOTH_POINT_SIZE_RANGE = 2834;
	public static final int GL_SMOOTH_POINT_SIZE_GRANULARITY = 2835;
	public static final int GL_SMOOTH_LINE_WIDTH_RANGE = 2850;
	public static final int GL_SMOOTH_LINE_WIDTH_GRANULARITY = 2851;
	public static final int GL_ALIASED_POINT_SIZE_RANGE = 33901;
	public static final int GL_ALIASED_LINE_WIDTH_RANGE = 33902;
	public static final int GL_CONSTANT_COLOR = 32769;
	public static final int GL_ONE_MINUS_CONSTANT_COLOR = 32770;
	public static final int GL_CONSTANT_ALPHA = 32771;
	public static final int GL_ONE_MINUS_CONSTANT_ALPHA = 32772;
	public static final int GL_BLEND_COLOR = 32773;
	public static final int GL_FUNC_ADD = 32774;
	public static final int GL_MIN = 32775;
	public static final int GL_MAX = 32776;
	public static final int GL_BLEND_EQUATION = 32777;
	public static final int GL_FUNC_SUBTRACT = 32778;
	public static final int GL_FUNC_REVERSE_SUBTRACT = 32779;
	public static final int GL_CONVOLUTION_1D = 32784;
	public static final int GL_CONVOLUTION_2D = 32785;
	public static final int GL_SEPARABLE_2D = 32786;
	public static final int GL_CONVOLUTION_BORDER_MODE = 32787;
	public static final int GL_CONVOLUTION_FILTER_SCALE = 32788;
	public static final int GL_CONVOLUTION_FILTER_BIAS = 32789;
	public static final int GL_REDUCE = 32790;
	public static final int GL_CONVOLUTION_FORMAT = 32791;
	public static final int GL_CONVOLUTION_WIDTH = 32792;
	public static final int GL_CONVOLUTION_HEIGHT = 32793;
	public static final int GL_MAX_CONVOLUTION_WIDTH = 32794;
	public static final int GL_MAX_CONVOLUTION_HEIGHT = 32795;
	public static final int GL_POST_CONVOLUTION_RED_SCALE = 32796;
	public static final int GL_POST_CONVOLUTION_GREEN_SCALE = 32797;
	public static final int GL_POST_CONVOLUTION_BLUE_SCALE = 32798;
	public static final int GL_POST_CONVOLUTION_ALPHA_SCALE = 32799;
	public static final int GL_POST_CONVOLUTION_RED_BIAS = 32800;
	public static final int GL_POST_CONVOLUTION_GREEN_BIAS = 32801;
	public static final int GL_POST_CONVOLUTION_BLUE_BIAS = 32802;
	public static final int GL_POST_CONVOLUTION_ALPHA_BIAS = 32803;
	public static final int GL_HISTOGRAM = 32804;
	public static final int GL_PROXY_HISTOGRAM = 32805;
	public static final int GL_HISTOGRAM_WIDTH = 32806;
	public static final int GL_HISTOGRAM_FORMAT = 32807;
	public static final int GL_HISTOGRAM_RED_SIZE = 32808;
	public static final int GL_HISTOGRAM_GREEN_SIZE = 32809;
	public static final int GL_HISTOGRAM_BLUE_SIZE = 32810;
	public static final int GL_HISTOGRAM_ALPHA_SIZE = 32811;
	public static final int GL_HISTOGRAM_LUMINANCE_SIZE = 32812;
	public static final int GL_HISTOGRAM_SINK = 32813;
	public static final int GL_MINMAX = 32814;
	public static final int GL_MINMAX_FORMAT = 32815;
	public static final int GL_MINMAX_SINK = 32816;
	public static final int GL_TABLE_TOO_LARGE = 32817;
	public static final int GL_COLOR_MATRIX = 32945;
	public static final int GL_COLOR_MATRIX_STACK_DEPTH = 32946;
	public static final int GL_MAX_COLOR_MATRIX_STACK_DEPTH = 32947;
	public static final int GL_POST_COLOR_MATRIX_RED_SCALE = 32948;
	public static final int GL_POST_COLOR_MATRIX_GREEN_SCALE = 32949;
	public static final int GL_POST_COLOR_MATRIX_BLUE_SCALE = 32950;
	public static final int GL_POST_COLOR_MATRIX_ALPHA_SCALE = 32951;
	public static final int GL_POST_COLOR_MATRIX_RED_BIAS = 32952;
	public static final int GL_POST_COLOR_MATRIX_GREEN_BIAS = 32953;
	public static final int GL_POST_COLOR_MATRIX_BLUE_BIAS = 32954;
	public static final int GL_POST_COLOR_MATRIX_ALPHA_BIAS = 32955;
	public static final int GL_COLOR_TABLE = 32976;
	public static final int GL_POST_CONVOLUTION_COLOR_TABLE = 32977;
	public static final int GL_POST_COLOR_MATRIX_COLOR_TABLE = 32978;
	public static final int GL_PROXY_COLOR_TABLE = 32979;
	public static final int GL_PROXY_POST_CONVOLUTION_COLOR_TABLE = 32980;
	public static final int GL_PROXY_POST_COLOR_MATRIX_COLOR_TABLE = 32981;
	public static final int GL_COLOR_TABLE_SCALE = 32982;
	public static final int GL_COLOR_TABLE_BIAS = 32983;
	public static final int GL_COLOR_TABLE_FORMAT = 32984;
	public static final int GL_COLOR_TABLE_WIDTH = 32985;
	public static final int GL_COLOR_TABLE_RED_SIZE = 32986;
	public static final int GL_COLOR_TABLE_GREEN_SIZE = 32987;
	public static final int GL_COLOR_TABLE_BLUE_SIZE = 32988;
	public static final int GL_COLOR_TABLE_ALPHA_SIZE = 32989;
	public static final int GL_COLOR_TABLE_LUMINANCE_SIZE = 32990;
	public static final int GL_COLOR_TABLE_INTENSITY_SIZE = 32991;
	public static final int GL_CONSTANT_BORDER = 33105;
	public static final int GL_REPLICATE_BORDER = 33107;
	public static final int GL_CONVOLUTION_BORDER_COLOR = 33108;
	public static final int GL_TEXTURE0 = 33984;
	public static final int GL_TEXTURE1 = 33985;
	public static final int GL_TEXTURE2 = 33986;
	public static final int GL_TEXTURE3 = 33987;
	public static final int GL_TEXTURE4 = 33988;
	public static final int GL_TEXTURE5 = 33989;
	public static final int GL_TEXTURE6 = 33990;
	public static final int GL_TEXTURE7 = 33991;
	public static final int GL_TEXTURE8 = 33992;
	public static final int GL_TEXTURE9 = 33993;
	public static final int GL_TEXTURE10 = 33994;
	public static final int GL_TEXTURE11 = 33995;
	public static final int GL_TEXTURE12 = 33996;
	public static final int GL_TEXTURE13 = 33997;
	public static final int GL_TEXTURE14 = 33998;
	public static final int GL_TEXTURE15 = 33999;
	public static final int GL_TEXTURE16 = 34000;
	public static final int GL_TEXTURE17 = 34001;
	public static final int GL_TEXTURE18 = 34002;
	public static final int GL_TEXTURE19 = 34003;
	public static final int GL_TEXTURE20 = 34004;
	public static final int GL_TEXTURE21 = 34005;
	public static final int GL_TEXTURE22 = 34006;
	public static final int GL_TEXTURE23 = 34007;
	public static final int GL_TEXTURE24 = 34008;
	public static final int GL_TEXTURE25 = 34009;
	public static final int GL_TEXTURE26 = 34010;
	public static final int GL_TEXTURE27 = 34011;
	public static final int GL_TEXTURE28 = 34012;
	public static final int GL_TEXTURE29 = 34013;
	public static final int GL_TEXTURE30 = 34014;
	public static final int GL_TEXTURE31 = 34015;
	public static final int GL_ACTIVE_TEXTURE = 34016;
	public static final int GL_CLIENT_ACTIVE_TEXTURE = 34017;
	public static final int GL_MAX_TEXTURE_UNITS = 34018;
	public static final int GL_TRANSPOSE_MODELVIEW_MATRIX = 34019;
	public static final int GL_TRANSPOSE_PROJECTION_MATRIX = 34020;
	public static final int GL_TRANSPOSE_TEXTURE_MATRIX = 34021;
	public static final int GL_TRANSPOSE_COLOR_MATRIX = 34022;
	public static final int GL_MULTISAMPLE = 32925;
	public static final int GL_SAMPLE_ALPHA_TO_COVERAGE = 32926;
	public static final int GL_SAMPLE_ALPHA_TO_ONE = 32927;
	public static final int GL_SAMPLE_COVERAGE = 32928;
	public static final int GL_SAMPLE_BUFFERS = 32936;
	public static final int GL_SAMPLES = 32937;
	public static final int GL_SAMPLE_COVERAGE_VALUE = 32938;
	public static final int GL_SAMPLE_COVERAGE_INVERT = 32939;
	public static final int GL_MULTISAMPLE_BIT = 536870912;
	public static final int GL_NORMAL_MAP = 34065;
	public static final int GL_REFLECTION_MAP = 34066;
	public static final int GL_TEXTURE_CUBE_MAP = 34067;
	public static final int GL_TEXTURE_BINDING_CUBE_MAP = 34068;
	public static final int GL_TEXTURE_CUBE_MAP_POSITIVE_X = 34069;
	public static final int GL_TEXTURE_CUBE_MAP_NEGATIVE_X = 34070;
	public static final int GL_TEXTURE_CUBE_MAP_POSITIVE_Y = 34071;
	public static final int GL_TEXTURE_CUBE_MAP_NEGATIVE_Y = 34072;
	public static final int GL_TEXTURE_CUBE_MAP_POSITIVE_Z = 34073;
	public static final int GL_TEXTURE_CUBE_MAP_NEGATIVE_Z = 34074;
	public static final int GL_PROXY_TEXTURE_CUBE_MAP = 34075;
	public static final int GL_MAX_CUBE_MAP_TEXTURE_SIZE = 34076;
	public static final int GL_COMPRESSED_ALPHA = 34025;
	public static final int GL_COMPRESSED_LUMINANCE = 34026;
	public static final int GL_COMPRESSED_LUMINANCE_ALPHA = 34027;
	public static final int GL_COMPRESSED_INTENSITY = 34028;
	public static final int GL_COMPRESSED_RGB = 34029;
	public static final int GL_COMPRESSED_RGBA = 34030;
	public static final int GL_TEXTURE_COMPRESSION_HINT = 34031;
	public static final int GL_TEXTURE_COMPRESSED_IMAGE_SIZE = 34464;
	public static final int GL_TEXTURE_COMPRESSED = 34465;
	public static final int GL_NUM_COMPRESSED_TEXTURE_FORMATS = 34466;
	public static final int GL_COMPRESSED_TEXTURE_FORMATS = 34467;
	public static final int GL_CLAMP_TO_BORDER = 33069;
	public static final int GL_COMBINE = 34160;
	public static final int GL_COMBINE_RGB = 34161;
	public static final int GL_COMBINE_ALPHA = 34162;
	public static final int GL_SOURCE0_RGB = 34176;
	public static final int GL_SOURCE1_RGB = 34177;
	public static final int GL_SOURCE2_RGB = 34178;
	public static final int GL_SOURCE0_ALPHA = 34184;
	public static final int GL_SOURCE1_ALPHA = 34185;
	public static final int GL_SOURCE2_ALPHA = 34186;
	public static final int GL_OPERAND0_RGB = 34192;
	public static final int GL_OPERAND1_RGB = 34193;
	public static final int GL_OPERAND2_RGB = 34194;
	public static final int GL_OPERAND0_ALPHA = 34200;
	public static final int GL_OPERAND1_ALPHA = 34201;
	public static final int GL_OPERAND2_ALPHA = 34202;
	public static final int GL_RGB_SCALE = 34163;
	public static final int GL_ADD_SIGNED = 34164;
	public static final int GL_INTERPOLATE = 34165;
	public static final int GL_SUBTRACT = 34023;
	public static final int GL_CONSTANT = 34166;
	public static final int GL_PRIMARY_COLOR = 34167;
	public static final int GL_PREVIOUS = 34168;
	public static final int GL_DOT3_RGB = 34478;
	public static final int GL_DOT3_RGBA = 34479;
	public static final int GL_BLEND_DST_RGB = 32968;
	public static final int GL_BLEND_SRC_RGB = 32969;
	public static final int GL_BLEND_DST_ALPHA = 32970;
	public static final int GL_BLEND_SRC_ALPHA = 32971;
	public static final int GL_POINT_SIZE_MIN = 33062;
	public static final int GL_POINT_SIZE_MAX = 33063;
	public static final int GL_POINT_FADE_THRESHOLD_SIZE = 33064;
	public static final int GL_POINT_DISTANCE_ATTENUATION = 33065;
	public static final int GL_GENERATE_MIPMAP = 33169;
	public static final int GL_GENERATE_MIPMAP_HINT = 33170;
	public static final int GL_DEPTH_COMPONENT16 = 33189;
	public static final int GL_DEPTH_COMPONENT24 = 33190;
	public static final int GL_DEPTH_COMPONENT32 = 33191;
	public static final int GL_MIRRORED_REPEAT = 33648;
	public static final int GL_FOG_COORDINATE_SOURCE = 33872;
	public static final int GL_FOG_COORDINATE = 33873;
	public static final int GL_FRAGMENT_DEPTH = 33874;
	public static final int GL_CURRENT_FOG_COORDINATE = 33875;
	public static final int GL_FOG_COORDINATE_ARRAY_TYPE = 33876;
	public static final int GL_FOG_COORDINATE_ARRAY_STRIDE = 33877;
	public static final int GL_FOG_COORDINATE_ARRAY_POINTER = 33878;
	public static final int GL_FOG_COORDINATE_ARRAY = 33879;
	public static final int GL_COLOR_SUM = 33880;
	public static final int GL_CURRENT_SECONDARY_COLOR = 33881;
	public static final int GL_SECONDARY_COLOR_ARRAY_SIZE = 33882;
	public static final int GL_SECONDARY_COLOR_ARRAY_TYPE = 33883;
	public static final int GL_SECONDARY_COLOR_ARRAY_STRIDE = 33884;
	public static final int GL_SECONDARY_COLOR_ARRAY_POINTER = 33885;
	public static final int GL_SECONDARY_COLOR_ARRAY = 33886;
	public static final int GL_MAX_TEXTURE_LOD_BIAS = 34045;
	public static final int GL_TEXTURE_FILTER_CONTROL = 34048;
	public static final int GL_TEXTURE_LOD_BIAS = 34049;
	public static final int GL_INCR_WRAP = 34055;
	public static final int GL_DECR_WRAP = 34056;
	public static final int GL_TEXTURE_DEPTH_SIZE = 34890;
	public static final int GL_DEPTH_TEXTURE_MODE = 34891;
	public static final int GL_TEXTURE_COMPARE_MODE = 34892;
	public static final int GL_TEXTURE_COMPARE_FUNC = 34893;
	public static final int GL_COMPARE_R_TO_TEXTURE = 34894;
	public static final int GL_BUFFER_SIZE = 34660;
	public static final int GL_BUFFER_USAGE = 34661;
	public static final int GL_QUERY_COUNTER_BITS = 34916;
	public static final int GL_CURRENT_QUERY = 34917;
	public static final int GL_QUERY_RESULT = 34918;
	public static final int GL_QUERY_RESULT_AVAILABLE = 34919;
	public static final int GL_ARRAY_BUFFER = 34962;
	public static final int GL_ELEMENT_ARRAY_BUFFER = 34963;
	public static final int GL_ARRAY_BUFFER_BINDING = 34964;
	public static final int GL_ELEMENT_ARRAY_BUFFER_BINDING = 34965;
	public static final int GL_VERTEX_ARRAY_BUFFER_BINDING = 34966;
	public static final int GL_NORMAL_ARRAY_BUFFER_BINDING = 34967;
	public static final int GL_COLOR_ARRAY_BUFFER_BINDING = 34968;
	public static final int GL_INDEX_ARRAY_BUFFER_BINDING = 34969;
	public static final int GL_TEXTURE_COORD_ARRAY_BUFFER_BINDING = 34970;
	public static final int GL_EDGE_FLAG_ARRAY_BUFFER_BINDING = 34971;
	public static final int GL_SECONDARY_COLOR_ARRAY_BUFFER_BINDING = 34972;
	public static final int GL_FOG_COORDINATE_ARRAY_BUFFER_BINDING = 34973;
	public static final int GL_WEIGHT_ARRAY_BUFFER_BINDING = 34974;
	public static final int GL_VERTEX_ATTRIB_ARRAY_BUFFER_BINDING = 34975;
	public static final int GL_READ_ONLY = 35000;
	public static final int GL_WRITE_ONLY = 35001;
	public static final int GL_READ_WRITE = 35002;
	public static final int GL_BUFFER_ACCESS = 35003;
	public static final int GL_BUFFER_MAPPED = 35004;
	public static final int GL_BUFFER_MAP_POINTER = 35005;
	public static final int GL_STREAM_DRAW = 35040;
	public static final int GL_STREAM_READ = 35041;
	public static final int GL_STREAM_COPY = 35042;
	public static final int GL_STATIC_DRAW = 35044;
	public static final int GL_STATIC_READ = 35045;
	public static final int GL_STATIC_COPY = 35046;
	public static final int GL_DYNAMIC_DRAW = 35048;
	public static final int GL_DYNAMIC_READ = 35049;
	public static final int GL_DYNAMIC_COPY = 35050;
	public static final int GL_SAMPLES_PASSED = 35092;
	public static final int GL_FOG_COORD_SRC = 33872;
	public static final int GL_FOG_COORD = 33873;
	public static final int GL_CURRENT_FOG_COORD = 33875;
	public static final int GL_FOG_COORD_ARRAY_TYPE = 33876;
	public static final int GL_FOG_COORD_ARRAY_STRIDE = 33877;
	public static final int GL_FOG_COORD_ARRAY_POINTER = 33878;
	public static final int GL_FOG_COORD_ARRAY = 33879;
	public static final int GL_FOG_COORD_ARRAY_BUFFER_BINDING = 34973;
	public static final int GL_SRC0_RGB = 34176;
	public static final int GL_SRC1_RGB = 34177;
	public static final int GL_SRC2_RGB = 34178;
	public static final int GL_SRC0_ALPHA = 34184;
	public static final int GL_SRC1_ALPHA = 34185;
	public static final int GL_SRC2_ALPHA = 34186;
	public static final int GL_BLEND_EQUATION_RGB = 32777;
	public static final int GL_VERTEX_ATTRIB_ARRAY_ENABLED = 34338;
	public static final int GL_VERTEX_ATTRIB_ARRAY_SIZE = 34339;
	public static final int GL_VERTEX_ATTRIB_ARRAY_STRIDE = 34340;
	public static final int GL_VERTEX_ATTRIB_ARRAY_TYPE = 34341;
	public static final int GL_CURRENT_VERTEX_ATTRIB = 34342;
	public static final int GL_VERTEX_PROGRAM_POINT_SIZE = 34370;
	public static final int GL_VERTEX_PROGRAM_TWO_SIDE = 34371;
	public static final int GL_VERTEX_ATTRIB_ARRAY_POINTER = 34373;
	public static final int GL_STENCIL_BACK_FUNC = 34816;
	public static final int GL_STENCIL_BACK_FAIL = 34817;
	public static final int GL_STENCIL_BACK_PASS_DEPTH_FAIL = 34818;
	public static final int GL_STENCIL_BACK_PASS_DEPTH_PASS = 34819;
	public static final int GL_MAX_DRAW_BUFFERS = 34852;
	public static final int GL_DRAW_BUFFER0 = 34853;
	public static final int GL_DRAW_BUFFER1 = 34854;
	public static final int GL_DRAW_BUFFER2 = 34855;
	public static final int GL_DRAW_BUFFER3 = 34856;
	public static final int GL_DRAW_BUFFER4 = 34857;
	public static final int GL_DRAW_BUFFER5 = 34858;
	public static final int GL_DRAW_BUFFER6 = 34859;
	public static final int GL_DRAW_BUFFER7 = 34860;
	public static final int GL_DRAW_BUFFER8 = 34861;
	public static final int GL_DRAW_BUFFER9 = 34862;
	public static final int GL_DRAW_BUFFER10 = 34863;
	public static final int GL_DRAW_BUFFER11 = 34864;
	public static final int GL_DRAW_BUFFER12 = 34865;
	public static final int GL_DRAW_BUFFER13 = 34866;
	public static final int GL_DRAW_BUFFER14 = 34867;
	public static final int GL_DRAW_BUFFER15 = 34868;
	public static final int GL_BLEND_EQUATION_ALPHA = 34877;
	public static final int GL_POINT_SPRITE = 34913;
	public static final int GL_COORD_REPLACE = 34914;
	public static final int GL_MAX_VERTEX_ATTRIBS = 34921;
	public static final int GL_VERTEX_ATTRIB_ARRAY_NORMALIZED = 34922;
	public static final int GL_MAX_TEXTURE_COORDS = 34929;
	public static final int GL_MAX_TEXTURE_IMAGE_UNITS = 34930;
	public static final int GL_FRAGMENT_SHADER = 35632;
	public static final int GL_VERTEX_SHADER = 35633;
	public static final int GL_MAX_FRAGMENT_UNIFORM_COMPONENTS = 35657;
	public static final int GL_MAX_VERTEX_UNIFORM_COMPONENTS = 35658;
	public static final int GL_MAX_VARYING_FLOATS = 35659;
	public static final int GL_MAX_VERTEX_TEXTURE_IMAGE_UNITS = 35660;
	public static final int GL_MAX_COMBINED_TEXTURE_IMAGE_UNITS = 35661;
	public static final int GL_SHADER_TYPE = 35663;
	public static final int GL_FLOAT_VEC2 = 35664;
	public static final int GL_FLOAT_VEC3 = 35665;
	public static final int GL_FLOAT_VEC4 = 35666;
	public static final int GL_INT_VEC2 = 35667;
	public static final int GL_INT_VEC3 = 35668;
	public static final int GL_INT_VEC4 = 35669;
	public static final int GL_BOOL = 35670;
	public static final int GL_BOOL_VEC2 = 35671;
	public static final int GL_BOOL_VEC3 = 35672;
	public static final int GL_BOOL_VEC4 = 35673;
	public static final int GL_FLOAT_MAT2 = 35674;
	public static final int GL_FLOAT_MAT3 = 35675;
	public static final int GL_FLOAT_MAT4 = 35676;
	public static final int GL_SAMPLER_1D = 35677;
	public static final int GL_SAMPLER_2D = 35678;
	public static final int GL_SAMPLER_3D = 35679;
	public static final int GL_SAMPLER_CUBE = 35680;
	public static final int GL_SAMPLER_1D_SHADOW = 35681;
	public static final int GL_SAMPLER_2D_SHADOW = 35682;
	public static final int GL_DELETE_STATUS = 35712;
	public static final int GL_COMPILE_STATUS = 35713;
	public static final int GL_LINK_STATUS = 35714;
	public static final int GL_VALIDATE_STATUS = 35715;
	public static final int GL_INFO_LOG_LENGTH = 35716;
	public static final int GL_ATTACHED_SHADERS = 35717;
	public static final int GL_ACTIVE_UNIFORMS = 35718;
	public static final int GL_ACTIVE_UNIFORM_MAX_LENGTH = 35719;
	public static final int GL_SHADER_SOURCE_LENGTH = 35720;
	public static final int GL_ACTIVE_ATTRIBUTES = 35721;
	public static final int GL_ACTIVE_ATTRIBUTE_MAX_LENGTH = 35722;
	public static final int GL_FRAGMENT_SHADER_DERIVATIVE_HINT = 35723;
	public static final int GL_SHADING_LANGUAGE_VERSION = 35724;
	public static final int GL_CURRENT_PROGRAM = 35725;
	public static final int GL_POINT_SPRITE_COORD_ORIGIN = 36000;
	public static final int GL_LOWER_LEFT = 36001;
	public static final int GL_UPPER_LEFT = 36002;
	public static final int GL_STENCIL_BACK_REF = 36003;
	public static final int GL_STENCIL_BACK_VALUE_MASK = 36004;
	public static final int GL_STENCIL_BACK_WRITEMASK = 36005;
	public static final int GL_CURRENT_RASTER_SECONDARY_COLOR = 33887;
	public static final int GL_PIXEL_PACK_BUFFER = 35051;
	public static final int GL_PIXEL_UNPACK_BUFFER = 35052;
	public static final int GL_PIXEL_PACK_BUFFER_BINDING = 35053;
	public static final int GL_PIXEL_UNPACK_BUFFER_BINDING = 35055;
	public static final int GL_FLOAT_MAT2x3 = 35685;
	public static final int GL_FLOAT_MAT2x4 = 35686;
	public static final int GL_FLOAT_MAT3x2 = 35687;
	public static final int GL_FLOAT_MAT3x4 = 35688;
	public static final int GL_FLOAT_MAT4x2 = 35689;
	public static final int GL_FLOAT_MAT4x3 = 35690;
	public static final int GL_SRGB = 35904;
	public static final int GL_SRGB8 = 35905;
	public static final int GL_SRGB_ALPHA = 35906;
	public static final int GL_SRGB8_ALPHA8 = 35907;
	public static final int GL_SLUMINANCE_ALPHA = 35908;
	public static final int GL_SLUMINANCE8_ALPHA8 = 35909;
	public static final int GL_SLUMINANCE = 35910;
	public static final int GL_SLUMINANCE8 = 35911;
	public static final int GL_COMPRESSED_SRGB = 35912;
	public static final int GL_COMPRESSED_SRGB_ALPHA = 35913;
	public static final int GL_COMPRESSED_SLUMINANCE = 35914;
	public static final int GL_COMPRESSED_SLUMINANCE_ALPHA = 35915;
	public static final int GL_POINT_SIZE_MIN_ARB = 33062;
	public static final int GL_POINT_SIZE_MAX_ARB = 33063;
	public static final int GL_POINT_FADE_THRESHOLD_SIZE_ARB = 33064;
	public static final int GL_POINT_DISTANCE_ATTENUATION_ARB = 33065;
	public static final int GL_MAX_VERTEX_UNITS_ARB = 34468;
	public static final int GL_ACTIVE_VERTEX_UNITS_ARB = 34469;
	public static final int GL_WEIGHT_SUM_UNITY_ARB = 34470;
	public static final int GL_VERTEX_BLEND_ARB = 34471;
	public static final int GL_CURRENT_WEIGHT_ARB = 34472;
	public static final int GL_WEIGHT_ARRAY_TYPE_ARB = 34473;
	public static final int GL_WEIGHT_ARRAY_STRIDE_ARB = 34474;
	public static final int GL_WEIGHT_ARRAY_SIZE_ARB = 34475;
	public static final int GL_WEIGHT_ARRAY_POINTER_ARB = 34476;
	public static final int GL_WEIGHT_ARRAY_ARB = 34477;
	public static final int GL_MODELVIEW0_ARB = 5888;
	public static final int GL_MODELVIEW1_ARB = 34058;
	public static final int GL_MODELVIEW2_ARB = 34594;
	public static final int GL_MODELVIEW3_ARB = 34595;
	public static final int GL_MODELVIEW4_ARB = 34596;
	public static final int GL_MODELVIEW5_ARB = 34597;
	public static final int GL_MODELVIEW6_ARB = 34598;
	public static final int GL_MODELVIEW7_ARB = 34599;
	public static final int GL_MODELVIEW8_ARB = 34600;
	public static final int GL_MODELVIEW9_ARB = 34601;
	public static final int GL_MODELVIEW10_ARB = 34602;
	public static final int GL_MODELVIEW11_ARB = 34603;
	public static final int GL_MODELVIEW12_ARB = 34604;
	public static final int GL_MODELVIEW13_ARB = 34605;
	public static final int GL_MODELVIEW14_ARB = 34606;
	public static final int GL_MODELVIEW15_ARB = 34607;
	public static final int GL_MODELVIEW16_ARB = 34608;
	public static final int GL_MODELVIEW17_ARB = 34609;
	public static final int GL_MODELVIEW18_ARB = 34610;
	public static final int GL_MODELVIEW19_ARB = 34611;
	public static final int GL_MODELVIEW20_ARB = 34612;
	public static final int GL_MODELVIEW21_ARB = 34613;
	public static final int GL_MODELVIEW22_ARB = 34614;
	public static final int GL_MODELVIEW23_ARB = 34615;
	public static final int GL_MODELVIEW24_ARB = 34616;
	public static final int GL_MODELVIEW25_ARB = 34617;
	public static final int GL_MODELVIEW26_ARB = 34618;
	public static final int GL_MODELVIEW27_ARB = 34619;
	public static final int GL_MODELVIEW28_ARB = 34620;
	public static final int GL_MODELVIEW29_ARB = 34621;
	public static final int GL_MODELVIEW30_ARB = 34622;
	public static final int GL_MODELVIEW31_ARB = 34623;
	public static final int GL_MATRIX_PALETTE_ARB = 34880;
	public static final int GL_MAX_MATRIX_PALETTE_STACK_DEPTH_ARB = 34881;
	public static final int GL_MAX_PALETTE_MATRICES_ARB = 34882;
	public static final int GL_CURRENT_PALETTE_MATRIX_ARB = 34883;
	public static final int GL_MATRIX_INDEX_ARRAY_ARB = 34884;
	public static final int GL_CURRENT_MATRIX_INDEX_ARB = 34885;
	public static final int GL_MATRIX_INDEX_ARRAY_SIZE_ARB = 34886;
	public static final int GL_MATRIX_INDEX_ARRAY_TYPE_ARB = 34887;
	public static final int GL_MATRIX_INDEX_ARRAY_STRIDE_ARB = 34888;
	public static final int GL_MATRIX_INDEX_ARRAY_POINTER_ARB = 34889;
	public static final int GL_MIRRORED_REPEAT_ARB = 33648;
	public static final int GL_DEPTH_COMPONENT16_ARB = 33189;
	public static final int GL_DEPTH_COMPONENT24_ARB = 33190;
	public static final int GL_DEPTH_COMPONENT32_ARB = 33191;
	public static final int GL_TEXTURE_DEPTH_SIZE_ARB = 34890;
	public static final int GL_DEPTH_TEXTURE_MODE_ARB = 34891;
	public static final int GL_TEXTURE_COMPARE_MODE_ARB = 34892;
	public static final int GL_TEXTURE_COMPARE_FUNC_ARB = 34893;
	public static final int GL_COMPARE_R_TO_TEXTURE_ARB = 34894;
	public static final int GL_TEXTURE_COMPARE_FAIL_VALUE_ARB = 32959;
	public static final int GL_COLOR_SUM_ARB = 33880;
	public static final int GL_VERTEX_PROGRAM_ARB = 34336;
	public static final int GL_VERTEX_ATTRIB_ARRAY_ENABLED_ARB = 34338;
	public static final int GL_VERTEX_ATTRIB_ARRAY_SIZE_ARB = 34339;
	public static final int GL_VERTEX_ATTRIB_ARRAY_STRIDE_ARB = 34340;
	public static final int GL_VERTEX_ATTRIB_ARRAY_TYPE_ARB = 34341;
	public static final int GL_CURRENT_VERTEX_ATTRIB_ARB = 34342;
	public static final int GL_PROGRAM_LENGTH_ARB = 34343;
	public static final int GL_PROGRAM_STRING_ARB = 34344;
	public static final int GL_MAX_PROGRAM_MATRIX_STACK_DEPTH_ARB = 34350;
	public static final int GL_MAX_PROGRAM_MATRICES_ARB = 34351;
	public static final int GL_CURRENT_MATRIX_STACK_DEPTH_ARB = 34368;
	public static final int GL_CURRENT_MATRIX_ARB = 34369;
	public static final int GL_VERTEX_PROGRAM_POINT_SIZE_ARB = 34370;
	public static final int GL_VERTEX_PROGRAM_TWO_SIDE_ARB = 34371;
	public static final int GL_VERTEX_ATTRIB_ARRAY_POINTER_ARB = 34373;
	public static final int GL_PROGRAM_ERROR_POSITION_ARB = 34379;
	public static final int GL_PROGRAM_BINDING_ARB = 34423;
	public static final int GL_MAX_VERTEX_ATTRIBS_ARB = 34921;
	public static final int GL_VERTEX_ATTRIB_ARRAY_NORMALIZED_ARB = 34922;
	public static final int GL_PROGRAM_ERROR_STRING_ARB = 34932;
	public static final int GL_PROGRAM_FORMAT_ASCII_ARB = 34933;
	public static final int GL_PROGRAM_FORMAT_ARB = 34934;
	public static final int GL_PROGRAM_INSTRUCTIONS_ARB = 34976;
	public static final int GL_MAX_PROGRAM_INSTRUCTIONS_ARB = 34977;
	public static final int GL_PROGRAM_NATIVE_INSTRUCTIONS_ARB = 34978;
	public static final int GL_MAX_PROGRAM_NATIVE_INSTRUCTIONS_ARB = 34979;
	public static final int GL_PROGRAM_TEMPORARIES_ARB = 34980;
	public static final int GL_MAX_PROGRAM_TEMPORARIES_ARB = 34981;
	public static final int GL_PROGRAM_NATIVE_TEMPORARIES_ARB = 34982;
	public static final int GL_MAX_PROGRAM_NATIVE_TEMPORARIES_ARB = 34983;
	public static final int GL_PROGRAM_PARAMETERS_ARB = 34984;
	public static final int GL_MAX_PROGRAM_PARAMETERS_ARB = 34985;
	public static final int GL_PROGRAM_NATIVE_PARAMETERS_ARB = 34986;
	public static final int GL_MAX_PROGRAM_NATIVE_PARAMETERS_ARB = 34987;
	public static final int GL_PROGRAM_ATTRIBS_ARB = 34988;
	public static final int GL_MAX_PROGRAM_ATTRIBS_ARB = 34989;
	public static final int GL_PROGRAM_NATIVE_ATTRIBS_ARB = 34990;
	public static final int GL_MAX_PROGRAM_NATIVE_ATTRIBS_ARB = 34991;
	public static final int GL_PROGRAM_ADDRESS_REGISTERS_ARB = 34992;
	public static final int GL_MAX_PROGRAM_ADDRESS_REGISTERS_ARB = 34993;
	public static final int GL_PROGRAM_NATIVE_ADDRESS_REGISTERS_ARB = 34994;
	public static final int GL_MAX_PROGRAM_NATIVE_ADDRESS_REGISTERS_ARB = 34995;
	public static final int GL_MAX_PROGRAM_LOCAL_PARAMETERS_ARB = 34996;
	public static final int GL_MAX_PROGRAM_ENV_PARAMETERS_ARB = 34997;
	public static final int GL_PROGRAM_UNDER_NATIVE_LIMITS_ARB = 34998;
	public static final int GL_TRANSPOSE_CURRENT_MATRIX_ARB = 34999;
	public static final int GL_MATRIX0_ARB = 35008;
	public static final int GL_MATRIX1_ARB = 35009;
	public static final int GL_MATRIX2_ARB = 35010;
	public static final int GL_MATRIX3_ARB = 35011;
	public static final int GL_MATRIX4_ARB = 35012;
	public static final int GL_MATRIX5_ARB = 35013;
	public static final int GL_MATRIX6_ARB = 35014;
	public static final int GL_MATRIX7_ARB = 35015;
	public static final int GL_MATRIX8_ARB = 35016;
	public static final int GL_MATRIX9_ARB = 35017;
	public static final int GL_MATRIX10_ARB = 35018;
	public static final int GL_MATRIX11_ARB = 35019;
	public static final int GL_MATRIX12_ARB = 35020;
	public static final int GL_MATRIX13_ARB = 35021;
	public static final int GL_MATRIX14_ARB = 35022;
	public static final int GL_MATRIX15_ARB = 35023;
	public static final int GL_MATRIX16_ARB = 35024;
	public static final int GL_MATRIX17_ARB = 35025;
	public static final int GL_MATRIX18_ARB = 35026;
	public static final int GL_MATRIX19_ARB = 35027;
	public static final int GL_MATRIX20_ARB = 35028;
	public static final int GL_MATRIX21_ARB = 35029;
	public static final int GL_MATRIX22_ARB = 35030;
	public static final int GL_MATRIX23_ARB = 35031;
	public static final int GL_MATRIX24_ARB = 35032;
	public static final int GL_MATRIX25_ARB = 35033;
	public static final int GL_MATRIX26_ARB = 35034;
	public static final int GL_MATRIX27_ARB = 35035;
	public static final int GL_MATRIX28_ARB = 35036;
	public static final int GL_MATRIX29_ARB = 35037;
	public static final int GL_MATRIX30_ARB = 35038;
	public static final int GL_MATRIX31_ARB = 35039;
	public static final int GL_FRAGMENT_PROGRAM_ARB = 34820;
	public static final int GL_PROGRAM_ALU_INSTRUCTIONS_ARB = 34821;
	public static final int GL_PROGRAM_TEX_INSTRUCTIONS_ARB = 34822;
	public static final int GL_PROGRAM_TEX_INDIRECTIONS_ARB = 34823;
	public static final int GL_PROGRAM_NATIVE_ALU_INSTRUCTIONS_ARB = 34824;
	public static final int GL_PROGRAM_NATIVE_TEX_INSTRUCTIONS_ARB = 34825;
	public static final int GL_PROGRAM_NATIVE_TEX_INDIRECTIONS_ARB = 34826;
	public static final int GL_MAX_PROGRAM_ALU_INSTRUCTIONS_ARB = 34827;
	public static final int GL_MAX_PROGRAM_TEX_INSTRUCTIONS_ARB = 34828;
	public static final int GL_MAX_PROGRAM_TEX_INDIRECTIONS_ARB = 34829;
	public static final int GL_MAX_PROGRAM_NATIVE_ALU_INSTRUCTIONS_ARB = 34830;
	public static final int GL_MAX_PROGRAM_NATIVE_TEX_INSTRUCTIONS_ARB = 34831;
	public static final int GL_MAX_PROGRAM_NATIVE_TEX_INDIRECTIONS_ARB = 34832;
	public static final int GL_MAX_TEXTURE_COORDS_ARB = 34929;
	public static final int GL_MAX_TEXTURE_IMAGE_UNITS_ARB = 34930;
	public static final int GL_BUFFER_SIZE_ARB = 34660;
	public static final int GL_BUFFER_USAGE_ARB = 34661;
	public static final int GL_ARRAY_BUFFER_ARB = 34962;
	public static final int GL_ELEMENT_ARRAY_BUFFER_ARB = 34963;
	public static final int GL_ARRAY_BUFFER_BINDING_ARB = 34964;
	public static final int GL_ELEMENT_ARRAY_BUFFER_BINDING_ARB = 34965;
	public static final int GL_VERTEX_ARRAY_BUFFER_BINDING_ARB = 34966;
	public static final int GL_NORMAL_ARRAY_BUFFER_BINDING_ARB = 34967;
	public static final int GL_COLOR_ARRAY_BUFFER_BINDING_ARB = 34968;
	public static final int GL_INDEX_ARRAY_BUFFER_BINDING_ARB = 34969;
	public static final int GL_TEXTURE_COORD_ARRAY_BUFFER_BINDING_ARB = 34970;
	public static final int GL_EDGE_FLAG_ARRAY_BUFFER_BINDING_ARB = 34971;
	public static final int GL_SECONDARY_COLOR_ARRAY_BUFFER_BINDING_ARB = 34972;
	public static final int GL_FOG_COORDINATE_ARRAY_BUFFER_BINDING_ARB = 34973;
	public static final int GL_WEIGHT_ARRAY_BUFFER_BINDING_ARB = 34974;
	public static final int GL_VERTEX_ATTRIB_ARRAY_BUFFER_BINDING_ARB = 34975;
	public static final int GL_READ_ONLY_ARB = 35000;
	public static final int GL_WRITE_ONLY_ARB = 35001;
	public static final int GL_READ_WRITE_ARB = 35002;
	public static final int GL_BUFFER_ACCESS_ARB = 35003;
	public static final int GL_BUFFER_MAPPED_ARB = 35004;
	public static final int GL_BUFFER_MAP_POINTER_ARB = 35005;
	public static final int GL_STREAM_DRAW_ARB = 35040;
	public static final int GL_STREAM_READ_ARB = 35041;
	public static final int GL_STREAM_COPY_ARB = 35042;
	public static final int GL_STATIC_DRAW_ARB = 35044;
	public static final int GL_STATIC_READ_ARB = 35045;
	public static final int GL_STATIC_COPY_ARB = 35046;
	public static final int GL_DYNAMIC_DRAW_ARB = 35048;
	public static final int GL_DYNAMIC_READ_ARB = 35049;
	public static final int GL_DYNAMIC_COPY_ARB = 35050;
	public static final int GL_QUERY_COUNTER_BITS_ARB = 34916;
	public static final int GL_CURRENT_QUERY_ARB = 34917;
	public static final int GL_QUERY_RESULT_ARB = 34918;
	public static final int GL_QUERY_RESULT_AVAILABLE_ARB = 34919;
	public static final int GL_SAMPLES_PASSED_ARB = 35092;
	public static final int GL_PROGRAM_OBJECT_ARB = 35648;
	public static final int GL_SHADER_OBJECT_ARB = 35656;
	public static final int GL_OBJECT_TYPE_ARB = 35662;
	public static final int GL_OBJECT_SUBTYPE_ARB = 35663;
	public static final int GL_FLOAT_VEC2_ARB = 35664;
	public static final int GL_FLOAT_VEC3_ARB = 35665;
	public static final int GL_FLOAT_VEC4_ARB = 35666;
	public static final int GL_INT_VEC2_ARB = 35667;
	public static final int GL_INT_VEC3_ARB = 35668;
	public static final int GL_INT_VEC4_ARB = 35669;
	public static final int GL_BOOL_ARB = 35670;
	public static final int GL_BOOL_VEC2_ARB = 35671;
	public static final int GL_BOOL_VEC3_ARB = 35672;
	public static final int GL_BOOL_VEC4_ARB = 35673;
	public static final int GL_FLOAT_MAT2_ARB = 35674;
	public static final int GL_FLOAT_MAT3_ARB = 35675;
	public static final int GL_FLOAT_MAT4_ARB = 35676;
	public static final int GL_SAMPLER_1D_ARB = 35677;
	public static final int GL_SAMPLER_2D_ARB = 35678;
	public static final int GL_SAMPLER_3D_ARB = 35679;
	public static final int GL_SAMPLER_CUBE_ARB = 35680;
	public static final int GL_SAMPLER_1D_SHADOW_ARB = 35681;
	public static final int GL_SAMPLER_2D_SHADOW_ARB = 35682;
	public static final int GL_SAMPLER_2D_RECT_ARB = 35683;
	public static final int GL_SAMPLER_2D_RECT_SHADOW_ARB = 35684;
	public static final int GL_OBJECT_DELETE_STATUS_ARB = 35712;
	public static final int GL_OBJECT_COMPILE_STATUS_ARB = 35713;
	public static final int GL_OBJECT_LINK_STATUS_ARB = 35714;
	public static final int GL_OBJECT_VALIDATE_STATUS_ARB = 35715;
	public static final int GL_OBJECT_INFO_LOG_LENGTH_ARB = 35716;
	public static final int GL_OBJECT_ATTACHED_OBJECTS_ARB = 35717;
	public static final int GL_OBJECT_ACTIVE_UNIFORMS_ARB = 35718;
	public static final int GL_OBJECT_ACTIVE_UNIFORM_MAX_LENGTH_ARB = 35719;
	public static final int GL_OBJECT_SHADER_SOURCE_LENGTH_ARB = 35720;
	public static final int GL_VERTEX_SHADER_ARB = 35633;
	public static final int GL_MAX_VERTEX_UNIFORM_COMPONENTS_ARB = 35658;
	public static final int GL_MAX_VARYING_FLOATS_ARB = 35659;
	public static final int GL_MAX_VERTEX_TEXTURE_IMAGE_UNITS_ARB = 35660;
	public static final int GL_MAX_COMBINED_TEXTURE_IMAGE_UNITS_ARB = 35661;
	public static final int GL_OBJECT_ACTIVE_ATTRIBUTES_ARB = 35721;
	public static final int GL_OBJECT_ACTIVE_ATTRIBUTE_MAX_LENGTH_ARB = 35722;
	public static final int GL_FRAGMENT_SHADER_ARB = 35632;
	public static final int GL_MAX_FRAGMENT_UNIFORM_COMPONENTS_ARB = 35657;
	public static final int GL_FRAGMENT_SHADER_DERIVATIVE_HINT_ARB = 35723;
	public static final int GL_SHADING_LANGUAGE_VERSION_ARB = 35724;
	public static final int GL_POINT_SPRITE_ARB = 34913;
	public static final int GL_COORD_REPLACE_ARB = 34914;
	public static final int GL_MAX_DRAW_BUFFERS_ARB = 34852;
	public static final int GL_DRAW_BUFFER0_ARB = 34853;
	public static final int GL_DRAW_BUFFER1_ARB = 34854;
	public static final int GL_DRAW_BUFFER2_ARB = 34855;
	public static final int GL_DRAW_BUFFER3_ARB = 34856;
	public static final int GL_DRAW_BUFFER4_ARB = 34857;
	public static final int GL_DRAW_BUFFER5_ARB = 34858;
	public static final int GL_DRAW_BUFFER6_ARB = 34859;
	public static final int GL_DRAW_BUFFER7_ARB = 34860;
	public static final int GL_DRAW_BUFFER8_ARB = 34861;
	public static final int GL_DRAW_BUFFER9_ARB = 34862;
	public static final int GL_DRAW_BUFFER10_ARB = 34863;
	public static final int GL_DRAW_BUFFER11_ARB = 34864;
	public static final int GL_DRAW_BUFFER12_ARB = 34865;
	public static final int GL_DRAW_BUFFER13_ARB = 34866;
	public static final int GL_DRAW_BUFFER14_ARB = 34867;
	public static final int GL_DRAW_BUFFER15_ARB = 34868;
	public static final int GL_TEXTURE_RECTANGLE_ARB = 34037;
	public static final int GL_TEXTURE_BINDING_RECTANGLE_ARB = 34038;
	public static final int GL_PROXY_TEXTURE_RECTANGLE_ARB = 34039;
	public static final int GL_MAX_RECTANGLE_TEXTURE_SIZE_ARB = 34040;
	public static final int GL_RGBA_FLOAT_MODE_ARB = 34848;
	public static final int GL_CLAMP_VERTEX_COLOR_ARB = 35098;
	public static final int GL_CLAMP_FRAGMENT_COLOR_ARB = 35099;
	public static final int GL_CLAMP_READ_COLOR_ARB = 35100;
	public static final int GL_FIXED_ONLY_ARB = 35101;
	public static final int GL_HALF_FLOAT_ARB = 5131;
	public static final int GL_TEXTURE_RED_TYPE_ARB = 35856;
	public static final int GL_TEXTURE_GREEN_TYPE_ARB = 35857;
	public static final int GL_TEXTURE_BLUE_TYPE_ARB = 35858;
	public static final int GL_TEXTURE_ALPHA_TYPE_ARB = 35859;
	public static final int GL_TEXTURE_LUMINANCE_TYPE_ARB = 35860;
	public static final int GL_TEXTURE_INTENSITY_TYPE_ARB = 35861;
	public static final int GL_TEXTURE_DEPTH_TYPE_ARB = 35862;
	public static final int GL_UNSIGNED_NORMALIZED_ARB = 35863;
	public static final int GL_RGBA32F_ARB = 34836;
	public static final int GL_RGB32F_ARB = 34837;
	public static final int GL_ALPHA32F_ARB = 34838;
	public static final int GL_INTENSITY32F_ARB = 34839;
	public static final int GL_LUMINANCE32F_ARB = 34840;
	public static final int GL_LUMINANCE_ALPHA32F_ARB = 34841;
	public static final int GL_RGBA16F_ARB = 34842;
	public static final int GL_RGB16F_ARB = 34843;
	public static final int GL_ALPHA16F_ARB = 34844;
	public static final int GL_INTENSITY16F_ARB = 34845;
	public static final int GL_LUMINANCE16F_ARB = 34846;
	public static final int GL_LUMINANCE_ALPHA16F_ARB = 34847;
	public static final int GL_PIXEL_PACK_BUFFER_ARB = 35051;
	public static final int GL_PIXEL_UNPACK_BUFFER_ARB = 35052;
	public static final int GL_PIXEL_PACK_BUFFER_BINDING_ARB = 35053;
	public static final int GL_PIXEL_UNPACK_BUFFER_BINDING_ARB = 35055;
	public static final int GL_ABGR_EXT = 32768;
	public static final int GL_FILTER4_SGIS = 33094;
	public static final int GL_TEXTURE_FILTER4_SIZE_SGIS = 33095;
	public static final int GL_PIXEL_TEXTURE_SGIS = 33619;
	public static final int GL_PIXEL_FRAGMENT_RGB_SOURCE_SGIS = 33620;
	public static final int GL_PIXEL_FRAGMENT_ALPHA_SOURCE_SGIS = 33621;
	public static final int GL_PIXEL_GROUP_COLOR_SGIS = 33622;
	public static final int GL_PIXEL_TEX_GEN_SGIX = 33081;
	public static final int GL_PIXEL_TEX_GEN_MODE_SGIX = 33579;
	public static final int GL_PACK_SKIP_VOLUMES_SGIS = 33072;
	public static final int GL_PACK_IMAGE_DEPTH_SGIS = 33073;
	public static final int GL_UNPACK_SKIP_VOLUMES_SGIS = 33074;
	public static final int GL_UNPACK_IMAGE_DEPTH_SGIS = 33075;
	public static final int GL_TEXTURE_4D_SGIS = 33076;
	public static final int GL_PROXY_TEXTURE_4D_SGIS = 33077;
	public static final int GL_TEXTURE_4DSIZE_SGIS = 33078;
	public static final int GL_TEXTURE_WRAP_Q_SGIS = 33079;
	public static final int GL_MAX_4D_TEXTURE_SIZE_SGIS = 33080;
	public static final int GL_TEXTURE_4D_BINDING_SGIS = 33103;
	public static final int GL_TEXTURE_COLOR_TABLE_SGI = 32956;
	public static final int GL_PROXY_TEXTURE_COLOR_TABLE_SGI = 32957;
	public static final int GL_CMYK_EXT = 32780;
	public static final int GL_CMYKA_EXT = 32781;
	public static final int GL_PACK_CMYK_HINT_EXT = 32782;
	public static final int GL_UNPACK_CMYK_HINT_EXT = 32783;
	public static final int GL_DETAIL_TEXTURE_2D_SGIS = 32917;
	public static final int GL_DETAIL_TEXTURE_2D_BINDING_SGIS = 32918;
	public static final int GL_LINEAR_DETAIL_SGIS = 32919;
	public static final int GL_LINEAR_DETAIL_ALPHA_SGIS = 32920;
	public static final int GL_LINEAR_DETAIL_COLOR_SGIS = 32921;
	public static final int GL_DETAIL_TEXTURE_LEVEL_SGIS = 32922;
	public static final int GL_DETAIL_TEXTURE_MODE_SGIS = 32923;
	public static final int GL_DETAIL_TEXTURE_FUNC_POINTS_SGIS = 32924;
	public static final int GL_LINEAR_SHARPEN_SGIS = 32941;
	public static final int GL_LINEAR_SHARPEN_ALPHA_SGIS = 32942;
	public static final int GL_LINEAR_SHARPEN_COLOR_SGIS = 32943;
	public static final int GL_SHARPEN_TEXTURE_FUNC_POINTS_SGIS = 32944;
	public static final int GL_MULTISAMPLE_SGIS = 32925;
	public static final int GL_SAMPLE_ALPHA_TO_MASK_SGIS = 32926;
	public static final int GL_SAMPLE_ALPHA_TO_ONE_SGIS = 32927;
	public static final int GL_SAMPLE_MASK_SGIS = 32928;
	public static final int GL_1PASS_SGIS = 32929;
	public static final int GL_2PASS_0_SGIS = 32930;
	public static final int GL_2PASS_1_SGIS = 32931;
	public static final int GL_4PASS_0_SGIS = 32932;
	public static final int GL_4PASS_1_SGIS = 32933;
	public static final int GL_4PASS_2_SGIS = 32934;
	public static final int GL_4PASS_3_SGIS = 32935;
	public static final int GL_SAMPLE_BUFFERS_SGIS = 32936;
	public static final int GL_SAMPLES_SGIS = 32937;
	public static final int GL_SAMPLE_MASK_VALUE_SGIS = 32938;
	public static final int GL_SAMPLE_MASK_INVERT_SGIS = 32939;
	public static final int GL_SAMPLE_PATTERN_SGIS = 32940;
	public static final int GL_GENERATE_MIPMAP_SGIS = 33169;
	public static final int GL_GENERATE_MIPMAP_HINT_SGIS = 33170;
	public static final int GL_LINEAR_CLIPMAP_LINEAR_SGIX = 33136;
	public static final int GL_TEXTURE_CLIPMAP_CENTER_SGIX = 33137;
	public static final int GL_TEXTURE_CLIPMAP_FRAME_SGIX = 33138;
	public static final int GL_TEXTURE_CLIPMAP_OFFSET_SGIX = 33139;
	public static final int GL_TEXTURE_CLIPMAP_VIRTUAL_DEPTH_SGIX = 33140;
	public static final int GL_TEXTURE_CLIPMAP_LOD_OFFSET_SGIX = 33141;
	public static final int GL_TEXTURE_CLIPMAP_DEPTH_SGIX = 33142;
	public static final int GL_MAX_CLIPMAP_DEPTH_SGIX = 33143;
	public static final int GL_MAX_CLIPMAP_VIRTUAL_DEPTH_SGIX = 33144;
	public static final int GL_NEAREST_CLIPMAP_NEAREST_SGIX = 33869;
	public static final int GL_NEAREST_CLIPMAP_LINEAR_SGIX = 33870;
	public static final int GL_LINEAR_CLIPMAP_NEAREST_SGIX = 33871;
	public static final int GL_TEXTURE_COMPARE_SGIX = 33178;
	public static final int GL_TEXTURE_COMPARE_OPERATOR_SGIX = 33179;
	public static final int GL_TEXTURE_LEQUAL_R_SGIX = 33180;
	public static final int GL_TEXTURE_GEQUAL_R_SGIX = 33181;
	public static final int GL_INTERLACE_SGIX = 32916;
	public static final int GL_PIXEL_TILE_BEST_ALIGNMENT_SGIX = 33086;
	public static final int GL_PIXEL_TILE_CACHE_INCREMENT_SGIX = 33087;
	public static final int GL_PIXEL_TILE_WIDTH_SGIX = 33088;
	public static final int GL_PIXEL_TILE_HEIGHT_SGIX = 33089;
	public static final int GL_PIXEL_TILE_GRID_WIDTH_SGIX = 33090;
	public static final int GL_PIXEL_TILE_GRID_HEIGHT_SGIX = 33091;
	public static final int GL_PIXEL_TILE_GRID_DEPTH_SGIX = 33092;
	public static final int GL_PIXEL_TILE_CACHE_SIZE_SGIX = 33093;
	public static final int GL_DUAL_ALPHA4_SGIS = 33040;
	public static final int GL_DUAL_ALPHA8_SGIS = 33041;
	public static final int GL_DUAL_ALPHA12_SGIS = 33042;
	public static final int GL_DUAL_ALPHA16_SGIS = 33043;
	public static final int GL_DUAL_LUMINANCE4_SGIS = 33044;
	public static final int GL_DUAL_LUMINANCE8_SGIS = 33045;
	public static final int GL_DUAL_LUMINANCE12_SGIS = 33046;
	public static final int GL_DUAL_LUMINANCE16_SGIS = 33047;
	public static final int GL_DUAL_INTENSITY4_SGIS = 33048;
	public static final int GL_DUAL_INTENSITY8_SGIS = 33049;
	public static final int GL_DUAL_INTENSITY12_SGIS = 33050;
	public static final int GL_DUAL_INTENSITY16_SGIS = 33051;
	public static final int GL_DUAL_LUMINANCE_ALPHA4_SGIS = 33052;
	public static final int GL_DUAL_LUMINANCE_ALPHA8_SGIS = 33053;
	public static final int GL_QUAD_ALPHA4_SGIS = 33054;
	public static final int GL_QUAD_ALPHA8_SGIS = 33055;
	public static final int GL_QUAD_LUMINANCE4_SGIS = 33056;
	public static final int GL_QUAD_LUMINANCE8_SGIS = 33057;
	public static final int GL_QUAD_INTENSITY4_SGIS = 33058;
	public static final int GL_QUAD_INTENSITY8_SGIS = 33059;
	public static final int GL_DUAL_TEXTURE_SELECT_SGIS = 33060;
	public static final int GL_QUAD_TEXTURE_SELECT_SGIS = 33061;
	public static final int GL_SPRITE_SGIX = 33096;
	public static final int GL_SPRITE_MODE_SGIX = 33097;
	public static final int GL_SPRITE_AXIS_SGIX = 33098;
	public static final int GL_SPRITE_TRANSLATION_SGIX = 33099;
	public static final int GL_SPRITE_AXIAL_SGIX = 33100;
	public static final int GL_SPRITE_OBJECT_ALIGNED_SGIX = 33101;
	public static final int GL_SPRITE_EYE_ALIGNED_SGIX = 33102;
	public static final int GL_TEXTURE_MULTI_BUFFER_HINT_SGIX = 33070;
	public static final int GL_POINT_SIZE_MIN_EXT = 33062;
	public static final int GL_POINT_SIZE_MAX_EXT = 33063;
	public static final int GL_POINT_FADE_THRESHOLD_SIZE_EXT = 33064;
	public static final int GL_DISTANCE_ATTENUATION_EXT = 33065;
	public static final int GL_POINT_SIZE_MIN_SGIS = 33062;
	public static final int GL_POINT_SIZE_MAX_SGIS = 33063;
	public static final int GL_POINT_FADE_THRESHOLD_SIZE_SGIS = 33064;
	public static final int GL_DISTANCE_ATTENUATION_SGIS = 33065;
	public static final int GL_INSTRUMENT_BUFFER_POINTER_SGIX = 33152;
	public static final int GL_INSTRUMENT_MEASUREMENTS_SGIX = 33153;
	public static final int GL_POST_TEXTURE_FILTER_BIAS_SGIX = 33145;
	public static final int GL_POST_TEXTURE_FILTER_SCALE_SGIX = 33146;
	public static final int GL_POST_TEXTURE_FILTER_BIAS_RANGE_SGIX = 33147;
	public static final int GL_POST_TEXTURE_FILTER_SCALE_RANGE_SGIX = 33148;
	public static final int GL_FRAMEZOOM_SGIX = 33163;
	public static final int GL_FRAMEZOOM_FACTOR_SGIX = 33164;
	public static final int GL_MAX_FRAMEZOOM_FACTOR_SGIX = 33165;
	public static final int GL_TEXTURE_DEFORMATION_BIT_SGIX = 1;
	public static final int GL_GEOMETRY_DEFORMATION_BIT_SGIX = 2;
	public static final int GL_GEOMETRY_DEFORMATION_SGIX = 33172;
	public static final int GL_TEXTURE_DEFORMATION_SGIX = 33173;
	public static final int GL_DEFORMATIONS_MASK_SGIX = 33174;
	public static final int GL_MAX_DEFORMATION_ORDER_SGIX = 33175;
	public static final int GL_REFERENCE_PLANE_SGIX = 33149;
	public static final int GL_REFERENCE_PLANE_EQUATION_SGIX = 33150;
	public static final int GL_DEPTH_COMPONENT16_SGIX = 33189;
	public static final int GL_DEPTH_COMPONENT24_SGIX = 33190;
	public static final int GL_DEPTH_COMPONENT32_SGIX = 33191;
	public static final int GL_FOG_FUNC_SGIS = 33066;
	public static final int GL_FOG_FUNC_POINTS_SGIS = 33067;
	public static final int GL_MAX_FOG_FUNC_POINTS_SGIS = 33068;
	public static final int GL_FOG_OFFSET_SGIX = 33176;
	public static final int GL_FOG_OFFSET_VALUE_SGIX = 33177;
	public static final int GL_IMAGE_SCALE_X_HP = 33109;
	public static final int GL_IMAGE_SCALE_Y_HP = 33110;
	public static final int GL_IMAGE_TRANSLATE_X_HP = 33111;
	public static final int GL_IMAGE_TRANSLATE_Y_HP = 33112;
	public static final int GL_IMAGE_ROTATE_ANGLE_HP = 33113;
	public static final int GL_IMAGE_ROTATE_ORIGIN_X_HP = 33114;
	public static final int GL_IMAGE_ROTATE_ORIGIN_Y_HP = 33115;
	public static final int GL_IMAGE_MAG_FILTER_HP = 33116;
	public static final int GL_IMAGE_MIN_FILTER_HP = 33117;
	public static final int GL_IMAGE_CUBIC_WEIGHT_HP = 33118;
	public static final int GL_CUBIC_HP = 33119;
	public static final int GL_AVERAGE_HP = 33120;
	public static final int GL_IMAGE_TRANSFORM_2D_HP = 33121;
	public static final int GL_POST_IMAGE_TRANSFORM_COLOR_TABLE_HP = 33122;
	public static final int GL_PROXY_POST_IMAGE_TRANSFORM_COLOR_TABLE_HP = 33123;
	public static final int GL_TEXTURE_ENV_BIAS_SGIX = 32958;
	public static final int GL_VERTEX_DATA_HINT_PGI = 107050;
	public static final int GL_VERTEX_CONSISTENT_HINT_PGI = 107051;
	public static final int GL_MATERIAL_SIDE_HINT_PGI = 107052;
	public static final int GL_MAX_VERTEX_HINT_PGI = 107053;
	public static final int GL_COLOR3_BIT_PGI = 65536;
	public static final int GL_COLOR4_BIT_PGI = 131072;
	public static final int GL_EDGEFLAG_BIT_PGI = 262144;
	public static final int GL_INDEX_BIT_PGI = 524288;
	public static final int GL_MAT_AMBIENT_BIT_PGI = 1048576;
	public static final int GL_MAT_AMBIENT_AND_DIFFUSE_BIT_PGI = 2097152;
	public static final int GL_MAT_DIFFUSE_BIT_PGI = 4194304;
	public static final int GL_MAT_EMISSION_BIT_PGI = 8388608;
	public static final int GL_MAT_COLOR_INDEXES_BIT_PGI = 16777216;
	public static final int GL_MAT_SHININESS_BIT_PGI = 33554432;
	public static final int GL_MAT_SPECULAR_BIT_PGI = 67108864;
	public static final int GL_NORMAL_BIT_PGI = 134217728;
	public static final int GL_TEXCOORD1_BIT_PGI = 268435456;
	public static final int GL_TEXCOORD2_BIT_PGI = 536870912;
	public static final int GL_TEXCOORD3_BIT_PGI = 1073741824;
	public static final long GL_TEXCOORD4_BIT_PGI = -2147483648L;
	public static final int GL_VERTEX23_BIT_PGI = 4;
	public static final int GL_VERTEX4_BIT_PGI = 8;
	public static final int GL_PREFER_DOUBLEBUFFER_HINT_PGI = 107000;
	public static final int GL_CONSERVE_MEMORY_HINT_PGI = 107005;
	public static final int GL_RECLAIM_MEMORY_HINT_PGI = 107006;
	public static final int GL_NATIVE_GRAPHICS_HANDLE_PGI = 107010;
	public static final int GL_NATIVE_GRAPHICS_BEGIN_HINT_PGI = 107011;
	public static final int GL_NATIVE_GRAPHICS_END_HINT_PGI = 107012;
	public static final int GL_ALWAYS_FAST_HINT_PGI = 107020;
	public static final int GL_ALWAYS_SOFT_HINT_PGI = 107021;
	public static final int GL_ALLOW_DRAW_OBJ_HINT_PGI = 107022;
	public static final int GL_ALLOW_DRAW_WIN_HINT_PGI = 107023;
	public static final int GL_ALLOW_DRAW_FRG_HINT_PGI = 107024;
	public static final int GL_ALLOW_DRAW_MEM_HINT_PGI = 107025;
	public static final int GL_STRICT_DEPTHFUNC_HINT_PGI = 107030;
	public static final int GL_STRICT_LIGHTING_HINT_PGI = 107031;
	public static final int GL_STRICT_SCISSOR_HINT_PGI = 107032;
	public static final int GL_FULL_STIPPLE_HINT_PGI = 107033;
	public static final int GL_CLIP_NEAR_HINT_PGI = 107040;
	public static final int GL_CLIP_FAR_HINT_PGI = 107041;
	public static final int GL_WIDE_LINE_HINT_PGI = 107042;
	public static final int GL_BACK_NORMALS_HINT_PGI = 107043;
	public static final int GL_COLOR_INDEX1_EXT = 32994;
	public static final int GL_COLOR_INDEX2_EXT = 32995;
	public static final int GL_COLOR_INDEX4_EXT = 32996;
	public static final int GL_COLOR_INDEX8_EXT = 32997;
	public static final int GL_COLOR_INDEX12_EXT = 32998;
	public static final int GL_COLOR_INDEX16_EXT = 32999;
	public static final int GL_TEXTURE_INDEX_SIZE_EXT = 33005;
	public static final int GL_CLIP_VOLUME_CLIPPING_HINT_EXT = 33008;
	public static final int GL_LIST_PRIORITY_SGIX = 33154;
	public static final int GL_IR_INSTRUMENT1_SGIX = 33151;
	public static final int GL_CALLIGRAPHIC_FRAGMENT_SGIX = 33155;
	public static final int GL_TEXTURE_LOD_BIAS_S_SGIX = 33166;
	public static final int GL_TEXTURE_LOD_BIAS_T_SGIX = 33167;
	public static final int GL_TEXTURE_LOD_BIAS_R_SGIX = 33168;
	public static final int GL_SHADOW_AMBIENT_SGIX = 32959;
	public static final int GL_INDEX_MATERIAL_EXT = 33208;
	public static final int GL_INDEX_MATERIAL_PARAMETER_EXT = 33209;
	public static final int GL_INDEX_MATERIAL_FACE_EXT = 33210;
	public static final int GL_INDEX_TEST_EXT = 33205;
	public static final int GL_INDEX_TEST_FUNC_EXT = 33206;
	public static final int GL_INDEX_TEST_REF_EXT = 33207;
	public static final int GL_IUI_V2F_EXT = 33197;
	public static final int GL_IUI_V3F_EXT = 33198;
	public static final int GL_IUI_N3F_V2F_EXT = 33199;
	public static final int GL_IUI_N3F_V3F_EXT = 33200;
	public static final int GL_T2F_IUI_V2F_EXT = 33201;
	public static final int GL_T2F_IUI_V3F_EXT = 33202;
	public static final int GL_T2F_IUI_N3F_V2F_EXT = 33203;
	public static final int GL_T2F_IUI_N3F_V3F_EXT = 33204;
	public static final int GL_ARRAY_ELEMENT_LOCK_FIRST_EXT = 33192;
	public static final int GL_ARRAY_ELEMENT_LOCK_COUNT_EXT = 33193;
	public static final int GL_CULL_VERTEX_EXT = 33194;
	public static final int GL_CULL_VERTEX_EYE_POSITION_EXT = 33195;
	public static final int GL_CULL_VERTEX_OBJECT_POSITION_EXT = 33196;
	public static final int GL_YCRCB_422_SGIX = 33211;
	public static final int GL_YCRCB_444_SGIX = 33212;
	public static final int GL_FRAGMENT_LIGHTING_SGIX = 33792;
	public static final int GL_FRAGMENT_COLOR_MATERIAL_SGIX = 33793;
	public static final int GL_FRAGMENT_COLOR_MATERIAL_FACE_SGIX = 33794;
	public static final int GL_FRAGMENT_COLOR_MATERIAL_PARAMETER_SGIX = 33795;
	public static final int GL_MAX_FRAGMENT_LIGHTS_SGIX = 33796;
	public static final int GL_MAX_ACTIVE_LIGHTS_SGIX = 33797;
	public static final int GL_CURRENT_RASTER_NORMAL_SGIX = 33798;
	public static final int GL_LIGHT_ENV_MODE_SGIX = 33799;
	public static final int GL_FRAGMENT_LIGHT_MODEL_LOCAL_VIEWER_SGIX = 33800;
	public static final int GL_FRAGMENT_LIGHT_MODEL_TWO_SIDE_SGIX = 33801;
	public static final int GL_FRAGMENT_LIGHT_MODEL_AMBIENT_SGIX = 33802;
	public static final int GL_FRAGMENT_LIGHT_MODEL_NORMAL_INTERPOLATION_SGIX = 33803;
	public static final int GL_FRAGMENT_LIGHT0_SGIX = 33804;
	public static final int GL_FRAGMENT_LIGHT1_SGIX = 33805;
	public static final int GL_FRAGMENT_LIGHT2_SGIX = 33806;
	public static final int GL_FRAGMENT_LIGHT3_SGIX = 33807;
	public static final int GL_FRAGMENT_LIGHT4_SGIX = 33808;
	public static final int GL_FRAGMENT_LIGHT5_SGIX = 33809;
	public static final int GL_FRAGMENT_LIGHT6_SGIX = 33810;
	public static final int GL_FRAGMENT_LIGHT7_SGIX = 33811;
	public static final int GL_RASTER_POSITION_UNCLIPPED_IBM = 103010;
	public static final int GL_TEXTURE_LIGHTING_MODE_HP = 33127;
	public static final int GL_TEXTURE_POST_SPECULAR_HP = 33128;
	public static final int GL_TEXTURE_PRE_SPECULAR_HP = 33129;
	public static final int GL_PHONG_WIN = 33002;
	public static final int GL_PHONG_HINT_WIN = 33003;
	public static final int GL_FOG_SPECULAR_TEXTURE_WIN = 33004;
	public static final int GL_FRAGMENT_MATERIAL_EXT = 33609;
	public static final int GL_FRAGMENT_NORMAL_EXT = 33610;
	public static final int GL_FRAGMENT_COLOR_EXT = 33612;
	public static final int GL_ATTENUATION_EXT = 33613;
	public static final int GL_SHADOW_ATTENUATION_EXT = 33614;
	public static final int GL_TEXTURE_APPLICATION_MODE_EXT = 33615;
	public static final int GL_TEXTURE_LIGHT_EXT = 33616;
	public static final int GL_TEXTURE_MATERIAL_FACE_EXT = 33617;
	public static final int GL_TEXTURE_MATERIAL_PARAMETER_EXT = 33618;
	public static final int GL_ALPHA_MIN_SGIX = 33568;
	public static final int GL_ALPHA_MAX_SGIX = 33569;
	public static final int GL_PIXEL_TEX_GEN_Q_CEILING_SGIX = 33156;
	public static final int GL_PIXEL_TEX_GEN_Q_ROUND_SGIX = 33157;
	public static final int GL_PIXEL_TEX_GEN_Q_FLOOR_SGIX = 33158;
	public static final int GL_PIXEL_TEX_GEN_ALPHA_REPLACE_SGIX = 33159;
	public static final int GL_PIXEL_TEX_GEN_ALPHA_NO_REPLACE_SGIX = 33160;
	public static final int GL_PIXEL_TEX_GEN_ALPHA_LS_SGIX = 33161;
	public static final int GL_PIXEL_TEX_GEN_ALPHA_MS_SGIX = 33162;
	public static final int GL_ASYNC_MARKER_SGIX = 33577;
	public static final int GL_ASYNC_TEX_IMAGE_SGIX = 33628;
	public static final int GL_ASYNC_DRAW_PIXELS_SGIX = 33629;
	public static final int GL_ASYNC_READ_PIXELS_SGIX = 33630;
	public static final int GL_MAX_ASYNC_TEX_IMAGE_SGIX = 33631;
	public static final int GL_MAX_ASYNC_DRAW_PIXELS_SGIX = 33632;
	public static final int GL_MAX_ASYNC_READ_PIXELS_SGIX = 33633;
	public static final int GL_ASYNC_HISTOGRAM_SGIX = 33580;
	public static final int GL_MAX_ASYNC_HISTOGRAM_SGIX = 33581;
	public static final int GL_OCCLUSION_TEST_HP = 33125;
	public static final int GL_OCCLUSION_TEST_RESULT_HP = 33126;
	public static final int GL_PIXEL_TRANSFORM_2D_EXT = 33584;
	public static final int GL_PIXEL_MAG_FILTER_EXT = 33585;
	public static final int GL_PIXEL_MIN_FILTER_EXT = 33586;
	public static final int GL_PIXEL_CUBIC_WEIGHT_EXT = 33587;
	public static final int GL_CUBIC_EXT = 33588;
	public static final int GL_AVERAGE_EXT = 33589;
	public static final int GL_PIXEL_TRANSFORM_2D_STACK_DEPTH_EXT = 33590;
	public static final int GL_MAX_PIXEL_TRANSFORM_2D_STACK_DEPTH_EXT = 33591;
	public static final int GL_PIXEL_TRANSFORM_2D_MATRIX_EXT = 33592;
	public static final int GL_SHARED_TEXTURE_PALETTE_EXT = 33275;
	public static final int GL_COLOR_SUM_EXT = 33880;
	public static final int GL_CURRENT_SECONDARY_COLOR_EXT = 33881;
	public static final int GL_SECONDARY_COLOR_ARRAY_SIZE_EXT = 33882;
	public static final int GL_SECONDARY_COLOR_ARRAY_TYPE_EXT = 33883;
	public static final int GL_SECONDARY_COLOR_ARRAY_STRIDE_EXT = 33884;
	public static final int GL_SECONDARY_COLOR_ARRAY_POINTER_EXT = 33885;
	public static final int GL_SECONDARY_COLOR_ARRAY_EXT = 33886;
	public static final int GL_PERTURB_EXT = 34222;
	public static final int GL_TEXTURE_NORMAL_EXT = 34223;
	public static final int GL_FOG_COORDINATE_SOURCE_EXT = 33872;
	public static final int GL_FOG_COORDINATE_EXT = 33873;
	public static final int GL_FRAGMENT_DEPTH_EXT = 33874;
	public static final int GL_CURRENT_FOG_COORDINATE_EXT = 33875;
	public static final int GL_FOG_COORDINATE_ARRAY_TYPE_EXT = 33876;
	public static final int GL_FOG_COORDINATE_ARRAY_STRIDE_EXT = 33877;
	public static final int GL_FOG_COORDINATE_ARRAY_POINTER_EXT = 33878;
	public static final int GL_FOG_COORDINATE_ARRAY_EXT = 33879;
	public static final int GL_SCREEN_COORDINATES_REND = 33936;
	public static final int GL_INVERTED_SCREEN_W_REND = 33937;
	public static final int GL_LIGHT_MODEL_SPECULAR_VECTOR_APPLE = 34224;
	public static final int GL_TRANSFORM_HINT_APPLE = 34225;
	public static final int GL_FOG_SCALE_SGIX = 33276;
	public static final int GL_FOG_SCALE_VALUE_SGIX = 33277;
	public static final int GL_UNPACK_CONSTANT_DATA_SUNX = 33237;
	public static final int GL_TEXTURE_CONSTANT_DATA_SUNX = 33238;
	public static final int GL_GLOBAL_ALPHA_SUN = 33241;
	public static final int GL_GLOBAL_ALPHA_FACTOR_SUN = 33242;
	public static final int GL_BLEND_DST_RGB_EXT = 32968;
	public static final int GL_BLEND_SRC_RGB_EXT = 32969;
	public static final int GL_BLEND_DST_ALPHA_EXT = 32970;
	public static final int GL_BLEND_SRC_ALPHA_EXT = 32971;
	public static final int GL_RED_MIN_CLAMP_INGR = 34144;
	public static final int GL_GREEN_MIN_CLAMP_INGR = 34145;
	public static final int GL_BLUE_MIN_CLAMP_INGR = 34146;
	public static final int GL_ALPHA_MIN_CLAMP_INGR = 34147;
	public static final int GL_RED_MAX_CLAMP_INGR = 34148;
	public static final int GL_GREEN_MAX_CLAMP_INGR = 34149;
	public static final int GL_BLUE_MAX_CLAMP_INGR = 34150;
	public static final int GL_ALPHA_MAX_CLAMP_INGR = 34151;
	public static final int GL_INTERLACE_READ_INGR = 34152;
	public static final int GL_INCR_WRAP_EXT = 34055;
	public static final int GL_DECR_WRAP_EXT = 34056;
	public static final int GL_422_EXT = 32972;
	public static final int GL_422_REV_EXT = 32973;
	public static final int GL_422_AVERAGE_EXT = 32974;
	public static final int GL_422_REV_AVERAGE_EXT = 32975;
	public static final int GL_NORMAL_MAP_NV = 34065;
	public static final int GL_REFLECTION_MAP_NV = 34066;
	public static final int GL_WRAP_BORDER_SUN = 33236;
	public static final int GL_MAX_TEXTURE_LOD_BIAS_EXT = 34045;
	public static final int GL_TEXTURE_FILTER_CONTROL_EXT = 34048;
	public static final int GL_TEXTURE_LOD_BIAS_EXT = 34049;
	public static final int GL_TEXTURE_MAX_ANISOTROPY_EXT = 34046;
	public static final int GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT = 34047;
	public static final int GL_MODELVIEW0_STACK_DEPTH_EXT = 2979;
	public static final int GL_MODELVIEW1_STACK_DEPTH_EXT = 34050;
	public static final int GL_MODELVIEW0_MATRIX_EXT = 2982;
	public static final int GL_MODELVIEW1_MATRIX_EXT = 34054;
	public static final int GL_VERTEX_WEIGHTING_EXT = 34057;
	public static final int GL_MODELVIEW0_EXT = 5888;
	public static final int GL_MODELVIEW1_EXT = 34058;
	public static final int GL_CURRENT_VERTEX_WEIGHT_EXT = 34059;
	public static final int GL_VERTEX_WEIGHT_ARRAY_EXT = 34060;
	public static final int GL_VERTEX_WEIGHT_ARRAY_SIZE_EXT = 34061;
	public static final int GL_VERTEX_WEIGHT_ARRAY_TYPE_EXT = 34062;
	public static final int GL_VERTEX_WEIGHT_ARRAY_STRIDE_EXT = 34063;
	public static final int GL_VERTEX_WEIGHT_ARRAY_POINTER_EXT = 34064;
	public static final int GL_MAX_SHININESS_NV = 34052;
	public static final int GL_MAX_SPOT_EXPONENT_NV = 34053;
	public static final int GL_VERTEX_ARRAY_RANGE_NV = 34077;
	public static final int GL_VERTEX_ARRAY_RANGE_LENGTH_NV = 34078;
	public static final int GL_VERTEX_ARRAY_RANGE_VALID_NV = 34079;
	public static final int GL_MAX_VERTEX_ARRAY_RANGE_ELEMENT_NV = 34080;
	public static final int GL_VERTEX_ARRAY_RANGE_POINTER_NV = 34081;
	public static final int GL_REGISTER_COMBINERS_NV = 34082;
	public static final int GL_VARIABLE_A_NV = 34083;
	public static final int GL_VARIABLE_B_NV = 34084;
	public static final int GL_VARIABLE_C_NV = 34085;
	public static final int GL_VARIABLE_D_NV = 34086;
	public static final int GL_VARIABLE_E_NV = 34087;
	public static final int GL_VARIABLE_F_NV = 34088;
	public static final int GL_VARIABLE_G_NV = 34089;
	public static final int GL_CONSTANT_COLOR0_NV = 34090;
	public static final int GL_CONSTANT_COLOR1_NV = 34091;
	public static final int GL_PRIMARY_COLOR_NV = 34092;
	public static final int GL_SECONDARY_COLOR_NV = 34093;
	public static final int GL_SPARE0_NV = 34094;
	public static final int GL_SPARE1_NV = 34095;
	public static final int GL_DISCARD_NV = 34096;
	public static final int GL_E_TIMES_F_NV = 34097;
	public static final int GL_SPARE0_PLUS_SECONDARY_COLOR_NV = 34098;
	public static final int GL_UNSIGNED_IDENTITY_NV = 34102;
	public static final int GL_UNSIGNED_INVERT_NV = 34103;
	public static final int GL_EXPAND_NORMAL_NV = 34104;
	public static final int GL_EXPAND_NEGATE_NV = 34105;
	public static final int GL_HALF_BIAS_NORMAL_NV = 34106;
	public static final int GL_HALF_BIAS_NEGATE_NV = 34107;
	public static final int GL_SIGNED_IDENTITY_NV = 34108;
	public static final int GL_SIGNED_NEGATE_NV = 34109;
	public static final int GL_SCALE_BY_TWO_NV = 34110;
	public static final int GL_SCALE_BY_FOUR_NV = 34111;
	public static final int GL_SCALE_BY_ONE_HALF_NV = 34112;
	public static final int GL_BIAS_BY_NEGATIVE_ONE_HALF_NV = 34113;
	public static final int GL_COMBINER_INPUT_NV = 34114;
	public static final int GL_COMBINER_MAPPING_NV = 34115;
	public static final int GL_COMBINER_COMPONENT_USAGE_NV = 34116;
	public static final int GL_COMBINER_AB_DOT_PRODUCT_NV = 34117;
	public static final int GL_COMBINER_CD_DOT_PRODUCT_NV = 34118;
	public static final int GL_COMBINER_MUX_SUM_NV = 34119;
	public static final int GL_COMBINER_SCALE_NV = 34120;
	public static final int GL_COMBINER_BIAS_NV = 34121;
	public static final int GL_COMBINER_AB_OUTPUT_NV = 34122;
	public static final int GL_COMBINER_CD_OUTPUT_NV = 34123;
	public static final int GL_COMBINER_SUM_OUTPUT_NV = 34124;
	public static final int GL_MAX_GENERAL_COMBINERS_NV = 34125;
	public static final int GL_NUM_GENERAL_COMBINERS_NV = 34126;
	public static final int GL_COLOR_SUM_CLAMP_NV = 34127;
	public static final int GL_COMBINER0_NV = 34128;
	public static final int GL_COMBINER1_NV = 34129;
	public static final int GL_COMBINER2_NV = 34130;
	public static final int GL_COMBINER3_NV = 34131;
	public static final int GL_COMBINER4_NV = 34132;
	public static final int GL_COMBINER5_NV = 34133;
	public static final int GL_COMBINER6_NV = 34134;
	public static final int GL_COMBINER7_NV = 34135;
	public static final int GL_FOG_DISTANCE_MODE_NV = 34138;
	public static final int GL_EYE_RADIAL_NV = 34139;
	public static final int GL_EYE_PLANE_ABSOLUTE_NV = 34140;
	public static final int GL_EMBOSS_LIGHT_NV = 34141;
	public static final int GL_EMBOSS_CONSTANT_NV = 34142;
	public static final int GL_EMBOSS_MAP_NV = 34143;
	public static final int GL_COMBINE4_NV = 34051;
	public static final int GL_SOURCE3_RGB_NV = 34179;
	public static final int GL_SOURCE3_ALPHA_NV = 34187;
	public static final int GL_OPERAND3_RGB_NV = 34195;
	public static final int GL_OPERAND3_ALPHA_NV = 34203;
	public static final int GL_COMPRESSED_RGB_S3TC_DXT1_EXT = 33776;
	public static final int GL_COMPRESSED_RGBA_S3TC_DXT1_EXT = 33777;
	public static final int GL_COMPRESSED_RGBA_S3TC_DXT3_EXT = 33778;
	public static final int GL_COMPRESSED_RGBA_S3TC_DXT5_EXT = 33779;
	public static final int GL_CULL_VERTEX_IBM = 103050;
	public static final int GL_PACK_SUBSAMPLE_RATE_SGIX = 34208;
	public static final int GL_UNPACK_SUBSAMPLE_RATE_SGIX = 34209;
	public static final int GL_PIXEL_SUBSAMPLE_4444_SGIX = 34210;
	public static final int GL_PIXEL_SUBSAMPLE_2424_SGIX = 34211;
	public static final int GL_PIXEL_SUBSAMPLE_4242_SGIX = 34212;
	public static final int GL_YCRCB_SGIX = 33560;
	public static final int GL_YCRCBA_SGIX = 33561;
	public static final int GL_DEPTH_PASS_INSTRUMENT_SGIX = 33552;
	public static final int GL_DEPTH_PASS_INSTRUMENT_COUNTERS_SGIX = 33553;
	public static final int GL_DEPTH_PASS_INSTRUMENT_MAX_SGIX = 33554;
	public static final int GL_COMPRESSED_RGB_FXT1_3DFX = 34480;
	public static final int GL_COMPRESSED_RGBA_FXT1_3DFX = 34481;
	public static final int GL_MULTISAMPLE_3DFX = 34482;
	public static final int GL_SAMPLE_BUFFERS_3DFX = 34483;
	public static final int GL_SAMPLES_3DFX = 34484;
	public static final int GL_MULTISAMPLE_BIT_3DFX = 536870912;
	public static final int GL_MULTISAMPLE_EXT = 32925;
	public static final int GL_SAMPLE_ALPHA_TO_MASK_EXT = 32926;
	public static final int GL_SAMPLE_ALPHA_TO_ONE_EXT = 32927;
	public static final int GL_SAMPLE_MASK_EXT = 32928;
	public static final int GL_1PASS_EXT = 32929;
	public static final int GL_2PASS_0_EXT = 32930;
	public static final int GL_2PASS_1_EXT = 32931;
	public static final int GL_4PASS_0_EXT = 32932;
	public static final int GL_4PASS_1_EXT = 32933;
	public static final int GL_4PASS_2_EXT = 32934;
	public static final int GL_4PASS_3_EXT = 32935;
	public static final int GL_SAMPLE_BUFFERS_EXT = 32936;
	public static final int GL_SAMPLES_EXT = 32937;
	public static final int GL_SAMPLE_MASK_VALUE_EXT = 32938;
	public static final int GL_SAMPLE_MASK_INVERT_EXT = 32939;
	public static final int GL_SAMPLE_PATTERN_EXT = 32940;
	public static final int GL_MULTISAMPLE_BIT_EXT = 536870912;
	public static final int GL_VERTEX_PRECLIP_SGIX = 33774;
	public static final int GL_VERTEX_PRECLIP_HINT_SGIX = 33775;
	public static final int GL_CONVOLUTION_HINT_SGIX = 33558;
	public static final int GL_PACK_RESAMPLE_SGIX = 33836;
	public static final int GL_UNPACK_RESAMPLE_SGIX = 33837;
	public static final int GL_RESAMPLE_REPLICATE_SGIX = 33838;
	public static final int GL_RESAMPLE_ZERO_FILL_SGIX = 33839;
	public static final int GL_RESAMPLE_DECIMATE_SGIX = 33840;
	public static final int GL_EYE_DISTANCE_TO_POINT_SGIS = 33264;
	public static final int GL_OBJECT_DISTANCE_TO_POINT_SGIS = 33265;
	public static final int GL_EYE_DISTANCE_TO_LINE_SGIS = 33266;
	public static final int GL_OBJECT_DISTANCE_TO_LINE_SGIS = 33267;
	public static final int GL_EYE_POINT_SGIS = 33268;
	public static final int GL_OBJECT_POINT_SGIS = 33269;
	public static final int GL_EYE_LINE_SGIS = 33270;
	public static final int GL_OBJECT_LINE_SGIS = 33271;
	public static final int GL_TEXTURE_COLOR_WRITEMASK_SGIS = 33263;
	public static final int GL_MIRROR_CLAMP_ATI = 34626;
	public static final int GL_MIRROR_CLAMP_TO_EDGE_ATI = 34627;
	public static final int GL_ALL_COMPLETED_NV = 34034;
	public static final int GL_FENCE_STATUS_NV = 34035;
	public static final int GL_FENCE_CONDITION_NV = 34036;
	public static final int GL_MIRRORED_REPEAT_IBM = 33648;
	public static final int GL_EVAL_2D_NV = 34496;
	public static final int GL_EVAL_TRIANGULAR_2D_NV = 34497;
	public static final int GL_MAP_TESSELLATION_NV = 34498;
	public static final int GL_MAP_ATTRIB_U_ORDER_NV = 34499;
	public static final int GL_MAP_ATTRIB_V_ORDER_NV = 34500;
	public static final int GL_EVAL_FRACTIONAL_TESSELLATION_NV = 34501;
	public static final int GL_EVAL_VERTEX_ATTRIB0_NV = 34502;
	public static final int GL_EVAL_VERTEX_ATTRIB1_NV = 34503;
	public static final int GL_EVAL_VERTEX_ATTRIB2_NV = 34504;
	public static final int GL_EVAL_VERTEX_ATTRIB3_NV = 34505;
	public static final int GL_EVAL_VERTEX_ATTRIB4_NV = 34506;
	public static final int GL_EVAL_VERTEX_ATTRIB5_NV = 34507;
	public static final int GL_EVAL_VERTEX_ATTRIB6_NV = 34508;
	public static final int GL_EVAL_VERTEX_ATTRIB7_NV = 34509;
	public static final int GL_EVAL_VERTEX_ATTRIB8_NV = 34510;
	public static final int GL_EVAL_VERTEX_ATTRIB9_NV = 34511;
	public static final int GL_EVAL_VERTEX_ATTRIB10_NV = 34512;
	public static final int GL_EVAL_VERTEX_ATTRIB11_NV = 34513;
	public static final int GL_EVAL_VERTEX_ATTRIB12_NV = 34514;
	public static final int GL_EVAL_VERTEX_ATTRIB13_NV = 34515;
	public static final int GL_EVAL_VERTEX_ATTRIB14_NV = 34516;
	public static final int GL_EVAL_VERTEX_ATTRIB15_NV = 34517;
	public static final int GL_MAX_MAP_TESSELLATION_NV = 34518;
	public static final int GL_MAX_RATIONAL_EVAL_ORDER_NV = 34519;
	public static final int GL_DEPTH_STENCIL_NV = 34041;
	public static final int GL_UNSIGNED_INT_24_8_NV = 34042;
	public static final int GL_PER_STAGE_CONSTANTS_NV = 34101;
	public static final int GL_TEXTURE_RECTANGLE_NV = 34037;
	public static final int GL_TEXTURE_BINDING_RECTANGLE_NV = 34038;
	public static final int GL_PROXY_TEXTURE_RECTANGLE_NV = 34039;
	public static final int GL_MAX_RECTANGLE_TEXTURE_SIZE_NV = 34040;
	public static final int GL_OFFSET_TEXTURE_RECTANGLE_NV = 34380;
	public static final int GL_OFFSET_TEXTURE_RECTANGLE_SCALE_NV = 34381;
	public static final int GL_DOT_PRODUCT_TEXTURE_RECTANGLE_NV = 34382;
	public static final int GL_RGBA_UNSIGNED_DOT_PRODUCT_MAPPING_NV = 34521;
	public static final int GL_UNSIGNED_INT_S8_S8_8_8_NV = 34522;
	public static final int GL_UNSIGNED_INT_8_8_S8_S8_REV_NV = 34523;
	public static final int GL_DSDT_MAG_INTENSITY_NV = 34524;
	public static final int GL_SHADER_CONSISTENT_NV = 34525;
	public static final int GL_TEXTURE_SHADER_NV = 34526;
	public static final int GL_SHADER_OPERATION_NV = 34527;
	public static final int GL_CULL_MODES_NV = 34528;
	public static final int GL_OFFSET_TEXTURE_MATRIX_NV = 34529;
	public static final int GL_OFFSET_TEXTURE_SCALE_NV = 34530;
	public static final int GL_OFFSET_TEXTURE_BIAS_NV = 34531;
	public static final int GL_OFFSET_TEXTURE_2D_MATRIX_NV = 34529;
	public static final int GL_OFFSET_TEXTURE_2D_SCALE_NV = 34530;
	public static final int GL_OFFSET_TEXTURE_2D_BIAS_NV = 34531;
	public static final int GL_PREVIOUS_TEXTURE_INPUT_NV = 34532;
	public static final int GL_CONST_EYE_NV = 34533;
	public static final int GL_PASS_THROUGH_NV = 34534;
	public static final int GL_CULL_FRAGMENT_NV = 34535;
	public static final int GL_OFFSET_TEXTURE_2D_NV = 34536;
	public static final int GL_DEPENDENT_AR_TEXTURE_2D_NV = 34537;
	public static final int GL_DEPENDENT_GB_TEXTURE_2D_NV = 34538;
	public static final int GL_DOT_PRODUCT_NV = 34540;
	public static final int GL_DOT_PRODUCT_DEPTH_REPLACE_NV = 34541;
	public static final int GL_DOT_PRODUCT_TEXTURE_2D_NV = 34542;
	public static final int GL_DOT_PRODUCT_TEXTURE_CUBE_MAP_NV = 34544;
	public static final int GL_DOT_PRODUCT_DIFFUSE_CUBE_MAP_NV = 34545;
	public static final int GL_DOT_PRODUCT_REFLECT_CUBE_MAP_NV = 34546;
	public static final int GL_DOT_PRODUCT_CONST_EYE_REFLECT_CUBE_MAP_NV = 34547;
	public static final int GL_HILO_NV = 34548;
	public static final int GL_DSDT_NV = 34549;
	public static final int GL_DSDT_MAG_NV = 34550;
	public static final int GL_DSDT_MAG_VIB_NV = 34551;
	public static final int GL_HILO16_NV = 34552;
	public static final int GL_SIGNED_HILO_NV = 34553;
	public static final int GL_SIGNED_HILO16_NV = 34554;
	public static final int GL_SIGNED_RGBA_NV = 34555;
	public static final int GL_SIGNED_RGBA8_NV = 34556;
	public static final int GL_SIGNED_RGB_NV = 34558;
	public static final int GL_SIGNED_RGB8_NV = 34559;
	public static final int GL_SIGNED_LUMINANCE_NV = 34561;
	public static final int GL_SIGNED_LUMINANCE8_NV = 34562;
	public static final int GL_SIGNED_LUMINANCE_ALPHA_NV = 34563;
	public static final int GL_SIGNED_LUMINANCE8_ALPHA8_NV = 34564;
	public static final int GL_SIGNED_ALPHA_NV = 34565;
	public static final int GL_SIGNED_ALPHA8_NV = 34566;
	public static final int GL_SIGNED_INTENSITY_NV = 34567;
	public static final int GL_SIGNED_INTENSITY8_NV = 34568;
	public static final int GL_DSDT8_NV = 34569;
	public static final int GL_DSDT8_MAG8_NV = 34570;
	public static final int GL_DSDT8_MAG8_INTENSITY8_NV = 34571;
	public static final int GL_SIGNED_RGB_UNSIGNED_ALPHA_NV = 34572;
	public static final int GL_SIGNED_RGB8_UNSIGNED_ALPHA8_NV = 34573;
	public static final int GL_HI_SCALE_NV = 34574;
	public static final int GL_LO_SCALE_NV = 34575;
	public static final int GL_DS_SCALE_NV = 34576;
	public static final int GL_DT_SCALE_NV = 34577;
	public static final int GL_MAGNITUDE_SCALE_NV = 34578;
	public static final int GL_VIBRANCE_SCALE_NV = 34579;
	public static final int GL_HI_BIAS_NV = 34580;
	public static final int GL_LO_BIAS_NV = 34581;
	public static final int GL_DS_BIAS_NV = 34582;
	public static final int GL_DT_BIAS_NV = 34583;
	public static final int GL_MAGNITUDE_BIAS_NV = 34584;
	public static final int GL_VIBRANCE_BIAS_NV = 34585;
	public static final int GL_TEXTURE_BORDER_VALUES_NV = 34586;
	public static final int GL_TEXTURE_HI_SIZE_NV = 34587;
	public static final int GL_TEXTURE_LO_SIZE_NV = 34588;
	public static final int GL_TEXTURE_DS_SIZE_NV = 34589;
	public static final int GL_TEXTURE_DT_SIZE_NV = 34590;
	public static final int GL_TEXTURE_MAG_SIZE_NV = 34591;
	public static final int GL_DOT_PRODUCT_TEXTURE_3D_NV = 34543;
	public static final int GL_VERTEX_ARRAY_RANGE_WITHOUT_FLUSH_NV = 34099;
	public static final int GL_VERTEX_PROGRAM_NV = 34336;
	public static final int GL_VERTEX_STATE_PROGRAM_NV = 34337;
	public static final int GL_ATTRIB_ARRAY_SIZE_NV = 34339;
	public static final int GL_ATTRIB_ARRAY_STRIDE_NV = 34340;
	public static final int GL_ATTRIB_ARRAY_TYPE_NV = 34341;
	public static final int GL_CURRENT_ATTRIB_NV = 34342;
	public static final int GL_PROGRAM_LENGTH_NV = 34343;
	public static final int GL_PROGRAM_STRING_NV = 34344;
	public static final int GL_MODELVIEW_PROJECTION_NV = 34345;
	public static final int GL_IDENTITY_NV = 34346;
	public static final int GL_INVERSE_NV = 34347;
	public static final int GL_TRANSPOSE_NV = 34348;
	public static final int GL_INVERSE_TRANSPOSE_NV = 34349;
	public static final int GL_MAX_TRACK_MATRIX_STACK_DEPTH_NV = 34350;
	public static final int GL_MAX_TRACK_MATRICES_NV = 34351;
	public static final int GL_MATRIX0_NV = 34352;
	public static final int GL_MATRIX1_NV = 34353;
	public static final int GL_MATRIX2_NV = 34354;
	public static final int GL_MATRIX3_NV = 34355;
	public static final int GL_MATRIX4_NV = 34356;
	public static final int GL_MATRIX5_NV = 34357;
	public static final int GL_MATRIX6_NV = 34358;
	public static final int GL_MATRIX7_NV = 34359;
	public static final int GL_CURRENT_MATRIX_STACK_DEPTH_NV = 34368;
	public static final int GL_CURRENT_MATRIX_NV = 34369;
	public static final int GL_VERTEX_PROGRAM_POINT_SIZE_NV = 34370;
	public static final int GL_VERTEX_PROGRAM_TWO_SIDE_NV = 34371;
	public static final int GL_PROGRAM_PARAMETER_NV = 34372;
	public static final int GL_ATTRIB_ARRAY_POINTER_NV = 34373;
	public static final int GL_PROGRAM_TARGET_NV = 34374;
	public static final int GL_PROGRAM_RESIDENT_NV = 34375;
	public static final int GL_TRACK_MATRIX_NV = 34376;
	public static final int GL_TRACK_MATRIX_TRANSFORM_NV = 34377;
	public static final int GL_VERTEX_PROGRAM_BINDING_NV = 34378;
	public static final int GL_PROGRAM_ERROR_POSITION_NV = 34379;
	public static final int GL_VERTEX_ATTRIB_ARRAY0_NV = 34384;
	public static final int GL_VERTEX_ATTRIB_ARRAY1_NV = 34385;
	public static final int GL_VERTEX_ATTRIB_ARRAY2_NV = 34386;
	public static final int GL_VERTEX_ATTRIB_ARRAY3_NV = 34387;
	public static final int GL_VERTEX_ATTRIB_ARRAY4_NV = 34388;
	public static final int GL_VERTEX_ATTRIB_ARRAY5_NV = 34389;
	public static final int GL_VERTEX_ATTRIB_ARRAY6_NV = 34390;
	public static final int GL_VERTEX_ATTRIB_ARRAY7_NV = 34391;
	public static final int GL_VERTEX_ATTRIB_ARRAY8_NV = 34392;
	public static final int GL_VERTEX_ATTRIB_ARRAY9_NV = 34393;
	public static final int GL_VERTEX_ATTRIB_ARRAY10_NV = 34394;
	public static final int GL_VERTEX_ATTRIB_ARRAY11_NV = 34395;
	public static final int GL_VERTEX_ATTRIB_ARRAY12_NV = 34396;
	public static final int GL_VERTEX_ATTRIB_ARRAY13_NV = 34397;
	public static final int GL_VERTEX_ATTRIB_ARRAY14_NV = 34398;
	public static final int GL_VERTEX_ATTRIB_ARRAY15_NV = 34399;
	public static final int GL_MAP1_VERTEX_ATTRIB0_4_NV = 34400;
	public static final int GL_MAP1_VERTEX_ATTRIB1_4_NV = 34401;
	public static final int GL_MAP1_VERTEX_ATTRIB2_4_NV = 34402;
	public static final int GL_MAP1_VERTEX_ATTRIB3_4_NV = 34403;
	public static final int GL_MAP1_VERTEX_ATTRIB4_4_NV = 34404;
	public static final int GL_MAP1_VERTEX_ATTRIB5_4_NV = 34405;
	public static final int GL_MAP1_VERTEX_ATTRIB6_4_NV = 34406;
	public static final int GL_MAP1_VERTEX_ATTRIB7_4_NV = 34407;
	public static final int GL_MAP1_VERTEX_ATTRIB8_4_NV = 34408;
	public static final int GL_MAP1_VERTEX_ATTRIB9_4_NV = 34409;
	public static final int GL_MAP1_VERTEX_ATTRIB10_4_NV = 34410;
	public static final int GL_MAP1_VERTEX_ATTRIB11_4_NV = 34411;
	public static final int GL_MAP1_VERTEX_ATTRIB12_4_NV = 34412;
	public static final int GL_MAP1_VERTEX_ATTRIB13_4_NV = 34413;
	public static final int GL_MAP1_VERTEX_ATTRIB14_4_NV = 34414;
	public static final int GL_MAP1_VERTEX_ATTRIB15_4_NV = 34415;
	public static final int GL_MAP2_VERTEX_ATTRIB0_4_NV = 34416;
	public static final int GL_MAP2_VERTEX_ATTRIB1_4_NV = 34417;
	public static final int GL_MAP2_VERTEX_ATTRIB2_4_NV = 34418;
	public static final int GL_MAP2_VERTEX_ATTRIB3_4_NV = 34419;
	public static final int GL_MAP2_VERTEX_ATTRIB4_4_NV = 34420;
	public static final int GL_MAP2_VERTEX_ATTRIB5_4_NV = 34421;
	public static final int GL_MAP2_VERTEX_ATTRIB6_4_NV = 34422;
	public static final int GL_MAP2_VERTEX_ATTRIB7_4_NV = 34423;
	public static final int GL_MAP2_VERTEX_ATTRIB8_4_NV = 34424;
	public static final int GL_MAP2_VERTEX_ATTRIB9_4_NV = 34425;
	public static final int GL_MAP2_VERTEX_ATTRIB10_4_NV = 34426;
	public static final int GL_MAP2_VERTEX_ATTRIB11_4_NV = 34427;
	public static final int GL_MAP2_VERTEX_ATTRIB12_4_NV = 34428;
	public static final int GL_MAP2_VERTEX_ATTRIB13_4_NV = 34429;
	public static final int GL_MAP2_VERTEX_ATTRIB14_4_NV = 34430;
	public static final int GL_MAP2_VERTEX_ATTRIB15_4_NV = 34431;
	public static final int GL_TEXTURE_MAX_CLAMP_S_SGIX = 33641;
	public static final int GL_TEXTURE_MAX_CLAMP_T_SGIX = 33642;
	public static final int GL_TEXTURE_MAX_CLAMP_R_SGIX = 33643;
	public static final int GL_SCALEBIAS_HINT_SGIX = 33570;
	public static final int GL_INTERLACE_OML = 35200;
	public static final int GL_INTERLACE_READ_OML = 35201;
	public static final int GL_FORMAT_SUBSAMPLE_24_24_OML = 35202;
	public static final int GL_FORMAT_SUBSAMPLE_244_244_OML = 35203;
	public static final int GL_PACK_RESAMPLE_OML = 35204;
	public static final int GL_UNPACK_RESAMPLE_OML = 35205;
	public static final int GL_RESAMPLE_REPLICATE_OML = 35206;
	public static final int GL_RESAMPLE_ZERO_FILL_OML = 35207;
	public static final int GL_RESAMPLE_AVERAGE_OML = 35208;
	public static final int GL_RESAMPLE_DECIMATE_OML = 35209;
	public static final int GL_DEPTH_STENCIL_TO_RGBA_NV = 34926;
	public static final int GL_DEPTH_STENCIL_TO_BGRA_NV = 34927;
	public static final int GL_BUMP_ROT_MATRIX_ATI = 34677;
	public static final int GL_BUMP_ROT_MATRIX_SIZE_ATI = 34678;
	public static final int GL_BUMP_NUM_TEX_UNITS_ATI = 34679;
	public static final int GL_BUMP_TEX_UNITS_ATI = 34680;
	public static final int GL_DUDV_ATI = 34681;
	public static final int GL_DU8DV8_ATI = 34682;
	public static final int GL_BUMP_ENVMAP_ATI = 34683;
	public static final int GL_BUMP_TARGET_ATI = 34684;
	public static final int GL_FRAGMENT_SHADER_ATI = 35104;
	public static final int GL_REG_0_ATI = 35105;
	public static final int GL_REG_1_ATI = 35106;
	public static final int GL_REG_2_ATI = 35107;
	public static final int GL_REG_3_ATI = 35108;
	public static final int GL_REG_4_ATI = 35109;
	public static final int GL_REG_5_ATI = 35110;
	public static final int GL_REG_6_ATI = 35111;
	public static final int GL_REG_7_ATI = 35112;
	public static final int GL_REG_8_ATI = 35113;
	public static final int GL_REG_9_ATI = 35114;
	public static final int GL_REG_10_ATI = 35115;
	public static final int GL_REG_11_ATI = 35116;
	public static final int GL_REG_12_ATI = 35117;
	public static final int GL_REG_13_ATI = 35118;
	public static final int GL_REG_14_ATI = 35119;
	public static final int GL_REG_15_ATI = 35120;
	public static final int GL_REG_16_ATI = 35121;
	public static final int GL_REG_17_ATI = 35122;
	public static final int GL_REG_18_ATI = 35123;
	public static final int GL_REG_19_ATI = 35124;
	public static final int GL_REG_20_ATI = 35125;
	public static final int GL_REG_21_ATI = 35126;
	public static final int GL_REG_22_ATI = 35127;
	public static final int GL_REG_23_ATI = 35128;
	public static final int GL_REG_24_ATI = 35129;
	public static final int GL_REG_25_ATI = 35130;
	public static final int GL_REG_26_ATI = 35131;
	public static final int GL_REG_27_ATI = 35132;
	public static final int GL_REG_28_ATI = 35133;
	public static final int GL_REG_29_ATI = 35134;
	public static final int GL_REG_30_ATI = 35135;
	public static final int GL_REG_31_ATI = 35136;
	public static final int GL_CON_0_ATI = 35137;
	public static final int GL_CON_1_ATI = 35138;
	public static final int GL_CON_2_ATI = 35139;
	public static final int GL_CON_3_ATI = 35140;
	public static final int GL_CON_4_ATI = 35141;
	public static final int GL_CON_5_ATI = 35142;
	public static final int GL_CON_6_ATI = 35143;
	public static final int GL_CON_7_ATI = 35144;
	public static final int GL_CON_8_ATI = 35145;
	public static final int GL_CON_9_ATI = 35146;
	public static final int GL_CON_10_ATI = 35147;
	public static final int GL_CON_11_ATI = 35148;
	public static final int GL_CON_12_ATI = 35149;
	public static final int GL_CON_13_ATI = 35150;
	public static final int GL_CON_14_ATI = 35151;
	public static final int GL_CON_15_ATI = 35152;
	public static final int GL_CON_16_ATI = 35153;
	public static final int GL_CON_17_ATI = 35154;
	public static final int GL_CON_18_ATI = 35155;
	public static final int GL_CON_19_ATI = 35156;
	public static final int GL_CON_20_ATI = 35157;
	public static final int GL_CON_21_ATI = 35158;
	public static final int GL_CON_22_ATI = 35159;
	public static final int GL_CON_23_ATI = 35160;
	public static final int GL_CON_24_ATI = 35161;
	public static final int GL_CON_25_ATI = 35162;
	public static final int GL_CON_26_ATI = 35163;
	public static final int GL_CON_27_ATI = 35164;
	public static final int GL_CON_28_ATI = 35165;
	public static final int GL_CON_29_ATI = 35166;
	public static final int GL_CON_30_ATI = 35167;
	public static final int GL_CON_31_ATI = 35168;
	public static final int GL_MOV_ATI = 35169;
	public static final int GL_ADD_ATI = 35171;
	public static final int GL_MUL_ATI = 35172;
	public static final int GL_SUB_ATI = 35173;
	public static final int GL_DOT3_ATI = 35174;
	public static final int GL_DOT4_ATI = 35175;
	public static final int GL_MAD_ATI = 35176;
	public static final int GL_LERP_ATI = 35177;
	public static final int GL_CND_ATI = 35178;
	public static final int GL_CND0_ATI = 35179;
	public static final int GL_DOT2_ADD_ATI = 35180;
	public static final int GL_SECONDARY_INTERPOLATOR_ATI = 35181;
	public static final int GL_NUM_FRAGMENT_REGISTERS_ATI = 35182;
	public static final int GL_NUM_FRAGMENT_CONSTANTS_ATI = 35183;
	public static final int GL_NUM_PASSES_ATI = 35184;
	public static final int GL_NUM_INSTRUCTIONS_PER_PASS_ATI = 35185;
	public static final int GL_NUM_INSTRUCTIONS_TOTAL_ATI = 35186;
	public static final int GL_NUM_INPUT_INTERPOLATOR_COMPONENTS_ATI = 35187;
	public static final int GL_NUM_LOOPBACK_COMPONENTS_ATI = 35188;
	public static final int GL_COLOR_ALPHA_PAIRING_ATI = 35189;
	public static final int GL_SWIZZLE_STR_ATI = 35190;
	public static final int GL_SWIZZLE_STQ_ATI = 35191;
	public static final int GL_SWIZZLE_STR_DR_ATI = 35192;
	public static final int GL_SWIZZLE_STQ_DQ_ATI = 35193;
	public static final int GL_SWIZZLE_STRQ_ATI = 35194;
	public static final int GL_SWIZZLE_STRQ_DQ_ATI = 35195;
	public static final int GL_RED_BIT_ATI = 1;
	public static final int GL_GREEN_BIT_ATI = 2;
	public static final int GL_BLUE_BIT_ATI = 4;
	public static final int GL_2X_BIT_ATI = 1;
	public static final int GL_4X_BIT_ATI = 2;
	public static final int GL_8X_BIT_ATI = 4;
	public static final int GL_HALF_BIT_ATI = 8;
	public static final int GL_QUARTER_BIT_ATI = 16;
	public static final int GL_EIGHTH_BIT_ATI = 32;
	public static final int GL_SATURATE_BIT_ATI = 64;
	public static final int GL_COMP_BIT_ATI = 2;
	public static final int GL_NEGATE_BIT_ATI = 4;
	public static final int GL_BIAS_BIT_ATI = 8;
	public static final int GL_PN_TRIANGLES_ATI = 34800;
	public static final int GL_MAX_PN_TRIANGLES_TESSELATION_LEVEL_ATI = 34801;
	public static final int GL_PN_TRIANGLES_POINT_MODE_ATI = 34802;
	public static final int GL_PN_TRIANGLES_NORMAL_MODE_ATI = 34803;
	public static final int GL_PN_TRIANGLES_TESSELATION_LEVEL_ATI = 34804;
	public static final int GL_PN_TRIANGLES_POINT_MODE_LINEAR_ATI = 34805;
	public static final int GL_PN_TRIANGLES_POINT_MODE_CUBIC_ATI = 34806;
	public static final int GL_PN_TRIANGLES_NORMAL_MODE_LINEAR_ATI = 34807;
	public static final int GL_PN_TRIANGLES_NORMAL_MODE_QUADRATIC_ATI = 34808;
	public static final int GL_STATIC_ATI = 34656;
	public static final int GL_DYNAMIC_ATI = 34657;
	public static final int GL_PRESERVE_ATI = 34658;
	public static final int GL_DISCARD_ATI = 34659;
	public static final int GL_OBJECT_BUFFER_SIZE_ATI = 34660;
	public static final int GL_OBJECT_BUFFER_USAGE_ATI = 34661;
	public static final int GL_ARRAY_OBJECT_BUFFER_ATI = 34662;
	public static final int GL_ARRAY_OBJECT_OFFSET_ATI = 34663;
	public static final int GL_VERTEX_SHADER_EXT = 34688;
	public static final int GL_VERTEX_SHADER_BINDING_EXT = 34689;
	public static final int GL_OP_INDEX_EXT = 34690;
	public static final int GL_OP_NEGATE_EXT = 34691;
	public static final int GL_OP_DOT3_EXT = 34692;
	public static final int GL_OP_DOT4_EXT = 34693;
	public static final int GL_OP_MUL_EXT = 34694;
	public static final int GL_OP_ADD_EXT = 34695;
	public static final int GL_OP_MADD_EXT = 34696;
	public static final int GL_OP_FRAC_EXT = 34697;
	public static final int GL_OP_MAX_EXT = 34698;
	public static final int GL_OP_MIN_EXT = 34699;
	public static final int GL_OP_SET_GE_EXT = 34700;
	public static final int GL_OP_SET_LT_EXT = 34701;
	public static final int GL_OP_CLAMP_EXT = 34702;
	public static final int GL_OP_FLOOR_EXT = 34703;
	public static final int GL_OP_ROUND_EXT = 34704;
	public static final int GL_OP_EXP_BASE_2_EXT = 34705;
	public static final int GL_OP_LOG_BASE_2_EXT = 34706;
	public static final int GL_OP_POWER_EXT = 34707;
	public static final int GL_OP_RECIP_EXT = 34708;
	public static final int GL_OP_RECIP_SQRT_EXT = 34709;
	public static final int GL_OP_SUB_EXT = 34710;
	public static final int GL_OP_CROSS_PRODUCT_EXT = 34711;
	public static final int GL_OP_MULTIPLY_MATRIX_EXT = 34712;
	public static final int GL_OP_MOV_EXT = 34713;
	public static final int GL_OUTPUT_VERTEX_EXT = 34714;
	public static final int GL_OUTPUT_COLOR0_EXT = 34715;
	public static final int GL_OUTPUT_COLOR1_EXT = 34716;
	public static final int GL_OUTPUT_TEXTURE_COORD0_EXT = 34717;
	public static final int GL_OUTPUT_TEXTURE_COORD1_EXT = 34718;
	public static final int GL_OUTPUT_TEXTURE_COORD2_EXT = 34719;
	public static final int GL_OUTPUT_TEXTURE_COORD3_EXT = 34720;
	public static final int GL_OUTPUT_TEXTURE_COORD4_EXT = 34721;
	public static final int GL_OUTPUT_TEXTURE_COORD5_EXT = 34722;
	public static final int GL_OUTPUT_TEXTURE_COORD6_EXT = 34723;
	public static final int GL_OUTPUT_TEXTURE_COORD7_EXT = 34724;
	public static final int GL_OUTPUT_TEXTURE_COORD8_EXT = 34725;
	public static final int GL_OUTPUT_TEXTURE_COORD9_EXT = 34726;
	public static final int GL_OUTPUT_TEXTURE_COORD10_EXT = 34727;
	public static final int GL_OUTPUT_TEXTURE_COORD11_EXT = 34728;
	public static final int GL_OUTPUT_TEXTURE_COORD12_EXT = 34729;
	public static final int GL_OUTPUT_TEXTURE_COORD13_EXT = 34730;
	public static final int GL_OUTPUT_TEXTURE_COORD14_EXT = 34731;
	public static final int GL_OUTPUT_TEXTURE_COORD15_EXT = 34732;
	public static final int GL_OUTPUT_TEXTURE_COORD16_EXT = 34733;
	public static final int GL_OUTPUT_TEXTURE_COORD17_EXT = 34734;
	public static final int GL_OUTPUT_TEXTURE_COORD18_EXT = 34735;
	public static final int GL_OUTPUT_TEXTURE_COORD19_EXT = 34736;
	public static final int GL_OUTPUT_TEXTURE_COORD20_EXT = 34737;
	public static final int GL_OUTPUT_TEXTURE_COORD21_EXT = 34738;
	public static final int GL_OUTPUT_TEXTURE_COORD22_EXT = 34739;
	public static final int GL_OUTPUT_TEXTURE_COORD23_EXT = 34740;
	public static final int GL_OUTPUT_TEXTURE_COORD24_EXT = 34741;
	public static final int GL_OUTPUT_TEXTURE_COORD25_EXT = 34742;
	public static final int GL_OUTPUT_TEXTURE_COORD26_EXT = 34743;
	public static final int GL_OUTPUT_TEXTURE_COORD27_EXT = 34744;
	public static final int GL_OUTPUT_TEXTURE_COORD28_EXT = 34745;
	public static final int GL_OUTPUT_TEXTURE_COORD29_EXT = 34746;
	public static final int GL_OUTPUT_TEXTURE_COORD30_EXT = 34747;
	public static final int GL_OUTPUT_TEXTURE_COORD31_EXT = 34748;
	public static final int GL_OUTPUT_FOG_EXT = 34749;
	public static final int GL_SCALAR_EXT = 34750;
	public static final int GL_VECTOR_EXT = 34751;
	public static final int GL_MATRIX_EXT = 34752;
	public static final int GL_VARIANT_EXT = 34753;
	public static final int GL_INVARIANT_EXT = 34754;
	public static final int GL_LOCAL_CONSTANT_EXT = 34755;
	public static final int GL_LOCAL_EXT = 34756;
	public static final int GL_MAX_VERTEX_SHADER_INSTRUCTIONS_EXT = 34757;
	public static final int GL_MAX_VERTEX_SHADER_VARIANTS_EXT = 34758;
	public static final int GL_MAX_VERTEX_SHADER_INVARIANTS_EXT = 34759;
	public static final int GL_MAX_VERTEX_SHADER_LOCAL_CONSTANTS_EXT = 34760;
	public static final int GL_MAX_VERTEX_SHADER_LOCALS_EXT = 34761;
	public static final int GL_MAX_OPTIMIZED_VERTEX_SHADER_INSTRUCTIONS_EXT = 34762;
	public static final int GL_MAX_OPTIMIZED_VERTEX_SHADER_VARIANTS_EXT = 34763;
	public static final int GL_MAX_OPTIMIZED_VERTEX_SHADER_LOCAL_CONSTANTS_EXT = 34764;
	public static final int GL_MAX_OPTIMIZED_VERTEX_SHADER_INVARIANTS_EXT = 34765;
	public static final int GL_MAX_OPTIMIZED_VERTEX_SHADER_LOCALS_EXT = 34766;
	public static final int GL_VERTEX_SHADER_INSTRUCTIONS_EXT = 34767;
	public static final int GL_VERTEX_SHADER_VARIANTS_EXT = 34768;
	public static final int GL_VERTEX_SHADER_INVARIANTS_EXT = 34769;
	public static final int GL_VERTEX_SHADER_LOCAL_CONSTANTS_EXT = 34770;
	public static final int GL_VERTEX_SHADER_LOCALS_EXT = 34771;
	public static final int GL_VERTEX_SHADER_OPTIMIZED_EXT = 34772;
	public static final int GL_X_EXT = 34773;
	public static final int GL_Y_EXT = 34774;
	public static final int GL_Z_EXT = 34775;
	public static final int GL_W_EXT = 34776;
	public static final int GL_NEGATIVE_X_EXT = 34777;
	public static final int GL_NEGATIVE_Y_EXT = 34778;
	public static final int GL_NEGATIVE_Z_EXT = 34779;
	public static final int GL_NEGATIVE_W_EXT = 34780;
	public static final int GL_ZERO_EXT = 34781;
	public static final int GL_ONE_EXT = 34782;
	public static final int GL_NEGATIVE_ONE_EXT = 34783;
	public static final int GL_NORMALIZED_RANGE_EXT = 34784;
	public static final int GL_FULL_RANGE_EXT = 34785;
	public static final int GL_CURRENT_VERTEX_EXT = 34786;
	public static final int GL_MVP_MATRIX_EXT = 34787;
	public static final int GL_VARIANT_VALUE_EXT = 34788;
	public static final int GL_VARIANT_DATATYPE_EXT = 34789;
	public static final int GL_VARIANT_ARRAY_STRIDE_EXT = 34790;
	public static final int GL_VARIANT_ARRAY_TYPE_EXT = 34791;
	public static final int GL_VARIANT_ARRAY_EXT = 34792;
	public static final int GL_VARIANT_ARRAY_POINTER_EXT = 34793;
	public static final int GL_INVARIANT_VALUE_EXT = 34794;
	public static final int GL_INVARIANT_DATATYPE_EXT = 34795;
	public static final int GL_LOCAL_CONSTANT_VALUE_EXT = 34796;
	public static final int GL_LOCAL_CONSTANT_DATATYPE_EXT = 34797;
	public static final int GL_TEXTURE_RECTANGLE_EXT = 34037;
	public static final int GL_TEXTURE_BINDING_RECTANGLE_EXT = 34038;
	public static final int GL_PROXY_TEXTURE_RECTANGLE_EXT = 34039;
	public static final int GL_MAX_RECTANGLE_TEXTURE_SIZE_EXT = 34040;
	public static final int GL_MAX_VERTEX_STREAMS_ATI = 34667;
	public static final int GL_VERTEX_STREAM0_ATI = 34668;
	public static final int GL_VERTEX_STREAM1_ATI = 34669;
	public static final int GL_VERTEX_STREAM2_ATI = 34670;
	public static final int GL_VERTEX_STREAM3_ATI = 34671;
	public static final int GL_VERTEX_STREAM4_ATI = 34672;
	public static final int GL_VERTEX_STREAM5_ATI = 34673;
	public static final int GL_VERTEX_STREAM6_ATI = 34674;
	public static final int GL_VERTEX_STREAM7_ATI = 34675;
	public static final int GL_VERTEX_SOURCE_ATI = 34676;
	public static final int GL_ELEMENT_ARRAY_ATI = 34664;
	public static final int GL_ELEMENT_ARRAY_TYPE_ATI = 34665;
	public static final int GL_ELEMENT_ARRAY_POINTER_ATI = 34666;
	public static final int GL_QUAD_MESH_SUN = 34324;
	public static final int GL_TRIANGLE_MESH_SUN = 34325;
	public static final int GL_SLICE_ACCUM_SUN = 34252;
	public static final int GL_MULTISAMPLE_FILTER_HINT_NV = 34100;
	public static final int GL_DEPTH_CLAMP_NV = 34383;
	public static final int GL_PIXEL_COUNTER_BITS_NV = 34916;
	public static final int GL_CURRENT_OCCLUSION_QUERY_ID_NV = 34917;
	public static final int GL_PIXEL_COUNT_NV = 34918;
	public static final int GL_PIXEL_COUNT_AVAILABLE_NV = 34919;
	public static final int GL_POINT_SPRITE_NV = 34913;
	public static final int GL_COORD_REPLACE_NV = 34914;
	public static final int GL_POINT_SPRITE_R_MODE_NV = 34915;
	public static final int GL_OFFSET_PROJECTIVE_TEXTURE_2D_NV = 34896;
	public static final int GL_OFFSET_PROJECTIVE_TEXTURE_2D_SCALE_NV = 34897;
	public static final int GL_OFFSET_PROJECTIVE_TEXTURE_RECTANGLE_NV = 34898;
	public static final int GL_OFFSET_PROJECTIVE_TEXTURE_RECTANGLE_SCALE_NV = 34899;
	public static final int GL_OFFSET_HILO_TEXTURE_2D_NV = 34900;
	public static final int GL_OFFSET_HILO_TEXTURE_RECTANGLE_NV = 34901;
	public static final int GL_OFFSET_HILO_PROJECTIVE_TEXTURE_2D_NV = 34902;
	public static final int GL_OFFSET_HILO_PROJECTIVE_TEXTURE_RECTANGLE_NV = 34903;
	public static final int GL_DEPENDENT_HILO_TEXTURE_2D_NV = 34904;
	public static final int GL_DEPENDENT_RGB_TEXTURE_3D_NV = 34905;
	public static final int GL_DEPENDENT_RGB_TEXTURE_CUBE_MAP_NV = 34906;
	public static final int GL_DOT_PRODUCT_PASS_THROUGH_NV = 34907;
	public static final int GL_DOT_PRODUCT_TEXTURE_1D_NV = 34908;
	public static final int GL_DOT_PRODUCT_AFFINE_DEPTH_REPLACE_NV = 34909;
	public static final int GL_HILO8_NV = 34910;
	public static final int GL_SIGNED_HILO8_NV = 34911;
	public static final int GL_FORCE_BLUE_TO_ONE_NV = 34912;
	public static final int GL_STENCIL_TEST_TWO_SIDE_EXT = 35088;
	public static final int GL_ACTIVE_STENCIL_FACE_EXT = 35089;
	public static final int GL_TEXT_FRAGMENT_SHADER_ATI = 33280;
	public static final int GL_UNPACK_CLIENT_STORAGE_APPLE = 34226;
	public static final int GL_ELEMENT_ARRAY_APPLE = 34664;
	public static final int GL_ELEMENT_ARRAY_TYPE_APPLE = 34665;
	public static final int GL_ELEMENT_ARRAY_POINTER_APPLE = 34666;
	public static final int GL_DRAW_PIXELS_APPLE = 35338;
	public static final int GL_FENCE_APPLE = 35339;
	public static final int GL_VERTEX_ARRAY_BINDING_APPLE = 34229;
	public static final int GL_VERTEX_ARRAY_RANGE_APPLE = 34077;
	public static final int GL_VERTEX_ARRAY_RANGE_LENGTH_APPLE = 34078;
	public static final int GL_MAX_VERTEX_ARRAY_RANGE_ELEMENT_APPLE = 34080;
	public static final int GL_VERTEX_ARRAY_RANGE_POINTER_APPLE = 34081;
	public static final int GL_VERTEX_ARRAY_STORAGE_HINT_APPLE = 34079;
	public static final int GL_STORAGE_PRIVATE_APPLE = 34237;
	public static final int GL_STORAGE_CACHED_APPLE = 34238;
	public static final int GL_STORAGE_SHARED_APPLE = 34239;
	public static final int GL_YCBCR_422_APPLE = 34233;
	public static final int GL_UNSIGNED_SHORT_8_8_APPLE = 34234;
	public static final int GL_UNSIGNED_SHORT_8_8_REV_APPLE = 34235;
	public static final int GL_RGB_S3TC = 33696;
	public static final int GL_RGB4_S3TC = 33697;
	public static final int GL_RGBA_S3TC = 33698;
	public static final int GL_RGBA4_S3TC = 33699;
	public static final int GL_MAX_DRAW_BUFFERS_ATI = 34852;
	public static final int GL_DRAW_BUFFER0_ATI = 34853;
	public static final int GL_DRAW_BUFFER1_ATI = 34854;
	public static final int GL_DRAW_BUFFER2_ATI = 34855;
	public static final int GL_DRAW_BUFFER3_ATI = 34856;
	public static final int GL_DRAW_BUFFER4_ATI = 34857;
	public static final int GL_DRAW_BUFFER5_ATI = 34858;
	public static final int GL_DRAW_BUFFER6_ATI = 34859;
	public static final int GL_DRAW_BUFFER7_ATI = 34860;
	public static final int GL_DRAW_BUFFER8_ATI = 34861;
	public static final int GL_DRAW_BUFFER9_ATI = 34862;
	public static final int GL_DRAW_BUFFER10_ATI = 34863;
	public static final int GL_DRAW_BUFFER11_ATI = 34864;
	public static final int GL_DRAW_BUFFER12_ATI = 34865;
	public static final int GL_DRAW_BUFFER13_ATI = 34866;
	public static final int GL_DRAW_BUFFER14_ATI = 34867;
	public static final int GL_DRAW_BUFFER15_ATI = 34868;
	public static final int GL_TYPE_RGBA_FLOAT_ATI = 34848;
	public static final int GL_COLOR_CLEAR_UNCLAMPED_VALUE_ATI = 34869;
	public static final int GL_MODULATE_ADD_ATI = 34628;
	public static final int GL_MODULATE_SIGNED_ADD_ATI = 34629;
	public static final int GL_MODULATE_SUBTRACT_ATI = 34630;
	public static final int GL_RGBA_FLOAT32_ATI = 34836;
	public static final int GL_RGB_FLOAT32_ATI = 34837;
	public static final int GL_ALPHA_FLOAT32_ATI = 34838;
	public static final int GL_INTENSITY_FLOAT32_ATI = 34839;
	public static final int GL_LUMINANCE_FLOAT32_ATI = 34840;
	public static final int GL_LUMINANCE_ALPHA_FLOAT32_ATI = 34841;
	public static final int GL_RGBA_FLOAT16_ATI = 34842;
	public static final int GL_RGB_FLOAT16_ATI = 34843;
	public static final int GL_ALPHA_FLOAT16_ATI = 34844;
	public static final int GL_INTENSITY_FLOAT16_ATI = 34845;
	public static final int GL_LUMINANCE_FLOAT16_ATI = 34846;
	public static final int GL_LUMINANCE_ALPHA_FLOAT16_ATI = 34847;
	public static final int GL_FLOAT_R_NV = 34944;
	public static final int GL_FLOAT_RG_NV = 34945;
	public static final int GL_FLOAT_RGB_NV = 34946;
	public static final int GL_FLOAT_RGBA_NV = 34947;
	public static final int GL_FLOAT_R16_NV = 34948;
	public static final int GL_FLOAT_R32_NV = 34949;
	public static final int GL_FLOAT_RG16_NV = 34950;
	public static final int GL_FLOAT_RG32_NV = 34951;
	public static final int GL_FLOAT_RGB16_NV = 34952;
	public static final int GL_FLOAT_RGB32_NV = 34953;
	public static final int GL_FLOAT_RGBA16_NV = 34954;
	public static final int GL_FLOAT_RGBA32_NV = 34955;
	public static final int GL_TEXTURE_FLOAT_COMPONENTS_NV = 34956;
	public static final int GL_FLOAT_CLEAR_COLOR_VALUE_NV = 34957;
	public static final int GL_FLOAT_RGBA_MODE_NV = 34958;
	public static final int GL_MAX_FRAGMENT_PROGRAM_LOCAL_PARAMETERS_NV = 34920;
	public static final int GL_FRAGMENT_PROGRAM_NV = 34928;
	public static final int GL_MAX_TEXTURE_COORDS_NV = 34929;
	public static final int GL_MAX_TEXTURE_IMAGE_UNITS_NV = 34930;
	public static final int GL_FRAGMENT_PROGRAM_BINDING_NV = 34931;
	public static final int GL_PROGRAM_ERROR_STRING_NV = 34932;
	public static final int GL_HALF_FLOAT_NV = 5131;
	public static final int GL_WRITE_PIXEL_DATA_RANGE_NV = 34936;
	public static final int GL_READ_PIXEL_DATA_RANGE_NV = 34937;
	public static final int GL_WRITE_PIXEL_DATA_RANGE_LENGTH_NV = 34938;
	public static final int GL_READ_PIXEL_DATA_RANGE_LENGTH_NV = 34939;
	public static final int GL_WRITE_PIXEL_DATA_RANGE_POINTER_NV = 34940;
	public static final int GL_READ_PIXEL_DATA_RANGE_POINTER_NV = 34941;
	public static final int GL_PRIMITIVE_RESTART_NV = 34136;
	public static final int GL_PRIMITIVE_RESTART_INDEX_NV = 34137;
	public static final int GL_TEXTURE_UNSIGNED_REMAP_MODE_NV = 34959;
	public static final int GL_STENCIL_BACK_FUNC_ATI = 34816;
	public static final int GL_STENCIL_BACK_FAIL_ATI = 34817;
	public static final int GL_STENCIL_BACK_PASS_DEPTH_FAIL_ATI = 34818;
	public static final int GL_STENCIL_BACK_PASS_DEPTH_PASS_ATI = 34819;
	public static final int GL_IMPLEMENTATION_COLOR_READ_TYPE_OES = 35738;
	public static final int GL_IMPLEMENTATION_COLOR_READ_FORMAT_OES = 35739;
	public static final int GL_DEPTH_BOUNDS_TEST_EXT = 34960;
	public static final int GL_DEPTH_BOUNDS_EXT = 34961;
	public static final int GL_MIRROR_CLAMP_EXT = 34626;
	public static final int GL_MIRROR_CLAMP_TO_EDGE_EXT = 34627;
	public static final int GL_MIRROR_CLAMP_TO_BORDER_EXT = 35090;
	public static final int GL_BLEND_EQUATION_RGB_EXT = 32777;
	public static final int GL_BLEND_EQUATION_ALPHA_EXT = 34877;
	public static final int GL_PACK_INVERT_MESA = 34648;
	public static final int GL_UNSIGNED_SHORT_8_8_MESA = 34234;
	public static final int GL_UNSIGNED_SHORT_8_8_REV_MESA = 34235;
	public static final int GL_YCBCR_MESA = 34647;
	public static final int GL_PIXEL_PACK_BUFFER_EXT = 35051;
	public static final int GL_PIXEL_UNPACK_BUFFER_EXT = 35052;
	public static final int GL_PIXEL_PACK_BUFFER_BINDING_EXT = 35053;
	public static final int GL_PIXEL_UNPACK_BUFFER_BINDING_EXT = 35055;
	public static final int GL_MAX_PROGRAM_EXEC_INSTRUCTIONS_NV = 35060;
	public static final int GL_MAX_PROGRAM_CALL_DEPTH_NV = 35061;
	public static final int GL_MAX_PROGRAM_IF_DEPTH_NV = 35062;
	public static final int GL_MAX_PROGRAM_LOOP_DEPTH_NV = 35063;
	public static final int GL_MAX_PROGRAM_LOOP_COUNT_NV = 35064;
	public static final int GL_INVALID_FRAMEBUFFER_OPERATION_EXT = 1286;
	public static final int GL_MAX_RENDERBUFFER_SIZE_EXT = 34024;
	public static final int GL_FRAMEBUFFER_BINDING_EXT = 36006;
	public static final int GL_RENDERBUFFER_BINDING_EXT = 36007;
	public static final int GL_FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE_EXT = 36048;
	public static final int GL_FRAMEBUFFER_ATTACHMENT_OBJECT_NAME_EXT = 36049;
	public static final int GL_FRAMEBUFFER_ATTACHMENT_TEXTURE_LEVEL_EXT = 36050;
	public static final int GL_FRAMEBUFFER_ATTACHMENT_TEXTURE_CUBE_MAP_FACE_EXT = 36051;
	public static final int GL_FRAMEBUFFER_ATTACHMENT_TEXTURE_3D_ZOFFSET_EXT = 36052;
	public static final int GL_FRAMEBUFFER_COMPLETE_EXT = 36053;
	public static final int GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT_EXT = 36054;
	public static final int GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT_EXT = 36055;
	public static final int GL_FRAMEBUFFER_INCOMPLETE_DUPLICATE_ATTACHMENT_EXT = 36056;
	public static final int GL_FRAMEBUFFER_INCOMPLETE_DIMENSIONS_EXT = 36057;
	public static final int GL_FRAMEBUFFER_INCOMPLETE_FORMATS_EXT = 36058;
	public static final int GL_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER_EXT = 36059;
	public static final int GL_FRAMEBUFFER_INCOMPLETE_READ_BUFFER_EXT = 36060;
	public static final int GL_FRAMEBUFFER_UNSUPPORTED_EXT = 36061;
	public static final int GL_MAX_COLOR_ATTACHMENTS_EXT = 36063;
	public static final int GL_COLOR_ATTACHMENT0_EXT = 36064;
	public static final int GL_COLOR_ATTACHMENT1_EXT = 36065;
	public static final int GL_COLOR_ATTACHMENT2_EXT = 36066;
	public static final int GL_COLOR_ATTACHMENT3_EXT = 36067;
	public static final int GL_COLOR_ATTACHMENT4_EXT = 36068;
	public static final int GL_COLOR_ATTACHMENT5_EXT = 36069;
	public static final int GL_COLOR_ATTACHMENT6_EXT = 36070;
	public static final int GL_COLOR_ATTACHMENT7_EXT = 36071;
	public static final int GL_COLOR_ATTACHMENT8_EXT = 36072;
	public static final int GL_COLOR_ATTACHMENT9_EXT = 36073;
	public static final int GL_COLOR_ATTACHMENT10_EXT = 36074;
	public static final int GL_COLOR_ATTACHMENT11_EXT = 36075;
	public static final int GL_COLOR_ATTACHMENT12_EXT = 36076;
	public static final int GL_COLOR_ATTACHMENT13_EXT = 36077;
	public static final int GL_COLOR_ATTACHMENT14_EXT = 36078;
	public static final int GL_COLOR_ATTACHMENT15_EXT = 36079;
	public static final int GL_DEPTH_ATTACHMENT_EXT = 36096;
	public static final int GL_STENCIL_ATTACHMENT_EXT = 36128;
	public static final int GL_FRAMEBUFFER_EXT = 36160;
	public static final int GL_RENDERBUFFER_EXT = 36161;
	public static final int GL_RENDERBUFFER_WIDTH_EXT = 36162;
	public static final int GL_RENDERBUFFER_HEIGHT_EXT = 36163;
	public static final int GL_RENDERBUFFER_INTERNAL_FORMAT_EXT = 36164;
	public static final int GL_STENCIL_INDEX1_EXT = 36166;
	public static final int GL_STENCIL_INDEX4_EXT = 36167;
	public static final int GL_STENCIL_INDEX8_EXT = 36168;
	public static final int GL_STENCIL_INDEX16_EXT = 36169;
	public static final int GL_RENDERBUFFER_RED_SIZE_EXT = 36176;
	public static final int GL_RENDERBUFFER_GREEN_SIZE_EXT = 36177;
	public static final int GL_RENDERBUFFER_BLUE_SIZE_EXT = 36178;
	public static final int GL_RENDERBUFFER_ALPHA_SIZE_EXT = 36179;
	public static final int GL_RENDERBUFFER_DEPTH_SIZE_EXT = 36180;
	public static final int GL_RENDERBUFFER_STENCIL_SIZE_EXT = 36181;
	public static final int GL_DEPTH_STENCIL_EXT = 34041;
	public static final int GL_UNSIGNED_INT_24_8_EXT = 34042;
	public static final int GL_DEPTH24_STENCIL8_EXT = 35056;
	public static final int GL_TEXTURE_STENCIL_SIZE_EXT = 35057;
	public static final int GL_STENCIL_TAG_BITS_EXT = 35058;
	public static final int GL_STENCIL_CLEAR_TAG_VALUE_EXT = 35059;
	public static final int GL_SRGB_EXT = 35904;
	public static final int GL_SRGB8_EXT = 35905;
	public static final int GL_SRGB_ALPHA_EXT = 35906;
	public static final int GL_SRGB8_ALPHA8_EXT = 35907;
	public static final int GL_SLUMINANCE_ALPHA_EXT = 35908;
	public static final int GL_SLUMINANCE8_ALPHA8_EXT = 35909;
	public static final int GL_SLUMINANCE_EXT = 35910;
	public static final int GL_SLUMINANCE8_EXT = 35911;
	public static final int GL_COMPRESSED_SRGB_EXT = 35912;
	public static final int GL_COMPRESSED_SRGB_ALPHA_EXT = 35913;
	public static final int GL_COMPRESSED_SLUMINANCE_EXT = 35914;
	public static final int GL_COMPRESSED_SLUMINANCE_ALPHA_EXT = 35915;
	public static final int GL_COMPRESSED_SRGB_S3TC_DXT1_EXT = 35916;
	public static final int GL_COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT = 35917;
	public static final int GL_COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT = 35918;
	public static final int GL_COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT = 35919;
	public static final int GL_READ_FRAMEBUFFER_EXT = 36008;
	public static final int GL_DRAW_FRAMEBUFFER_EXT = 36009;
	public static final int GL_READ_FRAMEBUFFER_BINDING_EXT = 36006;
	public static final int GL_DRAW_FRAMEBUFFER_BINDING_EXT = 36010;
	public static final int GL_RENDERBUFFER_SAMPLES_EXT = 36011;
	public static final int GL_FRAMEBUFFER_INCOMPLETE_MULTISAMPLE_EXT = 36182;
	public static final int GL_MAX_SAMPLES_EXT = 36183;
	public static final int GL_TEXTURE_1D_STACK_MESAX = 34649;
	public static final int GL_TEXTURE_2D_STACK_MESAX = 34650;
	public static final int GL_PROXY_TEXTURE_1D_STACK_MESAX = 34651;
	public static final int GL_PROXY_TEXTURE_2D_STACK_MESAX = 34652;
	public static final int GL_TEXTURE_1D_STACK_BINDING_MESAX = 34653;
	public static final int GL_TEXTURE_2D_STACK_BINDING_MESAX = 34654;
	public static final int GL_TIME_ELAPSED_EXT = 35007;
	public static final int GL_BUFFER_SERIALIZED_MODIFY_APPLE = 35346;
	public static final int GL_BUFFER_FLUSHING_UNMAP_APPLE = 35347;
	public static final int GL_CG_VERTEX_SHADER_EXT = 35086;
	public static final int GL_CG_FRAGMENT_SHADER_EXT = 35087;
	public static final int GL_TEXTURE_BUFFER_EXT = 35882;
	public static final int GL_MAX_TEXTURE_BUFFER_SIZE_EXT = 35883;
	public static final int GL_TEXTURE_BINDING_BUFFER_EXT = 35884;
	public static final int GL_TEXTURE_BUFFER_DATA_STORE_BINDING_EXT = 35885;
	public static final int GL_TEXTURE_BUFFER_FORMAT_EXT = 35886;
	public static final int GL_SAMPLER_1D_ARRAY_EXT = 36288;
	public static final int GL_SAMPLER_2D_ARRAY_EXT = 36289;
	public static final int GL_SAMPLER_BUFFER_EXT = 36290;
	public static final int GL_SAMPLER_1D_ARRAY_SHADOW_EXT = 36291;
	public static final int GL_SAMPLER_2D_ARRAY_SHADOW_EXT = 36292;
	public static final int GL_SAMPLER_CUBE_SHADOW_EXT = 36293;
	public static final int GL_UNSIGNED_INT_VEC2_EXT = 36294;
	public static final int GL_UNSIGNED_INT_VEC3_EXT = 36295;
	public static final int GL_UNSIGNED_INT_VEC4_EXT = 36296;
	public static final int GL_INT_SAMPLER_1D_EXT = 36297;
	public static final int GL_INT_SAMPLER_2D_EXT = 36298;
	public static final int GL_INT_SAMPLER_3D_EXT = 36299;
	public static final int GL_INT_SAMPLER_CUBE_EXT = 36300;
	public static final int GL_INT_SAMPLER_2D_RECT_EXT = 36301;
	public static final int GL_INT_SAMPLER_1D_ARRAY_EXT = 36302;
	public static final int GL_INT_SAMPLER_2D_ARRAY_EXT = 36303;
	public static final int GL_INT_SAMPLER_BUFFER_EXT = 36304;
	public static final int GL_UNSIGNED_INT_SAMPLER_1D_EXT = 36305;
	public static final int GL_UNSIGNED_INT_SAMPLER_2D_EXT = 36306;
	public static final int GL_UNSIGNED_INT_SAMPLER_3D_EXT = 36307;
	public static final int GL_UNSIGNED_INT_SAMPLER_CUBE_EXT = 36308;
	public static final int GL_UNSIGNED_INT_SAMPLER_2D_RECT_EXT = 36309;
	public static final int GL_UNSIGNED_INT_SAMPLER_1D_ARRAY_EXT = 36310;
	public static final int GL_UNSIGNED_INT_SAMPLER_2D_ARRAY_EXT = 36311;
	public static final int GL_UNSIGNED_INT_SAMPLER_BUFFER_EXT = 36312;
	public static final int GL_VERTEX_ATTRIB_ARRAY_INTEGER_EXT = 35069;
	public static final int GL_GEOMETRY_SHADER_EXT = 36313;
	public static final int GL_MAX_GEOMETRY_VARYING_COMPONENTS_EXT = 36317;
	public static final int GL_MAX_VERTEX_VARYING_COMPONENTS_EXT = 36318;
	public static final int GL_MAX_VARYING_COMPONENTS_EXT = 35659;
	public static final int GL_MAX_GEOMETRY_UNIFORM_COMPONENTS_EXT = 36319;
	public static final int GL_MAX_GEOMETRY_OUTPUT_VERTICES_EXT = 36320;
	public static final int GL_MAX_GEOMETRY_TOTAL_OUTPUT_COMPONENTS_EXT = 36321;
	public static final int GL_GEOMETRY_VERTICES_OUT_EXT = 36314;
	public static final int GL_GEOMETRY_INPUT_TYPE_EXT = 36315;
	public static final int GL_GEOMETRY_OUTPUT_TYPE_EXT = 36316;
	public static final int GL_MAX_GEOMETRY_TEXTURE_IMAGE_UNITS_EXT = 35881;
	public static final int GL_LINES_ADJACENCY_EXT = 10;
	public static final int GL_LINE_STRIP_ADJACENCY_EXT = 11;
	public static final int GL_TRIANGLES_ADJACENCY_EXT = 12;
	public static final int GL_TRIANGLE_STRIP_ADJACENCY_EXT = 13;
	public static final int GL_FRAMEBUFFER_ATTACHMENT_LAYERED_EXT = 36263;
	public static final int GL_FRAMEBUFFER_INCOMPLETE_LAYER_TARGETS_EXT = 36264;
	public static final int GL_FRAMEBUFFER_INCOMPLETE_LAYER_COUNT_EXT = 36265;
	public static final int GL_FRAMEBUFFER_ATTACHMENT_TEXTURE_LAYER_EXT = 36052;
	public static final int GL_PROGRAM_POINT_SIZE_EXT = 34370;
	public static final int GL_MAX_VERTEX_BINDABLE_UNIFORMS_EXT = 36322;
	public static final int GL_MAX_FRAGMENT_BINDABLE_UNIFORMS_EXT = 36323;
	public static final int GL_MAX_GEOMETRY_BINDABLE_UNIFORMS_EXT = 36324;
	public static final int GL_MAX_BINDABLE_UNIFORM_SIZE_EXT = 36333;
	public static final int GL_UNIFORM_BUFFER_EXT = 36334;
	public static final int GL_UNIFORM_BUFFER_BINDING_EXT = 36335;
	public static final int GL_FRAMEBUFFER_SRGB_EXT = 36281;
	public static final int GL_FRAMEBUFFER_SRGB_CAPABLE_EXT = 36282;
	public static final int GL_RGB9_E5_EXT = 35901;
	public static final int GL_UNSIGNED_INT_5_9_9_9_REV_EXT = 35902;
	public static final int GL_TEXTURE_SHARED_SIZE_EXT = 35903;
	public static final int GL_R11F_G11F_B10F_EXT = 35898;
	public static final int GL_UNSIGNED_INT_10F_11F_11F_REV_EXT = 35899;
	public static final int GL_RGBA_SIGNED_COMPONENTS_EXT = 35900;
	public static final int GL_TEXTURE_1D_ARRAY_EXT = 35864;
	public static final int GL_PROXY_TEXTURE_1D_ARRAY_EXT = 35865;
	public static final int GL_TEXTURE_2D_ARRAY_EXT = 35866;
	public static final int GL_PROXY_TEXTURE_2D_ARRAY_EXT = 35867;
	public static final int GL_TEXTURE_BINDING_1D_ARRAY_EXT = 35868;
	public static final int GL_TEXTURE_BINDING_2D_ARRAY_EXT = 35869;
	public static final int GL_MAX_ARRAY_TEXTURE_LAYERS_EXT = 35071;
	public static final int GL_COMPARE_REF_DEPTH_TO_TEXTURE_EXT = 34894;
	public static final int GL_RGBA32UI_EXT = 36208;
	public static final int GL_RGB32UI_EXT = 36209;
	public static final int GL_ALPHA32UI_EXT = 36210;
	public static final int GL_INTENSITY32UI_EXT = 36211;
	public static final int GL_LUMINANCE32UI_EXT = 36212;
	public static final int GL_LUMINANCE_ALPHA32UI_EXT = 36213;
	public static final int GL_RGBA16UI_EXT = 36214;
	public static final int GL_RGB16UI_EXT = 36215;
	public static final int GL_ALPHA16UI_EXT = 36216;
	public static final int GL_INTENSITY16UI_EXT = 36217;
	public static final int GL_LUMINANCE16UI_EXT = 36218;
	public static final int GL_LUMINANCE_ALPHA16UI_EXT = 36219;
	public static final int GL_RGBA8UI_EXT = 36220;
	public static final int GL_RGB8UI_EXT = 36221;
	public static final int GL_ALPHA8UI_EXT = 36222;
	public static final int GL_INTENSITY8UI_EXT = 36223;
	public static final int GL_LUMINANCE8UI_EXT = 36224;
	public static final int GL_LUMINANCE_ALPHA8UI_EXT = 36225;
	public static final int GL_RGBA32I_EXT = 36226;
	public static final int GL_RGB32I_EXT = 36227;
	public static final int GL_ALPHA32I_EXT = 36228;
	public static final int GL_INTENSITY32I_EXT = 36229;
	public static final int GL_LUMINANCE32I_EXT = 36230;
	public static final int GL_LUMINANCE_ALPHA32I_EXT = 36231;
	public static final int GL_RGBA16I_EXT = 36232;
	public static final int GL_RGB16I_EXT = 36233;
	public static final int GL_ALPHA16I_EXT = 36234;
	public static final int GL_INTENSITY16I_EXT = 36235;
	public static final int GL_LUMINANCE16I_EXT = 36236;
	public static final int GL_LUMINANCE_ALPHA16I_EXT = 36237;
	public static final int GL_RGBA8I_EXT = 36238;
	public static final int GL_RGB8I_EXT = 36239;
	public static final int GL_ALPHA8I_EXT = 36240;
	public static final int GL_INTENSITY8I_EXT = 36241;
	public static final int GL_LUMINANCE8I_EXT = 36242;
	public static final int GL_LUMINANCE_ALPHA8I_EXT = 36243;
	public static final int GL_RED_INTEGER_EXT = 36244;
	public static final int GL_GREEN_INTEGER_EXT = 36245;
	public static final int GL_BLUE_INTEGER_EXT = 36246;
	public static final int GL_ALPHA_INTEGER_EXT = 36247;
	public static final int GL_RGB_INTEGER_EXT = 36248;
	public static final int GL_RGBA_INTEGER_EXT = 36249;
	public static final int GL_BGR_INTEGER_EXT = 36250;
	public static final int GL_BGRA_INTEGER_EXT = 36251;
	public static final int GL_LUMINANCE_INTEGER_EXT = 36252;
	public static final int GL_LUMINANCE_ALPHA_INTEGER_EXT = 36253;
	public static final int GL_RGBA_INTEGER_MODE_EXT = 36254;
	public static final int GL_DEPTH_COMPONENT32F_NV = 36267;
	public static final int GL_DEPTH32F_STENCIL8_NV = 36268;
	public static final int GL_FLOAT_32_UNSIGNED_INT_24_8_REV_NV = 36269;
	public static final int GL_DEPTH_BUFFER_FLOAT_MODE_NV = 36271;
	public static final int GL_COMPRESSED_LUMINANCE_LATC1_EXT = 35952;
	public static final int GL_COMPRESSED_SIGNED_LUMINANCE_LATC1_EXT = 35953;
	public static final int GL_COMPRESSED_LUMINANCE_ALPHA_LATC2_EXT = 35954;
	public static final int GL_COMPRESSED_SIGNED_LUMINANCE_ALPHA_LATC2_EXT = 35955;
	public static final int GL_BACK_PRIMARY_COLOR_NV = 35959;
	public static final int GL_BACK_SECONDARY_COLOR_NV = 35960;
	public static final int GL_TEXTURE_COORD_NV = 35961;
	public static final int GL_CLIP_DISTANCE_NV = 35962;
	public static final int GL_VERTEX_ID_NV = 35963;
	public static final int GL_PRIMITIVE_ID_NV = 35964;
	public static final int GL_GENERIC_ATTRIB_NV = 35965;
	public static final int GL_TRANSFORM_FEEDBACK_ATTRIBS_NV = 35966;
	public static final int GL_TRANSFORM_FEEDBACK_BUFFER_MODE_NV = 35967;
	public static final int GL_MAX_TRANSFORM_FEEDBACK_SEPARATE_COMPONENTS_NV = 35968;
	public static final int GL_ACTIVE_VARYINGS_NV = 35969;
	public static final int GL_ACTIVE_VARYING_MAX_LENGTH_NV = 35970;
	public static final int GL_TRANSFORM_FEEDBACK_VARYINGS_NV = 35971;
	public static final int GL_TRANSFORM_FEEDBACK_BUFFER_START_NV = 35972;
	public static final int GL_TRANSFORM_FEEDBACK_BUFFER_SIZE_NV = 35973;
	public static final int GL_TRANSFORM_FEEDBACK_RECORD_NV = 35974;
	public static final int GL_PRIMITIVES_GENERATED_NV = 35975;
	public static final int GL_TRANSFORM_FEEDBACK_PRIMITIVES_WRITTEN_NV = 35976;
	public static final int GL_RASTERIZER_DISCARD_NV = 35977;
	public static final int GL_MAX_TRANSFORM_FEEDBACK_INTERLEAVED_ATTRIBS_NV = 35978;
	public static final int GL_MAX_TRANSFORM_FEEDBACK_SEPARATE_ATTRIBS_NV = 35979;
	public static final int GL_INTERLEAVED_ATTRIBS_NV = 35980;
	public static final int GL_SEPARATE_ATTRIBS_NV = 35981;
	public static final int GL_TRANSFORM_FEEDBACK_BUFFER_NV = 35982;
	public static final int GL_TRANSFORM_FEEDBACK_BUFFER_BINDING_NV = 35983;
	public static final int GL_GEOMETRY_PROGRAM_NV = 35878;
	public static final int GL_MAX_PROGRAM_OUTPUT_VERTICES_NV = 35879;
	public static final int GL_MAX_PROGRAM_TOTAL_OUTPUT_COMPONENTS_NV = 35880;
	public static final int GL_MIN_PROGRAM_TEXEL_OFFSET_NV = 35076;
	public static final int GL_MAX_PROGRAM_TEXEL_OFFSET_NV = 35077;
	public static final int GL_PROGRAM_ATTRIB_COMPONENTS_NV = 35078;
	public static final int GL_PROGRAM_RESULT_COMPONENTS_NV = 35079;
	public static final int GL_MAX_PROGRAM_ATTRIB_COMPONENTS_NV = 35080;
	public static final int GL_MAX_PROGRAM_RESULT_COMPONENTS_NV = 35081;
	public static final int GL_MAX_PROGRAM_GENERIC_ATTRIBS_NV = 36261;
	public static final int GL_MAX_PROGRAM_GENERIC_RESULTS_NV = 36262;
	public static final int GL_RENDERBUFFER_COVERAGE_SAMPLES_NV = 36011;
	public static final int GL_RENDERBUFFER_COLOR_SAMPLES_NV = 36368;
	public static final int GL_MAX_RENDERBUFFER_COVERAGE_SAMPLES_NV = 36183;
	public static final int GL_MAX_RENDERBUFFER_COLOR_SAMPLES_NV = 36369;
	public static final int GL_MAX_MULTISAMPLE_COVERAGE_MODES_NV = 36370;
	public static final int GL_MULTISAMPLE_COVERAGE_MODES_NV = 36371;
	public static final int GL_COMPRESSED_RED_RGTC1_EXT = 36283;
	public static final int GL_COMPRESSED_SIGNED_RED_RGTC1_EXT = 36284;
	public static final int GL_COMPRESSED_RED_GREEN_RGTC2_EXT = 36285;
	public static final int GL_COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT = 36286;
	public static final int GL_OES_read_format = 1;
	public static final int GL_GREMEDY_string_marker = 1;
	public static final int GL_MESAX_texture_stack = 1;
	public static final int GL_KTX_FRONT_REGION = 0;
	public static final int GL_KTX_BACK_REGION = 1;
	public static final int GL_KTX_Z_REGION = 2;
	public static final int GL_KTX_STENCIL_REGION = 3;
	public static final int GL_TEXTURE_RANGE_LENGTH_APPLE = 34231;
	public static final int GL_TEXTURE_RANGE_POINTER_APPLE = 34232;
	public static final int GL_TEXTURE_STORAGE_HINT_APPLE = 34236;
	public static final int GL_TEXTURE_MINIMIZE_STORAGE_APPLE = 34230;
	public static final int GL_HALF_APPLE = 5131;
	public static final int GL_COLOR_FLOAT_APPLE = 35343;
	public static final int GL_RGBA_FLOAT32_APPLE = 34836;
	public static final int GL_RGB_FLOAT32_APPLE = 34837;
	public static final int GL_ALPHA_FLOAT32_APPLE = 34838;
	public static final int GL_INTENSITY_FLOAT32_APPLE = 34839;
	public static final int GL_LUMINANCE_FLOAT32_APPLE = 34840;
	public static final int GL_LUMINANCE_ALPHA_FLOAT32_APPLE = 34841;
	public static final int GL_RGBA_FLOAT16_APPLE = 34842;
	public static final int GL_RGB_FLOAT16_APPLE = 34843;
	public static final int GL_ALPHA_FLOAT16_APPLE = 34844;
	public static final int GL_INTENSITY_FLOAT16_APPLE = 34845;
	public static final int GL_LUMINANCE_FLOAT16_APPLE = 34846;
	public static final int GL_LUMINANCE_ALPHA_FLOAT16_APPLE = 34847;
	public static final int GL_MIN_PBUFFER_VIEWPORT_DIMS_APPLE = 35344;
	public static final int GL_VERTEX_ATTRIB_MAP1_APPLE = 35328;
	public static final int GL_VERTEX_ATTRIB_MAP2_APPLE = 35329;
	public static final int GL_VERTEX_ATTRIB_MAP1_SIZE_APPLE = 35330;
	public static final int GL_VERTEX_ATTRIB_MAP1_COEFF_APPLE = 35331;
	public static final int GL_VERTEX_ATTRIB_MAP1_ORDER_APPLE = 35332;
	public static final int GL_VERTEX_ATTRIB_MAP1_DOMAIN_APPLE = 35333;
	public static final int GL_VERTEX_ATTRIB_MAP2_SIZE_APPLE = 35334;
	public static final int GL_VERTEX_ATTRIB_MAP2_COEFF_APPLE = 35335;
	public static final int GL_VERTEX_ATTRIB_MAP2_ORDER_APPLE = 35336;
	public static final int GL_VERTEX_ATTRIB_MAP2_DOMAIN_APPLE = 35337;
	
	public static void glAccum(int arg0, float arg1){ gl.glAccum(arg0, arg1); }
	public static void glActiveStencilFaceEXT(int arg0){ gl.glActiveStencilFaceEXT(arg0); }
	public static void glActiveTexture(int arg0){ gl.glActiveTexture(arg0); }
	public static void glActiveVaryingNV(int arg0, java.nio.ByteBuffer arg1){ gl.glActiveVaryingNV(arg0, arg1); }
	public static void glActiveVaryingNV(int arg0, byte[] arg1, int arg2){ gl.glActiveVaryingNV(arg0, arg1, arg2); }
	public static void glAlphaFragmentOp1ATI(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5){ gl.glAlphaFragmentOp1ATI(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glAlphaFragmentOp2ATI(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6, int arg7, int arg8){ gl.glAlphaFragmentOp2ATI(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8); }
	public static void glAlphaFragmentOp3ATI(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6, int arg7, int arg8, int arg9, int arg10, int arg11){ gl.glAlphaFragmentOp3ATI(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11); }
	public static void glAlphaFunc(int arg0, float arg1){ gl.glAlphaFunc(arg0, arg1); }
	public static void glApplyTextureEXT(int arg0){ gl.glApplyTextureEXT(arg0); }
	public static boolean glAreProgramsResidentNV(int arg0, java.nio.IntBuffer arg1, java.nio.ByteBuffer arg2){return gl.glAreProgramsResidentNV(arg0, arg1, arg2); }
	public static boolean glAreProgramsResidentNV(int arg0, int[] arg1, int arg2, byte[] arg3, int arg4){return gl.glAreProgramsResidentNV(arg0, arg1, arg2, arg3, arg4); }
	public static boolean glAreTexturesResident(int arg0, java.nio.IntBuffer arg1, java.nio.ByteBuffer arg2){return gl.glAreTexturesResident(arg0, arg1, arg2); }
	public static boolean glAreTexturesResident(int arg0, int[] arg1, int arg2, byte[] arg3, int arg4){return gl.glAreTexturesResident(arg0, arg1, arg2, arg3, arg4); }
	public static void glArrayElement(int arg0){ gl.glArrayElement(arg0); }
	public static void glArrayObjectATI(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5){ gl.glArrayObjectATI(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glAsyncMarkerSGIX(int arg0){ gl.glAsyncMarkerSGIX(arg0); }
	public static void glAttachObjectARB(int arg0, int arg1){ gl.glAttachObjectARB(arg0, arg1); }
	public static void glAttachShader(int arg0, int arg1){ gl.glAttachShader(arg0, arg1); }
	public static void glBegin(int arg0){ gl.glBegin(arg0); }
	public static void glBeginFragmentShaderATI(){ gl.glBeginFragmentShaderATI(); }
	public static void glBeginOcclusionQueryNV(int arg0){ gl.glBeginOcclusionQueryNV(arg0); }
	public static void glBeginQuery(int arg0, int arg1){ gl.glBeginQuery(arg0, arg1); }
	public static void glBeginQueryARB(int arg0, int arg1){ gl.glBeginQueryARB(arg0, arg1); }
	public static void glBeginTransformFeedbackNV(int arg0){ gl.glBeginTransformFeedbackNV(arg0); }
	public static void glBeginVertexShaderEXT(){ gl.glBeginVertexShaderEXT(); }
	public static void glBindAttribLocation(int arg0, int arg1, java.lang.String arg2){ gl.glBindAttribLocation(arg0, arg1, arg2); }
	public static void glBindAttribLocationARB(int arg0, int arg1, java.lang.String arg2){ gl.glBindAttribLocationARB(arg0, arg1, arg2); }
	public static void glBindBuffer(int arg0, int arg1){ gl.glBindBuffer(arg0, arg1); }
	public static void glBindBufferARB(int arg0, int arg1){ gl.glBindBufferARB(arg0, arg1); }
	public static void glBindBufferBaseNV(int arg0, int arg1, int arg2){ gl.glBindBufferBaseNV(arg0, arg1, arg2); }
	public static void glBindBufferOffsetNV(int arg0, int arg1, int arg2, int arg3){ gl.glBindBufferOffsetNV(arg0, arg1, arg2, arg3); }
	public static void glBindBufferRangeNV(int arg0, int arg1, int arg2, int arg3, int arg4){ gl.glBindBufferRangeNV(arg0, arg1, arg2, arg3, arg4); }
	public static void glBindFragDataLocationEXT(int arg0, int arg1, java.nio.ByteBuffer arg2){ gl.glBindFragDataLocationEXT(arg0, arg1, arg2); }
	public static void glBindFragDataLocationEXT(int arg0, int arg1, byte[] arg2, int arg3){ gl.glBindFragDataLocationEXT(arg0, arg1, arg2, arg3); }
	public static void glBindFragmentShaderATI(int arg0){ gl.glBindFragmentShaderATI(arg0); }
	public static void glBindFramebufferEXT(int arg0, int arg1){ gl.glBindFramebufferEXT(arg0, arg1); }
	public static int glBindLightParameterEXT(int arg0, int arg1){return gl.glBindLightParameterEXT(arg0, arg1); }
	public static int glBindMaterialParameterEXT(int arg0, int arg1){return gl.glBindMaterialParameterEXT(arg0, arg1); }
	public static int glBindParameterEXT(int arg0){return gl.glBindParameterEXT(arg0); }
	public static void glBindProgramARB(int arg0, int arg1){ gl.glBindProgramARB(arg0, arg1); }
	public static void glBindProgramNV(int arg0, int arg1){ gl.glBindProgramNV(arg0, arg1); }
	public static void glBindRenderbufferEXT(int arg0, int arg1){ gl.glBindRenderbufferEXT(arg0, arg1); }
	public static int glBindTexGenParameterEXT(int arg0, int arg1, int arg2){return gl.glBindTexGenParameterEXT(arg0, arg1, arg2); }
	public static void glBindTexture(int arg0, int arg1){ gl.glBindTexture(arg0, arg1); }
	public static int glBindTextureUnitParameterEXT(int arg0, int arg1){return gl.glBindTextureUnitParameterEXT(arg0, arg1); }
	public static void glBindVertexArrayAPPLE(int arg0){ gl.glBindVertexArrayAPPLE(arg0); }
	public static void glBindVertexShaderEXT(int arg0){ gl.glBindVertexShaderEXT(arg0); }
	public static void glBitmap(int arg0, int arg1, float arg2, float arg3, float arg4, float arg5, java.nio.ByteBuffer arg6){ gl.glBitmap(arg0, arg1, arg2, arg3, arg4, arg5, arg6); }
	public static void glBitmap(int arg0, int arg1, float arg2, float arg3, float arg4, float arg5, byte[] arg6, int arg7){ gl.glBitmap(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7); }
	public static void glBitmap(int arg0, int arg1, float arg2, float arg3, float arg4, float arg5, long arg6){ gl.glBitmap(arg0, arg1, arg2, arg3, arg4, arg5, arg6); }
	public static void glBlendColor(float arg0, float arg1, float arg2, float arg3){ gl.glBlendColor(arg0, arg1, arg2, arg3); }
	public static void glBlendEquation(int arg0){ gl.glBlendEquation(arg0); }
	public static void glBlendEquationSeparate(int arg0, int arg1){ gl.glBlendEquationSeparate(arg0, arg1); }
	public static void glBlendEquationSeparateEXT(int arg0, int arg1){ gl.glBlendEquationSeparateEXT(arg0, arg1); }
	public static void glBlendFunc(int arg0, int arg1){ gl.glBlendFunc(arg0, arg1); }
	public static void glBlendFuncSeparate(int arg0, int arg1, int arg2, int arg3){ gl.glBlendFuncSeparate(arg0, arg1, arg2, arg3); }
	public static void glBlendFuncSeparateEXT(int arg0, int arg1, int arg2, int arg3){ gl.glBlendFuncSeparateEXT(arg0, arg1, arg2, arg3); }
	public static void glBlendFuncSeparateINGR(int arg0, int arg1, int arg2, int arg3){ gl.glBlendFuncSeparateINGR(arg0, arg1, arg2, arg3); }
	public static void glBlitFramebufferEXT(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6, int arg7, int arg8, int arg9){ gl.glBlitFramebufferEXT(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9); }
	public static void glBufferData(int arg0, int arg1, java.nio.Buffer arg2, int arg3){ gl.glBufferData(arg0, arg1, arg2, arg3); }
	public static void glBufferDataARB(int arg0, int arg1, java.nio.Buffer arg2, int arg3){ gl.glBufferDataARB(arg0, arg1, arg2, arg3); }
	public static void glBufferParameteriAPPLE(int arg0, int arg1, int arg2){ gl.glBufferParameteriAPPLE(arg0, arg1, arg2); }
	public static int glBufferRegionEnabled(){return gl.glBufferRegionEnabled(); }
	public static void glBufferSubData(int arg0, int arg1, int arg2, java.nio.Buffer arg3){ gl.glBufferSubData(arg0, arg1, arg2, arg3); }
	public static void glBufferSubDataARB(int arg0, int arg1, int arg2, java.nio.Buffer arg3){ gl.glBufferSubDataARB(arg0, arg1, arg2, arg3); }
	public static void glCallList(int arg0){ gl.glCallList(arg0); }
	public static void glCallLists(int arg0, int arg1, java.nio.Buffer arg2){ gl.glCallLists(arg0, arg1, arg2); }
	public static int glCheckFramebufferStatusEXT(int arg0){return gl.glCheckFramebufferStatusEXT(arg0); }
	public static void glClampColorARB(int arg0, int arg1){ gl.glClampColorARB(arg0, arg1); }
	public static void glClear(int arg0){ gl.glClear(arg0); }
	public static void glClearAccum(float arg0, float arg1, float arg2, float arg3){ gl.glClearAccum(arg0, arg1, arg2, arg3); }
	public static void glClearColor(float arg0, float arg1, float arg2, float arg3){ gl.glClearColor(arg0, arg1, arg2, arg3); }
	public static void glClearColorIiEXT(int arg0, int arg1, int arg2, int arg3){ gl.glClearColorIiEXT(arg0, arg1, arg2, arg3); }
	public static void glClearColorIuiEXT(int arg0, int arg1, int arg2, int arg3){ gl.glClearColorIuiEXT(arg0, arg1, arg2, arg3); }
	public static void glClearDepth(double arg0){ gl.glClearDepth(arg0); }
	public static void glClearDepthdNV(double arg0){ gl.glClearDepthdNV(arg0); }
	public static void glClearIndex(float arg0){ gl.glClearIndex(arg0); }
	public static void glClearStencil(int arg0){ gl.glClearStencil(arg0); }
	public static void glClientActiveTexture(int arg0){ gl.glClientActiveTexture(arg0); }
	public static void glClientActiveVertexStreamATI(int arg0){ gl.glClientActiveVertexStreamATI(arg0); }
	public static void glClipPlane(int arg0, java.nio.DoubleBuffer arg1){ gl.glClipPlane(arg0, arg1); }
	public static void glClipPlane(int arg0, double[] arg1, int arg2){ gl.glClipPlane(arg0, arg1, arg2); }
	public static void glColor3b(byte arg0, byte arg1, byte arg2){ gl.glColor3b(arg0, arg1, arg2); }
	public static void glColor3bv(java.nio.ByteBuffer arg0){ gl.glColor3bv(arg0); }
	public static void glColor3bv(byte[] arg0, int arg1){ gl.glColor3bv(arg0, arg1); }
	public static void glColor3d(double arg0, double arg1, double arg2){ gl.glColor3d(arg0, arg1, arg2); }
	public static void glColor3dv(java.nio.DoubleBuffer arg0){ gl.glColor3dv(arg0); }
	public static void glColor3dv(double[] arg0, int arg1){ gl.glColor3dv(arg0, arg1); }
	public static void glColor3f(float arg0, float arg1, float arg2){ gl.glColor3f(arg0, arg1, arg2); }
	public static void glColor3fVertex3fSUN(float arg0, float arg1, float arg2, float arg3, float arg4, float arg5){ gl.glColor3fVertex3fSUN(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glColor3fVertex3fvSUN(java.nio.FloatBuffer arg0, java.nio.FloatBuffer arg1){ gl.glColor3fVertex3fvSUN(arg0, arg1); }
	public static void glColor3fVertex3fvSUN(float[] arg0, int arg1, float[] arg2, int arg3){ gl.glColor3fVertex3fvSUN(arg0, arg1, arg2, arg3); }
	public static void glColor3fv(java.nio.FloatBuffer arg0){ gl.glColor3fv(arg0); }
	public static void glColor3fv(float[] arg0, int arg1){ gl.glColor3fv(arg0, arg1); }
	public static void glColor3hNV(short arg0, short arg1, short arg2){ gl.glColor3hNV(arg0, arg1, arg2); }
	public static void glColor3hvNV(java.nio.ShortBuffer arg0){ gl.glColor3hvNV(arg0); }
	public static void glColor3hvNV(short[] arg0, int arg1){ gl.glColor3hvNV(arg0, arg1); }
	public static void glColor3i(int arg0, int arg1, int arg2){ gl.glColor3i(arg0, arg1, arg2); }
	public static void glColor3iv(java.nio.IntBuffer arg0){ gl.glColor3iv(arg0); }
	public static void glColor3iv(int[] arg0, int arg1){ gl.glColor3iv(arg0, arg1); }
	public static void glColor3s(short arg0, short arg1, short arg2){ gl.glColor3s(arg0, arg1, arg2); }
	public static void glColor3sv(java.nio.ShortBuffer arg0){ gl.glColor3sv(arg0); }
	public static void glColor3sv(short[] arg0, int arg1){ gl.glColor3sv(arg0, arg1); }
	public static void glColor3ub(byte arg0, byte arg1, byte arg2){ gl.glColor3ub(arg0, arg1, arg2); }
	public static void glColor3ubv(java.nio.ByteBuffer arg0){ gl.glColor3ubv(arg0); }
	public static void glColor3ubv(byte[] arg0, int arg1){ gl.glColor3ubv(arg0, arg1); }
	public static void glColor3ui(int arg0, int arg1, int arg2){ gl.glColor3ui(arg0, arg1, arg2); }
	public static void glColor3uiv(java.nio.IntBuffer arg0){ gl.glColor3uiv(arg0); }
	public static void glColor3uiv(int[] arg0, int arg1){ gl.glColor3uiv(arg0, arg1); }
	public static void glColor3us(short arg0, short arg1, short arg2){ gl.glColor3us(arg0, arg1, arg2); }
	public static void glColor3usv(java.nio.ShortBuffer arg0){ gl.glColor3usv(arg0); }
	public static void glColor3usv(short[] arg0, int arg1){ gl.glColor3usv(arg0, arg1); }
	public static void glColor4b(byte arg0, byte arg1, byte arg2, byte arg3){ gl.glColor4b(arg0, arg1, arg2, arg3); }
	public static void glColor4bv(java.nio.ByteBuffer arg0){ gl.glColor4bv(arg0); }
	public static void glColor4bv(byte[] arg0, int arg1){ gl.glColor4bv(arg0, arg1); }
	public static void glColor4d(double arg0, double arg1, double arg2, double arg3){ gl.glColor4d(arg0, arg1, arg2, arg3); }
	public static void glColor4dv(java.nio.DoubleBuffer arg0){ gl.glColor4dv(arg0); }
	public static void glColor4dv(double[] arg0, int arg1){ gl.glColor4dv(arg0, arg1); }
	public static void glColor4f(float arg0, float arg1, float arg2, float arg3){ gl.glColor4f(arg0, arg1, arg2, arg3); }
	public static void glColor4fNormal3fVertex3fSUN(float arg0, float arg1, float arg2, float arg3, float arg4, float arg5, float arg6, float arg7, float arg8, float arg9){ gl.glColor4fNormal3fVertex3fSUN(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9); }
	public static void glColor4fNormal3fVertex3fvSUN(java.nio.FloatBuffer arg0, java.nio.FloatBuffer arg1, java.nio.FloatBuffer arg2){ gl.glColor4fNormal3fVertex3fvSUN(arg0, arg1, arg2); }
	public static void glColor4fNormal3fVertex3fvSUN(float[] arg0, int arg1, float[] arg2, int arg3, float[] arg4, int arg5){ gl.glColor4fNormal3fVertex3fvSUN(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glColor4fv(java.nio.FloatBuffer arg0){ gl.glColor4fv(arg0); }
	public static void glColor4fv(float[] arg0, int arg1){ gl.glColor4fv(arg0, arg1); }
	public static void glColor4hNV(short arg0, short arg1, short arg2, short arg3){ gl.glColor4hNV(arg0, arg1, arg2, arg3); }
	public static void glColor4hvNV(java.nio.ShortBuffer arg0){ gl.glColor4hvNV(arg0); }
	public static void glColor4hvNV(short[] arg0, int arg1){ gl.glColor4hvNV(arg0, arg1); }
	public static void glColor4i(int arg0, int arg1, int arg2, int arg3){ gl.glColor4i(arg0, arg1, arg2, arg3); }
	public static void glColor4iv(java.nio.IntBuffer arg0){ gl.glColor4iv(arg0); }
	public static void glColor4iv(int[] arg0, int arg1){ gl.glColor4iv(arg0, arg1); }
	public static void glColor4s(short arg0, short arg1, short arg2, short arg3){ gl.glColor4s(arg0, arg1, arg2, arg3); }
	public static void glColor4sv(java.nio.ShortBuffer arg0){ gl.glColor4sv(arg0); }
	public static void glColor4sv(short[] arg0, int arg1){ gl.glColor4sv(arg0, arg1); }
	public static void glColor4ub(byte arg0, byte arg1, byte arg2, byte arg3){ gl.glColor4ub(arg0, arg1, arg2, arg3); }
	public static void glColor4ubVertex2fSUN(byte arg0, byte arg1, byte arg2, byte arg3, float arg4, float arg5){ gl.glColor4ubVertex2fSUN(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glColor4ubVertex2fvSUN(java.nio.ByteBuffer arg0, java.nio.FloatBuffer arg1){ gl.glColor4ubVertex2fvSUN(arg0, arg1); }
	public static void glColor4ubVertex2fvSUN(byte[] arg0, int arg1, float[] arg2, int arg3){ gl.glColor4ubVertex2fvSUN(arg0, arg1, arg2, arg3); }
	public static void glColor4ubVertex3fSUN(byte arg0, byte arg1, byte arg2, byte arg3, float arg4, float arg5, float arg6){ gl.glColor4ubVertex3fSUN(arg0, arg1, arg2, arg3, arg4, arg5, arg6); }
	public static void glColor4ubVertex3fvSUN(java.nio.ByteBuffer arg0, java.nio.FloatBuffer arg1){ gl.glColor4ubVertex3fvSUN(arg0, arg1); }
	public static void glColor4ubVertex3fvSUN(byte[] arg0, int arg1, float[] arg2, int arg3){ gl.glColor4ubVertex3fvSUN(arg0, arg1, arg2, arg3); }
	public static void glColor4ubv(java.nio.ByteBuffer arg0){ gl.glColor4ubv(arg0); }
	public static void glColor4ubv(byte[] arg0, int arg1){ gl.glColor4ubv(arg0, arg1); }
	public static void glColor4ui(int arg0, int arg1, int arg2, int arg3){ gl.glColor4ui(arg0, arg1, arg2, arg3); }
	public static void glColor4uiv(java.nio.IntBuffer arg0){ gl.glColor4uiv(arg0); }
	public static void glColor4uiv(int[] arg0, int arg1){ gl.glColor4uiv(arg0, arg1); }
	public static void glColor4us(short arg0, short arg1, short arg2, short arg3){ gl.glColor4us(arg0, arg1, arg2, arg3); }
	public static void glColor4usv(java.nio.ShortBuffer arg0){ gl.glColor4usv(arg0); }
	public static void glColor4usv(short[] arg0, int arg1){ gl.glColor4usv(arg0, arg1); }
	public static void glColorFragmentOp1ATI(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6){ gl.glColorFragmentOp1ATI(arg0, arg1, arg2, arg3, arg4, arg5, arg6); }
	public static void glColorFragmentOp2ATI(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6, int arg7, int arg8, int arg9){ gl.glColorFragmentOp2ATI(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9); }
	public static void glColorFragmentOp3ATI(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6, int arg7, int arg8, int arg9, int arg10, int arg11, int arg12){ gl.glColorFragmentOp3ATI(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12); }
	public static void glColorMask(boolean arg0, boolean arg1, boolean arg2, boolean arg3){ gl.glColorMask(arg0, arg1, arg2, arg3); }
	public static void glColorMaskIndexedEXT(int arg0, boolean arg1, boolean arg2, boolean arg3, boolean arg4){ gl.glColorMaskIndexedEXT(arg0, arg1, arg2, arg3, arg4); }
	public static void glColorMaterial(int arg0, int arg1){ gl.glColorMaterial(arg0, arg1); }
	public static void glColorPointer(int arg0, int arg1, int arg2, java.nio.Buffer arg3){ gl.glColorPointer(arg0, arg1, arg2, arg3); }
	public static void glColorPointer(int arg0, int arg1, int arg2, long arg3){ gl.glColorPointer(arg0, arg1, arg2, arg3); }
	public static void glColorSubTable(int arg0, int arg1, int arg2, int arg3, int arg4, java.nio.Buffer arg5){ gl.glColorSubTable(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glColorSubTable(int arg0, int arg1, int arg2, int arg3, int arg4, long arg5){ gl.glColorSubTable(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glColorTable(int arg0, int arg1, int arg2, int arg3, int arg4, java.nio.Buffer arg5){ gl.glColorTable(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glColorTable(int arg0, int arg1, int arg2, int arg3, int arg4, long arg5){ gl.glColorTable(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glColorTableEXT(int arg0, int arg1, int arg2, int arg3, int arg4, java.nio.Buffer arg5){ gl.glColorTableEXT(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glColorTableParameterfv(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glColorTableParameterfv(arg0, arg1, arg2); }
	public static void glColorTableParameterfv(int arg0, int arg1, float[] arg2, int arg3){ gl.glColorTableParameterfv(arg0, arg1, arg2, arg3); }
	public static void glColorTableParameteriv(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glColorTableParameteriv(arg0, arg1, arg2); }
	public static void glColorTableParameteriv(int arg0, int arg1, int[] arg2, int arg3){ gl.glColorTableParameteriv(arg0, arg1, arg2, arg3); }
	public static void glCombinerInputNV(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5){ gl.glCombinerInputNV(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glCombinerOutputNV(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6, boolean arg7, boolean arg8, boolean arg9){ gl.glCombinerOutputNV(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9); }
	public static void glCombinerParameterfNV(int arg0, float arg1){ gl.glCombinerParameterfNV(arg0, arg1); }
	public static void glCombinerParameterfvNV(int arg0, java.nio.FloatBuffer arg1){ gl.glCombinerParameterfvNV(arg0, arg1); }
	public static void glCombinerParameterfvNV(int arg0, float[] arg1, int arg2){ gl.glCombinerParameterfvNV(arg0, arg1, arg2); }
	public static void glCombinerParameteriNV(int arg0, int arg1){ gl.glCombinerParameteriNV(arg0, arg1); }
	public static void glCombinerParameterivNV(int arg0, java.nio.IntBuffer arg1){ gl.glCombinerParameterivNV(arg0, arg1); }
	public static void glCombinerParameterivNV(int arg0, int[] arg1, int arg2){ gl.glCombinerParameterivNV(arg0, arg1, arg2); }
	public static void glCombinerStageParameterfvNV(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glCombinerStageParameterfvNV(arg0, arg1, arg2); }
	public static void glCombinerStageParameterfvNV(int arg0, int arg1, float[] arg2, int arg3){ gl.glCombinerStageParameterfvNV(arg0, arg1, arg2, arg3); }
	public static void glCompileShader(int arg0){ gl.glCompileShader(arg0); }
	public static void glCompileShaderARB(int arg0){ gl.glCompileShaderARB(arg0); }
	public static void glCompressedTexImage1D(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, java.nio.Buffer arg6){ gl.glCompressedTexImage1D(arg0, arg1, arg2, arg3, arg4, arg5, arg6); }
	public static void glCompressedTexImage1D(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, long arg6){ gl.glCompressedTexImage1D(arg0, arg1, arg2, arg3, arg4, arg5, arg6); }
	public static void glCompressedTexImage2D(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6, java.nio.Buffer arg7){ gl.glCompressedTexImage2D(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7); }
	public static void glCompressedTexImage2D(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6, long arg7){ gl.glCompressedTexImage2D(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7); }
	public static void glCompressedTexImage3D(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6, int arg7, java.nio.Buffer arg8){ gl.glCompressedTexImage3D(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8); }
	public static void glCompressedTexImage3D(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6, int arg7, long arg8){ gl.glCompressedTexImage3D(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8); }
	public static void glCompressedTexSubImage1D(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, java.nio.Buffer arg6){ gl.glCompressedTexSubImage1D(arg0, arg1, arg2, arg3, arg4, arg5, arg6); }
	public static void glCompressedTexSubImage1D(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, long arg6){ gl.glCompressedTexSubImage1D(arg0, arg1, arg2, arg3, arg4, arg5, arg6); }
	public static void glCompressedTexSubImage2D(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6, int arg7, java.nio.Buffer arg8){ gl.glCompressedTexSubImage2D(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8); }
	public static void glCompressedTexSubImage2D(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6, int arg7, long arg8){ gl.glCompressedTexSubImage2D(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8); }
	public static void glCompressedTexSubImage3D(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6, int arg7, int arg8, int arg9, java.nio.Buffer arg10){ gl.glCompressedTexSubImage3D(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10); }
	public static void glCompressedTexSubImage3D(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6, int arg7, int arg8, int arg9, long arg10){ gl.glCompressedTexSubImage3D(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10); }
	public static void glConvolutionFilter1D(int arg0, int arg1, int arg2, int arg3, int arg4, java.nio.Buffer arg5){ gl.glConvolutionFilter1D(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glConvolutionFilter1D(int arg0, int arg1, int arg2, int arg3, int arg4, long arg5){ gl.glConvolutionFilter1D(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glConvolutionFilter2D(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, java.nio.Buffer arg6){ gl.glConvolutionFilter2D(arg0, arg1, arg2, arg3, arg4, arg5, arg6); }
	public static void glConvolutionFilter2D(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, long arg6){ gl.glConvolutionFilter2D(arg0, arg1, arg2, arg3, arg4, arg5, arg6); }
	public static void glConvolutionParameterf(int arg0, int arg1, float arg2){ gl.glConvolutionParameterf(arg0, arg1, arg2); }
	public static void glConvolutionParameterfv(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glConvolutionParameterfv(arg0, arg1, arg2); }
	public static void glConvolutionParameterfv(int arg0, int arg1, float[] arg2, int arg3){ gl.glConvolutionParameterfv(arg0, arg1, arg2, arg3); }
	public static void glConvolutionParameteri(int arg0, int arg1, int arg2){ gl.glConvolutionParameteri(arg0, arg1, arg2); }
	public static void glConvolutionParameteriv(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glConvolutionParameteriv(arg0, arg1, arg2); }
	public static void glConvolutionParameteriv(int arg0, int arg1, int[] arg2, int arg3){ gl.glConvolutionParameteriv(arg0, arg1, arg2, arg3); }
	public static void glCopyColorSubTable(int arg0, int arg1, int arg2, int arg3, int arg4){ gl.glCopyColorSubTable(arg0, arg1, arg2, arg3, arg4); }
	public static void glCopyColorTable(int arg0, int arg1, int arg2, int arg3, int arg4){ gl.glCopyColorTable(arg0, arg1, arg2, arg3, arg4); }
	public static void glCopyConvolutionFilter1D(int arg0, int arg1, int arg2, int arg3, int arg4){ gl.glCopyConvolutionFilter1D(arg0, arg1, arg2, arg3, arg4); }
	public static void glCopyConvolutionFilter2D(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5){ gl.glCopyConvolutionFilter2D(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glCopyPixels(int arg0, int arg1, int arg2, int arg3, int arg4){ gl.glCopyPixels(arg0, arg1, arg2, arg3, arg4); }
	public static void glCopyTexImage1D(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6){ gl.glCopyTexImage1D(arg0, arg1, arg2, arg3, arg4, arg5, arg6); }
	public static void glCopyTexImage2D(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6, int arg7){ gl.glCopyTexImage2D(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7); }
	public static void glCopyTexSubImage1D(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5){ gl.glCopyTexSubImage1D(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glCopyTexSubImage2D(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6, int arg7){ gl.glCopyTexSubImage2D(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7); }
	public static void glCopyTexSubImage3D(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6, int arg7, int arg8){ gl.glCopyTexSubImage3D(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8); }
	public static int glCreateProgram(){return gl.glCreateProgram(); }
	public static int glCreateProgramObjectARB(){return gl.glCreateProgramObjectARB(); }
	public static int glCreateShader(int arg0){return gl.glCreateShader(arg0); }
	public static int glCreateShaderObjectARB(int arg0){return gl.glCreateShaderObjectARB(arg0); }
	public static void glCullFace(int arg0){ gl.glCullFace(arg0); }
	public static void glCullParameterdvEXT(int arg0, java.nio.DoubleBuffer arg1){ gl.glCullParameterdvEXT(arg0, arg1); }
	public static void glCullParameterdvEXT(int arg0, double[] arg1, int arg2){ gl.glCullParameterdvEXT(arg0, arg1, arg2); }
	public static void glCullParameterfvEXT(int arg0, java.nio.FloatBuffer arg1){ gl.glCullParameterfvEXT(arg0, arg1); }
	public static void glCullParameterfvEXT(int arg0, float[] arg1, int arg2){ gl.glCullParameterfvEXT(arg0, arg1, arg2); }
	public static void glCurrentPaletteMatrixARB(int arg0){ gl.glCurrentPaletteMatrixARB(arg0); }
	public static void glDeformSGIX(int arg0){ gl.glDeformSGIX(arg0); }
	public static void glDeformationMap3dSGIX(int arg0, double arg1, double arg2, int arg3, int arg4, double arg5, double arg6, int arg7, int arg8, double arg9, double arg10, int arg11, int arg12, java.nio.DoubleBuffer arg13){ gl.glDeformationMap3dSGIX(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13); }
	public static void glDeformationMap3dSGIX(int arg0, double arg1, double arg2, int arg3, int arg4, double arg5, double arg6, int arg7, int arg8, double arg9, double arg10, int arg11, int arg12, double[] arg13, int arg14){ gl.glDeformationMap3dSGIX(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14); }
	public static void glDeformationMap3fSGIX(int arg0, float arg1, float arg2, int arg3, int arg4, float arg5, float arg6, int arg7, int arg8, float arg9, float arg10, int arg11, int arg12, java.nio.FloatBuffer arg13){ gl.glDeformationMap3fSGIX(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13); }
	public static void glDeformationMap3fSGIX(int arg0, float arg1, float arg2, int arg3, int arg4, float arg5, float arg6, int arg7, int arg8, float arg9, float arg10, int arg11, int arg12, float[] arg13, int arg14){ gl.glDeformationMap3fSGIX(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14); }
	public static void glDeleteAsyncMarkersSGIX(int arg0, int arg1){ gl.glDeleteAsyncMarkersSGIX(arg0, arg1); }
	public static void glDeleteBufferRegion(int arg0){ gl.glDeleteBufferRegion(arg0); }
	public static void glDeleteBuffers(int arg0, java.nio.IntBuffer arg1){ gl.glDeleteBuffers(arg0, arg1); }
	public static void glDeleteBuffers(int arg0, int[] arg1, int arg2){ gl.glDeleteBuffers(arg0, arg1, arg2); }
	public static void glDeleteBuffersARB(int arg0, java.nio.IntBuffer arg1){ gl.glDeleteBuffersARB(arg0, arg1); }
	public static void glDeleteBuffersARB(int arg0, int[] arg1, int arg2){ gl.glDeleteBuffersARB(arg0, arg1, arg2); }
	public static void glDeleteFencesAPPLE(int arg0, java.nio.IntBuffer arg1){ gl.glDeleteFencesAPPLE(arg0, arg1); }
	public static void glDeleteFencesAPPLE(int arg0, int[] arg1, int arg2){ gl.glDeleteFencesAPPLE(arg0, arg1, arg2); }
	public static void glDeleteFencesNV(int arg0, java.nio.IntBuffer arg1){ gl.glDeleteFencesNV(arg0, arg1); }
	public static void glDeleteFencesNV(int arg0, int[] arg1, int arg2){ gl.glDeleteFencesNV(arg0, arg1, arg2); }
	public static void glDeleteFragmentShaderATI(int arg0){ gl.glDeleteFragmentShaderATI(arg0); }
	public static void glDeleteFramebuffersEXT(int arg0, java.nio.IntBuffer arg1){ gl.glDeleteFramebuffersEXT(arg0, arg1); }
	public static void glDeleteFramebuffersEXT(int arg0, int[] arg1, int arg2){ gl.glDeleteFramebuffersEXT(arg0, arg1, arg2); }
	public static void glDeleteLists(int arg0, int arg1){ gl.glDeleteLists(arg0, arg1); }
	public static void glDeleteObjectARB(int arg0){ gl.glDeleteObjectARB(arg0); }
	public static void glDeleteOcclusionQueriesNV(int arg0, java.nio.IntBuffer arg1){ gl.glDeleteOcclusionQueriesNV(arg0, arg1); }
	public static void glDeleteOcclusionQueriesNV(int arg0, int[] arg1, int arg2){ gl.glDeleteOcclusionQueriesNV(arg0, arg1, arg2); }
	public static void glDeleteProgram(int arg0){ gl.glDeleteProgram(arg0); }
	public static void glDeleteProgramsARB(int arg0, java.nio.IntBuffer arg1){ gl.glDeleteProgramsARB(arg0, arg1); }
	public static void glDeleteProgramsARB(int arg0, int[] arg1, int arg2){ gl.glDeleteProgramsARB(arg0, arg1, arg2); }
	public static void glDeleteProgramsNV(int arg0, java.nio.IntBuffer arg1){ gl.glDeleteProgramsNV(arg0, arg1); }
	public static void glDeleteProgramsNV(int arg0, int[] arg1, int arg2){ gl.glDeleteProgramsNV(arg0, arg1, arg2); }
	public static void glDeleteQueries(int arg0, java.nio.IntBuffer arg1){ gl.glDeleteQueries(arg0, arg1); }
	public static void glDeleteQueries(int arg0, int[] arg1, int arg2){ gl.glDeleteQueries(arg0, arg1, arg2); }
	public static void glDeleteQueriesARB(int arg0, java.nio.IntBuffer arg1){ gl.glDeleteQueriesARB(arg0, arg1); }
	public static void glDeleteQueriesARB(int arg0, int[] arg1, int arg2){ gl.glDeleteQueriesARB(arg0, arg1, arg2); }
	public static void glDeleteRenderbuffersEXT(int arg0, java.nio.IntBuffer arg1){ gl.glDeleteRenderbuffersEXT(arg0, arg1); }
	public static void glDeleteRenderbuffersEXT(int arg0, int[] arg1, int arg2){ gl.glDeleteRenderbuffersEXT(arg0, arg1, arg2); }
	public static void glDeleteShader(int arg0){ gl.glDeleteShader(arg0); }
	public static void glDeleteTextures(int arg0, java.nio.IntBuffer arg1){ gl.glDeleteTextures(arg0, arg1); }
	public static void glDeleteTextures(int arg0, int[] arg1, int arg2){ gl.glDeleteTextures(arg0, arg1, arg2); }
	public static void glDeleteVertexArraysAPPLE(int arg0, java.nio.IntBuffer arg1){ gl.glDeleteVertexArraysAPPLE(arg0, arg1); }
	public static void glDeleteVertexArraysAPPLE(int arg0, int[] arg1, int arg2){ gl.glDeleteVertexArraysAPPLE(arg0, arg1, arg2); }
	public static void glDeleteVertexShaderEXT(int arg0){ gl.glDeleteVertexShaderEXT(arg0); }
	public static void glDepthBoundsEXT(double arg0, double arg1){ gl.glDepthBoundsEXT(arg0, arg1); }
	public static void glDepthBoundsdNV(double arg0, double arg1){ gl.glDepthBoundsdNV(arg0, arg1); }
	public static void glDepthFunc(int arg0){ gl.glDepthFunc(arg0); }
	public static void glDepthMask(boolean arg0){ gl.glDepthMask(arg0); }
	public static void glDepthRange(double arg0, double arg1){ gl.glDepthRange(arg0, arg1); }
	public static void glDepthRangedNV(double arg0, double arg1){ gl.glDepthRangedNV(arg0, arg1); }
	public static void glDetachObjectARB(int arg0, int arg1){ gl.glDetachObjectARB(arg0, arg1); }
	public static void glDetachShader(int arg0, int arg1){ gl.glDetachShader(arg0, arg1); }
	public static void glDetailTexFuncSGIS(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glDetailTexFuncSGIS(arg0, arg1, arg2); }
	public static void glDetailTexFuncSGIS(int arg0, int arg1, float[] arg2, int arg3){ gl.glDetailTexFuncSGIS(arg0, arg1, arg2, arg3); }
	public static void glDisable(int arg0){ gl.glDisable(arg0); }
	public static void glDisableClientState(int arg0){ gl.glDisableClientState(arg0); }
	public static void glDisableIndexedEXT(int arg0, int arg1){ gl.glDisableIndexedEXT(arg0, arg1); }
	public static void glDisableVariantClientStateEXT(int arg0){ gl.glDisableVariantClientStateEXT(arg0); }
	public static void glDisableVertexAttribAPPLE(int arg0, int arg1){ gl.glDisableVertexAttribAPPLE(arg0, arg1); }
	public static void glDisableVertexAttribArray(int arg0){ gl.glDisableVertexAttribArray(arg0); }
	public static void glDisableVertexAttribArrayARB(int arg0){ gl.glDisableVertexAttribArrayARB(arg0); }
	public static void glDrawArrays(int arg0, int arg1, int arg2){ gl.glDrawArrays(arg0, arg1, arg2); }
	public static void glDrawArraysInstancedEXT(int arg0, int arg1, int arg2, int arg3){ gl.glDrawArraysInstancedEXT(arg0, arg1, arg2, arg3); }
	public static void glDrawBuffer(int arg0){ gl.glDrawBuffer(arg0); }
	public static void glDrawBufferRegion(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6){ gl.glDrawBufferRegion(arg0, arg1, arg2, arg3, arg4, arg5, arg6); }
	public static void glDrawBuffers(int arg0, java.nio.IntBuffer arg1){ gl.glDrawBuffers(arg0, arg1); }
	public static void glDrawBuffers(int arg0, int[] arg1, int arg2){ gl.glDrawBuffers(arg0, arg1, arg2); }
	public static void glDrawBuffersARB(int arg0, java.nio.IntBuffer arg1){ gl.glDrawBuffersARB(arg0, arg1); }
	public static void glDrawBuffersARB(int arg0, int[] arg1, int arg2){ gl.glDrawBuffersARB(arg0, arg1, arg2); }
	public static void glDrawBuffersATI(int arg0, java.nio.IntBuffer arg1){ gl.glDrawBuffersATI(arg0, arg1); }
	public static void glDrawBuffersATI(int arg0, int[] arg1, int arg2){ gl.glDrawBuffersATI(arg0, arg1, arg2); }
	public static void glDrawElementArrayAPPLE(int arg0, int arg1, int arg2){ gl.glDrawElementArrayAPPLE(arg0, arg1, arg2); }
	public static void glDrawElementArrayATI(int arg0, int arg1){ gl.glDrawElementArrayATI(arg0, arg1); }
	public static void glDrawElements(int arg0, int arg1, int arg2, java.nio.Buffer arg3){ gl.glDrawElements(arg0, arg1, arg2, arg3); }
	public static void glDrawElements(int arg0, int arg1, int arg2, long arg3){ gl.glDrawElements(arg0, arg1, arg2, arg3); }
	public static void glDrawElementsInstancedEXT(int arg0, int arg1, int arg2, java.nio.Buffer arg3, int arg4){ gl.glDrawElementsInstancedEXT(arg0, arg1, arg2, arg3, arg4); }
	public static void glDrawMeshArraysSUN(int arg0, int arg1, int arg2, int arg3){ gl.glDrawMeshArraysSUN(arg0, arg1, arg2, arg3); }
	public static void glDrawPixels(int arg0, int arg1, int arg2, int arg3, java.nio.Buffer arg4){ gl.glDrawPixels(arg0, arg1, arg2, arg3, arg4); }
	public static void glDrawPixels(int arg0, int arg1, int arg2, int arg3, long arg4){ gl.glDrawPixels(arg0, arg1, arg2, arg3, arg4); }
	public static void glDrawRangeElementArrayAPPLE(int arg0, int arg1, int arg2, int arg3, int arg4){ gl.glDrawRangeElementArrayAPPLE(arg0, arg1, arg2, arg3, arg4); }
	public static void glDrawRangeElementArrayATI(int arg0, int arg1, int arg2, int arg3){ gl.glDrawRangeElementArrayATI(arg0, arg1, arg2, arg3); }
	public static void glDrawRangeElements(int arg0, int arg1, int arg2, int arg3, int arg4, java.nio.Buffer arg5){ gl.glDrawRangeElements(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glDrawRangeElements(int arg0, int arg1, int arg2, int arg3, int arg4, long arg5){ gl.glDrawRangeElements(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glEdgeFlag(boolean arg0){ gl.glEdgeFlag(arg0); }
	public static void glEdgeFlagPointer(int arg0, java.nio.Buffer arg1){ gl.glEdgeFlagPointer(arg0, arg1); }
	public static void glEdgeFlagPointer(int arg0, long arg1){ gl.glEdgeFlagPointer(arg0, arg1); }
	public static void glEdgeFlagv(java.nio.ByteBuffer arg0){ gl.glEdgeFlagv(arg0); }
	public static void glEdgeFlagv(byte[] arg0, int arg1){ gl.glEdgeFlagv(arg0, arg1); }
	public static void glElementPointerAPPLE(int arg0, java.nio.Buffer arg1){ gl.glElementPointerAPPLE(arg0, arg1); }
	public static void glElementPointerATI(int arg0, java.nio.Buffer arg1){ gl.glElementPointerATI(arg0, arg1); }
	public static void glElementPointerATI(int arg0, long arg1){ gl.glElementPointerATI(arg0, arg1); }
	public static void glEnable(int arg0){ gl.glEnable(arg0); }
	public static void glEnableClientState(int arg0){ gl.glEnableClientState(arg0); }
	public static void glEnableIndexedEXT(int arg0, int arg1){ gl.glEnableIndexedEXT(arg0, arg1); }
	public static void glEnableVariantClientStateEXT(int arg0){ gl.glEnableVariantClientStateEXT(arg0); }
	public static void glEnableVertexAttribAPPLE(int arg0, int arg1){ gl.glEnableVertexAttribAPPLE(arg0, arg1); }
	public static void glEnableVertexAttribArray(int arg0){ gl.glEnableVertexAttribArray(arg0); }
	public static void glEnableVertexAttribArrayARB(int arg0){ gl.glEnableVertexAttribArrayARB(arg0); }
	public static void glEnd(){ gl.glEnd(); }
	public static void glEndFragmentShaderATI(){ gl.glEndFragmentShaderATI(); }
	public static void glEndList(){ gl.glEndList(); }
	public static void glEndOcclusionQueryNV(){ gl.glEndOcclusionQueryNV(); }
	public static void glEndQuery(int arg0){ gl.glEndQuery(arg0); }
	public static void glEndQueryARB(int arg0){ gl.glEndQueryARB(arg0); }
	public static void glEndTransformFeedbackNV(){ gl.glEndTransformFeedbackNV(); }
	public static void glEndVertexShaderEXT(){ gl.glEndVertexShaderEXT(); }
	public static void glEvalCoord1d(double arg0){ gl.glEvalCoord1d(arg0); }
	public static void glEvalCoord1dv(java.nio.DoubleBuffer arg0){ gl.glEvalCoord1dv(arg0); }
	public static void glEvalCoord1dv(double[] arg0, int arg1){ gl.glEvalCoord1dv(arg0, arg1); }
	public static void glEvalCoord1f(float arg0){ gl.glEvalCoord1f(arg0); }
	public static void glEvalCoord1fv(java.nio.FloatBuffer arg0){ gl.glEvalCoord1fv(arg0); }
	public static void glEvalCoord1fv(float[] arg0, int arg1){ gl.glEvalCoord1fv(arg0, arg1); }
	public static void glEvalCoord2d(double arg0, double arg1){ gl.glEvalCoord2d(arg0, arg1); }
	public static void glEvalCoord2dv(java.nio.DoubleBuffer arg0){ gl.glEvalCoord2dv(arg0); }
	public static void glEvalCoord2dv(double[] arg0, int arg1){ gl.glEvalCoord2dv(arg0, arg1); }
	public static void glEvalCoord2f(float arg0, float arg1){ gl.glEvalCoord2f(arg0, arg1); }
	public static void glEvalCoord2fv(java.nio.FloatBuffer arg0){ gl.glEvalCoord2fv(arg0); }
	public static void glEvalCoord2fv(float[] arg0, int arg1){ gl.glEvalCoord2fv(arg0, arg1); }
	public static void glEvalMapsNV(int arg0, int arg1){ gl.glEvalMapsNV(arg0, arg1); }
	public static void glEvalMesh1(int arg0, int arg1, int arg2){ gl.glEvalMesh1(arg0, arg1, arg2); }
	public static void glEvalMesh2(int arg0, int arg1, int arg2, int arg3, int arg4){ gl.glEvalMesh2(arg0, arg1, arg2, arg3, arg4); }
	public static void glEvalPoint1(int arg0){ gl.glEvalPoint1(arg0); }
	public static void glEvalPoint2(int arg0, int arg1){ gl.glEvalPoint2(arg0, arg1); }
	public static void glExecuteProgramNV(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glExecuteProgramNV(arg0, arg1, arg2); }
	public static void glExecuteProgramNV(int arg0, int arg1, float[] arg2, int arg3){ gl.glExecuteProgramNV(arg0, arg1, arg2, arg3); }
	public static void glExtractComponentEXT(int arg0, int arg1, int arg2){ gl.glExtractComponentEXT(arg0, arg1, arg2); }
	public static void glFeedbackBuffer(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glFeedbackBuffer(arg0, arg1, arg2); }
	public static void glFinalCombinerInputNV(int arg0, int arg1, int arg2, int arg3){ gl.glFinalCombinerInputNV(arg0, arg1, arg2, arg3); }
	public static void glFinish(){ gl.glFinish(); }
	public static int glFinishAsyncSGIX(java.nio.IntBuffer arg0){return gl.glFinishAsyncSGIX(arg0); }
	public static int glFinishAsyncSGIX(int[] arg0, int arg1){return gl.glFinishAsyncSGIX(arg0, arg1); }
	public static void glFinishFenceAPPLE(int arg0){ gl.glFinishFenceAPPLE(arg0); }
	public static void glFinishFenceNV(int arg0){ gl.glFinishFenceNV(arg0); }
	public static void glFinishObjectAPPLE(int arg0, int arg1){ gl.glFinishObjectAPPLE(arg0, arg1); }
	public static void glFinishRenderAPPLE(){ gl.glFinishRenderAPPLE(); }
	public static void glFinishTextureSUNX(){ gl.glFinishTextureSUNX(); }
	public static void glFlush(){ gl.glFlush(); }
	public static void glFlushMappedBufferRangeAPPLE(int arg0, int arg1, int arg2){ gl.glFlushMappedBufferRangeAPPLE(arg0, arg1, arg2); }
	public static void glFlushPixelDataRangeNV(int arg0){ gl.glFlushPixelDataRangeNV(arg0); }
	public static void glFlushRasterSGIX(){ gl.glFlushRasterSGIX(); }
	public static void glFlushRenderAPPLE(){ gl.glFlushRenderAPPLE(); }
	public static void glFlushVertexArrayRangeAPPLE(int arg0, java.nio.Buffer arg1){ gl.glFlushVertexArrayRangeAPPLE(arg0, arg1); }
	public static void glFlushVertexArrayRangeNV(){ gl.glFlushVertexArrayRangeNV(); }
	public static void glFogCoordPointer(int arg0, int arg1, java.nio.Buffer arg2){ gl.glFogCoordPointer(arg0, arg1, arg2); }
	public static void glFogCoordPointer(int arg0, int arg1, long arg2){ gl.glFogCoordPointer(arg0, arg1, arg2); }
	public static void glFogCoordPointerEXT(int arg0, int arg1, java.nio.Buffer arg2){ gl.glFogCoordPointerEXT(arg0, arg1, arg2); }
	public static void glFogCoordPointerEXT(int arg0, int arg1, long arg2){ gl.glFogCoordPointerEXT(arg0, arg1, arg2); }
	public static void glFogCoordd(double arg0){ gl.glFogCoordd(arg0); }
	public static void glFogCoorddEXT(double arg0){ gl.glFogCoorddEXT(arg0); }
	public static void glFogCoorddv(java.nio.DoubleBuffer arg0){ gl.glFogCoorddv(arg0); }
	public static void glFogCoorddv(double[] arg0, int arg1){ gl.glFogCoorddv(arg0, arg1); }
	public static void glFogCoorddvEXT(java.nio.DoubleBuffer arg0){ gl.glFogCoorddvEXT(arg0); }
	public static void glFogCoorddvEXT(double[] arg0, int arg1){ gl.glFogCoorddvEXT(arg0, arg1); }
	public static void glFogCoordf(float arg0){ gl.glFogCoordf(arg0); }
	public static void glFogCoordfEXT(float arg0){ gl.glFogCoordfEXT(arg0); }
	public static void glFogCoordfv(java.nio.FloatBuffer arg0){ gl.glFogCoordfv(arg0); }
	public static void glFogCoordfv(float[] arg0, int arg1){ gl.glFogCoordfv(arg0, arg1); }
	public static void glFogCoordfvEXT(java.nio.FloatBuffer arg0){ gl.glFogCoordfvEXT(arg0); }
	public static void glFogCoordfvEXT(float[] arg0, int arg1){ gl.glFogCoordfvEXT(arg0, arg1); }
	public static void glFogCoordhNV(short arg0){ gl.glFogCoordhNV(arg0); }
	public static void glFogCoordhvNV(java.nio.ShortBuffer arg0){ gl.glFogCoordhvNV(arg0); }
	public static void glFogCoordhvNV(short[] arg0, int arg1){ gl.glFogCoordhvNV(arg0, arg1); }
	public static void glFogFuncSGIS(int arg0, java.nio.FloatBuffer arg1){ gl.glFogFuncSGIS(arg0, arg1); }
	public static void glFogFuncSGIS(int arg0, float[] arg1, int arg2){ gl.glFogFuncSGIS(arg0, arg1, arg2); }
	public static void glFogf(int arg0, float arg1){ gl.glFogf(arg0, arg1); }
	public static void glFogfv(int arg0, java.nio.FloatBuffer arg1){ gl.glFogfv(arg0, arg1); }
	public static void glFogfv(int arg0, float[] arg1, int arg2){ gl.glFogfv(arg0, arg1, arg2); }
	public static void glFogi(int arg0, int arg1){ gl.glFogi(arg0, arg1); }
	public static void glFogiv(int arg0, java.nio.IntBuffer arg1){ gl.glFogiv(arg0, arg1); }
	public static void glFogiv(int arg0, int[] arg1, int arg2){ gl.glFogiv(arg0, arg1, arg2); }
	public static void glFragmentColorMaterialSGIX(int arg0, int arg1){ gl.glFragmentColorMaterialSGIX(arg0, arg1); }
	public static void glFragmentLightModelfSGIX(int arg0, float arg1){ gl.glFragmentLightModelfSGIX(arg0, arg1); }
	public static void glFragmentLightModelfvSGIX(int arg0, java.nio.FloatBuffer arg1){ gl.glFragmentLightModelfvSGIX(arg0, arg1); }
	public static void glFragmentLightModelfvSGIX(int arg0, float[] arg1, int arg2){ gl.glFragmentLightModelfvSGIX(arg0, arg1, arg2); }
	public static void glFragmentLightModeliSGIX(int arg0, int arg1){ gl.glFragmentLightModeliSGIX(arg0, arg1); }
	public static void glFragmentLightModelivSGIX(int arg0, java.nio.IntBuffer arg1){ gl.glFragmentLightModelivSGIX(arg0, arg1); }
	public static void glFragmentLightModelivSGIX(int arg0, int[] arg1, int arg2){ gl.glFragmentLightModelivSGIX(arg0, arg1, arg2); }
	public static void glFragmentLightfSGIX(int arg0, int arg1, float arg2){ gl.glFragmentLightfSGIX(arg0, arg1, arg2); }
	public static void glFragmentLightfvSGIX(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glFragmentLightfvSGIX(arg0, arg1, arg2); }
	public static void glFragmentLightfvSGIX(int arg0, int arg1, float[] arg2, int arg3){ gl.glFragmentLightfvSGIX(arg0, arg1, arg2, arg3); }
	public static void glFragmentLightiSGIX(int arg0, int arg1, int arg2){ gl.glFragmentLightiSGIX(arg0, arg1, arg2); }
	public static void glFragmentLightivSGIX(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glFragmentLightivSGIX(arg0, arg1, arg2); }
	public static void glFragmentLightivSGIX(int arg0, int arg1, int[] arg2, int arg3){ gl.glFragmentLightivSGIX(arg0, arg1, arg2, arg3); }
	public static void glFragmentMaterialfSGIX(int arg0, int arg1, float arg2){ gl.glFragmentMaterialfSGIX(arg0, arg1, arg2); }
	public static void glFragmentMaterialfvSGIX(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glFragmentMaterialfvSGIX(arg0, arg1, arg2); }
	public static void glFragmentMaterialfvSGIX(int arg0, int arg1, float[] arg2, int arg3){ gl.glFragmentMaterialfvSGIX(arg0, arg1, arg2, arg3); }
	public static void glFragmentMaterialiSGIX(int arg0, int arg1, int arg2){ gl.glFragmentMaterialiSGIX(arg0, arg1, arg2); }
	public static void glFragmentMaterialivSGIX(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glFragmentMaterialivSGIX(arg0, arg1, arg2); }
	public static void glFragmentMaterialivSGIX(int arg0, int arg1, int[] arg2, int arg3){ gl.glFragmentMaterialivSGIX(arg0, arg1, arg2, arg3); }
	public static void glFrameZoomSGIX(int arg0){ gl.glFrameZoomSGIX(arg0); }
	public static void glFramebufferRenderbufferEXT(int arg0, int arg1, int arg2, int arg3){ gl.glFramebufferRenderbufferEXT(arg0, arg1, arg2, arg3); }
	public static void glFramebufferTexture1DEXT(int arg0, int arg1, int arg2, int arg3, int arg4){ gl.glFramebufferTexture1DEXT(arg0, arg1, arg2, arg3, arg4); }
	public static void glFramebufferTexture2DEXT(int arg0, int arg1, int arg2, int arg3, int arg4){ gl.glFramebufferTexture2DEXT(arg0, arg1, arg2, arg3, arg4); }
	public static void glFramebufferTexture3DEXT(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5){ gl.glFramebufferTexture3DEXT(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glFramebufferTextureEXT(int arg0, int arg1, int arg2, int arg3){ gl.glFramebufferTextureEXT(arg0, arg1, arg2, arg3); }
	public static void glFramebufferTextureFaceEXT(int arg0, int arg1, int arg2, int arg3, int arg4){ gl.glFramebufferTextureFaceEXT(arg0, arg1, arg2, arg3, arg4); }
	public static void glFramebufferTextureLayerEXT(int arg0, int arg1, int arg2, int arg3, int arg4){ gl.glFramebufferTextureLayerEXT(arg0, arg1, arg2, arg3, arg4); }
	public static void glFreeObjectBufferATI(int arg0){ gl.glFreeObjectBufferATI(arg0); }
	public static void glFrontFace(int arg0){ gl.glFrontFace(arg0); }
	public static void glFrustum(double arg0, double arg1, double arg2, double arg3, double arg4, double arg5){ gl.glFrustum(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static int glGenAsyncMarkersSGIX(int arg0){return gl.glGenAsyncMarkersSGIX(arg0); }
	public static void glGenBuffers(int arg0, java.nio.IntBuffer arg1){ gl.glGenBuffers(arg0, arg1); }
	public static void glGenBuffers(int arg0, int[] arg1, int arg2){ gl.glGenBuffers(arg0, arg1, arg2); }
	public static void glGenBuffersARB(int arg0, java.nio.IntBuffer arg1){ gl.glGenBuffersARB(arg0, arg1); }
	public static void glGenBuffersARB(int arg0, int[] arg1, int arg2){ gl.glGenBuffersARB(arg0, arg1, arg2); }
	public static void glGenFencesAPPLE(int arg0, java.nio.IntBuffer arg1){ gl.glGenFencesAPPLE(arg0, arg1); }
	public static void glGenFencesAPPLE(int arg0, int[] arg1, int arg2){ gl.glGenFencesAPPLE(arg0, arg1, arg2); }
	public static void glGenFencesNV(int arg0, java.nio.IntBuffer arg1){ gl.glGenFencesNV(arg0, arg1); }
	public static void glGenFencesNV(int arg0, int[] arg1, int arg2){ gl.glGenFencesNV(arg0, arg1, arg2); }
	public static int glGenFragmentShadersATI(int arg0){return gl.glGenFragmentShadersATI(arg0); }
	public static void glGenFramebuffersEXT(int arg0, java.nio.IntBuffer arg1){ gl.glGenFramebuffersEXT(arg0, arg1); }
	public static void glGenFramebuffersEXT(int arg0, int[] arg1, int arg2){ gl.glGenFramebuffersEXT(arg0, arg1, arg2); }
	public static int glGenLists(int arg0){return gl.glGenLists(arg0); }
	public static void glGenOcclusionQueriesNV(int arg0, java.nio.IntBuffer arg1){ gl.glGenOcclusionQueriesNV(arg0, arg1); }
	public static void glGenOcclusionQueriesNV(int arg0, int[] arg1, int arg2){ gl.glGenOcclusionQueriesNV(arg0, arg1, arg2); }
	public static void glGenProgramsARB(int arg0, java.nio.IntBuffer arg1){ gl.glGenProgramsARB(arg0, arg1); }
	public static void glGenProgramsARB(int arg0, int[] arg1, int arg2){ gl.glGenProgramsARB(arg0, arg1, arg2); }
	public static void glGenProgramsNV(int arg0, java.nio.IntBuffer arg1){ gl.glGenProgramsNV(arg0, arg1); }
	public static void glGenProgramsNV(int arg0, int[] arg1, int arg2){ gl.glGenProgramsNV(arg0, arg1, arg2); }
	public static void glGenQueries(int arg0, java.nio.IntBuffer arg1){ gl.glGenQueries(arg0, arg1); }
	public static void glGenQueries(int arg0, int[] arg1, int arg2){ gl.glGenQueries(arg0, arg1, arg2); }
	public static void glGenQueriesARB(int arg0, java.nio.IntBuffer arg1){ gl.glGenQueriesARB(arg0, arg1); }
	public static void glGenQueriesARB(int arg0, int[] arg1, int arg2){ gl.glGenQueriesARB(arg0, arg1, arg2); }
	public static void glGenRenderbuffersEXT(int arg0, java.nio.IntBuffer arg1){ gl.glGenRenderbuffersEXT(arg0, arg1); }
	public static void glGenRenderbuffersEXT(int arg0, int[] arg1, int arg2){ gl.glGenRenderbuffersEXT(arg0, arg1, arg2); }
	public static int glGenSymbolsEXT(int arg0, int arg1, int arg2, int arg3){return gl.glGenSymbolsEXT(arg0, arg1, arg2, arg3); }
	public static void glGenTextures(int arg0, java.nio.IntBuffer arg1){ gl.glGenTextures(arg0, arg1); }
	public static void glGenTextures(int arg0, int[] arg1, int arg2){ gl.glGenTextures(arg0, arg1, arg2); }
	public static void glGenVertexArraysAPPLE(int arg0, java.nio.IntBuffer arg1){ gl.glGenVertexArraysAPPLE(arg0, arg1); }
	public static void glGenVertexArraysAPPLE(int arg0, int[] arg1, int arg2){ gl.glGenVertexArraysAPPLE(arg0, arg1, arg2); }
	public static int glGenVertexShadersEXT(int arg0){return gl.glGenVertexShadersEXT(arg0); }
	public static void glGenerateMipmapEXT(int arg0){ gl.glGenerateMipmapEXT(arg0); }
	public static void glGetActiveAttrib(int arg0, int arg1, int arg2, java.nio.IntBuffer arg3, java.nio.IntBuffer arg4, java.nio.IntBuffer arg5, java.nio.ByteBuffer arg6){ gl.glGetActiveAttrib(arg0, arg1, arg2, arg3, arg4, arg5, arg6); }
	public static void glGetActiveAttrib(int arg0, int arg1, int arg2, int[] arg3, int arg4, int[] arg5, int arg6, int[] arg7, int arg8, byte[] arg9, int arg10){ gl.glGetActiveAttrib(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10); }
	public static void glGetActiveAttribARB(int arg0, int arg1, int arg2, java.nio.IntBuffer arg3, java.nio.IntBuffer arg4, java.nio.IntBuffer arg5, java.nio.ByteBuffer arg6){ gl.glGetActiveAttribARB(arg0, arg1, arg2, arg3, arg4, arg5, arg6); }
	public static void glGetActiveAttribARB(int arg0, int arg1, int arg2, int[] arg3, int arg4, int[] arg5, int arg6, int[] arg7, int arg8, byte[] arg9, int arg10){ gl.glGetActiveAttribARB(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10); }
	public static void glGetActiveUniform(int arg0, int arg1, int arg2, java.nio.IntBuffer arg3, java.nio.IntBuffer arg4, java.nio.IntBuffer arg5, java.nio.ByteBuffer arg6){ gl.glGetActiveUniform(arg0, arg1, arg2, arg3, arg4, arg5, arg6); }
	public static void glGetActiveUniform(int arg0, int arg1, int arg2, int[] arg3, int arg4, int[] arg5, int arg6, int[] arg7, int arg8, byte[] arg9, int arg10){ gl.glGetActiveUniform(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10); }
	public static void glGetActiveUniformARB(int arg0, int arg1, int arg2, java.nio.IntBuffer arg3, java.nio.IntBuffer arg4, java.nio.IntBuffer arg5, java.nio.ByteBuffer arg6){ gl.glGetActiveUniformARB(arg0, arg1, arg2, arg3, arg4, arg5, arg6); }
	public static void glGetActiveUniformARB(int arg0, int arg1, int arg2, int[] arg3, int arg4, int[] arg5, int arg6, int[] arg7, int arg8, byte[] arg9, int arg10){ gl.glGetActiveUniformARB(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10); }
	public static void glGetActiveVaryingNV(int arg0, int arg1, int arg2, java.nio.IntBuffer arg3, java.nio.IntBuffer arg4, java.nio.IntBuffer arg5, java.nio.ByteBuffer arg6){ gl.glGetActiveVaryingNV(arg0, arg1, arg2, arg3, arg4, arg5, arg6); }
	public static void glGetActiveVaryingNV(int arg0, int arg1, int arg2, int[] arg3, int arg4, int[] arg5, int arg6, int[] arg7, int arg8, byte[] arg9, int arg10){ gl.glGetActiveVaryingNV(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10); }
	public static void glGetArrayObjectfvATI(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glGetArrayObjectfvATI(arg0, arg1, arg2); }
	public static void glGetArrayObjectfvATI(int arg0, int arg1, float[] arg2, int arg3){ gl.glGetArrayObjectfvATI(arg0, arg1, arg2, arg3); }
	public static void glGetArrayObjectivATI(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetArrayObjectivATI(arg0, arg1, arg2); }
	public static void glGetArrayObjectivATI(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetArrayObjectivATI(arg0, arg1, arg2, arg3); }
	public static void glGetAttachedObjectsARB(int arg0, int arg1, java.nio.IntBuffer arg2, java.nio.IntBuffer arg3){ gl.glGetAttachedObjectsARB(arg0, arg1, arg2, arg3); }
	public static void glGetAttachedObjectsARB(int arg0, int arg1, int[] arg2, int arg3, int[] arg4, int arg5){ gl.glGetAttachedObjectsARB(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glGetAttachedShaders(int arg0, int arg1, java.nio.IntBuffer arg2, java.nio.IntBuffer arg3){ gl.glGetAttachedShaders(arg0, arg1, arg2, arg3); }
	public static void glGetAttachedShaders(int arg0, int arg1, int[] arg2, int arg3, int[] arg4, int arg5){ gl.glGetAttachedShaders(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static int glGetAttribLocation(int arg0, java.lang.String arg1){return gl.glGetAttribLocation(arg0, arg1); }
	public static int glGetAttribLocationARB(int arg0, java.lang.String arg1){return gl.glGetAttribLocationARB(arg0, arg1); }
	public static void glGetBooleanIndexedvEXT(int arg0, int arg1, java.nio.ByteBuffer arg2){ gl.glGetBooleanIndexedvEXT(arg0, arg1, arg2); }
	public static void glGetBooleanIndexedvEXT(int arg0, int arg1, byte[] arg2, int arg3){ gl.glGetBooleanIndexedvEXT(arg0, arg1, arg2, arg3); }
	public static void glGetBooleanv(int arg0, java.nio.ByteBuffer arg1){ gl.glGetBooleanv(arg0, arg1); }
	public static void glGetBooleanv(int arg0, byte[] arg1, int arg2){ gl.glGetBooleanv(arg0, arg1, arg2); }
	public static void glGetBufferParameteriv(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetBufferParameteriv(arg0, arg1, arg2); }
	public static void glGetBufferParameteriv(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetBufferParameteriv(arg0, arg1, arg2, arg3); }
	public static void glGetBufferParameterivARB(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetBufferParameterivARB(arg0, arg1, arg2); }
	public static void glGetBufferParameterivARB(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetBufferParameterivARB(arg0, arg1, arg2, arg3); }
	public static void glGetBufferSubData(int arg0, int arg1, int arg2, java.nio.Buffer arg3){ gl.glGetBufferSubData(arg0, arg1, arg2, arg3); }
	public static void glGetBufferSubDataARB(int arg0, int arg1, int arg2, java.nio.Buffer arg3){ gl.glGetBufferSubDataARB(arg0, arg1, arg2, arg3); }
	public static void glGetClipPlane(int arg0, java.nio.DoubleBuffer arg1){ gl.glGetClipPlane(arg0, arg1); }
	public static void glGetClipPlane(int arg0, double[] arg1, int arg2){ gl.glGetClipPlane(arg0, arg1, arg2); }
	public static void glGetColorTable(int arg0, int arg1, int arg2, java.nio.Buffer arg3){ gl.glGetColorTable(arg0, arg1, arg2, arg3); }
	public static void glGetColorTable(int arg0, int arg1, int arg2, long arg3){ gl.glGetColorTable(arg0, arg1, arg2, arg3); }
	public static void glGetColorTableEXT(int arg0, int arg1, int arg2, java.nio.Buffer arg3){ gl.glGetColorTableEXT(arg0, arg1, arg2, arg3); }
	public static void glGetColorTableParameterfv(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glGetColorTableParameterfv(arg0, arg1, arg2); }
	public static void glGetColorTableParameterfv(int arg0, int arg1, float[] arg2, int arg3){ gl.glGetColorTableParameterfv(arg0, arg1, arg2, arg3); }
	public static void glGetColorTableParameterfvEXT(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glGetColorTableParameterfvEXT(arg0, arg1, arg2); }
	public static void glGetColorTableParameterfvEXT(int arg0, int arg1, float[] arg2, int arg3){ gl.glGetColorTableParameterfvEXT(arg0, arg1, arg2, arg3); }
	public static void glGetColorTableParameteriv(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetColorTableParameteriv(arg0, arg1, arg2); }
	public static void glGetColorTableParameteriv(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetColorTableParameteriv(arg0, arg1, arg2, arg3); }
	public static void glGetColorTableParameterivEXT(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetColorTableParameterivEXT(arg0, arg1, arg2); }
	public static void glGetColorTableParameterivEXT(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetColorTableParameterivEXT(arg0, arg1, arg2, arg3); }
	public static void glGetCombinerInputParameterfvNV(int arg0, int arg1, int arg2, int arg3, java.nio.FloatBuffer arg4){ gl.glGetCombinerInputParameterfvNV(arg0, arg1, arg2, arg3, arg4); }
	public static void glGetCombinerInputParameterfvNV(int arg0, int arg1, int arg2, int arg3, float[] arg4, int arg5){ gl.glGetCombinerInputParameterfvNV(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glGetCombinerInputParameterivNV(int arg0, int arg1, int arg2, int arg3, java.nio.IntBuffer arg4){ gl.glGetCombinerInputParameterivNV(arg0, arg1, arg2, arg3, arg4); }
	public static void glGetCombinerInputParameterivNV(int arg0, int arg1, int arg2, int arg3, int[] arg4, int arg5){ gl.glGetCombinerInputParameterivNV(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glGetCombinerOutputParameterfvNV(int arg0, int arg1, int arg2, java.nio.FloatBuffer arg3){ gl.glGetCombinerOutputParameterfvNV(arg0, arg1, arg2, arg3); }
	public static void glGetCombinerOutputParameterfvNV(int arg0, int arg1, int arg2, float[] arg3, int arg4){ gl.glGetCombinerOutputParameterfvNV(arg0, arg1, arg2, arg3, arg4); }
	public static void glGetCombinerOutputParameterivNV(int arg0, int arg1, int arg2, java.nio.IntBuffer arg3){ gl.glGetCombinerOutputParameterivNV(arg0, arg1, arg2, arg3); }
	public static void glGetCombinerOutputParameterivNV(int arg0, int arg1, int arg2, int[] arg3, int arg4){ gl.glGetCombinerOutputParameterivNV(arg0, arg1, arg2, arg3, arg4); }
	public static void glGetCombinerStageParameterfvNV(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glGetCombinerStageParameterfvNV(arg0, arg1, arg2); }
	public static void glGetCombinerStageParameterfvNV(int arg0, int arg1, float[] arg2, int arg3){ gl.glGetCombinerStageParameterfvNV(arg0, arg1, arg2, arg3); }
	public static void glGetCompressedTexImage(int arg0, int arg1, java.nio.Buffer arg2){ gl.glGetCompressedTexImage(arg0, arg1, arg2); }
	public static void glGetCompressedTexImage(int arg0, int arg1, long arg2){ gl.glGetCompressedTexImage(arg0, arg1, arg2); }
	public static void glGetConvolutionFilter(int arg0, int arg1, int arg2, java.nio.Buffer arg3){ gl.glGetConvolutionFilter(arg0, arg1, arg2, arg3); }
	public static void glGetConvolutionFilter(int arg0, int arg1, int arg2, long arg3){ gl.glGetConvolutionFilter(arg0, arg1, arg2, arg3); }
	public static void glGetConvolutionParameterfv(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glGetConvolutionParameterfv(arg0, arg1, arg2); }
	public static void glGetConvolutionParameterfv(int arg0, int arg1, float[] arg2, int arg3){ gl.glGetConvolutionParameterfv(arg0, arg1, arg2, arg3); }
	public static void glGetConvolutionParameteriv(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetConvolutionParameteriv(arg0, arg1, arg2); }
	public static void glGetConvolutionParameteriv(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetConvolutionParameteriv(arg0, arg1, arg2, arg3); }
	public static void glGetDetailTexFuncSGIS(int arg0, java.nio.FloatBuffer arg1){ gl.glGetDetailTexFuncSGIS(arg0, arg1); }
	public static void glGetDetailTexFuncSGIS(int arg0, float[] arg1, int arg2){ gl.glGetDetailTexFuncSGIS(arg0, arg1, arg2); }
	public static void glGetDoublev(int arg0, java.nio.DoubleBuffer arg1){ gl.glGetDoublev(arg0, arg1); }
	public static void glGetDoublev(int arg0, double[] arg1, int arg2){ gl.glGetDoublev(arg0, arg1, arg2); }
	public static int glGetError(){return gl.glGetError(); }
	public static void glGetFenceivNV(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetFenceivNV(arg0, arg1, arg2); }
	public static void glGetFenceivNV(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetFenceivNV(arg0, arg1, arg2, arg3); }
	public static void glGetFinalCombinerInputParameterfvNV(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glGetFinalCombinerInputParameterfvNV(arg0, arg1, arg2); }
	public static void glGetFinalCombinerInputParameterfvNV(int arg0, int arg1, float[] arg2, int arg3){ gl.glGetFinalCombinerInputParameterfvNV(arg0, arg1, arg2, arg3); }
	public static void glGetFinalCombinerInputParameterivNV(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetFinalCombinerInputParameterivNV(arg0, arg1, arg2); }
	public static void glGetFinalCombinerInputParameterivNV(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetFinalCombinerInputParameterivNV(arg0, arg1, arg2, arg3); }
	public static void glGetFloatv(int arg0, java.nio.FloatBuffer arg1){ gl.glGetFloatv(arg0, arg1); }
	public static void glGetFloatv(int arg0, float[] arg1, int arg2){ gl.glGetFloatv(arg0, arg1, arg2); }
	public static void glGetFogFuncSGIS(java.nio.FloatBuffer arg0){ gl.glGetFogFuncSGIS(arg0); }
	public static void glGetFogFuncSGIS(float[] arg0, int arg1){ gl.glGetFogFuncSGIS(arg0, arg1); }
	public static int glGetFragDataLocationEXT(int arg0, java.nio.ByteBuffer arg1){return gl.glGetFragDataLocationEXT(arg0, arg1); }
	public static int glGetFragDataLocationEXT(int arg0, byte[] arg1, int arg2){return gl.glGetFragDataLocationEXT(arg0, arg1, arg2); }
	public static void glGetFragmentLightfvSGIX(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glGetFragmentLightfvSGIX(arg0, arg1, arg2); }
	public static void glGetFragmentLightfvSGIX(int arg0, int arg1, float[] arg2, int arg3){ gl.glGetFragmentLightfvSGIX(arg0, arg1, arg2, arg3); }
	public static void glGetFragmentLightivSGIX(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetFragmentLightivSGIX(arg0, arg1, arg2); }
	public static void glGetFragmentLightivSGIX(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetFragmentLightivSGIX(arg0, arg1, arg2, arg3); }
	public static void glGetFragmentMaterialfvSGIX(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glGetFragmentMaterialfvSGIX(arg0, arg1, arg2); }
	public static void glGetFragmentMaterialfvSGIX(int arg0, int arg1, float[] arg2, int arg3){ gl.glGetFragmentMaterialfvSGIX(arg0, arg1, arg2, arg3); }
	public static void glGetFragmentMaterialivSGIX(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetFragmentMaterialivSGIX(arg0, arg1, arg2); }
	public static void glGetFragmentMaterialivSGIX(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetFragmentMaterialivSGIX(arg0, arg1, arg2, arg3); }
	public static void glGetFramebufferAttachmentParameterivEXT(int arg0, int arg1, int arg2, java.nio.IntBuffer arg3){ gl.glGetFramebufferAttachmentParameterivEXT(arg0, arg1, arg2, arg3); }
	public static void glGetFramebufferAttachmentParameterivEXT(int arg0, int arg1, int arg2, int[] arg3, int arg4){ gl.glGetFramebufferAttachmentParameterivEXT(arg0, arg1, arg2, arg3, arg4); }
	public static int glGetHandleARB(int arg0){return gl.glGetHandleARB(arg0); }
	public static void glGetHistogram(int arg0, boolean arg1, int arg2, int arg3, java.nio.Buffer arg4){ gl.glGetHistogram(arg0, arg1, arg2, arg3, arg4); }
	public static void glGetHistogram(int arg0, boolean arg1, int arg2, int arg3, long arg4){ gl.glGetHistogram(arg0, arg1, arg2, arg3, arg4); }
	public static void glGetHistogramParameterfv(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glGetHistogramParameterfv(arg0, arg1, arg2); }
	public static void glGetHistogramParameterfv(int arg0, int arg1, float[] arg2, int arg3){ gl.glGetHistogramParameterfv(arg0, arg1, arg2, arg3); }
	public static void glGetHistogramParameteriv(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetHistogramParameteriv(arg0, arg1, arg2); }
	public static void glGetHistogramParameteriv(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetHistogramParameteriv(arg0, arg1, arg2, arg3); }
	public static void glGetImageTransformParameterfvHP(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glGetImageTransformParameterfvHP(arg0, arg1, arg2); }
	public static void glGetImageTransformParameterfvHP(int arg0, int arg1, float[] arg2, int arg3){ gl.glGetImageTransformParameterfvHP(arg0, arg1, arg2, arg3); }
	public static void glGetImageTransformParameterivHP(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetImageTransformParameterivHP(arg0, arg1, arg2); }
	public static void glGetImageTransformParameterivHP(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetImageTransformParameterivHP(arg0, arg1, arg2, arg3); }
	public static void glGetInfoLogARB(int arg0, int arg1, java.nio.IntBuffer arg2, java.nio.ByteBuffer arg3){ gl.glGetInfoLogARB(arg0, arg1, arg2, arg3); }
	public static void glGetInfoLogARB(int arg0, int arg1, int[] arg2, int arg3, byte[] arg4, int arg5){ gl.glGetInfoLogARB(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static int glGetInstrumentsSGIX(){return gl.glGetInstrumentsSGIX(); }
	public static void glGetIntegerIndexedvEXT(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetIntegerIndexedvEXT(arg0, arg1, arg2); }
	public static void glGetIntegerIndexedvEXT(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetIntegerIndexedvEXT(arg0, arg1, arg2, arg3); }
	public static void glGetIntegerv(int arg0, java.nio.IntBuffer arg1){ gl.glGetIntegerv(arg0, arg1); }
	public static void glGetIntegerv(int arg0, int[] arg1, int arg2){ gl.glGetIntegerv(arg0, arg1, arg2); }
	public static void glGetInvariantBooleanvEXT(int arg0, int arg1, java.nio.ByteBuffer arg2){ gl.glGetInvariantBooleanvEXT(arg0, arg1, arg2); }
	public static void glGetInvariantBooleanvEXT(int arg0, int arg1, byte[] arg2, int arg3){ gl.glGetInvariantBooleanvEXT(arg0, arg1, arg2, arg3); }
	public static void glGetInvariantFloatvEXT(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glGetInvariantFloatvEXT(arg0, arg1, arg2); }
	public static void glGetInvariantFloatvEXT(int arg0, int arg1, float[] arg2, int arg3){ gl.glGetInvariantFloatvEXT(arg0, arg1, arg2, arg3); }
	public static void glGetInvariantIntegervEXT(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetInvariantIntegervEXT(arg0, arg1, arg2); }
	public static void glGetInvariantIntegervEXT(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetInvariantIntegervEXT(arg0, arg1, arg2, arg3); }
	public static void glGetLightfv(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glGetLightfv(arg0, arg1, arg2); }
	public static void glGetLightfv(int arg0, int arg1, float[] arg2, int arg3){ gl.glGetLightfv(arg0, arg1, arg2, arg3); }
	public static void glGetLightiv(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetLightiv(arg0, arg1, arg2); }
	public static void glGetLightiv(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetLightiv(arg0, arg1, arg2, arg3); }
	public static void glGetListParameterfvSGIX(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glGetListParameterfvSGIX(arg0, arg1, arg2); }
	public static void glGetListParameterfvSGIX(int arg0, int arg1, float[] arg2, int arg3){ gl.glGetListParameterfvSGIX(arg0, arg1, arg2, arg3); }
	public static void glGetListParameterivSGIX(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetListParameterivSGIX(arg0, arg1, arg2); }
	public static void glGetListParameterivSGIX(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetListParameterivSGIX(arg0, arg1, arg2, arg3); }
	public static void glGetLocalConstantBooleanvEXT(int arg0, int arg1, java.nio.ByteBuffer arg2){ gl.glGetLocalConstantBooleanvEXT(arg0, arg1, arg2); }
	public static void glGetLocalConstantBooleanvEXT(int arg0, int arg1, byte[] arg2, int arg3){ gl.glGetLocalConstantBooleanvEXT(arg0, arg1, arg2, arg3); }
	public static void glGetLocalConstantFloatvEXT(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glGetLocalConstantFloatvEXT(arg0, arg1, arg2); }
	public static void glGetLocalConstantFloatvEXT(int arg0, int arg1, float[] arg2, int arg3){ gl.glGetLocalConstantFloatvEXT(arg0, arg1, arg2, arg3); }
	public static void glGetLocalConstantIntegervEXT(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetLocalConstantIntegervEXT(arg0, arg1, arg2); }
	public static void glGetLocalConstantIntegervEXT(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetLocalConstantIntegervEXT(arg0, arg1, arg2, arg3); }
	public static void glGetMapAttribParameterfvNV(int arg0, int arg1, int arg2, java.nio.FloatBuffer arg3){ gl.glGetMapAttribParameterfvNV(arg0, arg1, arg2, arg3); }
	public static void glGetMapAttribParameterfvNV(int arg0, int arg1, int arg2, float[] arg3, int arg4){ gl.glGetMapAttribParameterfvNV(arg0, arg1, arg2, arg3, arg4); }
	public static void glGetMapAttribParameterivNV(int arg0, int arg1, int arg2, java.nio.IntBuffer arg3){ gl.glGetMapAttribParameterivNV(arg0, arg1, arg2, arg3); }
	public static void glGetMapAttribParameterivNV(int arg0, int arg1, int arg2, int[] arg3, int arg4){ gl.glGetMapAttribParameterivNV(arg0, arg1, arg2, arg3, arg4); }
	public static void glGetMapControlPointsNV(int arg0, int arg1, int arg2, int arg3, int arg4, boolean arg5, java.nio.Buffer arg6){ gl.glGetMapControlPointsNV(arg0, arg1, arg2, arg3, arg4, arg5, arg6); }
	public static void glGetMapParameterfvNV(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glGetMapParameterfvNV(arg0, arg1, arg2); }
	public static void glGetMapParameterfvNV(int arg0, int arg1, float[] arg2, int arg3){ gl.glGetMapParameterfvNV(arg0, arg1, arg2, arg3); }
	public static void glGetMapParameterivNV(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetMapParameterivNV(arg0, arg1, arg2); }
	public static void glGetMapParameterivNV(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetMapParameterivNV(arg0, arg1, arg2, arg3); }
	public static void glGetMapdv(int arg0, int arg1, java.nio.DoubleBuffer arg2){ gl.glGetMapdv(arg0, arg1, arg2); }
	public static void glGetMapdv(int arg0, int arg1, double[] arg2, int arg3){ gl.glGetMapdv(arg0, arg1, arg2, arg3); }
	public static void glGetMapfv(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glGetMapfv(arg0, arg1, arg2); }
	public static void glGetMapfv(int arg0, int arg1, float[] arg2, int arg3){ gl.glGetMapfv(arg0, arg1, arg2, arg3); }
	public static void glGetMapiv(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetMapiv(arg0, arg1, arg2); }
	public static void glGetMapiv(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetMapiv(arg0, arg1, arg2, arg3); }
	public static void glGetMaterialfv(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glGetMaterialfv(arg0, arg1, arg2); }
	public static void glGetMaterialfv(int arg0, int arg1, float[] arg2, int arg3){ gl.glGetMaterialfv(arg0, arg1, arg2, arg3); }
	public static void glGetMaterialiv(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetMaterialiv(arg0, arg1, arg2); }
	public static void glGetMaterialiv(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetMaterialiv(arg0, arg1, arg2, arg3); }
	public static void glGetMinmax(int arg0, boolean arg1, int arg2, int arg3, java.nio.Buffer arg4){ gl.glGetMinmax(arg0, arg1, arg2, arg3, arg4); }
	public static void glGetMinmax(int arg0, boolean arg1, int arg2, int arg3, long arg4){ gl.glGetMinmax(arg0, arg1, arg2, arg3, arg4); }
	public static void glGetMinmaxParameterfv(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glGetMinmaxParameterfv(arg0, arg1, arg2); }
	public static void glGetMinmaxParameterfv(int arg0, int arg1, float[] arg2, int arg3){ gl.glGetMinmaxParameterfv(arg0, arg1, arg2, arg3); }
	public static void glGetMinmaxParameteriv(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetMinmaxParameteriv(arg0, arg1, arg2); }
	public static void glGetMinmaxParameteriv(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetMinmaxParameteriv(arg0, arg1, arg2, arg3); }
	public static void glGetObjectBufferfvATI(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glGetObjectBufferfvATI(arg0, arg1, arg2); }
	public static void glGetObjectBufferfvATI(int arg0, int arg1, float[] arg2, int arg3){ gl.glGetObjectBufferfvATI(arg0, arg1, arg2, arg3); }
	public static void glGetObjectBufferivATI(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetObjectBufferivATI(arg0, arg1, arg2); }
	public static void glGetObjectBufferivATI(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetObjectBufferivATI(arg0, arg1, arg2, arg3); }
	public static void glGetObjectParameterfvARB(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glGetObjectParameterfvARB(arg0, arg1, arg2); }
	public static void glGetObjectParameterfvARB(int arg0, int arg1, float[] arg2, int arg3){ gl.glGetObjectParameterfvARB(arg0, arg1, arg2, arg3); }
	public static void glGetObjectParameterivARB(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetObjectParameterivARB(arg0, arg1, arg2); }
	public static void glGetObjectParameterivARB(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetObjectParameterivARB(arg0, arg1, arg2, arg3); }
	public static void glGetOcclusionQueryivNV(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetOcclusionQueryivNV(arg0, arg1, arg2); }
	public static void glGetOcclusionQueryivNV(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetOcclusionQueryivNV(arg0, arg1, arg2, arg3); }
	public static void glGetOcclusionQueryuivNV(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetOcclusionQueryuivNV(arg0, arg1, arg2); }
	public static void glGetOcclusionQueryuivNV(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetOcclusionQueryuivNV(arg0, arg1, arg2, arg3); }
	public static void glGetPixelMapfv(int arg0, java.nio.FloatBuffer arg1){ gl.glGetPixelMapfv(arg0, arg1); }
	public static void glGetPixelMapfv(int arg0, float[] arg1, int arg2){ gl.glGetPixelMapfv(arg0, arg1, arg2); }
	public static void glGetPixelMapfv(int arg0, long arg1){ gl.glGetPixelMapfv(arg0, arg1); }
	public static void glGetPixelMapuiv(int arg0, java.nio.IntBuffer arg1){ gl.glGetPixelMapuiv(arg0, arg1); }
	public static void glGetPixelMapuiv(int arg0, int[] arg1, int arg2){ gl.glGetPixelMapuiv(arg0, arg1, arg2); }
	public static void glGetPixelMapuiv(int arg0, long arg1){ gl.glGetPixelMapuiv(arg0, arg1); }
	public static void glGetPixelMapusv(int arg0, java.nio.ShortBuffer arg1){ gl.glGetPixelMapusv(arg0, arg1); }
	public static void glGetPixelMapusv(int arg0, short[] arg1, int arg2){ gl.glGetPixelMapusv(arg0, arg1, arg2); }
	public static void glGetPixelMapusv(int arg0, long arg1){ gl.glGetPixelMapusv(arg0, arg1); }
	public static void glGetPixelTexGenParameterfvSGIS(int arg0, java.nio.FloatBuffer arg1){ gl.glGetPixelTexGenParameterfvSGIS(arg0, arg1); }
	public static void glGetPixelTexGenParameterfvSGIS(int arg0, float[] arg1, int arg2){ gl.glGetPixelTexGenParameterfvSGIS(arg0, arg1, arg2); }
	public static void glGetPixelTexGenParameterivSGIS(int arg0, java.nio.IntBuffer arg1){ gl.glGetPixelTexGenParameterivSGIS(arg0, arg1); }
	public static void glGetPixelTexGenParameterivSGIS(int arg0, int[] arg1, int arg2){ gl.glGetPixelTexGenParameterivSGIS(arg0, arg1, arg2); }
	public static void glGetPolygonStipple(java.nio.ByteBuffer arg0){ gl.glGetPolygonStipple(arg0); }
	public static void glGetPolygonStipple(byte[] arg0, int arg1){ gl.glGetPolygonStipple(arg0, arg1); }
	public static void glGetPolygonStipple(long arg0){ gl.glGetPolygonStipple(arg0); }
	public static void glGetProgramEnvParameterIivNV(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetProgramEnvParameterIivNV(arg0, arg1, arg2); }
	public static void glGetProgramEnvParameterIivNV(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetProgramEnvParameterIivNV(arg0, arg1, arg2, arg3); }
	public static void glGetProgramEnvParameterIuivNV(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetProgramEnvParameterIuivNV(arg0, arg1, arg2); }
	public static void glGetProgramEnvParameterIuivNV(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetProgramEnvParameterIuivNV(arg0, arg1, arg2, arg3); }
	public static void glGetProgramEnvParameterdvARB(int arg0, int arg1, java.nio.DoubleBuffer arg2){ gl.glGetProgramEnvParameterdvARB(arg0, arg1, arg2); }
	public static void glGetProgramEnvParameterdvARB(int arg0, int arg1, double[] arg2, int arg3){ gl.glGetProgramEnvParameterdvARB(arg0, arg1, arg2, arg3); }
	public static void glGetProgramEnvParameterfvARB(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glGetProgramEnvParameterfvARB(arg0, arg1, arg2); }
	public static void glGetProgramEnvParameterfvARB(int arg0, int arg1, float[] arg2, int arg3){ gl.glGetProgramEnvParameterfvARB(arg0, arg1, arg2, arg3); }
	public static void glGetProgramInfoLog(int arg0, int arg1, java.nio.IntBuffer arg2, java.nio.ByteBuffer arg3){ gl.glGetProgramInfoLog(arg0, arg1, arg2, arg3); }
	public static void glGetProgramInfoLog(int arg0, int arg1, int[] arg2, int arg3, byte[] arg4, int arg5){ gl.glGetProgramInfoLog(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glGetProgramLocalParameterIivNV(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetProgramLocalParameterIivNV(arg0, arg1, arg2); }
	public static void glGetProgramLocalParameterIivNV(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetProgramLocalParameterIivNV(arg0, arg1, arg2, arg3); }
	public static void glGetProgramLocalParameterIuivNV(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetProgramLocalParameterIuivNV(arg0, arg1, arg2); }
	public static void glGetProgramLocalParameterIuivNV(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetProgramLocalParameterIuivNV(arg0, arg1, arg2, arg3); }
	public static void glGetProgramLocalParameterdvARB(int arg0, int arg1, java.nio.DoubleBuffer arg2){ gl.glGetProgramLocalParameterdvARB(arg0, arg1, arg2); }
	public static void glGetProgramLocalParameterdvARB(int arg0, int arg1, double[] arg2, int arg3){ gl.glGetProgramLocalParameterdvARB(arg0, arg1, arg2, arg3); }
	public static void glGetProgramLocalParameterfvARB(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glGetProgramLocalParameterfvARB(arg0, arg1, arg2); }
	public static void glGetProgramLocalParameterfvARB(int arg0, int arg1, float[] arg2, int arg3){ gl.glGetProgramLocalParameterfvARB(arg0, arg1, arg2, arg3); }
	public static void glGetProgramNamedParameterdvNV(int arg0, int arg1, java.lang.String arg2, java.nio.DoubleBuffer arg3){ gl.glGetProgramNamedParameterdvNV(arg0, arg1, arg2, arg3); }
	public static void glGetProgramNamedParameterdvNV(int arg0, int arg1, java.lang.String arg2, double[] arg3, int arg4){ gl.glGetProgramNamedParameterdvNV(arg0, arg1, arg2, arg3, arg4); }
	public static void glGetProgramNamedParameterfvNV(int arg0, int arg1, java.lang.String arg2, java.nio.FloatBuffer arg3){ gl.glGetProgramNamedParameterfvNV(arg0, arg1, arg2, arg3); }
	public static void glGetProgramNamedParameterfvNV(int arg0, int arg1, java.lang.String arg2, float[] arg3, int arg4){ gl.glGetProgramNamedParameterfvNV(arg0, arg1, arg2, arg3, arg4); }
	public static void glGetProgramParameterdvNV(int arg0, int arg1, int arg2, java.nio.DoubleBuffer arg3){ gl.glGetProgramParameterdvNV(arg0, arg1, arg2, arg3); }
	public static void glGetProgramParameterdvNV(int arg0, int arg1, int arg2, double[] arg3, int arg4){ gl.glGetProgramParameterdvNV(arg0, arg1, arg2, arg3, arg4); }
	public static void glGetProgramParameterfvNV(int arg0, int arg1, int arg2, java.nio.FloatBuffer arg3){ gl.glGetProgramParameterfvNV(arg0, arg1, arg2, arg3); }
	public static void glGetProgramParameterfvNV(int arg0, int arg1, int arg2, float[] arg3, int arg4){ gl.glGetProgramParameterfvNV(arg0, arg1, arg2, arg3, arg4); }
	public static void glGetProgramStringARB(int arg0, int arg1, java.nio.Buffer arg2){ gl.glGetProgramStringARB(arg0, arg1, arg2); }
	public static void glGetProgramStringNV(int arg0, int arg1, java.nio.ByteBuffer arg2){ gl.glGetProgramStringNV(arg0, arg1, arg2); }
	public static void glGetProgramStringNV(int arg0, int arg1, byte[] arg2, int arg3){ gl.glGetProgramStringNV(arg0, arg1, arg2, arg3); }
	public static void glGetProgramiv(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetProgramiv(arg0, arg1, arg2); }
	public static void glGetProgramiv(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetProgramiv(arg0, arg1, arg2, arg3); }
	public static void glGetProgramivARB(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetProgramivARB(arg0, arg1, arg2); }
	public static void glGetProgramivARB(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetProgramivARB(arg0, arg1, arg2, arg3); }
	public static void glGetProgramivNV(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetProgramivNV(arg0, arg1, arg2); }
	public static void glGetProgramivNV(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetProgramivNV(arg0, arg1, arg2, arg3); }
	public static void glGetQueryObjecti64vEXT(int arg0, int arg1, java.nio.LongBuffer arg2){ gl.glGetQueryObjecti64vEXT(arg0, arg1, arg2); }
	public static void glGetQueryObjecti64vEXT(int arg0, int arg1, long[] arg2, int arg3){ gl.glGetQueryObjecti64vEXT(arg0, arg1, arg2, arg3); }
	public static void glGetQueryObjectiv(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetQueryObjectiv(arg0, arg1, arg2); }
	public static void glGetQueryObjectiv(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetQueryObjectiv(arg0, arg1, arg2, arg3); }
	public static void glGetQueryObjectivARB(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetQueryObjectivARB(arg0, arg1, arg2); }
	public static void glGetQueryObjectivARB(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetQueryObjectivARB(arg0, arg1, arg2, arg3); }
	public static void glGetQueryObjectui64vEXT(int arg0, int arg1, java.nio.LongBuffer arg2){ gl.glGetQueryObjectui64vEXT(arg0, arg1, arg2); }
	public static void glGetQueryObjectui64vEXT(int arg0, int arg1, long[] arg2, int arg3){ gl.glGetQueryObjectui64vEXT(arg0, arg1, arg2, arg3); }
	public static void glGetQueryObjectuiv(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetQueryObjectuiv(arg0, arg1, arg2); }
	public static void glGetQueryObjectuiv(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetQueryObjectuiv(arg0, arg1, arg2, arg3); }
	public static void glGetQueryObjectuivARB(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetQueryObjectuivARB(arg0, arg1, arg2); }
	public static void glGetQueryObjectuivARB(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetQueryObjectuivARB(arg0, arg1, arg2, arg3); }
	public static void glGetQueryiv(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetQueryiv(arg0, arg1, arg2); }
	public static void glGetQueryiv(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetQueryiv(arg0, arg1, arg2, arg3); }
	public static void glGetQueryivARB(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetQueryivARB(arg0, arg1, arg2); }
	public static void glGetQueryivARB(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetQueryivARB(arg0, arg1, arg2, arg3); }
	public static void glGetRenderbufferParameterivEXT(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetRenderbufferParameterivEXT(arg0, arg1, arg2); }
	public static void glGetRenderbufferParameterivEXT(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetRenderbufferParameterivEXT(arg0, arg1, arg2, arg3); }
	public static void glGetSeparableFilter(int arg0, int arg1, int arg2, java.nio.Buffer arg3, java.nio.Buffer arg4, java.nio.Buffer arg5){ gl.glGetSeparableFilter(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glGetSeparableFilter(int arg0, int arg1, int arg2, long arg3, long arg4, long arg5){ gl.glGetSeparableFilter(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glGetShaderInfoLog(int arg0, int arg1, java.nio.IntBuffer arg2, java.nio.ByteBuffer arg3){ gl.glGetShaderInfoLog(arg0, arg1, arg2, arg3); }
	public static void glGetShaderInfoLog(int arg0, int arg1, int[] arg2, int arg3, byte[] arg4, int arg5){ gl.glGetShaderInfoLog(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glGetShaderSource(int arg0, int arg1, java.nio.IntBuffer arg2, java.nio.ByteBuffer arg3){ gl.glGetShaderSource(arg0, arg1, arg2, arg3); }
	public static void glGetShaderSource(int arg0, int arg1, int[] arg2, int arg3, byte[] arg4, int arg5){ gl.glGetShaderSource(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glGetShaderSourceARB(int arg0, int arg1, java.nio.IntBuffer arg2, java.nio.ByteBuffer arg3){ gl.glGetShaderSourceARB(arg0, arg1, arg2, arg3); }
	public static void glGetShaderSourceARB(int arg0, int arg1, int[] arg2, int arg3, byte[] arg4, int arg5){ gl.glGetShaderSourceARB(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glGetShaderiv(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetShaderiv(arg0, arg1, arg2); }
	public static void glGetShaderiv(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetShaderiv(arg0, arg1, arg2, arg3); }
	public static void glGetSharpenTexFuncSGIS(int arg0, java.nio.FloatBuffer arg1){ gl.glGetSharpenTexFuncSGIS(arg0, arg1); }
	public static void glGetSharpenTexFuncSGIS(int arg0, float[] arg1, int arg2){ gl.glGetSharpenTexFuncSGIS(arg0, arg1, arg2); }
	public static java.lang.String glGetString(int arg0){return gl.glGetString(arg0); }
	public static void glGetTexBumpParameterfvATI(int arg0, java.nio.FloatBuffer arg1){ gl.glGetTexBumpParameterfvATI(arg0, arg1); }
	public static void glGetTexBumpParameterfvATI(int arg0, float[] arg1, int arg2){ gl.glGetTexBumpParameterfvATI(arg0, arg1, arg2); }
	public static void glGetTexBumpParameterivATI(int arg0, java.nio.IntBuffer arg1){ gl.glGetTexBumpParameterivATI(arg0, arg1); }
	public static void glGetTexBumpParameterivATI(int arg0, int[] arg1, int arg2){ gl.glGetTexBumpParameterivATI(arg0, arg1, arg2); }
	public static void glGetTexEnvfv(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glGetTexEnvfv(arg0, arg1, arg2); }
	public static void glGetTexEnvfv(int arg0, int arg1, float[] arg2, int arg3){ gl.glGetTexEnvfv(arg0, arg1, arg2, arg3); }
	public static void glGetTexEnviv(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetTexEnviv(arg0, arg1, arg2); }
	public static void glGetTexEnviv(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetTexEnviv(arg0, arg1, arg2, arg3); }
	public static void glGetTexFilterFuncSGIS(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glGetTexFilterFuncSGIS(arg0, arg1, arg2); }
	public static void glGetTexFilterFuncSGIS(int arg0, int arg1, float[] arg2, int arg3){ gl.glGetTexFilterFuncSGIS(arg0, arg1, arg2, arg3); }
	public static void glGetTexGendv(int arg0, int arg1, java.nio.DoubleBuffer arg2){ gl.glGetTexGendv(arg0, arg1, arg2); }
	public static void glGetTexGendv(int arg0, int arg1, double[] arg2, int arg3){ gl.glGetTexGendv(arg0, arg1, arg2, arg3); }
	public static void glGetTexGenfv(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glGetTexGenfv(arg0, arg1, arg2); }
	public static void glGetTexGenfv(int arg0, int arg1, float[] arg2, int arg3){ gl.glGetTexGenfv(arg0, arg1, arg2, arg3); }
	public static void glGetTexGeniv(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetTexGeniv(arg0, arg1, arg2); }
	public static void glGetTexGeniv(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetTexGeniv(arg0, arg1, arg2, arg3); }
	public static void glGetTexImage(int arg0, int arg1, int arg2, int arg3, java.nio.Buffer arg4){ gl.glGetTexImage(arg0, arg1, arg2, arg3, arg4); }
	public static void glGetTexImage(int arg0, int arg1, int arg2, int arg3, long arg4){ gl.glGetTexImage(arg0, arg1, arg2, arg3, arg4); }
	public static void glGetTexLevelParameterfv(int arg0, int arg1, int arg2, java.nio.FloatBuffer arg3){ gl.glGetTexLevelParameterfv(arg0, arg1, arg2, arg3); }
	public static void glGetTexLevelParameterfv(int arg0, int arg1, int arg2, float[] arg3, int arg4){ gl.glGetTexLevelParameterfv(arg0, arg1, arg2, arg3, arg4); }
	public static void glGetTexLevelParameteriv(int arg0, int arg1, int arg2, java.nio.IntBuffer arg3){ gl.glGetTexLevelParameteriv(arg0, arg1, arg2, arg3); }
	public static void glGetTexLevelParameteriv(int arg0, int arg1, int arg2, int[] arg3, int arg4){ gl.glGetTexLevelParameteriv(arg0, arg1, arg2, arg3, arg4); }
	public static void glGetTexParameterIivEXT(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetTexParameterIivEXT(arg0, arg1, arg2); }
	public static void glGetTexParameterIivEXT(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetTexParameterIivEXT(arg0, arg1, arg2, arg3); }
	public static void glGetTexParameterIuivEXT(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetTexParameterIuivEXT(arg0, arg1, arg2); }
	public static void glGetTexParameterIuivEXT(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetTexParameterIuivEXT(arg0, arg1, arg2, arg3); }
	public static void glGetTexParameterfv(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glGetTexParameterfv(arg0, arg1, arg2); }
	public static void glGetTexParameterfv(int arg0, int arg1, float[] arg2, int arg3){ gl.glGetTexParameterfv(arg0, arg1, arg2, arg3); }
	public static void glGetTexParameteriv(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetTexParameteriv(arg0, arg1, arg2); }
	public static void glGetTexParameteriv(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetTexParameteriv(arg0, arg1, arg2, arg3); }
	public static void glGetTrackMatrixivNV(int arg0, int arg1, int arg2, java.nio.IntBuffer arg3){ gl.glGetTrackMatrixivNV(arg0, arg1, arg2, arg3); }
	public static void glGetTrackMatrixivNV(int arg0, int arg1, int arg2, int[] arg3, int arg4){ gl.glGetTrackMatrixivNV(arg0, arg1, arg2, arg3, arg4); }
	public static void glGetTransformFeedbackVaryingNV(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetTransformFeedbackVaryingNV(arg0, arg1, arg2); }
	public static void glGetTransformFeedbackVaryingNV(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetTransformFeedbackVaryingNV(arg0, arg1, arg2, arg3); }
	public static int glGetUniformBufferSizeEXT(int arg0, int arg1){return gl.glGetUniformBufferSizeEXT(arg0, arg1); }
	public static int glGetUniformLocation(int arg0, java.lang.String arg1){return gl.glGetUniformLocation(arg0, arg1); }
	public static int glGetUniformLocationARB(int arg0, java.lang.String arg1){return gl.glGetUniformLocationARB(arg0, arg1); }
	public static int glGetUniformOffsetEXT(int arg0, int arg1){return gl.glGetUniformOffsetEXT(arg0, arg1); }
	public static void glGetUniformfv(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glGetUniformfv(arg0, arg1, arg2); }
	public static void glGetUniformfv(int arg0, int arg1, float[] arg2, int arg3){ gl.glGetUniformfv(arg0, arg1, arg2, arg3); }
	public static void glGetUniformfvARB(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glGetUniformfvARB(arg0, arg1, arg2); }
	public static void glGetUniformfvARB(int arg0, int arg1, float[] arg2, int arg3){ gl.glGetUniformfvARB(arg0, arg1, arg2, arg3); }
	public static void glGetUniformiv(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetUniformiv(arg0, arg1, arg2); }
	public static void glGetUniformiv(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetUniformiv(arg0, arg1, arg2, arg3); }
	public static void glGetUniformivARB(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetUniformivARB(arg0, arg1, arg2); }
	public static void glGetUniformivARB(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetUniformivARB(arg0, arg1, arg2, arg3); }
	public static void glGetUniformuivEXT(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetUniformuivEXT(arg0, arg1, arg2); }
	public static void glGetUniformuivEXT(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetUniformuivEXT(arg0, arg1, arg2, arg3); }
	public static void glGetVariantArrayObjectfvATI(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glGetVariantArrayObjectfvATI(arg0, arg1, arg2); }
	public static void glGetVariantArrayObjectfvATI(int arg0, int arg1, float[] arg2, int arg3){ gl.glGetVariantArrayObjectfvATI(arg0, arg1, arg2, arg3); }
	public static void glGetVariantArrayObjectivATI(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetVariantArrayObjectivATI(arg0, arg1, arg2); }
	public static void glGetVariantArrayObjectivATI(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetVariantArrayObjectivATI(arg0, arg1, arg2, arg3); }
	public static void glGetVariantBooleanvEXT(int arg0, int arg1, java.nio.ByteBuffer arg2){ gl.glGetVariantBooleanvEXT(arg0, arg1, arg2); }
	public static void glGetVariantBooleanvEXT(int arg0, int arg1, byte[] arg2, int arg3){ gl.glGetVariantBooleanvEXT(arg0, arg1, arg2, arg3); }
	public static void glGetVariantFloatvEXT(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glGetVariantFloatvEXT(arg0, arg1, arg2); }
	public static void glGetVariantFloatvEXT(int arg0, int arg1, float[] arg2, int arg3){ gl.glGetVariantFloatvEXT(arg0, arg1, arg2, arg3); }
	public static void glGetVariantIntegervEXT(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetVariantIntegervEXT(arg0, arg1, arg2); }
	public static void glGetVariantIntegervEXT(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetVariantIntegervEXT(arg0, arg1, arg2, arg3); }
	public static int glGetVaryingLocationNV(int arg0, java.nio.ByteBuffer arg1){return gl.glGetVaryingLocationNV(arg0, arg1); }
	public static int glGetVaryingLocationNV(int arg0, byte[] arg1, int arg2){return gl.glGetVaryingLocationNV(arg0, arg1, arg2); }
	public static void glGetVertexAttribArrayObjectfvATI(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glGetVertexAttribArrayObjectfvATI(arg0, arg1, arg2); }
	public static void glGetVertexAttribArrayObjectfvATI(int arg0, int arg1, float[] arg2, int arg3){ gl.glGetVertexAttribArrayObjectfvATI(arg0, arg1, arg2, arg3); }
	public static void glGetVertexAttribArrayObjectivATI(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetVertexAttribArrayObjectivATI(arg0, arg1, arg2); }
	public static void glGetVertexAttribArrayObjectivATI(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetVertexAttribArrayObjectivATI(arg0, arg1, arg2, arg3); }
	public static void glGetVertexAttribIivEXT(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetVertexAttribIivEXT(arg0, arg1, arg2); }
	public static void glGetVertexAttribIivEXT(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetVertexAttribIivEXT(arg0, arg1, arg2, arg3); }
	public static void glGetVertexAttribIuivEXT(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetVertexAttribIuivEXT(arg0, arg1, arg2); }
	public static void glGetVertexAttribIuivEXT(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetVertexAttribIuivEXT(arg0, arg1, arg2, arg3); }
	public static void glGetVertexAttribdv(int arg0, int arg1, java.nio.DoubleBuffer arg2){ gl.glGetVertexAttribdv(arg0, arg1, arg2); }
	public static void glGetVertexAttribdv(int arg0, int arg1, double[] arg2, int arg3){ gl.glGetVertexAttribdv(arg0, arg1, arg2, arg3); }
	public static void glGetVertexAttribdvARB(int arg0, int arg1, java.nio.DoubleBuffer arg2){ gl.glGetVertexAttribdvARB(arg0, arg1, arg2); }
	public static void glGetVertexAttribdvARB(int arg0, int arg1, double[] arg2, int arg3){ gl.glGetVertexAttribdvARB(arg0, arg1, arg2, arg3); }
	public static void glGetVertexAttribdvNV(int arg0, int arg1, java.nio.DoubleBuffer arg2){ gl.glGetVertexAttribdvNV(arg0, arg1, arg2); }
	public static void glGetVertexAttribdvNV(int arg0, int arg1, double[] arg2, int arg3){ gl.glGetVertexAttribdvNV(arg0, arg1, arg2, arg3); }
	public static void glGetVertexAttribfv(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glGetVertexAttribfv(arg0, arg1, arg2); }
	public static void glGetVertexAttribfv(int arg0, int arg1, float[] arg2, int arg3){ gl.glGetVertexAttribfv(arg0, arg1, arg2, arg3); }
	public static void glGetVertexAttribfvARB(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glGetVertexAttribfvARB(arg0, arg1, arg2); }
	public static void glGetVertexAttribfvARB(int arg0, int arg1, float[] arg2, int arg3){ gl.glGetVertexAttribfvARB(arg0, arg1, arg2, arg3); }
	public static void glGetVertexAttribfvNV(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glGetVertexAttribfvNV(arg0, arg1, arg2); }
	public static void glGetVertexAttribfvNV(int arg0, int arg1, float[] arg2, int arg3){ gl.glGetVertexAttribfvNV(arg0, arg1, arg2, arg3); }
	public static void glGetVertexAttribiv(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetVertexAttribiv(arg0, arg1, arg2); }
	public static void glGetVertexAttribiv(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetVertexAttribiv(arg0, arg1, arg2, arg3); }
	public static void glGetVertexAttribivARB(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetVertexAttribivARB(arg0, arg1, arg2); }
	public static void glGetVertexAttribivARB(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetVertexAttribivARB(arg0, arg1, arg2, arg3); }
	public static void glGetVertexAttribivNV(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glGetVertexAttribivNV(arg0, arg1, arg2); }
	public static void glGetVertexAttribivNV(int arg0, int arg1, int[] arg2, int arg3){ gl.glGetVertexAttribivNV(arg0, arg1, arg2, arg3); }
	public static void glGlobalAlphaFactorbSUN(byte arg0){ gl.glGlobalAlphaFactorbSUN(arg0); }
	public static void glGlobalAlphaFactordSUN(double arg0){ gl.glGlobalAlphaFactordSUN(arg0); }
	public static void glGlobalAlphaFactorfSUN(float arg0){ gl.glGlobalAlphaFactorfSUN(arg0); }
	public static void glGlobalAlphaFactoriSUN(int arg0){ gl.glGlobalAlphaFactoriSUN(arg0); }
	public static void glGlobalAlphaFactorsSUN(short arg0){ gl.glGlobalAlphaFactorsSUN(arg0); }
	public static void glGlobalAlphaFactorubSUN(byte arg0){ gl.glGlobalAlphaFactorubSUN(arg0); }
	public static void glGlobalAlphaFactoruiSUN(int arg0){ gl.glGlobalAlphaFactoruiSUN(arg0); }
	public static void glGlobalAlphaFactorusSUN(short arg0){ gl.glGlobalAlphaFactorusSUN(arg0); }
	public static void glHint(int arg0, int arg1){ gl.glHint(arg0, arg1); }
	public static void glHintPGI(int arg0, int arg1){ gl.glHintPGI(arg0, arg1); }
	public static void glHistogram(int arg0, int arg1, int arg2, boolean arg3){ gl.glHistogram(arg0, arg1, arg2, arg3); }
	public static void glIglooInterfaceSGIX(int arg0, java.nio.Buffer arg1){ gl.glIglooInterfaceSGIX(arg0, arg1); }
	public static void glImageTransformParameterfHP(int arg0, int arg1, float arg2){ gl.glImageTransformParameterfHP(arg0, arg1, arg2); }
	public static void glImageTransformParameterfvHP(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glImageTransformParameterfvHP(arg0, arg1, arg2); }
	public static void glImageTransformParameterfvHP(int arg0, int arg1, float[] arg2, int arg3){ gl.glImageTransformParameterfvHP(arg0, arg1, arg2, arg3); }
	public static void glImageTransformParameteriHP(int arg0, int arg1, int arg2){ gl.glImageTransformParameteriHP(arg0, arg1, arg2); }
	public static void glImageTransformParameterivHP(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glImageTransformParameterivHP(arg0, arg1, arg2); }
	public static void glImageTransformParameterivHP(int arg0, int arg1, int[] arg2, int arg3){ gl.glImageTransformParameterivHP(arg0, arg1, arg2, arg3); }
	public static void glIndexFuncEXT(int arg0, float arg1){ gl.glIndexFuncEXT(arg0, arg1); }
	public static void glIndexMask(int arg0){ gl.glIndexMask(arg0); }
	public static void glIndexMaterialEXT(int arg0, int arg1){ gl.glIndexMaterialEXT(arg0, arg1); }
	public static void glIndexPointer(int arg0, int arg1, java.nio.Buffer arg2){ gl.glIndexPointer(arg0, arg1, arg2); }
	public static void glIndexd(double arg0){ gl.glIndexd(arg0); }
	public static void glIndexdv(java.nio.DoubleBuffer arg0){ gl.glIndexdv(arg0); }
	public static void glIndexdv(double[] arg0, int arg1){ gl.glIndexdv(arg0, arg1); }
	public static void glIndexf(float arg0){ gl.glIndexf(arg0); }
	public static void glIndexfv(java.nio.FloatBuffer arg0){ gl.glIndexfv(arg0); }
	public static void glIndexfv(float[] arg0, int arg1){ gl.glIndexfv(arg0, arg1); }
	public static void glIndexi(int arg0){ gl.glIndexi(arg0); }
	public static void glIndexiv(java.nio.IntBuffer arg0){ gl.glIndexiv(arg0); }
	public static void glIndexiv(int[] arg0, int arg1){ gl.glIndexiv(arg0, arg1); }
	public static void glIndexs(short arg0){ gl.glIndexs(arg0); }
	public static void glIndexsv(java.nio.ShortBuffer arg0){ gl.glIndexsv(arg0); }
	public static void glIndexsv(short[] arg0, int arg1){ gl.glIndexsv(arg0, arg1); }
	public static void glIndexub(byte arg0){ gl.glIndexub(arg0); }
	public static void glIndexubv(java.nio.ByteBuffer arg0){ gl.glIndexubv(arg0); }
	public static void glIndexubv(byte[] arg0, int arg1){ gl.glIndexubv(arg0, arg1); }
	public static void glInitNames(){ gl.glInitNames(); }
	public static void glInsertComponentEXT(int arg0, int arg1, int arg2){ gl.glInsertComponentEXT(arg0, arg1, arg2); }
	public static void glInstrumentsBufferSGIX(int arg0, java.nio.IntBuffer arg1){ gl.glInstrumentsBufferSGIX(arg0, arg1); }
	public static void glInstrumentsBufferSGIX(int arg0, int[] arg1, int arg2){ gl.glInstrumentsBufferSGIX(arg0, arg1, arg2); }
	public static void glInterleavedArrays(int arg0, int arg1, java.nio.Buffer arg2){ gl.glInterleavedArrays(arg0, arg1, arg2); }
	public static void glInterleavedArrays(int arg0, int arg1, long arg2){ gl.glInterleavedArrays(arg0, arg1, arg2); }
	public static boolean glIsAsyncMarkerSGIX(int arg0){return gl.glIsAsyncMarkerSGIX(arg0); }
	public static boolean glIsBuffer(int arg0){return gl.glIsBuffer(arg0); }
	public static boolean glIsBufferARB(int arg0){return gl.glIsBufferARB(arg0); }
	public static boolean glIsEnabled(int arg0){return gl.glIsEnabled(arg0); }
	public static boolean glIsEnabledIndexedEXT(int arg0, int arg1){return gl.glIsEnabledIndexedEXT(arg0, arg1); }
	public static boolean glIsFenceAPPLE(int arg0){return gl.glIsFenceAPPLE(arg0); }
	public static boolean glIsFenceNV(int arg0){return gl.glIsFenceNV(arg0); }
	public static boolean glIsFramebufferEXT(int arg0){return gl.glIsFramebufferEXT(arg0); }
	public static boolean glIsList(int arg0){return gl.glIsList(arg0); }
	public static boolean glIsObjectBufferATI(int arg0){return gl.glIsObjectBufferATI(arg0); }
	public static boolean glIsOcclusionQueryNV(int arg0){return gl.glIsOcclusionQueryNV(arg0); }
	public static boolean glIsProgram(int arg0){return gl.glIsProgram(arg0); }
	public static boolean glIsProgramARB(int arg0){return gl.glIsProgramARB(arg0); }
	public static boolean glIsProgramNV(int arg0){return gl.glIsProgramNV(arg0); }
	public static boolean glIsQuery(int arg0){return gl.glIsQuery(arg0); }
	public static boolean glIsQueryARB(int arg0){return gl.glIsQueryARB(arg0); }
	public static boolean glIsRenderbufferEXT(int arg0){return gl.glIsRenderbufferEXT(arg0); }
	public static boolean glIsShader(int arg0){return gl.glIsShader(arg0); }
	public static boolean glIsTexture(int arg0){return gl.glIsTexture(arg0); }
	public static boolean glIsVariantEnabledEXT(int arg0, int arg1){return gl.glIsVariantEnabledEXT(arg0, arg1); }
	public static boolean glIsVertexArrayAPPLE(int arg0){return gl.glIsVertexArrayAPPLE(arg0); }
	public static boolean glIsVertexAttribEnabledAPPLE(int arg0, int arg1){return gl.glIsVertexAttribEnabledAPPLE(arg0, arg1); }
	public static void glLightEnviSGIX(int arg0, int arg1){ gl.glLightEnviSGIX(arg0, arg1); }
	public static void glLightModelf(int arg0, float arg1){ gl.glLightModelf(arg0, arg1); }
	public static void glLightModelfv(int arg0, java.nio.FloatBuffer arg1){ gl.glLightModelfv(arg0, arg1); }
	public static void glLightModelfv(int arg0, float[] arg1, int arg2){ gl.glLightModelfv(arg0, arg1, arg2); }
	public static void glLightModeli(int arg0, int arg1){ gl.glLightModeli(arg0, arg1); }
	public static void glLightModeliv(int arg0, java.nio.IntBuffer arg1){ gl.glLightModeliv(arg0, arg1); }
	public static void glLightModeliv(int arg0, int[] arg1, int arg2){ gl.glLightModeliv(arg0, arg1, arg2); }
	public static void glLightf(int arg0, int arg1, float arg2){ gl.glLightf(arg0, arg1, arg2); }
	public static void glLightfv(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glLightfv(arg0, arg1, arg2); }
	public static void glLightfv(int arg0, int arg1, float[] arg2, int arg3){ gl.glLightfv(arg0, arg1, arg2, arg3); }
	public static void glLighti(int arg0, int arg1, int arg2){ gl.glLighti(arg0, arg1, arg2); }
	public static void glLightiv(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glLightiv(arg0, arg1, arg2); }
	public static void glLightiv(int arg0, int arg1, int[] arg2, int arg3){ gl.glLightiv(arg0, arg1, arg2, arg3); }
	public static void glLineStipple(int arg0, short arg1){ gl.glLineStipple(arg0, arg1); }
	public static void glLineWidth(float arg0){ gl.glLineWidth(arg0); }
	public static void glLinkProgram(int arg0){ gl.glLinkProgram(arg0); }
	public static void glLinkProgramARB(int arg0){ gl.glLinkProgramARB(arg0); }
	public static void glListBase(int arg0){ gl.glListBase(arg0); }
	public static void glListParameterfSGIX(int arg0, int arg1, float arg2){ gl.glListParameterfSGIX(arg0, arg1, arg2); }
	public static void glListParameterfvSGIX(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glListParameterfvSGIX(arg0, arg1, arg2); }
	public static void glListParameterfvSGIX(int arg0, int arg1, float[] arg2, int arg3){ gl.glListParameterfvSGIX(arg0, arg1, arg2, arg3); }
	public static void glListParameteriSGIX(int arg0, int arg1, int arg2){ gl.glListParameteriSGIX(arg0, arg1, arg2); }
	public static void glListParameterivSGIX(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glListParameterivSGIX(arg0, arg1, arg2); }
	public static void glListParameterivSGIX(int arg0, int arg1, int[] arg2, int arg3){ gl.glListParameterivSGIX(arg0, arg1, arg2, arg3); }
	public static void glLoadIdentity(){ gl.glLoadIdentity(); }
	public static void glLoadIdentityDeformationMapSGIX(int arg0){ gl.glLoadIdentityDeformationMapSGIX(arg0); }
	public static void glLoadMatrixd(java.nio.DoubleBuffer arg0){ gl.glLoadMatrixd(arg0); }
	public static void glLoadMatrixd(double[] arg0, int arg1){ gl.glLoadMatrixd(arg0, arg1); }
	public static void glLoadMatrixf(java.nio.FloatBuffer arg0){ gl.glLoadMatrixf(arg0); }
	public static void glLoadMatrixf(float[] arg0, int arg1){ gl.glLoadMatrixf(arg0, arg1); }
	public static void glLoadName(int arg0){ gl.glLoadName(arg0); }
	public static void glLoadProgramNV(int arg0, int arg1, int arg2, java.lang.String arg3){ gl.glLoadProgramNV(arg0, arg1, arg2, arg3); }
	public static void glLoadTransposeMatrixd(java.nio.DoubleBuffer arg0){ gl.glLoadTransposeMatrixd(arg0); }
	public static void glLoadTransposeMatrixd(double[] arg0, int arg1){ gl.glLoadTransposeMatrixd(arg0, arg1); }
	public static void glLoadTransposeMatrixf(java.nio.FloatBuffer arg0){ gl.glLoadTransposeMatrixf(arg0); }
	public static void glLoadTransposeMatrixf(float[] arg0, int arg1){ gl.glLoadTransposeMatrixf(arg0, arg1); }
	public static void glLockArraysEXT(int arg0, int arg1){ gl.glLockArraysEXT(arg0, arg1); }
	public static void glLogicOp(int arg0){ gl.glLogicOp(arg0); }
	public static void glMap1d(int arg0, double arg1, double arg2, int arg3, int arg4, java.nio.DoubleBuffer arg5){ gl.glMap1d(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glMap1d(int arg0, double arg1, double arg2, int arg3, int arg4, double[] arg5, int arg6){ gl.glMap1d(arg0, arg1, arg2, arg3, arg4, arg5, arg6); }
	public static void glMap1f(int arg0, float arg1, float arg2, int arg3, int arg4, java.nio.FloatBuffer arg5){ gl.glMap1f(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glMap1f(int arg0, float arg1, float arg2, int arg3, int arg4, float[] arg5, int arg6){ gl.glMap1f(arg0, arg1, arg2, arg3, arg4, arg5, arg6); }
	public static void glMap2d(int arg0, double arg1, double arg2, int arg3, int arg4, double arg5, double arg6, int arg7, int arg8, java.nio.DoubleBuffer arg9){ gl.glMap2d(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9); }
	public static void glMap2d(int arg0, double arg1, double arg2, int arg3, int arg4, double arg5, double arg6, int arg7, int arg8, double[] arg9, int arg10){ gl.glMap2d(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10); }
	public static void glMap2f(int arg0, float arg1, float arg2, int arg3, int arg4, float arg5, float arg6, int arg7, int arg8, java.nio.FloatBuffer arg9){ gl.glMap2f(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9); }
	public static void glMap2f(int arg0, float arg1, float arg2, int arg3, int arg4, float arg5, float arg6, int arg7, int arg8, float[] arg9, int arg10){ gl.glMap2f(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10); }
	public static java.nio.ByteBuffer glMapBuffer(int arg0, int arg1){return gl.glMapBuffer(arg0, arg1); }
	public static java.nio.ByteBuffer glMapBufferARB(int arg0, int arg1){return gl.glMapBufferARB(arg0, arg1); }
	public static void glMapControlPointsNV(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6, boolean arg7, java.nio.Buffer arg8){ gl.glMapControlPointsNV(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8); }
	public static void glMapGrid1d(int arg0, double arg1, double arg2){ gl.glMapGrid1d(arg0, arg1, arg2); }
	public static void glMapGrid1f(int arg0, float arg1, float arg2){ gl.glMapGrid1f(arg0, arg1, arg2); }
	public static void glMapGrid2d(int arg0, double arg1, double arg2, int arg3, double arg4, double arg5){ gl.glMapGrid2d(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glMapGrid2f(int arg0, float arg1, float arg2, int arg3, float arg4, float arg5){ gl.glMapGrid2f(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glMapParameterfvNV(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glMapParameterfvNV(arg0, arg1, arg2); }
	public static void glMapParameterfvNV(int arg0, int arg1, float[] arg2, int arg3){ gl.glMapParameterfvNV(arg0, arg1, arg2, arg3); }
	public static void glMapParameterivNV(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glMapParameterivNV(arg0, arg1, arg2); }
	public static void glMapParameterivNV(int arg0, int arg1, int[] arg2, int arg3){ gl.glMapParameterivNV(arg0, arg1, arg2, arg3); }
	public static void glMapVertexAttrib1dAPPLE(int arg0, int arg1, double arg2, double arg3, int arg4, int arg5, java.nio.DoubleBuffer arg6){ gl.glMapVertexAttrib1dAPPLE(arg0, arg1, arg2, arg3, arg4, arg5, arg6); }
	public static void glMapVertexAttrib1dAPPLE(int arg0, int arg1, double arg2, double arg3, int arg4, int arg5, double[] arg6, int arg7){ gl.glMapVertexAttrib1dAPPLE(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7); }
	public static void glMapVertexAttrib1fAPPLE(int arg0, int arg1, float arg2, float arg3, int arg4, int arg5, java.nio.FloatBuffer arg6){ gl.glMapVertexAttrib1fAPPLE(arg0, arg1, arg2, arg3, arg4, arg5, arg6); }
	public static void glMapVertexAttrib1fAPPLE(int arg0, int arg1, float arg2, float arg3, int arg4, int arg5, float[] arg6, int arg7){ gl.glMapVertexAttrib1fAPPLE(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7); }
	public static void glMapVertexAttrib2dAPPLE(int arg0, int arg1, double arg2, double arg3, int arg4, int arg5, double arg6, double arg7, int arg8, int arg9, java.nio.DoubleBuffer arg10){ gl.glMapVertexAttrib2dAPPLE(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10); }
	public static void glMapVertexAttrib2dAPPLE(int arg0, int arg1, double arg2, double arg3, int arg4, int arg5, double arg6, double arg7, int arg8, int arg9, double[] arg10, int arg11){ gl.glMapVertexAttrib2dAPPLE(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11); }
	public static void glMapVertexAttrib2fAPPLE(int arg0, int arg1, float arg2, float arg3, int arg4, int arg5, float arg6, float arg7, int arg8, int arg9, java.nio.FloatBuffer arg10){ gl.glMapVertexAttrib2fAPPLE(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10); }
	public static void glMapVertexAttrib2fAPPLE(int arg0, int arg1, float arg2, float arg3, int arg4, int arg5, float arg6, float arg7, int arg8, int arg9, float[] arg10, int arg11){ gl.glMapVertexAttrib2fAPPLE(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11); }
	public static void glMaterialf(int arg0, int arg1, float arg2){ gl.glMaterialf(arg0, arg1, arg2); }
	public static void glMaterialfv(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glMaterialfv(arg0, arg1, arg2); }
	public static void glMaterialfv(int arg0, int arg1, float[] arg2, int arg3){ gl.glMaterialfv(arg0, arg1, arg2, arg3); }
	public static void glMateriali(int arg0, int arg1, int arg2){ gl.glMateriali(arg0, arg1, arg2); }
	public static void glMaterialiv(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glMaterialiv(arg0, arg1, arg2); }
	public static void glMaterialiv(int arg0, int arg1, int[] arg2, int arg3){ gl.glMaterialiv(arg0, arg1, arg2, arg3); }
	public static void glMatrixIndexPointerARB(int arg0, int arg1, int arg2, java.nio.Buffer arg3){ gl.glMatrixIndexPointerARB(arg0, arg1, arg2, arg3); }
	public static void glMatrixIndexPointerARB(int arg0, int arg1, int arg2, long arg3){ gl.glMatrixIndexPointerARB(arg0, arg1, arg2, arg3); }
	public static void glMatrixIndexubvARB(int arg0, java.nio.ByteBuffer arg1){ gl.glMatrixIndexubvARB(arg0, arg1); }
	public static void glMatrixIndexubvARB(int arg0, byte[] arg1, int arg2){ gl.glMatrixIndexubvARB(arg0, arg1, arg2); }
	public static void glMatrixIndexuivARB(int arg0, java.nio.IntBuffer arg1){ gl.glMatrixIndexuivARB(arg0, arg1); }
	public static void glMatrixIndexuivARB(int arg0, int[] arg1, int arg2){ gl.glMatrixIndexuivARB(arg0, arg1, arg2); }
	public static void glMatrixIndexusvARB(int arg0, java.nio.ShortBuffer arg1){ gl.glMatrixIndexusvARB(arg0, arg1); }
	public static void glMatrixIndexusvARB(int arg0, short[] arg1, int arg2){ gl.glMatrixIndexusvARB(arg0, arg1, arg2); }
	public static void glMatrixMode(int arg0){ gl.glMatrixMode(arg0); }
	public static void glMinmax(int arg0, int arg1, boolean arg2){ gl.glMinmax(arg0, arg1, arg2); }
	public static void glMultMatrixd(java.nio.DoubleBuffer arg0){ gl.glMultMatrixd(arg0); }
	public static void glMultMatrixd(double[] arg0, int arg1){ gl.glMultMatrixd(arg0, arg1); }
	public static void glMultMatrixf(java.nio.FloatBuffer arg0){ gl.glMultMatrixf(arg0); }
	public static void glMultMatrixf(float[] arg0, int arg1){ gl.glMultMatrixf(arg0, arg1); }
	public static void glMultTransposeMatrixd(java.nio.DoubleBuffer arg0){ gl.glMultTransposeMatrixd(arg0); }
	public static void glMultTransposeMatrixd(double[] arg0, int arg1){ gl.glMultTransposeMatrixd(arg0, arg1); }
	public static void glMultTransposeMatrixf(java.nio.FloatBuffer arg0){ gl.glMultTransposeMatrixf(arg0); }
	public static void glMultTransposeMatrixf(float[] arg0, int arg1){ gl.glMultTransposeMatrixf(arg0, arg1); }
	public static void glMultiDrawArrays(int arg0, java.nio.IntBuffer arg1, java.nio.IntBuffer arg2, int arg3){ gl.glMultiDrawArrays(arg0, arg1, arg2, arg3); }
	public static void glMultiDrawArrays(int arg0, int[] arg1, int arg2, int[] arg3, int arg4, int arg5){ gl.glMultiDrawArrays(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glMultiDrawArraysEXT(int arg0, java.nio.IntBuffer arg1, java.nio.IntBuffer arg2, int arg3){ gl.glMultiDrawArraysEXT(arg0, arg1, arg2, arg3); }
	public static void glMultiDrawArraysEXT(int arg0, int[] arg1, int arg2, int[] arg3, int arg4, int arg5){ gl.glMultiDrawArraysEXT(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glMultiDrawElementArrayAPPLE(int arg0, java.nio.IntBuffer arg1, java.nio.IntBuffer arg2, int arg3){ gl.glMultiDrawElementArrayAPPLE(arg0, arg1, arg2, arg3); }
	public static void glMultiDrawElementArrayAPPLE(int arg0, int[] arg1, int arg2, int[] arg3, int arg4, int arg5){ gl.glMultiDrawElementArrayAPPLE(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glMultiDrawElements(int arg0, java.nio.IntBuffer arg1, int arg2, java.nio.Buffer[] arg3, int arg4){ gl.glMultiDrawElements(arg0, arg1, arg2, arg3, arg4); }
	public static void glMultiDrawElements(int arg0, int[] arg1, int arg2, int arg3, java.nio.Buffer[] arg4, int arg5){ gl.glMultiDrawElements(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glMultiDrawElementsEXT(int arg0, java.nio.IntBuffer arg1, int arg2, java.nio.Buffer[] arg3, int arg4){ gl.glMultiDrawElementsEXT(arg0, arg1, arg2, arg3, arg4); }
	public static void glMultiDrawElementsEXT(int arg0, int[] arg1, int arg2, int arg3, java.nio.Buffer[] arg4, int arg5){ gl.glMultiDrawElementsEXT(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glMultiDrawRangeElementArrayAPPLE(int arg0, int arg1, int arg2, java.nio.IntBuffer arg3, java.nio.IntBuffer arg4, int arg5){ gl.glMultiDrawRangeElementArrayAPPLE(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glMultiDrawRangeElementArrayAPPLE(int arg0, int arg1, int arg2, int[] arg3, int arg4, int[] arg5, int arg6, int arg7){ gl.glMultiDrawRangeElementArrayAPPLE(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7); }
	public static void glMultiModeDrawArraysIBM(java.nio.IntBuffer arg0, java.nio.IntBuffer arg1, java.nio.IntBuffer arg2, int arg3, int arg4){ gl.glMultiModeDrawArraysIBM(arg0, arg1, arg2, arg3, arg4); }
	public static void glMultiModeDrawArraysIBM(int[] arg0, int arg1, int[] arg2, int arg3, int[] arg4, int arg5, int arg6, int arg7){ gl.glMultiModeDrawArraysIBM(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7); }
	public static void glMultiModeDrawElementsIBM(java.nio.IntBuffer arg0, java.nio.IntBuffer arg1, int arg2, java.nio.Buffer[] arg3, int arg4, int arg5){ gl.glMultiModeDrawElementsIBM(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glMultiModeDrawElementsIBM(int[] arg0, int arg1, int[] arg2, int arg3, int arg4, java.nio.Buffer[] arg5, int arg6, int arg7){ gl.glMultiModeDrawElementsIBM(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7); }
	public static void glMultiTexCoord1d(int arg0, double arg1){ gl.glMultiTexCoord1d(arg0, arg1); }
	public static void glMultiTexCoord1dv(int arg0, java.nio.DoubleBuffer arg1){ gl.glMultiTexCoord1dv(arg0, arg1); }
	public static void glMultiTexCoord1dv(int arg0, double[] arg1, int arg2){ gl.glMultiTexCoord1dv(arg0, arg1, arg2); }
	public static void glMultiTexCoord1f(int arg0, float arg1){ gl.glMultiTexCoord1f(arg0, arg1); }
	public static void glMultiTexCoord1fv(int arg0, java.nio.FloatBuffer arg1){ gl.glMultiTexCoord1fv(arg0, arg1); }
	public static void glMultiTexCoord1fv(int arg0, float[] arg1, int arg2){ gl.glMultiTexCoord1fv(arg0, arg1, arg2); }
	public static void glMultiTexCoord1hNV(int arg0, short arg1){ gl.glMultiTexCoord1hNV(arg0, arg1); }
	public static void glMultiTexCoord1hvNV(int arg0, java.nio.ShortBuffer arg1){ gl.glMultiTexCoord1hvNV(arg0, arg1); }
	public static void glMultiTexCoord1hvNV(int arg0, short[] arg1, int arg2){ gl.glMultiTexCoord1hvNV(arg0, arg1, arg2); }
	public static void glMultiTexCoord1i(int arg0, int arg1){ gl.glMultiTexCoord1i(arg0, arg1); }
	public static void glMultiTexCoord1iv(int arg0, java.nio.IntBuffer arg1){ gl.glMultiTexCoord1iv(arg0, arg1); }
	public static void glMultiTexCoord1iv(int arg0, int[] arg1, int arg2){ gl.glMultiTexCoord1iv(arg0, arg1, arg2); }
	public static void glMultiTexCoord1s(int arg0, short arg1){ gl.glMultiTexCoord1s(arg0, arg1); }
	public static void glMultiTexCoord1sv(int arg0, java.nio.ShortBuffer arg1){ gl.glMultiTexCoord1sv(arg0, arg1); }
	public static void glMultiTexCoord1sv(int arg0, short[] arg1, int arg2){ gl.glMultiTexCoord1sv(arg0, arg1, arg2); }
	public static void glMultiTexCoord2d(int arg0, double arg1, double arg2){ gl.glMultiTexCoord2d(arg0, arg1, arg2); }
	public static void glMultiTexCoord2dv(int arg0, java.nio.DoubleBuffer arg1){ gl.glMultiTexCoord2dv(arg0, arg1); }
	public static void glMultiTexCoord2dv(int arg0, double[] arg1, int arg2){ gl.glMultiTexCoord2dv(arg0, arg1, arg2); }
	public static void glMultiTexCoord2f(int arg0, float arg1, float arg2){ gl.glMultiTexCoord2f(arg0, arg1, arg2); }
	public static void glMultiTexCoord2fv(int arg0, java.nio.FloatBuffer arg1){ gl.glMultiTexCoord2fv(arg0, arg1); }
	public static void glMultiTexCoord2fv(int arg0, float[] arg1, int arg2){ gl.glMultiTexCoord2fv(arg0, arg1, arg2); }
	public static void glMultiTexCoord2hNV(int arg0, short arg1, short arg2){ gl.glMultiTexCoord2hNV(arg0, arg1, arg2); }
	public static void glMultiTexCoord2hvNV(int arg0, java.nio.ShortBuffer arg1){ gl.glMultiTexCoord2hvNV(arg0, arg1); }
	public static void glMultiTexCoord2hvNV(int arg0, short[] arg1, int arg2){ gl.glMultiTexCoord2hvNV(arg0, arg1, arg2); }
	public static void glMultiTexCoord2i(int arg0, int arg1, int arg2){ gl.glMultiTexCoord2i(arg0, arg1, arg2); }
	public static void glMultiTexCoord2iv(int arg0, java.nio.IntBuffer arg1){ gl.glMultiTexCoord2iv(arg0, arg1); }
	public static void glMultiTexCoord2iv(int arg0, int[] arg1, int arg2){ gl.glMultiTexCoord2iv(arg0, arg1, arg2); }
	public static void glMultiTexCoord2s(int arg0, short arg1, short arg2){ gl.glMultiTexCoord2s(arg0, arg1, arg2); }
	public static void glMultiTexCoord2sv(int arg0, java.nio.ShortBuffer arg1){ gl.glMultiTexCoord2sv(arg0, arg1); }
	public static void glMultiTexCoord2sv(int arg0, short[] arg1, int arg2){ gl.glMultiTexCoord2sv(arg0, arg1, arg2); }
	public static void glMultiTexCoord3d(int arg0, double arg1, double arg2, double arg3){ gl.glMultiTexCoord3d(arg0, arg1, arg2, arg3); }
	public static void glMultiTexCoord3dv(int arg0, java.nio.DoubleBuffer arg1){ gl.glMultiTexCoord3dv(arg0, arg1); }
	public static void glMultiTexCoord3dv(int arg0, double[] arg1, int arg2){ gl.glMultiTexCoord3dv(arg0, arg1, arg2); }
	public static void glMultiTexCoord3f(int arg0, float arg1, float arg2, float arg3){ gl.glMultiTexCoord3f(arg0, arg1, arg2, arg3); }
	public static void glMultiTexCoord3fv(int arg0, java.nio.FloatBuffer arg1){ gl.glMultiTexCoord3fv(arg0, arg1); }
	public static void glMultiTexCoord3fv(int arg0, float[] arg1, int arg2){ gl.glMultiTexCoord3fv(arg0, arg1, arg2); }
	public static void glMultiTexCoord3hNV(int arg0, short arg1, short arg2, short arg3){ gl.glMultiTexCoord3hNV(arg0, arg1, arg2, arg3); }
	public static void glMultiTexCoord3hvNV(int arg0, java.nio.ShortBuffer arg1){ gl.glMultiTexCoord3hvNV(arg0, arg1); }
	public static void glMultiTexCoord3hvNV(int arg0, short[] arg1, int arg2){ gl.glMultiTexCoord3hvNV(arg0, arg1, arg2); }
	public static void glMultiTexCoord3i(int arg0, int arg1, int arg2, int arg3){ gl.glMultiTexCoord3i(arg0, arg1, arg2, arg3); }
	public static void glMultiTexCoord3iv(int arg0, java.nio.IntBuffer arg1){ gl.glMultiTexCoord3iv(arg0, arg1); }
	public static void glMultiTexCoord3iv(int arg0, int[] arg1, int arg2){ gl.glMultiTexCoord3iv(arg0, arg1, arg2); }
	public static void glMultiTexCoord3s(int arg0, short arg1, short arg2, short arg3){ gl.glMultiTexCoord3s(arg0, arg1, arg2, arg3); }
	public static void glMultiTexCoord3sv(int arg0, java.nio.ShortBuffer arg1){ gl.glMultiTexCoord3sv(arg0, arg1); }
	public static void glMultiTexCoord3sv(int arg0, short[] arg1, int arg2){ gl.glMultiTexCoord3sv(arg0, arg1, arg2); }
	public static void glMultiTexCoord4d(int arg0, double arg1, double arg2, double arg3, double arg4){ gl.glMultiTexCoord4d(arg0, arg1, arg2, arg3, arg4); }
	public static void glMultiTexCoord4dv(int arg0, java.nio.DoubleBuffer arg1){ gl.glMultiTexCoord4dv(arg0, arg1); }
	public static void glMultiTexCoord4dv(int arg0, double[] arg1, int arg2){ gl.glMultiTexCoord4dv(arg0, arg1, arg2); }
	public static void glMultiTexCoord4f(int arg0, float arg1, float arg2, float arg3, float arg4){ gl.glMultiTexCoord4f(arg0, arg1, arg2, arg3, arg4); }
	public static void glMultiTexCoord4fv(int arg0, java.nio.FloatBuffer arg1){ gl.glMultiTexCoord4fv(arg0, arg1); }
	public static void glMultiTexCoord4fv(int arg0, float[] arg1, int arg2){ gl.glMultiTexCoord4fv(arg0, arg1, arg2); }
	public static void glMultiTexCoord4hNV(int arg0, short arg1, short arg2, short arg3, short arg4){ gl.glMultiTexCoord4hNV(arg0, arg1, arg2, arg3, arg4); }
	public static void glMultiTexCoord4hvNV(int arg0, java.nio.ShortBuffer arg1){ gl.glMultiTexCoord4hvNV(arg0, arg1); }
	public static void glMultiTexCoord4hvNV(int arg0, short[] arg1, int arg2){ gl.glMultiTexCoord4hvNV(arg0, arg1, arg2); }
	public static void glMultiTexCoord4i(int arg0, int arg1, int arg2, int arg3, int arg4){ gl.glMultiTexCoord4i(arg0, arg1, arg2, arg3, arg4); }
	public static void glMultiTexCoord4iv(int arg0, java.nio.IntBuffer arg1){ gl.glMultiTexCoord4iv(arg0, arg1); }
	public static void glMultiTexCoord4iv(int arg0, int[] arg1, int arg2){ gl.glMultiTexCoord4iv(arg0, arg1, arg2); }
	public static void glMultiTexCoord4s(int arg0, short arg1, short arg2, short arg3, short arg4){ gl.glMultiTexCoord4s(arg0, arg1, arg2, arg3, arg4); }
	public static void glMultiTexCoord4sv(int arg0, java.nio.ShortBuffer arg1){ gl.glMultiTexCoord4sv(arg0, arg1); }
	public static void glMultiTexCoord4sv(int arg0, short[] arg1, int arg2){ gl.glMultiTexCoord4sv(arg0, arg1, arg2); }
	public static int glNewBufferRegion(int arg0){return gl.glNewBufferRegion(arg0); }
	public static void glNewList(int arg0, int arg1){ gl.glNewList(arg0, arg1); }
	public static int glNewObjectBufferATI(int arg0, java.nio.Buffer arg1, int arg2){return gl.glNewObjectBufferATI(arg0, arg1, arg2); }
	public static void glNormal3b(byte arg0, byte arg1, byte arg2){ gl.glNormal3b(arg0, arg1, arg2); }
	public static void glNormal3bv(java.nio.ByteBuffer arg0){ gl.glNormal3bv(arg0); }
	public static void glNormal3bv(byte[] arg0, int arg1){ gl.glNormal3bv(arg0, arg1); }
	public static void glNormal3d(double arg0, double arg1, double arg2){ gl.glNormal3d(arg0, arg1, arg2); }
	public static void glNormal3dv(java.nio.DoubleBuffer arg0){ gl.glNormal3dv(arg0); }
	public static void glNormal3dv(double[] arg0, int arg1){ gl.glNormal3dv(arg0, arg1); }
	public static void glNormal3f(float arg0, float arg1, float arg2){ gl.glNormal3f(arg0, arg1, arg2); }
	public static void glNormal3fVertex3fSUN(float arg0, float arg1, float arg2, float arg3, float arg4, float arg5){ gl.glNormal3fVertex3fSUN(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glNormal3fVertex3fvSUN(java.nio.FloatBuffer arg0, java.nio.FloatBuffer arg1){ gl.glNormal3fVertex3fvSUN(arg0, arg1); }
	public static void glNormal3fVertex3fvSUN(float[] arg0, int arg1, float[] arg2, int arg3){ gl.glNormal3fVertex3fvSUN(arg0, arg1, arg2, arg3); }
	public static void glNormal3fv(java.nio.FloatBuffer arg0){ gl.glNormal3fv(arg0); }
	public static void glNormal3fv(float[] arg0, int arg1){ gl.glNormal3fv(arg0, arg1); }
	public static void glNormal3hNV(short arg0, short arg1, short arg2){ gl.glNormal3hNV(arg0, arg1, arg2); }
	public static void glNormal3hvNV(java.nio.ShortBuffer arg0){ gl.glNormal3hvNV(arg0); }
	public static void glNormal3hvNV(short[] arg0, int arg1){ gl.glNormal3hvNV(arg0, arg1); }
	public static void glNormal3i(int arg0, int arg1, int arg2){ gl.glNormal3i(arg0, arg1, arg2); }
	public static void glNormal3iv(java.nio.IntBuffer arg0){ gl.glNormal3iv(arg0); }
	public static void glNormal3iv(int[] arg0, int arg1){ gl.glNormal3iv(arg0, arg1); }
	public static void glNormal3s(short arg0, short arg1, short arg2){ gl.glNormal3s(arg0, arg1, arg2); }
	public static void glNormal3sv(java.nio.ShortBuffer arg0){ gl.glNormal3sv(arg0); }
	public static void glNormal3sv(short[] arg0, int arg1){ gl.glNormal3sv(arg0, arg1); }
	public static void glNormalPointer(int arg0, int arg1, java.nio.Buffer arg2){ gl.glNormalPointer(arg0, arg1, arg2); }
	public static void glNormalPointer(int arg0, int arg1, long arg2){ gl.glNormalPointer(arg0, arg1, arg2); }
	public static void glNormalStream3bATI(int arg0, byte arg1, byte arg2, byte arg3){ gl.glNormalStream3bATI(arg0, arg1, arg2, arg3); }
	public static void glNormalStream3bvATI(int arg0, java.nio.ByteBuffer arg1){ gl.glNormalStream3bvATI(arg0, arg1); }
	public static void glNormalStream3bvATI(int arg0, byte[] arg1, int arg2){ gl.glNormalStream3bvATI(arg0, arg1, arg2); }
	public static void glNormalStream3dATI(int arg0, double arg1, double arg2, double arg3){ gl.glNormalStream3dATI(arg0, arg1, arg2, arg3); }
	public static void glNormalStream3dvATI(int arg0, java.nio.DoubleBuffer arg1){ gl.glNormalStream3dvATI(arg0, arg1); }
	public static void glNormalStream3dvATI(int arg0, double[] arg1, int arg2){ gl.glNormalStream3dvATI(arg0, arg1, arg2); }
	public static void glNormalStream3fATI(int arg0, float arg1, float arg2, float arg3){ gl.glNormalStream3fATI(arg0, arg1, arg2, arg3); }
	public static void glNormalStream3fvATI(int arg0, java.nio.FloatBuffer arg1){ gl.glNormalStream3fvATI(arg0, arg1); }
	public static void glNormalStream3fvATI(int arg0, float[] arg1, int arg2){ gl.glNormalStream3fvATI(arg0, arg1, arg2); }
	public static void glNormalStream3iATI(int arg0, int arg1, int arg2, int arg3){ gl.glNormalStream3iATI(arg0, arg1, arg2, arg3); }
	public static void glNormalStream3ivATI(int arg0, java.nio.IntBuffer arg1){ gl.glNormalStream3ivATI(arg0, arg1); }
	public static void glNormalStream3ivATI(int arg0, int[] arg1, int arg2){ gl.glNormalStream3ivATI(arg0, arg1, arg2); }
	public static void glNormalStream3sATI(int arg0, short arg1, short arg2, short arg3){ gl.glNormalStream3sATI(arg0, arg1, arg2, arg3); }
	public static void glNormalStream3svATI(int arg0, java.nio.ShortBuffer arg1){ gl.glNormalStream3svATI(arg0, arg1); }
	public static void glNormalStream3svATI(int arg0, short[] arg1, int arg2){ gl.glNormalStream3svATI(arg0, arg1, arg2); }
	public static void glOrtho(double arg0, double arg1, double arg2, double arg3, double arg4, double arg5){ gl.glOrtho(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glPNTrianglesfATI(int arg0, float arg1){ gl.glPNTrianglesfATI(arg0, arg1); }
	public static void glPNTrianglesiATI(int arg0, int arg1){ gl.glPNTrianglesiATI(arg0, arg1); }
	public static void glPassTexCoordATI(int arg0, int arg1, int arg2){ gl.glPassTexCoordATI(arg0, arg1, arg2); }
	public static void glPassThrough(float arg0){ gl.glPassThrough(arg0); }
	public static void glPixelDataRangeNV(int arg0, int arg1, java.nio.Buffer arg2){ gl.glPixelDataRangeNV(arg0, arg1, arg2); }
	public static void glPixelMapfv(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glPixelMapfv(arg0, arg1, arg2); }
	public static void glPixelMapfv(int arg0, int arg1, float[] arg2, int arg3){ gl.glPixelMapfv(arg0, arg1, arg2, arg3); }
	public static void glPixelMapfv(int arg0, int arg1, long arg2){ gl.glPixelMapfv(arg0, arg1, arg2); }
	public static void glPixelMapuiv(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glPixelMapuiv(arg0, arg1, arg2); }
	public static void glPixelMapuiv(int arg0, int arg1, int[] arg2, int arg3){ gl.glPixelMapuiv(arg0, arg1, arg2, arg3); }
	public static void glPixelMapuiv(int arg0, int arg1, long arg2){ gl.glPixelMapuiv(arg0, arg1, arg2); }
	public static void glPixelMapusv(int arg0, int arg1, java.nio.ShortBuffer arg2){ gl.glPixelMapusv(arg0, arg1, arg2); }
	public static void glPixelMapusv(int arg0, int arg1, short[] arg2, int arg3){ gl.glPixelMapusv(arg0, arg1, arg2, arg3); }
	public static void glPixelMapusv(int arg0, int arg1, long arg2){ gl.glPixelMapusv(arg0, arg1, arg2); }
	public static void glPixelStoref(int arg0, float arg1){ gl.glPixelStoref(arg0, arg1); }
	public static void glPixelStorei(int arg0, int arg1){ gl.glPixelStorei(arg0, arg1); }
	public static void glPixelTexGenParameterfSGIS(int arg0, float arg1){ gl.glPixelTexGenParameterfSGIS(arg0, arg1); }
	public static void glPixelTexGenParameterfvSGIS(int arg0, java.nio.FloatBuffer arg1){ gl.glPixelTexGenParameterfvSGIS(arg0, arg1); }
	public static void glPixelTexGenParameterfvSGIS(int arg0, float[] arg1, int arg2){ gl.glPixelTexGenParameterfvSGIS(arg0, arg1, arg2); }
	public static void glPixelTexGenParameteriSGIS(int arg0, int arg1){ gl.glPixelTexGenParameteriSGIS(arg0, arg1); }
	public static void glPixelTexGenParameterivSGIS(int arg0, java.nio.IntBuffer arg1){ gl.glPixelTexGenParameterivSGIS(arg0, arg1); }
	public static void glPixelTexGenParameterivSGIS(int arg0, int[] arg1, int arg2){ gl.glPixelTexGenParameterivSGIS(arg0, arg1, arg2); }
	public static void glPixelTexGenSGIX(int arg0){ gl.glPixelTexGenSGIX(arg0); }
	public static void glPixelTransferf(int arg0, float arg1){ gl.glPixelTransferf(arg0, arg1); }
	public static void glPixelTransferi(int arg0, int arg1){ gl.glPixelTransferi(arg0, arg1); }
	public static void glPixelTransformParameterfEXT(int arg0, int arg1, float arg2){ gl.glPixelTransformParameterfEXT(arg0, arg1, arg2); }
	public static void glPixelTransformParameterfvEXT(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glPixelTransformParameterfvEXT(arg0, arg1, arg2); }
	public static void glPixelTransformParameterfvEXT(int arg0, int arg1, float[] arg2, int arg3){ gl.glPixelTransformParameterfvEXT(arg0, arg1, arg2, arg3); }
	public static void glPixelTransformParameteriEXT(int arg0, int arg1, int arg2){ gl.glPixelTransformParameteriEXT(arg0, arg1, arg2); }
	public static void glPixelTransformParameterivEXT(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glPixelTransformParameterivEXT(arg0, arg1, arg2); }
	public static void glPixelTransformParameterivEXT(int arg0, int arg1, int[] arg2, int arg3){ gl.glPixelTransformParameterivEXT(arg0, arg1, arg2, arg3); }
	public static void glPixelZoom(float arg0, float arg1){ gl.glPixelZoom(arg0, arg1); }
	public static void glPointParameterf(int arg0, float arg1){ gl.glPointParameterf(arg0, arg1); }
	public static void glPointParameterfARB(int arg0, float arg1){ gl.glPointParameterfARB(arg0, arg1); }
	public static void glPointParameterfEXT(int arg0, float arg1){ gl.glPointParameterfEXT(arg0, arg1); }
	public static void glPointParameterfSGIS(int arg0, float arg1){ gl.glPointParameterfSGIS(arg0, arg1); }
	public static void glPointParameterfv(int arg0, java.nio.FloatBuffer arg1){ gl.glPointParameterfv(arg0, arg1); }
	public static void glPointParameterfv(int arg0, float[] arg1, int arg2){ gl.glPointParameterfv(arg0, arg1, arg2); }
	public static void glPointParameterfvARB(int arg0, java.nio.FloatBuffer arg1){ gl.glPointParameterfvARB(arg0, arg1); }
	public static void glPointParameterfvARB(int arg0, float[] arg1, int arg2){ gl.glPointParameterfvARB(arg0, arg1, arg2); }
	public static void glPointParameterfvEXT(int arg0, java.nio.FloatBuffer arg1){ gl.glPointParameterfvEXT(arg0, arg1); }
	public static void glPointParameterfvEXT(int arg0, float[] arg1, int arg2){ gl.glPointParameterfvEXT(arg0, arg1, arg2); }
	public static void glPointParameterfvSGIS(int arg0, java.nio.FloatBuffer arg1){ gl.glPointParameterfvSGIS(arg0, arg1); }
	public static void glPointParameterfvSGIS(int arg0, float[] arg1, int arg2){ gl.glPointParameterfvSGIS(arg0, arg1, arg2); }
	public static void glPointParameteri(int arg0, int arg1){ gl.glPointParameteri(arg0, arg1); }
	public static void glPointParameteriNV(int arg0, int arg1){ gl.glPointParameteriNV(arg0, arg1); }
	public static void glPointParameteriv(int arg0, java.nio.IntBuffer arg1){ gl.glPointParameteriv(arg0, arg1); }
	public static void glPointParameteriv(int arg0, int[] arg1, int arg2){ gl.glPointParameteriv(arg0, arg1, arg2); }
	public static void glPointParameterivNV(int arg0, java.nio.IntBuffer arg1){ gl.glPointParameterivNV(arg0, arg1); }
	public static void glPointParameterivNV(int arg0, int[] arg1, int arg2){ gl.glPointParameterivNV(arg0, arg1, arg2); }
	public static void glPointSize(float arg0){ gl.glPointSize(arg0); }
	public static int glPollAsyncSGIX(java.nio.IntBuffer arg0){return gl.glPollAsyncSGIX(arg0); }
	public static int glPollAsyncSGIX(int[] arg0, int arg1){return gl.glPollAsyncSGIX(arg0, arg1); }
	public static int glPollInstrumentsSGIX(java.nio.IntBuffer arg0){return gl.glPollInstrumentsSGIX(arg0); }
	public static int glPollInstrumentsSGIX(int[] arg0, int arg1){return gl.glPollInstrumentsSGIX(arg0, arg1); }
	public static void glPolygonMode(int arg0, int arg1){ gl.glPolygonMode(arg0, arg1); }
	public static void glPolygonOffset(float arg0, float arg1){ gl.glPolygonOffset(arg0, arg1); }
	public static void glPolygonStipple(java.nio.ByteBuffer arg0){ gl.glPolygonStipple(arg0); }
	public static void glPolygonStipple(byte[] arg0, int arg1){ gl.glPolygonStipple(arg0, arg1); }
	public static void glPolygonStipple(long arg0){ gl.glPolygonStipple(arg0); }
	public static void glPopAttrib(){ gl.glPopAttrib(); }
	public static void glPopClientAttrib(){ gl.glPopClientAttrib(); }
	public static void glPopMatrix(){ gl.glPopMatrix(); }
	public static void glPopName(){ gl.glPopName(); }
	public static void glPrimitiveRestartIndexNV(int arg0){ gl.glPrimitiveRestartIndexNV(arg0); }
	public static void glPrimitiveRestartNV(){ gl.glPrimitiveRestartNV(); }
	public static void glPrioritizeTextures(int arg0, java.nio.IntBuffer arg1, java.nio.FloatBuffer arg2){ gl.glPrioritizeTextures(arg0, arg1, arg2); }
	public static void glPrioritizeTextures(int arg0, int[] arg1, int arg2, float[] arg3, int arg4){ gl.glPrioritizeTextures(arg0, arg1, arg2, arg3, arg4); }
	public static void glProgramBufferParametersIivNV(int arg0, int arg1, int arg2, int arg3, java.nio.IntBuffer arg4){ gl.glProgramBufferParametersIivNV(arg0, arg1, arg2, arg3, arg4); }
	public static void glProgramBufferParametersIivNV(int arg0, int arg1, int arg2, int arg3, int[] arg4, int arg5){ gl.glProgramBufferParametersIivNV(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glProgramBufferParametersIuivNV(int arg0, int arg1, int arg2, int arg3, java.nio.IntBuffer arg4){ gl.glProgramBufferParametersIuivNV(arg0, arg1, arg2, arg3, arg4); }
	public static void glProgramBufferParametersIuivNV(int arg0, int arg1, int arg2, int arg3, int[] arg4, int arg5){ gl.glProgramBufferParametersIuivNV(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glProgramBufferParametersfvNV(int arg0, int arg1, int arg2, int arg3, java.nio.FloatBuffer arg4){ gl.glProgramBufferParametersfvNV(arg0, arg1, arg2, arg3, arg4); }
	public static void glProgramBufferParametersfvNV(int arg0, int arg1, int arg2, int arg3, float[] arg4, int arg5){ gl.glProgramBufferParametersfvNV(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glProgramEnvParameter4dARB(int arg0, int arg1, double arg2, double arg3, double arg4, double arg5){ gl.glProgramEnvParameter4dARB(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glProgramEnvParameter4dvARB(int arg0, int arg1, java.nio.DoubleBuffer arg2){ gl.glProgramEnvParameter4dvARB(arg0, arg1, arg2); }
	public static void glProgramEnvParameter4dvARB(int arg0, int arg1, double[] arg2, int arg3){ gl.glProgramEnvParameter4dvARB(arg0, arg1, arg2, arg3); }
	public static void glProgramEnvParameter4fARB(int arg0, int arg1, float arg2, float arg3, float arg4, float arg5){ gl.glProgramEnvParameter4fARB(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glProgramEnvParameter4fvARB(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glProgramEnvParameter4fvARB(arg0, arg1, arg2); }
	public static void glProgramEnvParameter4fvARB(int arg0, int arg1, float[] arg2, int arg3){ gl.glProgramEnvParameter4fvARB(arg0, arg1, arg2, arg3); }
	public static void glProgramEnvParameterI4iNV(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5){ gl.glProgramEnvParameterI4iNV(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glProgramEnvParameterI4ivNV(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glProgramEnvParameterI4ivNV(arg0, arg1, arg2); }
	public static void glProgramEnvParameterI4ivNV(int arg0, int arg1, int[] arg2, int arg3){ gl.glProgramEnvParameterI4ivNV(arg0, arg1, arg2, arg3); }
	public static void glProgramEnvParameterI4uiNV(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5){ gl.glProgramEnvParameterI4uiNV(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glProgramEnvParameterI4uivNV(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glProgramEnvParameterI4uivNV(arg0, arg1, arg2); }
	public static void glProgramEnvParameterI4uivNV(int arg0, int arg1, int[] arg2, int arg3){ gl.glProgramEnvParameterI4uivNV(arg0, arg1, arg2, arg3); }
	public static void glProgramEnvParameters4fvEXT(int arg0, int arg1, int arg2, java.nio.FloatBuffer arg3){ gl.glProgramEnvParameters4fvEXT(arg0, arg1, arg2, arg3); }
	public static void glProgramEnvParameters4fvEXT(int arg0, int arg1, int arg2, float[] arg3, int arg4){ gl.glProgramEnvParameters4fvEXT(arg0, arg1, arg2, arg3, arg4); }
	public static void glProgramEnvParametersI4ivNV(int arg0, int arg1, int arg2, java.nio.IntBuffer arg3){ gl.glProgramEnvParametersI4ivNV(arg0, arg1, arg2, arg3); }
	public static void glProgramEnvParametersI4ivNV(int arg0, int arg1, int arg2, int[] arg3, int arg4){ gl.glProgramEnvParametersI4ivNV(arg0, arg1, arg2, arg3, arg4); }
	public static void glProgramEnvParametersI4uivNV(int arg0, int arg1, int arg2, java.nio.IntBuffer arg3){ gl.glProgramEnvParametersI4uivNV(arg0, arg1, arg2, arg3); }
	public static void glProgramEnvParametersI4uivNV(int arg0, int arg1, int arg2, int[] arg3, int arg4){ gl.glProgramEnvParametersI4uivNV(arg0, arg1, arg2, arg3, arg4); }
	public static void glProgramLocalParameter4dARB(int arg0, int arg1, double arg2, double arg3, double arg4, double arg5){ gl.glProgramLocalParameter4dARB(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glProgramLocalParameter4dvARB(int arg0, int arg1, java.nio.DoubleBuffer arg2){ gl.glProgramLocalParameter4dvARB(arg0, arg1, arg2); }
	public static void glProgramLocalParameter4dvARB(int arg0, int arg1, double[] arg2, int arg3){ gl.glProgramLocalParameter4dvARB(arg0, arg1, arg2, arg3); }
	public static void glProgramLocalParameter4fARB(int arg0, int arg1, float arg2, float arg3, float arg4, float arg5){ gl.glProgramLocalParameter4fARB(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glProgramLocalParameter4fvARB(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glProgramLocalParameter4fvARB(arg0, arg1, arg2); }
	public static void glProgramLocalParameter4fvARB(int arg0, int arg1, float[] arg2, int arg3){ gl.glProgramLocalParameter4fvARB(arg0, arg1, arg2, arg3); }
	public static void glProgramLocalParameterI4iNV(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5){ gl.glProgramLocalParameterI4iNV(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glProgramLocalParameterI4ivNV(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glProgramLocalParameterI4ivNV(arg0, arg1, arg2); }
	public static void glProgramLocalParameterI4ivNV(int arg0, int arg1, int[] arg2, int arg3){ gl.glProgramLocalParameterI4ivNV(arg0, arg1, arg2, arg3); }
	public static void glProgramLocalParameterI4uiNV(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5){ gl.glProgramLocalParameterI4uiNV(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glProgramLocalParameterI4uivNV(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glProgramLocalParameterI4uivNV(arg0, arg1, arg2); }
	public static void glProgramLocalParameterI4uivNV(int arg0, int arg1, int[] arg2, int arg3){ gl.glProgramLocalParameterI4uivNV(arg0, arg1, arg2, arg3); }
	public static void glProgramLocalParameters4fvEXT(int arg0, int arg1, int arg2, java.nio.FloatBuffer arg3){ gl.glProgramLocalParameters4fvEXT(arg0, arg1, arg2, arg3); }
	public static void glProgramLocalParameters4fvEXT(int arg0, int arg1, int arg2, float[] arg3, int arg4){ gl.glProgramLocalParameters4fvEXT(arg0, arg1, arg2, arg3, arg4); }
	public static void glProgramLocalParametersI4ivNV(int arg0, int arg1, int arg2, java.nio.IntBuffer arg3){ gl.glProgramLocalParametersI4ivNV(arg0, arg1, arg2, arg3); }
	public static void glProgramLocalParametersI4ivNV(int arg0, int arg1, int arg2, int[] arg3, int arg4){ gl.glProgramLocalParametersI4ivNV(arg0, arg1, arg2, arg3, arg4); }
	public static void glProgramLocalParametersI4uivNV(int arg0, int arg1, int arg2, java.nio.IntBuffer arg3){ gl.glProgramLocalParametersI4uivNV(arg0, arg1, arg2, arg3); }
	public static void glProgramLocalParametersI4uivNV(int arg0, int arg1, int arg2, int[] arg3, int arg4){ gl.glProgramLocalParametersI4uivNV(arg0, arg1, arg2, arg3, arg4); }
	public static void glProgramNamedParameter4dNV(int arg0, int arg1, java.lang.String arg2, double arg3, double arg4, double arg5, double arg6){ gl.glProgramNamedParameter4dNV(arg0, arg1, arg2, arg3, arg4, arg5, arg6); }
	public static void glProgramNamedParameter4dvNV(int arg0, int arg1, java.lang.String arg2, java.nio.DoubleBuffer arg3){ gl.glProgramNamedParameter4dvNV(arg0, arg1, arg2, arg3); }
	public static void glProgramNamedParameter4dvNV(int arg0, int arg1, java.lang.String arg2, double[] arg3, int arg4){ gl.glProgramNamedParameter4dvNV(arg0, arg1, arg2, arg3, arg4); }
	public static void glProgramNamedParameter4fNV(int arg0, int arg1, java.lang.String arg2, float arg3, float arg4, float arg5, float arg6){ gl.glProgramNamedParameter4fNV(arg0, arg1, arg2, arg3, arg4, arg5, arg6); }
	public static void glProgramNamedParameter4fvNV(int arg0, int arg1, java.lang.String arg2, java.nio.FloatBuffer arg3){ gl.glProgramNamedParameter4fvNV(arg0, arg1, arg2, arg3); }
	public static void glProgramNamedParameter4fvNV(int arg0, int arg1, java.lang.String arg2, float[] arg3, int arg4){ gl.glProgramNamedParameter4fvNV(arg0, arg1, arg2, arg3, arg4); }
	public static void glProgramParameter4dNV(int arg0, int arg1, double arg2, double arg3, double arg4, double arg5){ gl.glProgramParameter4dNV(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glProgramParameter4dvNV(int arg0, int arg1, java.nio.DoubleBuffer arg2){ gl.glProgramParameter4dvNV(arg0, arg1, arg2); }
	public static void glProgramParameter4dvNV(int arg0, int arg1, double[] arg2, int arg3){ gl.glProgramParameter4dvNV(arg0, arg1, arg2, arg3); }
	public static void glProgramParameter4fNV(int arg0, int arg1, float arg2, float arg3, float arg4, float arg5){ gl.glProgramParameter4fNV(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glProgramParameter4fvNV(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glProgramParameter4fvNV(arg0, arg1, arg2); }
	public static void glProgramParameter4fvNV(int arg0, int arg1, float[] arg2, int arg3){ gl.glProgramParameter4fvNV(arg0, arg1, arg2, arg3); }
	public static void glProgramParameteriEXT(int arg0, int arg1, int arg2){ gl.glProgramParameteriEXT(arg0, arg1, arg2); }
	public static void glProgramParameters4dvNV(int arg0, int arg1, int arg2, java.nio.DoubleBuffer arg3){ gl.glProgramParameters4dvNV(arg0, arg1, arg2, arg3); }
	public static void glProgramParameters4dvNV(int arg0, int arg1, int arg2, double[] arg3, int arg4){ gl.glProgramParameters4dvNV(arg0, arg1, arg2, arg3, arg4); }
	public static void glProgramParameters4fvNV(int arg0, int arg1, int arg2, java.nio.FloatBuffer arg3){ gl.glProgramParameters4fvNV(arg0, arg1, arg2, arg3); }
	public static void glProgramParameters4fvNV(int arg0, int arg1, int arg2, float[] arg3, int arg4){ gl.glProgramParameters4fvNV(arg0, arg1, arg2, arg3, arg4); }
	public static void glProgramStringARB(int arg0, int arg1, int arg2, java.lang.String arg3){ gl.glProgramStringARB(arg0, arg1, arg2, arg3); }
	public static void glProgramVertexLimitNV(int arg0, int arg1){ gl.glProgramVertexLimitNV(arg0, arg1); }
	public static void glPushAttrib(int arg0){ gl.glPushAttrib(arg0); }
	public static void glPushClientAttrib(int arg0){ gl.glPushClientAttrib(arg0); }
	public static void glPushMatrix(){ gl.glPushMatrix(); }
	public static void glPushName(int arg0){ gl.glPushName(arg0); }
	public static void glRasterPos2d(double arg0, double arg1){ gl.glRasterPos2d(arg0, arg1); }
	public static void glRasterPos2dv(java.nio.DoubleBuffer arg0){ gl.glRasterPos2dv(arg0); }
	public static void glRasterPos2dv(double[] arg0, int arg1){ gl.glRasterPos2dv(arg0, arg1); }
	public static void glRasterPos2f(float arg0, float arg1){ gl.glRasterPos2f(arg0, arg1); }
	public static void glRasterPos2fv(java.nio.FloatBuffer arg0){ gl.glRasterPos2fv(arg0); }
	public static void glRasterPos2fv(float[] arg0, int arg1){ gl.glRasterPos2fv(arg0, arg1); }
	public static void glRasterPos2i(int arg0, int arg1){ gl.glRasterPos2i(arg0, arg1); }
	public static void glRasterPos2iv(java.nio.IntBuffer arg0){ gl.glRasterPos2iv(arg0); }
	public static void glRasterPos2iv(int[] arg0, int arg1){ gl.glRasterPos2iv(arg0, arg1); }
	public static void glRasterPos2s(short arg0, short arg1){ gl.glRasterPos2s(arg0, arg1); }
	public static void glRasterPos2sv(java.nio.ShortBuffer arg0){ gl.glRasterPos2sv(arg0); }
	public static void glRasterPos2sv(short[] arg0, int arg1){ gl.glRasterPos2sv(arg0, arg1); }
	public static void glRasterPos3d(double arg0, double arg1, double arg2){ gl.glRasterPos3d(arg0, arg1, arg2); }
	public static void glRasterPos3dv(java.nio.DoubleBuffer arg0){ gl.glRasterPos3dv(arg0); }
	public static void glRasterPos3dv(double[] arg0, int arg1){ gl.glRasterPos3dv(arg0, arg1); }
	public static void glRasterPos3f(float arg0, float arg1, float arg2){ gl.glRasterPos3f(arg0, arg1, arg2); }
	public static void glRasterPos3fv(java.nio.FloatBuffer arg0){ gl.glRasterPos3fv(arg0); }
	public static void glRasterPos3fv(float[] arg0, int arg1){ gl.glRasterPos3fv(arg0, arg1); }
	public static void glRasterPos3i(int arg0, int arg1, int arg2){ gl.glRasterPos3i(arg0, arg1, arg2); }
	public static void glRasterPos3iv(java.nio.IntBuffer arg0){ gl.glRasterPos3iv(arg0); }
	public static void glRasterPos3iv(int[] arg0, int arg1){ gl.glRasterPos3iv(arg0, arg1); }
	public static void glRasterPos3s(short arg0, short arg1, short arg2){ gl.glRasterPos3s(arg0, arg1, arg2); }
	public static void glRasterPos3sv(java.nio.ShortBuffer arg0){ gl.glRasterPos3sv(arg0); }
	public static void glRasterPos3sv(short[] arg0, int arg1){ gl.glRasterPos3sv(arg0, arg1); }
	public static void glRasterPos4d(double arg0, double arg1, double arg2, double arg3){ gl.glRasterPos4d(arg0, arg1, arg2, arg3); }
	public static void glRasterPos4dv(java.nio.DoubleBuffer arg0){ gl.glRasterPos4dv(arg0); }
	public static void glRasterPos4dv(double[] arg0, int arg1){ gl.glRasterPos4dv(arg0, arg1); }
	public static void glRasterPos4f(float arg0, float arg1, float arg2, float arg3){ gl.glRasterPos4f(arg0, arg1, arg2, arg3); }
	public static void glRasterPos4fv(java.nio.FloatBuffer arg0){ gl.glRasterPos4fv(arg0); }
	public static void glRasterPos4fv(float[] arg0, int arg1){ gl.glRasterPos4fv(arg0, arg1); }
	public static void glRasterPos4i(int arg0, int arg1, int arg2, int arg3){ gl.glRasterPos4i(arg0, arg1, arg2, arg3); }
	public static void glRasterPos4iv(java.nio.IntBuffer arg0){ gl.glRasterPos4iv(arg0); }
	public static void glRasterPos4iv(int[] arg0, int arg1){ gl.glRasterPos4iv(arg0, arg1); }
	public static void glRasterPos4s(short arg0, short arg1, short arg2, short arg3){ gl.glRasterPos4s(arg0, arg1, arg2, arg3); }
	public static void glRasterPos4sv(java.nio.ShortBuffer arg0){ gl.glRasterPos4sv(arg0); }
	public static void glRasterPos4sv(short[] arg0, int arg1){ gl.glRasterPos4sv(arg0, arg1); }
	public static void glReadBuffer(int arg0){ gl.glReadBuffer(arg0); }
	public static void glReadBufferRegion(int arg0, int arg1, int arg2, int arg3, int arg4){ gl.glReadBufferRegion(arg0, arg1, arg2, arg3, arg4); }
	public static void glReadInstrumentsSGIX(int arg0){ gl.glReadInstrumentsSGIX(arg0); }
	public static void glReadPixels(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, java.nio.Buffer arg6){ gl.glReadPixels(arg0, arg1, arg2, arg3, arg4, arg5, arg6); }
	public static void glReadPixels(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, long arg6){ gl.glReadPixels(arg0, arg1, arg2, arg3, arg4, arg5, arg6); }
	public static void glRectd(double arg0, double arg1, double arg2, double arg3){ gl.glRectd(arg0, arg1, arg2, arg3); }
	public static void glRectdv(java.nio.DoubleBuffer arg0, java.nio.DoubleBuffer arg1){ gl.glRectdv(arg0, arg1); }
	public static void glRectdv(double[] arg0, int arg1, double[] arg2, int arg3){ gl.glRectdv(arg0, arg1, arg2, arg3); }
	public static void glRectf(float arg0, float arg1, float arg2, float arg3){ gl.glRectf(arg0, arg1, arg2, arg3); }
	public static void glRectfv(java.nio.FloatBuffer arg0, java.nio.FloatBuffer arg1){ gl.glRectfv(arg0, arg1); }
	public static void glRectfv(float[] arg0, int arg1, float[] arg2, int arg3){ gl.glRectfv(arg0, arg1, arg2, arg3); }
	public static void glRecti(int arg0, int arg1, int arg2, int arg3){ gl.glRecti(arg0, arg1, arg2, arg3); }
	public static void glRectiv(java.nio.IntBuffer arg0, java.nio.IntBuffer arg1){ gl.glRectiv(arg0, arg1); }
	public static void glRectiv(int[] arg0, int arg1, int[] arg2, int arg3){ gl.glRectiv(arg0, arg1, arg2, arg3); }
	public static void glRects(short arg0, short arg1, short arg2, short arg3){ gl.glRects(arg0, arg1, arg2, arg3); }
	public static void glRectsv(java.nio.ShortBuffer arg0, java.nio.ShortBuffer arg1){ gl.glRectsv(arg0, arg1); }
	public static void glRectsv(short[] arg0, int arg1, short[] arg2, int arg3){ gl.glRectsv(arg0, arg1, arg2, arg3); }
	public static void glReferencePlaneSGIX(java.nio.DoubleBuffer arg0){ gl.glReferencePlaneSGIX(arg0); }
	public static void glReferencePlaneSGIX(double[] arg0, int arg1){ gl.glReferencePlaneSGIX(arg0, arg1); }
	public static int glRenderMode(int arg0){return gl.glRenderMode(arg0); }
	public static void glRenderbufferStorageEXT(int arg0, int arg1, int arg2, int arg3){ gl.glRenderbufferStorageEXT(arg0, arg1, arg2, arg3); }
	public static void glRenderbufferStorageMultisampleCoverageNV(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5){ gl.glRenderbufferStorageMultisampleCoverageNV(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glRenderbufferStorageMultisampleEXT(int arg0, int arg1, int arg2, int arg3, int arg4){ gl.glRenderbufferStorageMultisampleEXT(arg0, arg1, arg2, arg3, arg4); }
	public static void glReplacementCodeuiColor3fVertex3fSUN(int arg0, float arg1, float arg2, float arg3, float arg4, float arg5, float arg6){ gl.glReplacementCodeuiColor3fVertex3fSUN(arg0, arg1, arg2, arg3, arg4, arg5, arg6); }
	public static void glReplacementCodeuiColor3fVertex3fvSUN(java.nio.IntBuffer arg0, java.nio.FloatBuffer arg1, java.nio.FloatBuffer arg2){ gl.glReplacementCodeuiColor3fVertex3fvSUN(arg0, arg1, arg2); }
	public static void glReplacementCodeuiColor3fVertex3fvSUN(int[] arg0, int arg1, float[] arg2, int arg3, float[] arg4, int arg5){ gl.glReplacementCodeuiColor3fVertex3fvSUN(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glReplacementCodeuiColor4fNormal3fVertex3fSUN(int arg0, float arg1, float arg2, float arg3, float arg4, float arg5, float arg6, float arg7, float arg8, float arg9, float arg10){ gl.glReplacementCodeuiColor4fNormal3fVertex3fSUN(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10); }
	public static void glReplacementCodeuiColor4fNormal3fVertex3fvSUN(java.nio.IntBuffer arg0, java.nio.FloatBuffer arg1, java.nio.FloatBuffer arg2, java.nio.FloatBuffer arg3){ gl.glReplacementCodeuiColor4fNormal3fVertex3fvSUN(arg0, arg1, arg2, arg3); }
	public static void glReplacementCodeuiColor4fNormal3fVertex3fvSUN(int[] arg0, int arg1, float[] arg2, int arg3, float[] arg4, int arg5, float[] arg6, int arg7){ gl.glReplacementCodeuiColor4fNormal3fVertex3fvSUN(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7); }
	public static void glReplacementCodeuiColor4ubVertex3fSUN(int arg0, byte arg1, byte arg2, byte arg3, byte arg4, float arg5, float arg6, float arg7){ gl.glReplacementCodeuiColor4ubVertex3fSUN(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7); }
	public static void glReplacementCodeuiColor4ubVertex3fvSUN(java.nio.IntBuffer arg0, java.nio.ByteBuffer arg1, java.nio.FloatBuffer arg2){ gl.glReplacementCodeuiColor4ubVertex3fvSUN(arg0, arg1, arg2); }
	public static void glReplacementCodeuiColor4ubVertex3fvSUN(int[] arg0, int arg1, byte[] arg2, int arg3, float[] arg4, int arg5){ gl.glReplacementCodeuiColor4ubVertex3fvSUN(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glReplacementCodeuiNormal3fVertex3fSUN(int arg0, float arg1, float arg2, float arg3, float arg4, float arg5, float arg6){ gl.glReplacementCodeuiNormal3fVertex3fSUN(arg0, arg1, arg2, arg3, arg4, arg5, arg6); }
	public static void glReplacementCodeuiNormal3fVertex3fvSUN(java.nio.IntBuffer arg0, java.nio.FloatBuffer arg1, java.nio.FloatBuffer arg2){ gl.glReplacementCodeuiNormal3fVertex3fvSUN(arg0, arg1, arg2); }
	public static void glReplacementCodeuiNormal3fVertex3fvSUN(int[] arg0, int arg1, float[] arg2, int arg3, float[] arg4, int arg5){ gl.glReplacementCodeuiNormal3fVertex3fvSUN(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glReplacementCodeuiTexCoord2fColor4fNormal3fVertex3fSUN(int arg0, float arg1, float arg2, float arg3, float arg4, float arg5, float arg6, float arg7, float arg8, float arg9, float arg10, float arg11, float arg12){ gl.glReplacementCodeuiTexCoord2fColor4fNormal3fVertex3fSUN(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12); }
	public static void glReplacementCodeuiTexCoord2fColor4fNormal3fVertex3fvSUN(java.nio.IntBuffer arg0, java.nio.FloatBuffer arg1, java.nio.FloatBuffer arg2, java.nio.FloatBuffer arg3, java.nio.FloatBuffer arg4){ gl.glReplacementCodeuiTexCoord2fColor4fNormal3fVertex3fvSUN(arg0, arg1, arg2, arg3, arg4); }
	public static void glReplacementCodeuiTexCoord2fColor4fNormal3fVertex3fvSUN(int[] arg0, int arg1, float[] arg2, int arg3, float[] arg4, int arg5, float[] arg6, int arg7, float[] arg8, int arg9){ gl.glReplacementCodeuiTexCoord2fColor4fNormal3fVertex3fvSUN(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9); }
	public static void glReplacementCodeuiTexCoord2fNormal3fVertex3fSUN(int arg0, float arg1, float arg2, float arg3, float arg4, float arg5, float arg6, float arg7, float arg8){ gl.glReplacementCodeuiTexCoord2fNormal3fVertex3fSUN(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8); }
	public static void glReplacementCodeuiTexCoord2fNormal3fVertex3fvSUN(java.nio.IntBuffer arg0, java.nio.FloatBuffer arg1, java.nio.FloatBuffer arg2, java.nio.FloatBuffer arg3){ gl.glReplacementCodeuiTexCoord2fNormal3fVertex3fvSUN(arg0, arg1, arg2, arg3); }
	public static void glReplacementCodeuiTexCoord2fNormal3fVertex3fvSUN(int[] arg0, int arg1, float[] arg2, int arg3, float[] arg4, int arg5, float[] arg6, int arg7){ gl.glReplacementCodeuiTexCoord2fNormal3fVertex3fvSUN(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7); }
	public static void glReplacementCodeuiTexCoord2fVertex3fSUN(int arg0, float arg1, float arg2, float arg3, float arg4, float arg5){ gl.glReplacementCodeuiTexCoord2fVertex3fSUN(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glReplacementCodeuiTexCoord2fVertex3fvSUN(java.nio.IntBuffer arg0, java.nio.FloatBuffer arg1, java.nio.FloatBuffer arg2){ gl.glReplacementCodeuiTexCoord2fVertex3fvSUN(arg0, arg1, arg2); }
	public static void glReplacementCodeuiTexCoord2fVertex3fvSUN(int[] arg0, int arg1, float[] arg2, int arg3, float[] arg4, int arg5){ gl.glReplacementCodeuiTexCoord2fVertex3fvSUN(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glReplacementCodeuiVertex3fSUN(int arg0, float arg1, float arg2, float arg3){ gl.glReplacementCodeuiVertex3fSUN(arg0, arg1, arg2, arg3); }
	public static void glReplacementCodeuiVertex3fvSUN(java.nio.IntBuffer arg0, java.nio.FloatBuffer arg1){ gl.glReplacementCodeuiVertex3fvSUN(arg0, arg1); }
	public static void glReplacementCodeuiVertex3fvSUN(int[] arg0, int arg1, float[] arg2, int arg3){ gl.glReplacementCodeuiVertex3fvSUN(arg0, arg1, arg2, arg3); }
	public static void glRequestResidentProgramsNV(int arg0, java.nio.IntBuffer arg1){ gl.glRequestResidentProgramsNV(arg0, arg1); }
	public static void glRequestResidentProgramsNV(int arg0, int[] arg1, int arg2){ gl.glRequestResidentProgramsNV(arg0, arg1, arg2); }
	public static void glResetHistogram(int arg0){ gl.glResetHistogram(arg0); }
	public static void glResetMinmax(int arg0){ gl.glResetMinmax(arg0); }
	public static void glResizeBuffersMESA(){ gl.glResizeBuffersMESA(); }
	public static void glRotated(double arg0, double arg1, double arg2, double arg3){ gl.glRotated(arg0, arg1, arg2, arg3); }
	public static void glRotatef(float arg0, float arg1, float arg2, float arg3){ gl.glRotatef(arg0, arg1, arg2, arg3); }
	public static void glSampleCoverage(float arg0, boolean arg1){ gl.glSampleCoverage(arg0, arg1); }
	public static void glSampleMapATI(int arg0, int arg1, int arg2){ gl.glSampleMapATI(arg0, arg1, arg2); }
	public static void glSampleMaskEXT(float arg0, boolean arg1){ gl.glSampleMaskEXT(arg0, arg1); }
	public static void glSampleMaskSGIS(float arg0, boolean arg1){ gl.glSampleMaskSGIS(arg0, arg1); }
	public static void glSamplePatternEXT(int arg0){ gl.glSamplePatternEXT(arg0); }
	public static void glSamplePatternSGIS(int arg0){ gl.glSamplePatternSGIS(arg0); }
	public static void glScaled(double arg0, double arg1, double arg2){ gl.glScaled(arg0, arg1, arg2); }
	public static void glScalef(float arg0, float arg1, float arg2){ gl.glScalef(arg0, arg1, arg2); }
	public static void glScissor(int arg0, int arg1, int arg2, int arg3){ gl.glScissor(arg0, arg1, arg2, arg3); }
	public static void glSecondaryColor3b(byte arg0, byte arg1, byte arg2){ gl.glSecondaryColor3b(arg0, arg1, arg2); }
	public static void glSecondaryColor3bEXT(byte arg0, byte arg1, byte arg2){ gl.glSecondaryColor3bEXT(arg0, arg1, arg2); }
	public static void glSecondaryColor3bv(java.nio.ByteBuffer arg0){ gl.glSecondaryColor3bv(arg0); }
	public static void glSecondaryColor3bv(byte[] arg0, int arg1){ gl.glSecondaryColor3bv(arg0, arg1); }
	public static void glSecondaryColor3bvEXT(java.nio.ByteBuffer arg0){ gl.glSecondaryColor3bvEXT(arg0); }
	public static void glSecondaryColor3bvEXT(byte[] arg0, int arg1){ gl.glSecondaryColor3bvEXT(arg0, arg1); }
	public static void glSecondaryColor3d(double arg0, double arg1, double arg2){ gl.glSecondaryColor3d(arg0, arg1, arg2); }
	public static void glSecondaryColor3dEXT(double arg0, double arg1, double arg2){ gl.glSecondaryColor3dEXT(arg0, arg1, arg2); }
	public static void glSecondaryColor3dv(java.nio.DoubleBuffer arg0){ gl.glSecondaryColor3dv(arg0); }
	public static void glSecondaryColor3dv(double[] arg0, int arg1){ gl.glSecondaryColor3dv(arg0, arg1); }
	public static void glSecondaryColor3dvEXT(java.nio.DoubleBuffer arg0){ gl.glSecondaryColor3dvEXT(arg0); }
	public static void glSecondaryColor3dvEXT(double[] arg0, int arg1){ gl.glSecondaryColor3dvEXT(arg0, arg1); }
	public static void glSecondaryColor3f(float arg0, float arg1, float arg2){ gl.glSecondaryColor3f(arg0, arg1, arg2); }
	public static void glSecondaryColor3fEXT(float arg0, float arg1, float arg2){ gl.glSecondaryColor3fEXT(arg0, arg1, arg2); }
	public static void glSecondaryColor3fv(java.nio.FloatBuffer arg0){ gl.glSecondaryColor3fv(arg0); }
	public static void glSecondaryColor3fv(float[] arg0, int arg1){ gl.glSecondaryColor3fv(arg0, arg1); }
	public static void glSecondaryColor3fvEXT(java.nio.FloatBuffer arg0){ gl.glSecondaryColor3fvEXT(arg0); }
	public static void glSecondaryColor3fvEXT(float[] arg0, int arg1){ gl.glSecondaryColor3fvEXT(arg0, arg1); }
	public static void glSecondaryColor3hNV(short arg0, short arg1, short arg2){ gl.glSecondaryColor3hNV(arg0, arg1, arg2); }
	public static void glSecondaryColor3hvNV(java.nio.ShortBuffer arg0){ gl.glSecondaryColor3hvNV(arg0); }
	public static void glSecondaryColor3hvNV(short[] arg0, int arg1){ gl.glSecondaryColor3hvNV(arg0, arg1); }
	public static void glSecondaryColor3i(int arg0, int arg1, int arg2){ gl.glSecondaryColor3i(arg0, arg1, arg2); }
	public static void glSecondaryColor3iEXT(int arg0, int arg1, int arg2){ gl.glSecondaryColor3iEXT(arg0, arg1, arg2); }
	public static void glSecondaryColor3iv(java.nio.IntBuffer arg0){ gl.glSecondaryColor3iv(arg0); }
	public static void glSecondaryColor3iv(int[] arg0, int arg1){ gl.glSecondaryColor3iv(arg0, arg1); }
	public static void glSecondaryColor3ivEXT(java.nio.IntBuffer arg0){ gl.glSecondaryColor3ivEXT(arg0); }
	public static void glSecondaryColor3ivEXT(int[] arg0, int arg1){ gl.glSecondaryColor3ivEXT(arg0, arg1); }
	public static void glSecondaryColor3s(short arg0, short arg1, short arg2){ gl.glSecondaryColor3s(arg0, arg1, arg2); }
	public static void glSecondaryColor3sEXT(short arg0, short arg1, short arg2){ gl.glSecondaryColor3sEXT(arg0, arg1, arg2); }
	public static void glSecondaryColor3sv(java.nio.ShortBuffer arg0){ gl.glSecondaryColor3sv(arg0); }
	public static void glSecondaryColor3sv(short[] arg0, int arg1){ gl.glSecondaryColor3sv(arg0, arg1); }
	public static void glSecondaryColor3svEXT(java.nio.ShortBuffer arg0){ gl.glSecondaryColor3svEXT(arg0); }
	public static void glSecondaryColor3svEXT(short[] arg0, int arg1){ gl.glSecondaryColor3svEXT(arg0, arg1); }
	public static void glSecondaryColor3ub(byte arg0, byte arg1, byte arg2){ gl.glSecondaryColor3ub(arg0, arg1, arg2); }
	public static void glSecondaryColor3ubEXT(byte arg0, byte arg1, byte arg2){ gl.glSecondaryColor3ubEXT(arg0, arg1, arg2); }
	public static void glSecondaryColor3ubv(java.nio.ByteBuffer arg0){ gl.glSecondaryColor3ubv(arg0); }
	public static void glSecondaryColor3ubv(byte[] arg0, int arg1){ gl.glSecondaryColor3ubv(arg0, arg1); }
	public static void glSecondaryColor3ubvEXT(java.nio.ByteBuffer arg0){ gl.glSecondaryColor3ubvEXT(arg0); }
	public static void glSecondaryColor3ubvEXT(byte[] arg0, int arg1){ gl.glSecondaryColor3ubvEXT(arg0, arg1); }
	public static void glSecondaryColor3ui(int arg0, int arg1, int arg2){ gl.glSecondaryColor3ui(arg0, arg1, arg2); }
	public static void glSecondaryColor3uiEXT(int arg0, int arg1, int arg2){ gl.glSecondaryColor3uiEXT(arg0, arg1, arg2); }
	public static void glSecondaryColor3uiv(java.nio.IntBuffer arg0){ gl.glSecondaryColor3uiv(arg0); }
	public static void glSecondaryColor3uiv(int[] arg0, int arg1){ gl.glSecondaryColor3uiv(arg0, arg1); }
	public static void glSecondaryColor3uivEXT(java.nio.IntBuffer arg0){ gl.glSecondaryColor3uivEXT(arg0); }
	public static void glSecondaryColor3uivEXT(int[] arg0, int arg1){ gl.glSecondaryColor3uivEXT(arg0, arg1); }
	public static void glSecondaryColor3us(short arg0, short arg1, short arg2){ gl.glSecondaryColor3us(arg0, arg1, arg2); }
	public static void glSecondaryColor3usEXT(short arg0, short arg1, short arg2){ gl.glSecondaryColor3usEXT(arg0, arg1, arg2); }
	public static void glSecondaryColor3usv(java.nio.ShortBuffer arg0){ gl.glSecondaryColor3usv(arg0); }
	public static void glSecondaryColor3usv(short[] arg0, int arg1){ gl.glSecondaryColor3usv(arg0, arg1); }
	public static void glSecondaryColor3usvEXT(java.nio.ShortBuffer arg0){ gl.glSecondaryColor3usvEXT(arg0); }
	public static void glSecondaryColor3usvEXT(short[] arg0, int arg1){ gl.glSecondaryColor3usvEXT(arg0, arg1); }
	public static void glSecondaryColorPointer(int arg0, int arg1, int arg2, java.nio.Buffer arg3){ gl.glSecondaryColorPointer(arg0, arg1, arg2, arg3); }
	public static void glSecondaryColorPointer(int arg0, int arg1, int arg2, long arg3){ gl.glSecondaryColorPointer(arg0, arg1, arg2, arg3); }
	public static void glSecondaryColorPointerEXT(int arg0, int arg1, int arg2, java.nio.Buffer arg3){ gl.glSecondaryColorPointerEXT(arg0, arg1, arg2, arg3); }
	public static void glSecondaryColorPointerEXT(int arg0, int arg1, int arg2, long arg3){ gl.glSecondaryColorPointerEXT(arg0, arg1, arg2, arg3); }
	public static void glSelectBuffer(int arg0, java.nio.IntBuffer arg1){ gl.glSelectBuffer(arg0, arg1); }
	public static void glSeparableFilter2D(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, java.nio.Buffer arg6, java.nio.Buffer arg7){ gl.glSeparableFilter2D(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7); }
	public static void glSeparableFilter2D(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, long arg6, long arg7){ gl.glSeparableFilter2D(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7); }
	public static void glSetFenceAPPLE(int arg0){ gl.glSetFenceAPPLE(arg0); }
	public static void glSetFenceNV(int arg0, int arg1){ gl.glSetFenceNV(arg0, arg1); }
	public static void glSetFragmentShaderConstantATI(int arg0, java.nio.FloatBuffer arg1){ gl.glSetFragmentShaderConstantATI(arg0, arg1); }
	public static void glSetFragmentShaderConstantATI(int arg0, float[] arg1, int arg2){ gl.glSetFragmentShaderConstantATI(arg0, arg1, arg2); }
	public static void glSetInvariantEXT(int arg0, int arg1, java.nio.Buffer arg2){ gl.glSetInvariantEXT(arg0, arg1, arg2); }
	public static void glSetLocalConstantEXT(int arg0, int arg1, java.nio.Buffer arg2){ gl.glSetLocalConstantEXT(arg0, arg1, arg2); }
	public static void glShadeModel(int arg0){ gl.glShadeModel(arg0); }
	public static void glShaderOp1EXT(int arg0, int arg1, int arg2){ gl.glShaderOp1EXT(arg0, arg1, arg2); }
	public static void glShaderOp2EXT(int arg0, int arg1, int arg2, int arg3){ gl.glShaderOp2EXT(arg0, arg1, arg2, arg3); }
	public static void glShaderOp3EXT(int arg0, int arg1, int arg2, int arg3, int arg4){ gl.glShaderOp3EXT(arg0, arg1, arg2, arg3, arg4); }
	public static void glShaderSource(int arg0, int arg1, java.lang.String[] arg2, java.nio.IntBuffer arg3){ gl.glShaderSource(arg0, arg1, arg2, arg3); }
	public static void glShaderSource(int arg0, int arg1, java.lang.String[] arg2, int[] arg3, int arg4){ gl.glShaderSource(arg0, arg1, arg2, arg3, arg4); }
	public static void glShaderSourceARB(int arg0, int arg1, java.lang.String[] arg2, java.nio.IntBuffer arg3){ gl.glShaderSourceARB(arg0, arg1, arg2, arg3); }
	public static void glShaderSourceARB(int arg0, int arg1, java.lang.String[] arg2, int[] arg3, int arg4){ gl.glShaderSourceARB(arg0, arg1, arg2, arg3, arg4); }
	public static void glSharpenTexFuncSGIS(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glSharpenTexFuncSGIS(arg0, arg1, arg2); }
	public static void glSharpenTexFuncSGIS(int arg0, int arg1, float[] arg2, int arg3){ gl.glSharpenTexFuncSGIS(arg0, arg1, arg2, arg3); }
	public static void glSpriteParameterfSGIX(int arg0, float arg1){ gl.glSpriteParameterfSGIX(arg0, arg1); }
	public static void glSpriteParameterfvSGIX(int arg0, java.nio.FloatBuffer arg1){ gl.glSpriteParameterfvSGIX(arg0, arg1); }
	public static void glSpriteParameterfvSGIX(int arg0, float[] arg1, int arg2){ gl.glSpriteParameterfvSGIX(arg0, arg1, arg2); }
	public static void glSpriteParameteriSGIX(int arg0, int arg1){ gl.glSpriteParameteriSGIX(arg0, arg1); }
	public static void glSpriteParameterivSGIX(int arg0, java.nio.IntBuffer arg1){ gl.glSpriteParameterivSGIX(arg0, arg1); }
	public static void glSpriteParameterivSGIX(int arg0, int[] arg1, int arg2){ gl.glSpriteParameterivSGIX(arg0, arg1, arg2); }
	public static void glStartInstrumentsSGIX(){ gl.glStartInstrumentsSGIX(); }
	public static void glStencilClearTagEXT(int arg0, int arg1){ gl.glStencilClearTagEXT(arg0, arg1); }
	public static void glStencilFunc(int arg0, int arg1, int arg2){ gl.glStencilFunc(arg0, arg1, arg2); }
	public static void glStencilFuncSeparate(int arg0, int arg1, int arg2, int arg3){ gl.glStencilFuncSeparate(arg0, arg1, arg2, arg3); }
	public static void glStencilFuncSeparateATI(int arg0, int arg1, int arg2, int arg3){ gl.glStencilFuncSeparateATI(arg0, arg1, arg2, arg3); }
	public static void glStencilMask(int arg0){ gl.glStencilMask(arg0); }
	public static void glStencilMaskSeparate(int arg0, int arg1){ gl.glStencilMaskSeparate(arg0, arg1); }
	public static void glStencilOp(int arg0, int arg1, int arg2){ gl.glStencilOp(arg0, arg1, arg2); }
	public static void glStencilOpSeparate(int arg0, int arg1, int arg2, int arg3){ gl.glStencilOpSeparate(arg0, arg1, arg2, arg3); }
	public static void glStencilOpSeparateATI(int arg0, int arg1, int arg2, int arg3){ gl.glStencilOpSeparateATI(arg0, arg1, arg2, arg3); }
	public static void glStopInstrumentsSGIX(int arg0){ gl.glStopInstrumentsSGIX(arg0); }
	public static void glStringMarkerGREMEDY(int arg0, java.nio.Buffer arg1){ gl.glStringMarkerGREMEDY(arg0, arg1); }
	public static void glSwapAPPLE(){ gl.glSwapAPPLE(); }
	public static void glSwizzleEXT(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5){ gl.glSwizzleEXT(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glTagSampleBufferSGIX(){ gl.glTagSampleBufferSGIX(); }
	public static void glTbufferMask3DFX(int arg0){ gl.glTbufferMask3DFX(arg0); }
	public static boolean glTestFenceAPPLE(int arg0){return gl.glTestFenceAPPLE(arg0); }
	public static boolean glTestFenceNV(int arg0){return gl.glTestFenceNV(arg0); }
	public static boolean glTestObjectAPPLE(int arg0, int arg1){return gl.glTestObjectAPPLE(arg0, arg1); }
	public static void glTexBufferEXT(int arg0, int arg1, int arg2){ gl.glTexBufferEXT(arg0, arg1, arg2); }
	public static void glTexBumpParameterfvATI(int arg0, java.nio.FloatBuffer arg1){ gl.glTexBumpParameterfvATI(arg0, arg1); }
	public static void glTexBumpParameterfvATI(int arg0, float[] arg1, int arg2){ gl.glTexBumpParameterfvATI(arg0, arg1, arg2); }
	public static void glTexBumpParameterivATI(int arg0, java.nio.IntBuffer arg1){ gl.glTexBumpParameterivATI(arg0, arg1); }
	public static void glTexBumpParameterivATI(int arg0, int[] arg1, int arg2){ gl.glTexBumpParameterivATI(arg0, arg1, arg2); }
	public static void glTexCoord1d(double arg0){ gl.glTexCoord1d(arg0); }
	public static void glTexCoord1dv(java.nio.DoubleBuffer arg0){ gl.glTexCoord1dv(arg0); }
	public static void glTexCoord1dv(double[] arg0, int arg1){ gl.glTexCoord1dv(arg0, arg1); }
	public static void glTexCoord1f(float arg0){ gl.glTexCoord1f(arg0); }
	public static void glTexCoord1fv(java.nio.FloatBuffer arg0){ gl.glTexCoord1fv(arg0); }
	public static void glTexCoord1fv(float[] arg0, int arg1){ gl.glTexCoord1fv(arg0, arg1); }
	public static void glTexCoord1hNV(short arg0){ gl.glTexCoord1hNV(arg0); }
	public static void glTexCoord1hvNV(java.nio.ShortBuffer arg0){ gl.glTexCoord1hvNV(arg0); }
	public static void glTexCoord1hvNV(short[] arg0, int arg1){ gl.glTexCoord1hvNV(arg0, arg1); }
	public static void glTexCoord1i(int arg0){ gl.glTexCoord1i(arg0); }
	public static void glTexCoord1iv(java.nio.IntBuffer arg0){ gl.glTexCoord1iv(arg0); }
	public static void glTexCoord1iv(int[] arg0, int arg1){ gl.glTexCoord1iv(arg0, arg1); }
	public static void glTexCoord1s(short arg0){ gl.glTexCoord1s(arg0); }
	public static void glTexCoord1sv(java.nio.ShortBuffer arg0){ gl.glTexCoord1sv(arg0); }
	public static void glTexCoord1sv(short[] arg0, int arg1){ gl.glTexCoord1sv(arg0, arg1); }
	public static void glTexCoord2d(double arg0, double arg1){ gl.glTexCoord2d(arg0, arg1); }
	public static void glTexCoord2dv(java.nio.DoubleBuffer arg0){ gl.glTexCoord2dv(arg0); }
	public static void glTexCoord2dv(double[] arg0, int arg1){ gl.glTexCoord2dv(arg0, arg1); }
	public static void glTexCoord2f(float arg0, float arg1){ gl.glTexCoord2f(arg0, arg1); }
	public static void glTexCoord2fColor3fVertex3fSUN(float arg0, float arg1, float arg2, float arg3, float arg4, float arg5, float arg6, float arg7){ gl.glTexCoord2fColor3fVertex3fSUN(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7); }
	public static void glTexCoord2fColor3fVertex3fvSUN(java.nio.FloatBuffer arg0, java.nio.FloatBuffer arg1, java.nio.FloatBuffer arg2){ gl.glTexCoord2fColor3fVertex3fvSUN(arg0, arg1, arg2); }
	public static void glTexCoord2fColor3fVertex3fvSUN(float[] arg0, int arg1, float[] arg2, int arg3, float[] arg4, int arg5){ gl.glTexCoord2fColor3fVertex3fvSUN(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glTexCoord2fColor4fNormal3fVertex3fSUN(float arg0, float arg1, float arg2, float arg3, float arg4, float arg5, float arg6, float arg7, float arg8, float arg9, float arg10, float arg11){ gl.glTexCoord2fColor4fNormal3fVertex3fSUN(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11); }
	public static void glTexCoord2fColor4fNormal3fVertex3fvSUN(java.nio.FloatBuffer arg0, java.nio.FloatBuffer arg1, java.nio.FloatBuffer arg2, java.nio.FloatBuffer arg3){ gl.glTexCoord2fColor4fNormal3fVertex3fvSUN(arg0, arg1, arg2, arg3); }
	public static void glTexCoord2fColor4fNormal3fVertex3fvSUN(float[] arg0, int arg1, float[] arg2, int arg3, float[] arg4, int arg5, float[] arg6, int arg7){ gl.glTexCoord2fColor4fNormal3fVertex3fvSUN(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7); }
	public static void glTexCoord2fColor4ubVertex3fSUN(float arg0, float arg1, byte arg2, byte arg3, byte arg4, byte arg5, float arg6, float arg7, float arg8){ gl.glTexCoord2fColor4ubVertex3fSUN(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8); }
	public static void glTexCoord2fColor4ubVertex3fvSUN(java.nio.FloatBuffer arg0, java.nio.ByteBuffer arg1, java.nio.FloatBuffer arg2){ gl.glTexCoord2fColor4ubVertex3fvSUN(arg0, arg1, arg2); }
	public static void glTexCoord2fColor4ubVertex3fvSUN(float[] arg0, int arg1, byte[] arg2, int arg3, float[] arg4, int arg5){ gl.glTexCoord2fColor4ubVertex3fvSUN(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glTexCoord2fNormal3fVertex3fSUN(float arg0, float arg1, float arg2, float arg3, float arg4, float arg5, float arg6, float arg7){ gl.glTexCoord2fNormal3fVertex3fSUN(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7); }
	public static void glTexCoord2fNormal3fVertex3fvSUN(java.nio.FloatBuffer arg0, java.nio.FloatBuffer arg1, java.nio.FloatBuffer arg2){ gl.glTexCoord2fNormal3fVertex3fvSUN(arg0, arg1, arg2); }
	public static void glTexCoord2fNormal3fVertex3fvSUN(float[] arg0, int arg1, float[] arg2, int arg3, float[] arg4, int arg5){ gl.glTexCoord2fNormal3fVertex3fvSUN(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glTexCoord2fVertex3fSUN(float arg0, float arg1, float arg2, float arg3, float arg4){ gl.glTexCoord2fVertex3fSUN(arg0, arg1, arg2, arg3, arg4); }
	public static void glTexCoord2fVertex3fvSUN(java.nio.FloatBuffer arg0, java.nio.FloatBuffer arg1){ gl.glTexCoord2fVertex3fvSUN(arg0, arg1); }
	public static void glTexCoord2fVertex3fvSUN(float[] arg0, int arg1, float[] arg2, int arg3){ gl.glTexCoord2fVertex3fvSUN(arg0, arg1, arg2, arg3); }
	public static void glTexCoord2fv(java.nio.FloatBuffer arg0){ gl.glTexCoord2fv(arg0); }
	public static void glTexCoord2fv(float[] arg0, int arg1){ gl.glTexCoord2fv(arg0, arg1); }
	public static void glTexCoord2hNV(short arg0, short arg1){ gl.glTexCoord2hNV(arg0, arg1); }
	public static void glTexCoord2hvNV(java.nio.ShortBuffer arg0){ gl.glTexCoord2hvNV(arg0); }
	public static void glTexCoord2hvNV(short[] arg0, int arg1){ gl.glTexCoord2hvNV(arg0, arg1); }
	public static void glTexCoord2i(int arg0, int arg1){ gl.glTexCoord2i(arg0, arg1); }
	public static void glTexCoord2iv(java.nio.IntBuffer arg0){ gl.glTexCoord2iv(arg0); }
	public static void glTexCoord2iv(int[] arg0, int arg1){ gl.glTexCoord2iv(arg0, arg1); }
	public static void glTexCoord2s(short arg0, short arg1){ gl.glTexCoord2s(arg0, arg1); }
	public static void glTexCoord2sv(java.nio.ShortBuffer arg0){ gl.glTexCoord2sv(arg0); }
	public static void glTexCoord2sv(short[] arg0, int arg1){ gl.glTexCoord2sv(arg0, arg1); }
	public static void glTexCoord3d(double arg0, double arg1, double arg2){ gl.glTexCoord3d(arg0, arg1, arg2); }
	public static void glTexCoord3dv(java.nio.DoubleBuffer arg0){ gl.glTexCoord3dv(arg0); }
	public static void glTexCoord3dv(double[] arg0, int arg1){ gl.glTexCoord3dv(arg0, arg1); }
	public static void glTexCoord3f(float arg0, float arg1, float arg2){ gl.glTexCoord3f(arg0, arg1, arg2); }
	public static void glTexCoord3fv(java.nio.FloatBuffer arg0){ gl.glTexCoord3fv(arg0); }
	public static void glTexCoord3fv(float[] arg0, int arg1){ gl.glTexCoord3fv(arg0, arg1); }
	public static void glTexCoord3hNV(short arg0, short arg1, short arg2){ gl.glTexCoord3hNV(arg0, arg1, arg2); }
	public static void glTexCoord3hvNV(java.nio.ShortBuffer arg0){ gl.glTexCoord3hvNV(arg0); }
	public static void glTexCoord3hvNV(short[] arg0, int arg1){ gl.glTexCoord3hvNV(arg0, arg1); }
	public static void glTexCoord3i(int arg0, int arg1, int arg2){ gl.glTexCoord3i(arg0, arg1, arg2); }
	public static void glTexCoord3iv(java.nio.IntBuffer arg0){ gl.glTexCoord3iv(arg0); }
	public static void glTexCoord3iv(int[] arg0, int arg1){ gl.glTexCoord3iv(arg0, arg1); }
	public static void glTexCoord3s(short arg0, short arg1, short arg2){ gl.glTexCoord3s(arg0, arg1, arg2); }
	public static void glTexCoord3sv(java.nio.ShortBuffer arg0){ gl.glTexCoord3sv(arg0); }
	public static void glTexCoord3sv(short[] arg0, int arg1){ gl.glTexCoord3sv(arg0, arg1); }
	public static void glTexCoord4d(double arg0, double arg1, double arg2, double arg3){ gl.glTexCoord4d(arg0, arg1, arg2, arg3); }
	public static void glTexCoord4dv(java.nio.DoubleBuffer arg0){ gl.glTexCoord4dv(arg0); }
	public static void glTexCoord4dv(double[] arg0, int arg1){ gl.glTexCoord4dv(arg0, arg1); }
	public static void glTexCoord4f(float arg0, float arg1, float arg2, float arg3){ gl.glTexCoord4f(arg0, arg1, arg2, arg3); }
	public static void glTexCoord4fColor4fNormal3fVertex4fSUN(float arg0, float arg1, float arg2, float arg3, float arg4, float arg5, float arg6, float arg7, float arg8, float arg9, float arg10, float arg11, float arg12, float arg13, float arg14){ gl.glTexCoord4fColor4fNormal3fVertex4fSUN(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14); }
	public static void glTexCoord4fColor4fNormal3fVertex4fvSUN(java.nio.FloatBuffer arg0, java.nio.FloatBuffer arg1, java.nio.FloatBuffer arg2, java.nio.FloatBuffer arg3){ gl.glTexCoord4fColor4fNormal3fVertex4fvSUN(arg0, arg1, arg2, arg3); }
	public static void glTexCoord4fColor4fNormal3fVertex4fvSUN(float[] arg0, int arg1, float[] arg2, int arg3, float[] arg4, int arg5, float[] arg6, int arg7){ gl.glTexCoord4fColor4fNormal3fVertex4fvSUN(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7); }
	public static void glTexCoord4fVertex4fSUN(float arg0, float arg1, float arg2, float arg3, float arg4, float arg5, float arg6, float arg7){ gl.glTexCoord4fVertex4fSUN(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7); }
	public static void glTexCoord4fVertex4fvSUN(java.nio.FloatBuffer arg0, java.nio.FloatBuffer arg1){ gl.glTexCoord4fVertex4fvSUN(arg0, arg1); }
	public static void glTexCoord4fVertex4fvSUN(float[] arg0, int arg1, float[] arg2, int arg3){ gl.glTexCoord4fVertex4fvSUN(arg0, arg1, arg2, arg3); }
	public static void glTexCoord4fv(java.nio.FloatBuffer arg0){ gl.glTexCoord4fv(arg0); }
	public static void glTexCoord4fv(float[] arg0, int arg1){ gl.glTexCoord4fv(arg0, arg1); }
	public static void glTexCoord4hNV(short arg0, short arg1, short arg2, short arg3){ gl.glTexCoord4hNV(arg0, arg1, arg2, arg3); }
	public static void glTexCoord4hvNV(java.nio.ShortBuffer arg0){ gl.glTexCoord4hvNV(arg0); }
	public static void glTexCoord4hvNV(short[] arg0, int arg1){ gl.glTexCoord4hvNV(arg0, arg1); }
	public static void glTexCoord4i(int arg0, int arg1, int arg2, int arg3){ gl.glTexCoord4i(arg0, arg1, arg2, arg3); }
	public static void glTexCoord4iv(java.nio.IntBuffer arg0){ gl.glTexCoord4iv(arg0); }
	public static void glTexCoord4iv(int[] arg0, int arg1){ gl.glTexCoord4iv(arg0, arg1); }
	public static void glTexCoord4s(short arg0, short arg1, short arg2, short arg3){ gl.glTexCoord4s(arg0, arg1, arg2, arg3); }
	public static void glTexCoord4sv(java.nio.ShortBuffer arg0){ gl.glTexCoord4sv(arg0); }
	public static void glTexCoord4sv(short[] arg0, int arg1){ gl.glTexCoord4sv(arg0, arg1); }
	public static void glTexCoordPointer(int arg0, int arg1, int arg2, java.nio.Buffer arg3){ gl.glTexCoordPointer(arg0, arg1, arg2, arg3); }
	public static void glTexCoordPointer(int arg0, int arg1, int arg2, long arg3){ gl.glTexCoordPointer(arg0, arg1, arg2, arg3); }
	public static void glTexEnvf(int arg0, int arg1, float arg2){ gl.glTexEnvf(arg0, arg1, arg2); }
	public static void glTexEnvfv(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glTexEnvfv(arg0, arg1, arg2); }
	public static void glTexEnvfv(int arg0, int arg1, float[] arg2, int arg3){ gl.glTexEnvfv(arg0, arg1, arg2, arg3); }
	public static void glTexEnvi(int arg0, int arg1, int arg2){ gl.glTexEnvi(arg0, arg1, arg2); }
	public static void glTexEnviv(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glTexEnviv(arg0, arg1, arg2); }
	public static void glTexEnviv(int arg0, int arg1, int[] arg2, int arg3){ gl.glTexEnviv(arg0, arg1, arg2, arg3); }
	public static void glTexFilterFuncSGIS(int arg0, int arg1, int arg2, java.nio.FloatBuffer arg3){ gl.glTexFilterFuncSGIS(arg0, arg1, arg2, arg3); }
	public static void glTexFilterFuncSGIS(int arg0, int arg1, int arg2, float[] arg3, int arg4){ gl.glTexFilterFuncSGIS(arg0, arg1, arg2, arg3, arg4); }
	public static void glTexGend(int arg0, int arg1, double arg2){ gl.glTexGend(arg0, arg1, arg2); }
	public static void glTexGendv(int arg0, int arg1, java.nio.DoubleBuffer arg2){ gl.glTexGendv(arg0, arg1, arg2); }
	public static void glTexGendv(int arg0, int arg1, double[] arg2, int arg3){ gl.glTexGendv(arg0, arg1, arg2, arg3); }
	public static void glTexGenf(int arg0, int arg1, float arg2){ gl.glTexGenf(arg0, arg1, arg2); }
	public static void glTexGenfv(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glTexGenfv(arg0, arg1, arg2); }
	public static void glTexGenfv(int arg0, int arg1, float[] arg2, int arg3){ gl.glTexGenfv(arg0, arg1, arg2, arg3); }
	public static void glTexGeni(int arg0, int arg1, int arg2){ gl.glTexGeni(arg0, arg1, arg2); }
	public static void glTexGeniv(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glTexGeniv(arg0, arg1, arg2); }
	public static void glTexGeniv(int arg0, int arg1, int[] arg2, int arg3){ gl.glTexGeniv(arg0, arg1, arg2, arg3); }
	public static void glTexImage1D(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6, java.nio.Buffer arg7){ gl.glTexImage1D(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7); }
	public static void glTexImage1D(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6, long arg7){ gl.glTexImage1D(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7); }
	public static void glTexImage2D(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6, int arg7, java.nio.Buffer arg8){ gl.glTexImage2D(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8); }
	public static void glTexImage2D(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6, int arg7, long arg8){ gl.glTexImage2D(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8); }
	public static void glTexImage3D(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6, int arg7, int arg8, java.nio.Buffer arg9){ gl.glTexImage3D(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9); }
	public static void glTexImage3D(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6, int arg7, int arg8, long arg9){ gl.glTexImage3D(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9); }
	public static void glTexImage4DSGIS(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6, int arg7, int arg8, int arg9, java.nio.Buffer arg10){ gl.glTexImage4DSGIS(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10); }
	public static void glTexParameterIivEXT(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glTexParameterIivEXT(arg0, arg1, arg2); }
	public static void glTexParameterIivEXT(int arg0, int arg1, int[] arg2, int arg3){ gl.glTexParameterIivEXT(arg0, arg1, arg2, arg3); }
	public static void glTexParameterIuivEXT(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glTexParameterIuivEXT(arg0, arg1, arg2); }
	public static void glTexParameterIuivEXT(int arg0, int arg1, int[] arg2, int arg3){ gl.glTexParameterIuivEXT(arg0, arg1, arg2, arg3); }
	public static void glTexParameterf(int arg0, int arg1, float arg2){ gl.glTexParameterf(arg0, arg1, arg2); }
	public static void glTexParameterfv(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glTexParameterfv(arg0, arg1, arg2); }
	public static void glTexParameterfv(int arg0, int arg1, float[] arg2, int arg3){ gl.glTexParameterfv(arg0, arg1, arg2, arg3); }
	public static void glTexParameteri(int arg0, int arg1, int arg2){ gl.glTexParameteri(arg0, arg1, arg2); }
	public static void glTexParameteriv(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glTexParameteriv(arg0, arg1, arg2); }
	public static void glTexParameteriv(int arg0, int arg1, int[] arg2, int arg3){ gl.glTexParameteriv(arg0, arg1, arg2, arg3); }
	public static void glTexSubImage1D(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, java.nio.Buffer arg6){ gl.glTexSubImage1D(arg0, arg1, arg2, arg3, arg4, arg5, arg6); }
	public static void glTexSubImage1D(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, long arg6){ gl.glTexSubImage1D(arg0, arg1, arg2, arg3, arg4, arg5, arg6); }
	public static void glTexSubImage2D(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6, int arg7, java.nio.Buffer arg8){ gl.glTexSubImage2D(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8); }
	public static void glTexSubImage2D(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6, int arg7, long arg8){ gl.glTexSubImage2D(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8); }
	public static void glTexSubImage3D(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6, int arg7, int arg8, int arg9, java.nio.Buffer arg10){ gl.glTexSubImage3D(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10); }
	public static void glTexSubImage3D(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6, int arg7, int arg8, int arg9, long arg10){ gl.glTexSubImage3D(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10); }
	public static void glTexSubImage4DSGIS(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6, int arg7, int arg8, int arg9, int arg10, int arg11, java.nio.Buffer arg12){ gl.glTexSubImage4DSGIS(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12); }
	public static void glTextureColorMaskSGIS(boolean arg0, boolean arg1, boolean arg2, boolean arg3){ gl.glTextureColorMaskSGIS(arg0, arg1, arg2, arg3); }
	public static void glTextureLightEXT(int arg0){ gl.glTextureLightEXT(arg0); }
	public static void glTextureMaterialEXT(int arg0, int arg1){ gl.glTextureMaterialEXT(arg0, arg1); }
	public static void glTextureNormalEXT(int arg0){ gl.glTextureNormalEXT(arg0); }
	public static void glTextureRangeAPPLE(int arg0, int arg1, java.nio.Buffer arg2){ gl.glTextureRangeAPPLE(arg0, arg1, arg2); }
	public static void glTrackMatrixNV(int arg0, int arg1, int arg2, int arg3){ gl.glTrackMatrixNV(arg0, arg1, arg2, arg3); }
	public static void glTransformFeedbackAttribsNV(int arg0, java.nio.IntBuffer arg1, int arg2){ gl.glTransformFeedbackAttribsNV(arg0, arg1, arg2); }
	public static void glTransformFeedbackAttribsNV(int arg0, int[] arg1, int arg2, int arg3){ gl.glTransformFeedbackAttribsNV(arg0, arg1, arg2, arg3); }
	public static void glTransformFeedbackVaryingsNV(int arg0, int arg1, java.nio.IntBuffer arg2, int arg3){ gl.glTransformFeedbackVaryingsNV(arg0, arg1, arg2, arg3); }
	public static void glTransformFeedbackVaryingsNV(int arg0, int arg1, int[] arg2, int arg3, int arg4){ gl.glTransformFeedbackVaryingsNV(arg0, arg1, arg2, arg3, arg4); }
	public static void glTranslated(double arg0, double arg1, double arg2){ gl.glTranslated(arg0, arg1, arg2); }
	public static void glTranslatef(float arg0, float arg1, float arg2){ gl.glTranslatef(arg0, arg1, arg2); }
	public static void glUniform1f(int arg0, float arg1){ gl.glUniform1f(arg0, arg1); }
	public static void glUniform1fARB(int arg0, float arg1){ gl.glUniform1fARB(arg0, arg1); }
	public static void glUniform1fv(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glUniform1fv(arg0, arg1, arg2); }
	public static void glUniform1fv(int arg0, int arg1, float[] arg2, int arg3){ gl.glUniform1fv(arg0, arg1, arg2, arg3); }
	public static void glUniform1fvARB(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glUniform1fvARB(arg0, arg1, arg2); }
	public static void glUniform1fvARB(int arg0, int arg1, float[] arg2, int arg3){ gl.glUniform1fvARB(arg0, arg1, arg2, arg3); }
	public static void glUniform1i(int arg0, int arg1){ gl.glUniform1i(arg0, arg1); }
	public static void glUniform1iARB(int arg0, int arg1){ gl.glUniform1iARB(arg0, arg1); }
	public static void glUniform1iv(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glUniform1iv(arg0, arg1, arg2); }
	public static void glUniform1iv(int arg0, int arg1, int[] arg2, int arg3){ gl.glUniform1iv(arg0, arg1, arg2, arg3); }
	public static void glUniform1ivARB(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glUniform1ivARB(arg0, arg1, arg2); }
	public static void glUniform1ivARB(int arg0, int arg1, int[] arg2, int arg3){ gl.glUniform1ivARB(arg0, arg1, arg2, arg3); }
	public static void glUniform1uiEXT(int arg0, int arg1){ gl.glUniform1uiEXT(arg0, arg1); }
	public static void glUniform1uivEXT(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glUniform1uivEXT(arg0, arg1, arg2); }
	public static void glUniform1uivEXT(int arg0, int arg1, int[] arg2, int arg3){ gl.glUniform1uivEXT(arg0, arg1, arg2, arg3); }
	public static void glUniform2f(int arg0, float arg1, float arg2){ gl.glUniform2f(arg0, arg1, arg2); }
	public static void glUniform2fARB(int arg0, float arg1, float arg2){ gl.glUniform2fARB(arg0, arg1, arg2); }
	public static void glUniform2fv(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glUniform2fv(arg0, arg1, arg2); }
	public static void glUniform2fv(int arg0, int arg1, float[] arg2, int arg3){ gl.glUniform2fv(arg0, arg1, arg2, arg3); }
	public static void glUniform2fvARB(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glUniform2fvARB(arg0, arg1, arg2); }
	public static void glUniform2fvARB(int arg0, int arg1, float[] arg2, int arg3){ gl.glUniform2fvARB(arg0, arg1, arg2, arg3); }
	public static void glUniform2i(int arg0, int arg1, int arg2){ gl.glUniform2i(arg0, arg1, arg2); }
	public static void glUniform2iARB(int arg0, int arg1, int arg2){ gl.glUniform2iARB(arg0, arg1, arg2); }
	public static void glUniform2iv(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glUniform2iv(arg0, arg1, arg2); }
	public static void glUniform2iv(int arg0, int arg1, int[] arg2, int arg3){ gl.glUniform2iv(arg0, arg1, arg2, arg3); }
	public static void glUniform2ivARB(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glUniform2ivARB(arg0, arg1, arg2); }
	public static void glUniform2ivARB(int arg0, int arg1, int[] arg2, int arg3){ gl.glUniform2ivARB(arg0, arg1, arg2, arg3); }
	public static void glUniform2uiEXT(int arg0, int arg1, int arg2){ gl.glUniform2uiEXT(arg0, arg1, arg2); }
	public static void glUniform2uivEXT(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glUniform2uivEXT(arg0, arg1, arg2); }
	public static void glUniform2uivEXT(int arg0, int arg1, int[] arg2, int arg3){ gl.glUniform2uivEXT(arg0, arg1, arg2, arg3); }
	public static void glUniform3f(int arg0, float arg1, float arg2, float arg3){ gl.glUniform3f(arg0, arg1, arg2, arg3); }
	public static void glUniform3fARB(int arg0, float arg1, float arg2, float arg3){ gl.glUniform3fARB(arg0, arg1, arg2, arg3); }
	public static void glUniform3fv(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glUniform3fv(arg0, arg1, arg2); }
	public static void glUniform3fv(int arg0, int arg1, float[] arg2, int arg3){ gl.glUniform3fv(arg0, arg1, arg2, arg3); }
	public static void glUniform3fvARB(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glUniform3fvARB(arg0, arg1, arg2); }
	public static void glUniform3fvARB(int arg0, int arg1, float[] arg2, int arg3){ gl.glUniform3fvARB(arg0, arg1, arg2, arg3); }
	public static void glUniform3i(int arg0, int arg1, int arg2, int arg3){ gl.glUniform3i(arg0, arg1, arg2, arg3); }
	public static void glUniform3iARB(int arg0, int arg1, int arg2, int arg3){ gl.glUniform3iARB(arg0, arg1, arg2, arg3); }
	public static void glUniform3iv(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glUniform3iv(arg0, arg1, arg2); }
	public static void glUniform3iv(int arg0, int arg1, int[] arg2, int arg3){ gl.glUniform3iv(arg0, arg1, arg2, arg3); }
	public static void glUniform3ivARB(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glUniform3ivARB(arg0, arg1, arg2); }
	public static void glUniform3ivARB(int arg0, int arg1, int[] arg2, int arg3){ gl.glUniform3ivARB(arg0, arg1, arg2, arg3); }
	public static void glUniform3uiEXT(int arg0, int arg1, int arg2, int arg3){ gl.glUniform3uiEXT(arg0, arg1, arg2, arg3); }
	public static void glUniform3uivEXT(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glUniform3uivEXT(arg0, arg1, arg2); }
	public static void glUniform3uivEXT(int arg0, int arg1, int[] arg2, int arg3){ gl.glUniform3uivEXT(arg0, arg1, arg2, arg3); }
	public static void glUniform4f(int arg0, float arg1, float arg2, float arg3, float arg4){ gl.glUniform4f(arg0, arg1, arg2, arg3, arg4); }
	public static void glUniform4fARB(int arg0, float arg1, float arg2, float arg3, float arg4){ gl.glUniform4fARB(arg0, arg1, arg2, arg3, arg4); }
	public static void glUniform4fv(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glUniform4fv(arg0, arg1, arg2); }
	public static void glUniform4fv(int arg0, int arg1, float[] arg2, int arg3){ gl.glUniform4fv(arg0, arg1, arg2, arg3); }
	public static void glUniform4fvARB(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glUniform4fvARB(arg0, arg1, arg2); }
	public static void glUniform4fvARB(int arg0, int arg1, float[] arg2, int arg3){ gl.glUniform4fvARB(arg0, arg1, arg2, arg3); }
	public static void glUniform4i(int arg0, int arg1, int arg2, int arg3, int arg4){ gl.glUniform4i(arg0, arg1, arg2, arg3, arg4); }
	public static void glUniform4iARB(int arg0, int arg1, int arg2, int arg3, int arg4){ gl.glUniform4iARB(arg0, arg1, arg2, arg3, arg4); }
	public static void glUniform4iv(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glUniform4iv(arg0, arg1, arg2); }
	public static void glUniform4iv(int arg0, int arg1, int[] arg2, int arg3){ gl.glUniform4iv(arg0, arg1, arg2, arg3); }
	public static void glUniform4ivARB(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glUniform4ivARB(arg0, arg1, arg2); }
	public static void glUniform4ivARB(int arg0, int arg1, int[] arg2, int arg3){ gl.glUniform4ivARB(arg0, arg1, arg2, arg3); }
	public static void glUniform4uiEXT(int arg0, int arg1, int arg2, int arg3, int arg4){ gl.glUniform4uiEXT(arg0, arg1, arg2, arg3, arg4); }
	public static void glUniform4uivEXT(int arg0, int arg1, java.nio.IntBuffer arg2){ gl.glUniform4uivEXT(arg0, arg1, arg2); }
	public static void glUniform4uivEXT(int arg0, int arg1, int[] arg2, int arg3){ gl.glUniform4uivEXT(arg0, arg1, arg2, arg3); }
	public static void glUniformBufferEXT(int arg0, int arg1, int arg2){ gl.glUniformBufferEXT(arg0, arg1, arg2); }
	public static void glUniformMatrix2fv(int arg0, int arg1, boolean arg2, java.nio.FloatBuffer arg3){ gl.glUniformMatrix2fv(arg0, arg1, arg2, arg3); }
	public static void glUniformMatrix2fv(int arg0, int arg1, boolean arg2, float[] arg3, int arg4){ gl.glUniformMatrix2fv(arg0, arg1, arg2, arg3, arg4); }
	public static void glUniformMatrix2fvARB(int arg0, int arg1, boolean arg2, java.nio.FloatBuffer arg3){ gl.glUniformMatrix2fvARB(arg0, arg1, arg2, arg3); }
	public static void glUniformMatrix2fvARB(int arg0, int arg1, boolean arg2, float[] arg3, int arg4){ gl.glUniformMatrix2fvARB(arg0, arg1, arg2, arg3, arg4); }
	public static void glUniformMatrix2x3fv(int arg0, int arg1, boolean arg2, java.nio.FloatBuffer arg3){ gl.glUniformMatrix2x3fv(arg0, arg1, arg2, arg3); }
	public static void glUniformMatrix2x3fv(int arg0, int arg1, boolean arg2, float[] arg3, int arg4){ gl.glUniformMatrix2x3fv(arg0, arg1, arg2, arg3, arg4); }
	public static void glUniformMatrix2x4fv(int arg0, int arg1, boolean arg2, java.nio.FloatBuffer arg3){ gl.glUniformMatrix2x4fv(arg0, arg1, arg2, arg3); }
	public static void glUniformMatrix2x4fv(int arg0, int arg1, boolean arg2, float[] arg3, int arg4){ gl.glUniformMatrix2x4fv(arg0, arg1, arg2, arg3, arg4); }
	public static void glUniformMatrix3fv(int arg0, int arg1, boolean arg2, java.nio.FloatBuffer arg3){ gl.glUniformMatrix3fv(arg0, arg1, arg2, arg3); }
	public static void glUniformMatrix3fv(int arg0, int arg1, boolean arg2, float[] arg3, int arg4){ gl.glUniformMatrix3fv(arg0, arg1, arg2, arg3, arg4); }
	public static void glUniformMatrix3fvARB(int arg0, int arg1, boolean arg2, java.nio.FloatBuffer arg3){ gl.glUniformMatrix3fvARB(arg0, arg1, arg2, arg3); }
	public static void glUniformMatrix3fvARB(int arg0, int arg1, boolean arg2, float[] arg3, int arg4){ gl.glUniformMatrix3fvARB(arg0, arg1, arg2, arg3, arg4); }
	public static void glUniformMatrix3x2fv(int arg0, int arg1, boolean arg2, java.nio.FloatBuffer arg3){ gl.glUniformMatrix3x2fv(arg0, arg1, arg2, arg3); }
	public static void glUniformMatrix3x2fv(int arg0, int arg1, boolean arg2, float[] arg3, int arg4){ gl.glUniformMatrix3x2fv(arg0, arg1, arg2, arg3, arg4); }
	public static void glUniformMatrix3x4fv(int arg0, int arg1, boolean arg2, java.nio.FloatBuffer arg3){ gl.glUniformMatrix3x4fv(arg0, arg1, arg2, arg3); }
	public static void glUniformMatrix3x4fv(int arg0, int arg1, boolean arg2, float[] arg3, int arg4){ gl.glUniformMatrix3x4fv(arg0, arg1, arg2, arg3, arg4); }
	public static void glUniformMatrix4fv(int arg0, int arg1, boolean arg2, java.nio.FloatBuffer arg3){ gl.glUniformMatrix4fv(arg0, arg1, arg2, arg3); }
	public static void glUniformMatrix4fv(int arg0, int arg1, boolean arg2, float[] arg3, int arg4){ gl.glUniformMatrix4fv(arg0, arg1, arg2, arg3, arg4); }
	public static void glUniformMatrix4fvARB(int arg0, int arg1, boolean arg2, java.nio.FloatBuffer arg3){ gl.glUniformMatrix4fvARB(arg0, arg1, arg2, arg3); }
	public static void glUniformMatrix4fvARB(int arg0, int arg1, boolean arg2, float[] arg3, int arg4){ gl.glUniformMatrix4fvARB(arg0, arg1, arg2, arg3, arg4); }
	public static void glUniformMatrix4x2fv(int arg0, int arg1, boolean arg2, java.nio.FloatBuffer arg3){ gl.glUniformMatrix4x2fv(arg0, arg1, arg2, arg3); }
	public static void glUniformMatrix4x2fv(int arg0, int arg1, boolean arg2, float[] arg3, int arg4){ gl.glUniformMatrix4x2fv(arg0, arg1, arg2, arg3, arg4); }
	public static void glUniformMatrix4x3fv(int arg0, int arg1, boolean arg2, java.nio.FloatBuffer arg3){ gl.glUniformMatrix4x3fv(arg0, arg1, arg2, arg3); }
	public static void glUniformMatrix4x3fv(int arg0, int arg1, boolean arg2, float[] arg3, int arg4){ gl.glUniformMatrix4x3fv(arg0, arg1, arg2, arg3, arg4); }
	public static void glUnlockArraysEXT(){ gl.glUnlockArraysEXT(); }
	public static boolean glUnmapBuffer(int arg0){return gl.glUnmapBuffer(arg0); }
	public static boolean glUnmapBufferARB(int arg0){return gl.glUnmapBufferARB(arg0); }
	public static void glUpdateObjectBufferATI(int arg0, int arg1, int arg2, java.nio.Buffer arg3, int arg4){ gl.glUpdateObjectBufferATI(arg0, arg1, arg2, arg3, arg4); }
	public static void glUseProgram(int arg0){ gl.glUseProgram(arg0); }
	public static void glUseProgramObjectARB(int arg0){ gl.glUseProgramObjectARB(arg0); }
	public static void glValidateProgram(int arg0){ gl.glValidateProgram(arg0); }
	public static void glValidateProgramARB(int arg0){ gl.glValidateProgramARB(arg0); }
	public static void glVariantArrayObjectATI(int arg0, int arg1, int arg2, int arg3, int arg4){ gl.glVariantArrayObjectATI(arg0, arg1, arg2, arg3, arg4); }
	public static void glVariantPointerEXT(int arg0, int arg1, int arg2, java.nio.Buffer arg3){ gl.glVariantPointerEXT(arg0, arg1, arg2, arg3); }
	public static void glVariantPointerEXT(int arg0, int arg1, int arg2, long arg3){ gl.glVariantPointerEXT(arg0, arg1, arg2, arg3); }
	public static void glVariantbvEXT(int arg0, java.nio.ByteBuffer arg1){ gl.glVariantbvEXT(arg0, arg1); }
	public static void glVariantbvEXT(int arg0, byte[] arg1, int arg2){ gl.glVariantbvEXT(arg0, arg1, arg2); }
	public static void glVariantdvEXT(int arg0, java.nio.DoubleBuffer arg1){ gl.glVariantdvEXT(arg0, arg1); }
	public static void glVariantdvEXT(int arg0, double[] arg1, int arg2){ gl.glVariantdvEXT(arg0, arg1, arg2); }
	public static void glVariantfvEXT(int arg0, java.nio.FloatBuffer arg1){ gl.glVariantfvEXT(arg0, arg1); }
	public static void glVariantfvEXT(int arg0, float[] arg1, int arg2){ gl.glVariantfvEXT(arg0, arg1, arg2); }
	public static void glVariantivEXT(int arg0, java.nio.IntBuffer arg1){ gl.glVariantivEXT(arg0, arg1); }
	public static void glVariantivEXT(int arg0, int[] arg1, int arg2){ gl.glVariantivEXT(arg0, arg1, arg2); }
	public static void glVariantsvEXT(int arg0, java.nio.ShortBuffer arg1){ gl.glVariantsvEXT(arg0, arg1); }
	public static void glVariantsvEXT(int arg0, short[] arg1, int arg2){ gl.glVariantsvEXT(arg0, arg1, arg2); }
	public static void glVariantubvEXT(int arg0, java.nio.ByteBuffer arg1){ gl.glVariantubvEXT(arg0, arg1); }
	public static void glVariantubvEXT(int arg0, byte[] arg1, int arg2){ gl.glVariantubvEXT(arg0, arg1, arg2); }
	public static void glVariantuivEXT(int arg0, java.nio.IntBuffer arg1){ gl.glVariantuivEXT(arg0, arg1); }
	public static void glVariantuivEXT(int arg0, int[] arg1, int arg2){ gl.glVariantuivEXT(arg0, arg1, arg2); }
	public static void glVariantusvEXT(int arg0, java.nio.ShortBuffer arg1){ gl.glVariantusvEXT(arg0, arg1); }
	public static void glVariantusvEXT(int arg0, short[] arg1, int arg2){ gl.glVariantusvEXT(arg0, arg1, arg2); }
	public static void glVertex2d(double arg0, double arg1){ gl.glVertex2d(arg0, arg1); }
	public static void glVertex2dv(java.nio.DoubleBuffer arg0){ gl.glVertex2dv(arg0); }
	public static void glVertex2dv(double[] arg0, int arg1){ gl.glVertex2dv(arg0, arg1); }
	public static void glVertex2f(float arg0, float arg1){ gl.glVertex2f(arg0, arg1); }
	public static void glVertex2fv(java.nio.FloatBuffer arg0){ gl.glVertex2fv(arg0); }
	public static void glVertex2fv(float[] arg0, int arg1){ gl.glVertex2fv(arg0, arg1); }
	public static void glVertex2hNV(short arg0, short arg1){ gl.glVertex2hNV(arg0, arg1); }
	public static void glVertex2hvNV(java.nio.ShortBuffer arg0){ gl.glVertex2hvNV(arg0); }
	public static void glVertex2hvNV(short[] arg0, int arg1){ gl.glVertex2hvNV(arg0, arg1); }
	public static void glVertex2i(int arg0, int arg1){ gl.glVertex2i(arg0, arg1); }
	public static void glVertex2iv(java.nio.IntBuffer arg0){ gl.glVertex2iv(arg0); }
	public static void glVertex2iv(int[] arg0, int arg1){ gl.glVertex2iv(arg0, arg1); }
	public static void glVertex2s(short arg0, short arg1){ gl.glVertex2s(arg0, arg1); }
	public static void glVertex2sv(java.nio.ShortBuffer arg0){ gl.glVertex2sv(arg0); }
	public static void glVertex2sv(short[] arg0, int arg1){ gl.glVertex2sv(arg0, arg1); }
	public static void glVertex3d(double arg0, double arg1, double arg2){ gl.glVertex3d(arg0, arg1, arg2); }
	public static void glVertex3dv(java.nio.DoubleBuffer arg0){ gl.glVertex3dv(arg0); }
	public static void glVertex3dv(double[] arg0, int arg1){ gl.glVertex3dv(arg0, arg1); }
	public static void glVertex3f(float arg0, float arg1, float arg2){ gl.glVertex3f(arg0, arg1, arg2); }
	public static void glVertex3fv(java.nio.FloatBuffer arg0){ gl.glVertex3fv(arg0); }
	public static void glVertex3fv(float[] arg0, int arg1){ gl.glVertex3fv(arg0, arg1); }
	public static void glVertex3hNV(short arg0, short arg1, short arg2){ gl.glVertex3hNV(arg0, arg1, arg2); }
	public static void glVertex3hvNV(java.nio.ShortBuffer arg0){ gl.glVertex3hvNV(arg0); }
	public static void glVertex3hvNV(short[] arg0, int arg1){ gl.glVertex3hvNV(arg0, arg1); }
	public static void glVertex3i(int arg0, int arg1, int arg2){ gl.glVertex3i(arg0, arg1, arg2); }
	public static void glVertex3iv(java.nio.IntBuffer arg0){ gl.glVertex3iv(arg0); }
	public static void glVertex3iv(int[] arg0, int arg1){ gl.glVertex3iv(arg0, arg1); }
	public static void glVertex3s(short arg0, short arg1, short arg2){ gl.glVertex3s(arg0, arg1, arg2); }
	public static void glVertex3sv(java.nio.ShortBuffer arg0){ gl.glVertex3sv(arg0); }
	public static void glVertex3sv(short[] arg0, int arg1){ gl.glVertex3sv(arg0, arg1); }
	public static void glVertex4d(double arg0, double arg1, double arg2, double arg3){ gl.glVertex4d(arg0, arg1, arg2, arg3); }
	public static void glVertex4dv(java.nio.DoubleBuffer arg0){ gl.glVertex4dv(arg0); }
	public static void glVertex4dv(double[] arg0, int arg1){ gl.glVertex4dv(arg0, arg1); }
	public static void glVertex4f(float arg0, float arg1, float arg2, float arg3){ gl.glVertex4f(arg0, arg1, arg2, arg3); }
	public static void glVertex4fv(java.nio.FloatBuffer arg0){ gl.glVertex4fv(arg0); }
	public static void glVertex4fv(float[] arg0, int arg1){ gl.glVertex4fv(arg0, arg1); }
	public static void glVertex4hNV(short arg0, short arg1, short arg2, short arg3){ gl.glVertex4hNV(arg0, arg1, arg2, arg3); }
	public static void glVertex4hvNV(java.nio.ShortBuffer arg0){ gl.glVertex4hvNV(arg0); }
	public static void glVertex4hvNV(short[] arg0, int arg1){ gl.glVertex4hvNV(arg0, arg1); }
	public static void glVertex4i(int arg0, int arg1, int arg2, int arg3){ gl.glVertex4i(arg0, arg1, arg2, arg3); }
	public static void glVertex4iv(java.nio.IntBuffer arg0){ gl.glVertex4iv(arg0); }
	public static void glVertex4iv(int[] arg0, int arg1){ gl.glVertex4iv(arg0, arg1); }
	public static void glVertex4s(short arg0, short arg1, short arg2, short arg3){ gl.glVertex4s(arg0, arg1, arg2, arg3); }
	public static void glVertex4sv(java.nio.ShortBuffer arg0){ gl.glVertex4sv(arg0); }
	public static void glVertex4sv(short[] arg0, int arg1){ gl.glVertex4sv(arg0, arg1); }
	public static void glVertexArrayParameteriAPPLE(int arg0, int arg1){ gl.glVertexArrayParameteriAPPLE(arg0, arg1); }
	public static void glVertexArrayRangeAPPLE(int arg0, java.nio.Buffer arg1){ gl.glVertexArrayRangeAPPLE(arg0, arg1); }
	public static void glVertexArrayRangeNV(int arg0, java.nio.Buffer arg1){ gl.glVertexArrayRangeNV(arg0, arg1); }
	public static void glVertexAttrib1d(int arg0, double arg1){ gl.glVertexAttrib1d(arg0, arg1); }
	public static void glVertexAttrib1dARB(int arg0, double arg1){ gl.glVertexAttrib1dARB(arg0, arg1); }
	public static void glVertexAttrib1dNV(int arg0, double arg1){ gl.glVertexAttrib1dNV(arg0, arg1); }
	public static void glVertexAttrib1dv(int arg0, java.nio.DoubleBuffer arg1){ gl.glVertexAttrib1dv(arg0, arg1); }
	public static void glVertexAttrib1dv(int arg0, double[] arg1, int arg2){ gl.glVertexAttrib1dv(arg0, arg1, arg2); }
	public static void glVertexAttrib1dvARB(int arg0, java.nio.DoubleBuffer arg1){ gl.glVertexAttrib1dvARB(arg0, arg1); }
	public static void glVertexAttrib1dvARB(int arg0, double[] arg1, int arg2){ gl.glVertexAttrib1dvARB(arg0, arg1, arg2); }
	public static void glVertexAttrib1dvNV(int arg0, java.nio.DoubleBuffer arg1){ gl.glVertexAttrib1dvNV(arg0, arg1); }
	public static void glVertexAttrib1dvNV(int arg0, double[] arg1, int arg2){ gl.glVertexAttrib1dvNV(arg0, arg1, arg2); }
	public static void glVertexAttrib1f(int arg0, float arg1){ gl.glVertexAttrib1f(arg0, arg1); }
	public static void glVertexAttrib1fARB(int arg0, float arg1){ gl.glVertexAttrib1fARB(arg0, arg1); }
	public static void glVertexAttrib1fNV(int arg0, float arg1){ gl.glVertexAttrib1fNV(arg0, arg1); }
	public static void glVertexAttrib1fv(int arg0, java.nio.FloatBuffer arg1){ gl.glVertexAttrib1fv(arg0, arg1); }
	public static void glVertexAttrib1fv(int arg0, float[] arg1, int arg2){ gl.glVertexAttrib1fv(arg0, arg1, arg2); }
	public static void glVertexAttrib1fvARB(int arg0, java.nio.FloatBuffer arg1){ gl.glVertexAttrib1fvARB(arg0, arg1); }
	public static void glVertexAttrib1fvARB(int arg0, float[] arg1, int arg2){ gl.glVertexAttrib1fvARB(arg0, arg1, arg2); }
	public static void glVertexAttrib1fvNV(int arg0, java.nio.FloatBuffer arg1){ gl.glVertexAttrib1fvNV(arg0, arg1); }
	public static void glVertexAttrib1fvNV(int arg0, float[] arg1, int arg2){ gl.glVertexAttrib1fvNV(arg0, arg1, arg2); }
	public static void glVertexAttrib1hNV(int arg0, short arg1){ gl.glVertexAttrib1hNV(arg0, arg1); }
	public static void glVertexAttrib1hvNV(int arg0, java.nio.ShortBuffer arg1){ gl.glVertexAttrib1hvNV(arg0, arg1); }
	public static void glVertexAttrib1hvNV(int arg0, short[] arg1, int arg2){ gl.glVertexAttrib1hvNV(arg0, arg1, arg2); }
	public static void glVertexAttrib1s(int arg0, short arg1){ gl.glVertexAttrib1s(arg0, arg1); }
	public static void glVertexAttrib1sARB(int arg0, short arg1){ gl.glVertexAttrib1sARB(arg0, arg1); }
	public static void glVertexAttrib1sNV(int arg0, short arg1){ gl.glVertexAttrib1sNV(arg0, arg1); }
	public static void glVertexAttrib1sv(int arg0, java.nio.ShortBuffer arg1){ gl.glVertexAttrib1sv(arg0, arg1); }
	public static void glVertexAttrib1sv(int arg0, short[] arg1, int arg2){ gl.glVertexAttrib1sv(arg0, arg1, arg2); }
	public static void glVertexAttrib1svARB(int arg0, java.nio.ShortBuffer arg1){ gl.glVertexAttrib1svARB(arg0, arg1); }
	public static void glVertexAttrib1svARB(int arg0, short[] arg1, int arg2){ gl.glVertexAttrib1svARB(arg0, arg1, arg2); }
	public static void glVertexAttrib1svNV(int arg0, java.nio.ShortBuffer arg1){ gl.glVertexAttrib1svNV(arg0, arg1); }
	public static void glVertexAttrib1svNV(int arg0, short[] arg1, int arg2){ gl.glVertexAttrib1svNV(arg0, arg1, arg2); }
	public static void glVertexAttrib2d(int arg0, double arg1, double arg2){ gl.glVertexAttrib2d(arg0, arg1, arg2); }
	public static void glVertexAttrib2dARB(int arg0, double arg1, double arg2){ gl.glVertexAttrib2dARB(arg0, arg1, arg2); }
	public static void glVertexAttrib2dNV(int arg0, double arg1, double arg2){ gl.glVertexAttrib2dNV(arg0, arg1, arg2); }
	public static void glVertexAttrib2dv(int arg0, java.nio.DoubleBuffer arg1){ gl.glVertexAttrib2dv(arg0, arg1); }
	public static void glVertexAttrib2dv(int arg0, double[] arg1, int arg2){ gl.glVertexAttrib2dv(arg0, arg1, arg2); }
	public static void glVertexAttrib2dvARB(int arg0, java.nio.DoubleBuffer arg1){ gl.glVertexAttrib2dvARB(arg0, arg1); }
	public static void glVertexAttrib2dvARB(int arg0, double[] arg1, int arg2){ gl.glVertexAttrib2dvARB(arg0, arg1, arg2); }
	public static void glVertexAttrib2dvNV(int arg0, java.nio.DoubleBuffer arg1){ gl.glVertexAttrib2dvNV(arg0, arg1); }
	public static void glVertexAttrib2dvNV(int arg0, double[] arg1, int arg2){ gl.glVertexAttrib2dvNV(arg0, arg1, arg2); }
	public static void glVertexAttrib2f(int arg0, float arg1, float arg2){ gl.glVertexAttrib2f(arg0, arg1, arg2); }
	public static void glVertexAttrib2fARB(int arg0, float arg1, float arg2){ gl.glVertexAttrib2fARB(arg0, arg1, arg2); }
	public static void glVertexAttrib2fNV(int arg0, float arg1, float arg2){ gl.glVertexAttrib2fNV(arg0, arg1, arg2); }
	public static void glVertexAttrib2fv(int arg0, java.nio.FloatBuffer arg1){ gl.glVertexAttrib2fv(arg0, arg1); }
	public static void glVertexAttrib2fv(int arg0, float[] arg1, int arg2){ gl.glVertexAttrib2fv(arg0, arg1, arg2); }
	public static void glVertexAttrib2fvARB(int arg0, java.nio.FloatBuffer arg1){ gl.glVertexAttrib2fvARB(arg0, arg1); }
	public static void glVertexAttrib2fvARB(int arg0, float[] arg1, int arg2){ gl.glVertexAttrib2fvARB(arg0, arg1, arg2); }
	public static void glVertexAttrib2fvNV(int arg0, java.nio.FloatBuffer arg1){ gl.glVertexAttrib2fvNV(arg0, arg1); }
	public static void glVertexAttrib2fvNV(int arg0, float[] arg1, int arg2){ gl.glVertexAttrib2fvNV(arg0, arg1, arg2); }
	public static void glVertexAttrib2hNV(int arg0, short arg1, short arg2){ gl.glVertexAttrib2hNV(arg0, arg1, arg2); }
	public static void glVertexAttrib2hvNV(int arg0, java.nio.ShortBuffer arg1){ gl.glVertexAttrib2hvNV(arg0, arg1); }
	public static void glVertexAttrib2hvNV(int arg0, short[] arg1, int arg2){ gl.glVertexAttrib2hvNV(arg0, arg1, arg2); }
	public static void glVertexAttrib2s(int arg0, short arg1, short arg2){ gl.glVertexAttrib2s(arg0, arg1, arg2); }
	public static void glVertexAttrib2sARB(int arg0, short arg1, short arg2){ gl.glVertexAttrib2sARB(arg0, arg1, arg2); }
	public static void glVertexAttrib2sNV(int arg0, short arg1, short arg2){ gl.glVertexAttrib2sNV(arg0, arg1, arg2); }
	public static void glVertexAttrib2sv(int arg0, java.nio.ShortBuffer arg1){ gl.glVertexAttrib2sv(arg0, arg1); }
	public static void glVertexAttrib2sv(int arg0, short[] arg1, int arg2){ gl.glVertexAttrib2sv(arg0, arg1, arg2); }
	public static void glVertexAttrib2svARB(int arg0, java.nio.ShortBuffer arg1){ gl.glVertexAttrib2svARB(arg0, arg1); }
	public static void glVertexAttrib2svARB(int arg0, short[] arg1, int arg2){ gl.glVertexAttrib2svARB(arg0, arg1, arg2); }
	public static void glVertexAttrib2svNV(int arg0, java.nio.ShortBuffer arg1){ gl.glVertexAttrib2svNV(arg0, arg1); }
	public static void glVertexAttrib2svNV(int arg0, short[] arg1, int arg2){ gl.glVertexAttrib2svNV(arg0, arg1, arg2); }
	public static void glVertexAttrib3d(int arg0, double arg1, double arg2, double arg3){ gl.glVertexAttrib3d(arg0, arg1, arg2, arg3); }
	public static void glVertexAttrib3dARB(int arg0, double arg1, double arg2, double arg3){ gl.glVertexAttrib3dARB(arg0, arg1, arg2, arg3); }
	public static void glVertexAttrib3dNV(int arg0, double arg1, double arg2, double arg3){ gl.glVertexAttrib3dNV(arg0, arg1, arg2, arg3); }
	public static void glVertexAttrib3dv(int arg0, java.nio.DoubleBuffer arg1){ gl.glVertexAttrib3dv(arg0, arg1); }
	public static void glVertexAttrib3dv(int arg0, double[] arg1, int arg2){ gl.glVertexAttrib3dv(arg0, arg1, arg2); }
	public static void glVertexAttrib3dvARB(int arg0, java.nio.DoubleBuffer arg1){ gl.glVertexAttrib3dvARB(arg0, arg1); }
	public static void glVertexAttrib3dvARB(int arg0, double[] arg1, int arg2){ gl.glVertexAttrib3dvARB(arg0, arg1, arg2); }
	public static void glVertexAttrib3dvNV(int arg0, java.nio.DoubleBuffer arg1){ gl.glVertexAttrib3dvNV(arg0, arg1); }
	public static void glVertexAttrib3dvNV(int arg0, double[] arg1, int arg2){ gl.glVertexAttrib3dvNV(arg0, arg1, arg2); }
	public static void glVertexAttrib3f(int arg0, float arg1, float arg2, float arg3){ gl.glVertexAttrib3f(arg0, arg1, arg2, arg3); }
	public static void glVertexAttrib3fARB(int arg0, float arg1, float arg2, float arg3){ gl.glVertexAttrib3fARB(arg0, arg1, arg2, arg3); }
	public static void glVertexAttrib3fNV(int arg0, float arg1, float arg2, float arg3){ gl.glVertexAttrib3fNV(arg0, arg1, arg2, arg3); }
	public static void glVertexAttrib3fv(int arg0, java.nio.FloatBuffer arg1){ gl.glVertexAttrib3fv(arg0, arg1); }
	public static void glVertexAttrib3fv(int arg0, float[] arg1, int arg2){ gl.glVertexAttrib3fv(arg0, arg1, arg2); }
	public static void glVertexAttrib3fvARB(int arg0, java.nio.FloatBuffer arg1){ gl.glVertexAttrib3fvARB(arg0, arg1); }
	public static void glVertexAttrib3fvARB(int arg0, float[] arg1, int arg2){ gl.glVertexAttrib3fvARB(arg0, arg1, arg2); }
	public static void glVertexAttrib3fvNV(int arg0, java.nio.FloatBuffer arg1){ gl.glVertexAttrib3fvNV(arg0, arg1); }
	public static void glVertexAttrib3fvNV(int arg0, float[] arg1, int arg2){ gl.glVertexAttrib3fvNV(arg0, arg1, arg2); }
	public static void glVertexAttrib3hNV(int arg0, short arg1, short arg2, short arg3){ gl.glVertexAttrib3hNV(arg0, arg1, arg2, arg3); }
	public static void glVertexAttrib3hvNV(int arg0, java.nio.ShortBuffer arg1){ gl.glVertexAttrib3hvNV(arg0, arg1); }
	public static void glVertexAttrib3hvNV(int arg0, short[] arg1, int arg2){ gl.glVertexAttrib3hvNV(arg0, arg1, arg2); }
	public static void glVertexAttrib3s(int arg0, short arg1, short arg2, short arg3){ gl.glVertexAttrib3s(arg0, arg1, arg2, arg3); }
	public static void glVertexAttrib3sARB(int arg0, short arg1, short arg2, short arg3){ gl.glVertexAttrib3sARB(arg0, arg1, arg2, arg3); }
	public static void glVertexAttrib3sNV(int arg0, short arg1, short arg2, short arg3){ gl.glVertexAttrib3sNV(arg0, arg1, arg2, arg3); }
	public static void glVertexAttrib3sv(int arg0, java.nio.ShortBuffer arg1){ gl.glVertexAttrib3sv(arg0, arg1); }
	public static void glVertexAttrib3sv(int arg0, short[] arg1, int arg2){ gl.glVertexAttrib3sv(arg0, arg1, arg2); }
	public static void glVertexAttrib3svARB(int arg0, java.nio.ShortBuffer arg1){ gl.glVertexAttrib3svARB(arg0, arg1); }
	public static void glVertexAttrib3svARB(int arg0, short[] arg1, int arg2){ gl.glVertexAttrib3svARB(arg0, arg1, arg2); }
	public static void glVertexAttrib3svNV(int arg0, java.nio.ShortBuffer arg1){ gl.glVertexAttrib3svNV(arg0, arg1); }
	public static void glVertexAttrib3svNV(int arg0, short[] arg1, int arg2){ gl.glVertexAttrib3svNV(arg0, arg1, arg2); }
	public static void glVertexAttrib4Nbv(int arg0, java.nio.ByteBuffer arg1){ gl.glVertexAttrib4Nbv(arg0, arg1); }
	public static void glVertexAttrib4Nbv(int arg0, byte[] arg1, int arg2){ gl.glVertexAttrib4Nbv(arg0, arg1, arg2); }
	public static void glVertexAttrib4NbvARB(int arg0, java.nio.ByteBuffer arg1){ gl.glVertexAttrib4NbvARB(arg0, arg1); }
	public static void glVertexAttrib4NbvARB(int arg0, byte[] arg1, int arg2){ gl.glVertexAttrib4NbvARB(arg0, arg1, arg2); }
	public static void glVertexAttrib4Niv(int arg0, java.nio.IntBuffer arg1){ gl.glVertexAttrib4Niv(arg0, arg1); }
	public static void glVertexAttrib4Niv(int arg0, int[] arg1, int arg2){ gl.glVertexAttrib4Niv(arg0, arg1, arg2); }
	public static void glVertexAttrib4NivARB(int arg0, java.nio.IntBuffer arg1){ gl.glVertexAttrib4NivARB(arg0, arg1); }
	public static void glVertexAttrib4NivARB(int arg0, int[] arg1, int arg2){ gl.glVertexAttrib4NivARB(arg0, arg1, arg2); }
	public static void glVertexAttrib4Nsv(int arg0, java.nio.ShortBuffer arg1){ gl.glVertexAttrib4Nsv(arg0, arg1); }
	public static void glVertexAttrib4Nsv(int arg0, short[] arg1, int arg2){ gl.glVertexAttrib4Nsv(arg0, arg1, arg2); }
	public static void glVertexAttrib4NsvARB(int arg0, java.nio.ShortBuffer arg1){ gl.glVertexAttrib4NsvARB(arg0, arg1); }
	public static void glVertexAttrib4NsvARB(int arg0, short[] arg1, int arg2){ gl.glVertexAttrib4NsvARB(arg0, arg1, arg2); }
	public static void glVertexAttrib4Nub(int arg0, byte arg1, byte arg2, byte arg3, byte arg4){ gl.glVertexAttrib4Nub(arg0, arg1, arg2, arg3, arg4); }
	public static void glVertexAttrib4NubARB(int arg0, byte arg1, byte arg2, byte arg3, byte arg4){ gl.glVertexAttrib4NubARB(arg0, arg1, arg2, arg3, arg4); }
	public static void glVertexAttrib4Nubv(int arg0, java.nio.ByteBuffer arg1){ gl.glVertexAttrib4Nubv(arg0, arg1); }
	public static void glVertexAttrib4Nubv(int arg0, byte[] arg1, int arg2){ gl.glVertexAttrib4Nubv(arg0, arg1, arg2); }
	public static void glVertexAttrib4NubvARB(int arg0, java.nio.ByteBuffer arg1){ gl.glVertexAttrib4NubvARB(arg0, arg1); }
	public static void glVertexAttrib4NubvARB(int arg0, byte[] arg1, int arg2){ gl.glVertexAttrib4NubvARB(arg0, arg1, arg2); }
	public static void glVertexAttrib4Nuiv(int arg0, java.nio.IntBuffer arg1){ gl.glVertexAttrib4Nuiv(arg0, arg1); }
	public static void glVertexAttrib4Nuiv(int arg0, int[] arg1, int arg2){ gl.glVertexAttrib4Nuiv(arg0, arg1, arg2); }
	public static void glVertexAttrib4NuivARB(int arg0, java.nio.IntBuffer arg1){ gl.glVertexAttrib4NuivARB(arg0, arg1); }
	public static void glVertexAttrib4NuivARB(int arg0, int[] arg1, int arg2){ gl.glVertexAttrib4NuivARB(arg0, arg1, arg2); }
	public static void glVertexAttrib4Nusv(int arg0, java.nio.ShortBuffer arg1){ gl.glVertexAttrib4Nusv(arg0, arg1); }
	public static void glVertexAttrib4Nusv(int arg0, short[] arg1, int arg2){ gl.glVertexAttrib4Nusv(arg0, arg1, arg2); }
	public static void glVertexAttrib4NusvARB(int arg0, java.nio.ShortBuffer arg1){ gl.glVertexAttrib4NusvARB(arg0, arg1); }
	public static void glVertexAttrib4NusvARB(int arg0, short[] arg1, int arg2){ gl.glVertexAttrib4NusvARB(arg0, arg1, arg2); }
	public static void glVertexAttrib4bv(int arg0, java.nio.ByteBuffer arg1){ gl.glVertexAttrib4bv(arg0, arg1); }
	public static void glVertexAttrib4bv(int arg0, byte[] arg1, int arg2){ gl.glVertexAttrib4bv(arg0, arg1, arg2); }
	public static void glVertexAttrib4bvARB(int arg0, java.nio.ByteBuffer arg1){ gl.glVertexAttrib4bvARB(arg0, arg1); }
	public static void glVertexAttrib4bvARB(int arg0, byte[] arg1, int arg2){ gl.glVertexAttrib4bvARB(arg0, arg1, arg2); }
	public static void glVertexAttrib4d(int arg0, double arg1, double arg2, double arg3, double arg4){ gl.glVertexAttrib4d(arg0, arg1, arg2, arg3, arg4); }
	public static void glVertexAttrib4dARB(int arg0, double arg1, double arg2, double arg3, double arg4){ gl.glVertexAttrib4dARB(arg0, arg1, arg2, arg3, arg4); }
	public static void glVertexAttrib4dNV(int arg0, double arg1, double arg2, double arg3, double arg4){ gl.glVertexAttrib4dNV(arg0, arg1, arg2, arg3, arg4); }
	public static void glVertexAttrib4dv(int arg0, java.nio.DoubleBuffer arg1){ gl.glVertexAttrib4dv(arg0, arg1); }
	public static void glVertexAttrib4dv(int arg0, double[] arg1, int arg2){ gl.glVertexAttrib4dv(arg0, arg1, arg2); }
	public static void glVertexAttrib4dvARB(int arg0, java.nio.DoubleBuffer arg1){ gl.glVertexAttrib4dvARB(arg0, arg1); }
	public static void glVertexAttrib4dvARB(int arg0, double[] arg1, int arg2){ gl.glVertexAttrib4dvARB(arg0, arg1, arg2); }
	public static void glVertexAttrib4dvNV(int arg0, java.nio.DoubleBuffer arg1){ gl.glVertexAttrib4dvNV(arg0, arg1); }
	public static void glVertexAttrib4dvNV(int arg0, double[] arg1, int arg2){ gl.glVertexAttrib4dvNV(arg0, arg1, arg2); }
	public static void glVertexAttrib4f(int arg0, float arg1, float arg2, float arg3, float arg4){ gl.glVertexAttrib4f(arg0, arg1, arg2, arg3, arg4); }
	public static void glVertexAttrib4fARB(int arg0, float arg1, float arg2, float arg3, float arg4){ gl.glVertexAttrib4fARB(arg0, arg1, arg2, arg3, arg4); }
	public static void glVertexAttrib4fNV(int arg0, float arg1, float arg2, float arg3, float arg4){ gl.glVertexAttrib4fNV(arg0, arg1, arg2, arg3, arg4); }
	public static void glVertexAttrib4fv(int arg0, java.nio.FloatBuffer arg1){ gl.glVertexAttrib4fv(arg0, arg1); }
	public static void glVertexAttrib4fv(int arg0, float[] arg1, int arg2){ gl.glVertexAttrib4fv(arg0, arg1, arg2); }
	public static void glVertexAttrib4fvARB(int arg0, java.nio.FloatBuffer arg1){ gl.glVertexAttrib4fvARB(arg0, arg1); }
	public static void glVertexAttrib4fvARB(int arg0, float[] arg1, int arg2){ gl.glVertexAttrib4fvARB(arg0, arg1, arg2); }
	public static void glVertexAttrib4fvNV(int arg0, java.nio.FloatBuffer arg1){ gl.glVertexAttrib4fvNV(arg0, arg1); }
	public static void glVertexAttrib4fvNV(int arg0, float[] arg1, int arg2){ gl.glVertexAttrib4fvNV(arg0, arg1, arg2); }
	public static void glVertexAttrib4hNV(int arg0, short arg1, short arg2, short arg3, short arg4){ gl.glVertexAttrib4hNV(arg0, arg1, arg2, arg3, arg4); }
	public static void glVertexAttrib4hvNV(int arg0, java.nio.ShortBuffer arg1){ gl.glVertexAttrib4hvNV(arg0, arg1); }
	public static void glVertexAttrib4hvNV(int arg0, short[] arg1, int arg2){ gl.glVertexAttrib4hvNV(arg0, arg1, arg2); }
	public static void glVertexAttrib4iv(int arg0, java.nio.IntBuffer arg1){ gl.glVertexAttrib4iv(arg0, arg1); }
	public static void glVertexAttrib4iv(int arg0, int[] arg1, int arg2){ gl.glVertexAttrib4iv(arg0, arg1, arg2); }
	public static void glVertexAttrib4ivARB(int arg0, java.nio.IntBuffer arg1){ gl.glVertexAttrib4ivARB(arg0, arg1); }
	public static void glVertexAttrib4ivARB(int arg0, int[] arg1, int arg2){ gl.glVertexAttrib4ivARB(arg0, arg1, arg2); }
	public static void glVertexAttrib4s(int arg0, short arg1, short arg2, short arg3, short arg4){ gl.glVertexAttrib4s(arg0, arg1, arg2, arg3, arg4); }
	public static void glVertexAttrib4sARB(int arg0, short arg1, short arg2, short arg3, short arg4){ gl.glVertexAttrib4sARB(arg0, arg1, arg2, arg3, arg4); }
	public static void glVertexAttrib4sNV(int arg0, short arg1, short arg2, short arg3, short arg4){ gl.glVertexAttrib4sNV(arg0, arg1, arg2, arg3, arg4); }
	public static void glVertexAttrib4sv(int arg0, java.nio.ShortBuffer arg1){ gl.glVertexAttrib4sv(arg0, arg1); }
	public static void glVertexAttrib4sv(int arg0, short[] arg1, int arg2){ gl.glVertexAttrib4sv(arg0, arg1, arg2); }
	public static void glVertexAttrib4svARB(int arg0, java.nio.ShortBuffer arg1){ gl.glVertexAttrib4svARB(arg0, arg1); }
	public static void glVertexAttrib4svARB(int arg0, short[] arg1, int arg2){ gl.glVertexAttrib4svARB(arg0, arg1, arg2); }
	public static void glVertexAttrib4svNV(int arg0, java.nio.ShortBuffer arg1){ gl.glVertexAttrib4svNV(arg0, arg1); }
	public static void glVertexAttrib4svNV(int arg0, short[] arg1, int arg2){ gl.glVertexAttrib4svNV(arg0, arg1, arg2); }
	public static void glVertexAttrib4ubNV(int arg0, byte arg1, byte arg2, byte arg3, byte arg4){ gl.glVertexAttrib4ubNV(arg0, arg1, arg2, arg3, arg4); }
	public static void glVertexAttrib4ubv(int arg0, java.nio.ByteBuffer arg1){ gl.glVertexAttrib4ubv(arg0, arg1); }
	public static void glVertexAttrib4ubv(int arg0, byte[] arg1, int arg2){ gl.glVertexAttrib4ubv(arg0, arg1, arg2); }
	public static void glVertexAttrib4ubvARB(int arg0, java.nio.ByteBuffer arg1){ gl.glVertexAttrib4ubvARB(arg0, arg1); }
	public static void glVertexAttrib4ubvARB(int arg0, byte[] arg1, int arg2){ gl.glVertexAttrib4ubvARB(arg0, arg1, arg2); }
	public static void glVertexAttrib4ubvNV(int arg0, java.nio.ByteBuffer arg1){ gl.glVertexAttrib4ubvNV(arg0, arg1); }
	public static void glVertexAttrib4ubvNV(int arg0, byte[] arg1, int arg2){ gl.glVertexAttrib4ubvNV(arg0, arg1, arg2); }
	public static void glVertexAttrib4uiv(int arg0, java.nio.IntBuffer arg1){ gl.glVertexAttrib4uiv(arg0, arg1); }
	public static void glVertexAttrib4uiv(int arg0, int[] arg1, int arg2){ gl.glVertexAttrib4uiv(arg0, arg1, arg2); }
	public static void glVertexAttrib4uivARB(int arg0, java.nio.IntBuffer arg1){ gl.glVertexAttrib4uivARB(arg0, arg1); }
	public static void glVertexAttrib4uivARB(int arg0, int[] arg1, int arg2){ gl.glVertexAttrib4uivARB(arg0, arg1, arg2); }
	public static void glVertexAttrib4usv(int arg0, java.nio.ShortBuffer arg1){ gl.glVertexAttrib4usv(arg0, arg1); }
	public static void glVertexAttrib4usv(int arg0, short[] arg1, int arg2){ gl.glVertexAttrib4usv(arg0, arg1, arg2); }
	public static void glVertexAttrib4usvARB(int arg0, java.nio.ShortBuffer arg1){ gl.glVertexAttrib4usvARB(arg0, arg1); }
	public static void glVertexAttrib4usvARB(int arg0, short[] arg1, int arg2){ gl.glVertexAttrib4usvARB(arg0, arg1, arg2); }
	public static void glVertexAttribArrayObjectATI(int arg0, int arg1, int arg2, boolean arg3, int arg4, int arg5, int arg6){ gl.glVertexAttribArrayObjectATI(arg0, arg1, arg2, arg3, arg4, arg5, arg6); }
	public static void glVertexAttribI1iEXT(int arg0, int arg1){ gl.glVertexAttribI1iEXT(arg0, arg1); }
	public static void glVertexAttribI1ivEXT(int arg0, java.nio.IntBuffer arg1){ gl.glVertexAttribI1ivEXT(arg0, arg1); }
	public static void glVertexAttribI1ivEXT(int arg0, int[] arg1, int arg2){ gl.glVertexAttribI1ivEXT(arg0, arg1, arg2); }
	public static void glVertexAttribI1uiEXT(int arg0, int arg1){ gl.glVertexAttribI1uiEXT(arg0, arg1); }
	public static void glVertexAttribI1uivEXT(int arg0, java.nio.IntBuffer arg1){ gl.glVertexAttribI1uivEXT(arg0, arg1); }
	public static void glVertexAttribI1uivEXT(int arg0, int[] arg1, int arg2){ gl.glVertexAttribI1uivEXT(arg0, arg1, arg2); }
	public static void glVertexAttribI2iEXT(int arg0, int arg1, int arg2){ gl.glVertexAttribI2iEXT(arg0, arg1, arg2); }
	public static void glVertexAttribI2ivEXT(int arg0, java.nio.IntBuffer arg1){ gl.glVertexAttribI2ivEXT(arg0, arg1); }
	public static void glVertexAttribI2ivEXT(int arg0, int[] arg1, int arg2){ gl.glVertexAttribI2ivEXT(arg0, arg1, arg2); }
	public static void glVertexAttribI2uiEXT(int arg0, int arg1, int arg2){ gl.glVertexAttribI2uiEXT(arg0, arg1, arg2); }
	public static void glVertexAttribI2uivEXT(int arg0, java.nio.IntBuffer arg1){ gl.glVertexAttribI2uivEXT(arg0, arg1); }
	public static void glVertexAttribI2uivEXT(int arg0, int[] arg1, int arg2){ gl.glVertexAttribI2uivEXT(arg0, arg1, arg2); }
	public static void glVertexAttribI3iEXT(int arg0, int arg1, int arg2, int arg3){ gl.glVertexAttribI3iEXT(arg0, arg1, arg2, arg3); }
	public static void glVertexAttribI3ivEXT(int arg0, java.nio.IntBuffer arg1){ gl.glVertexAttribI3ivEXT(arg0, arg1); }
	public static void glVertexAttribI3ivEXT(int arg0, int[] arg1, int arg2){ gl.glVertexAttribI3ivEXT(arg0, arg1, arg2); }
	public static void glVertexAttribI3uiEXT(int arg0, int arg1, int arg2, int arg3){ gl.glVertexAttribI3uiEXT(arg0, arg1, arg2, arg3); }
	public static void glVertexAttribI3uivEXT(int arg0, java.nio.IntBuffer arg1){ gl.glVertexAttribI3uivEXT(arg0, arg1); }
	public static void glVertexAttribI3uivEXT(int arg0, int[] arg1, int arg2){ gl.glVertexAttribI3uivEXT(arg0, arg1, arg2); }
	public static void glVertexAttribI4bvEXT(int arg0, java.nio.ByteBuffer arg1){ gl.glVertexAttribI4bvEXT(arg0, arg1); }
	public static void glVertexAttribI4bvEXT(int arg0, byte[] arg1, int arg2){ gl.glVertexAttribI4bvEXT(arg0, arg1, arg2); }
	public static void glVertexAttribI4iEXT(int arg0, int arg1, int arg2, int arg3, int arg4){ gl.glVertexAttribI4iEXT(arg0, arg1, arg2, arg3, arg4); }
	public static void glVertexAttribI4ivEXT(int arg0, java.nio.IntBuffer arg1){ gl.glVertexAttribI4ivEXT(arg0, arg1); }
	public static void glVertexAttribI4ivEXT(int arg0, int[] arg1, int arg2){ gl.glVertexAttribI4ivEXT(arg0, arg1, arg2); }
	public static void glVertexAttribI4svEXT(int arg0, java.nio.ShortBuffer arg1){ gl.glVertexAttribI4svEXT(arg0, arg1); }
	public static void glVertexAttribI4svEXT(int arg0, short[] arg1, int arg2){ gl.glVertexAttribI4svEXT(arg0, arg1, arg2); }
	public static void glVertexAttribI4ubvEXT(int arg0, java.nio.ByteBuffer arg1){ gl.glVertexAttribI4ubvEXT(arg0, arg1); }
	public static void glVertexAttribI4ubvEXT(int arg0, byte[] arg1, int arg2){ gl.glVertexAttribI4ubvEXT(arg0, arg1, arg2); }
	public static void glVertexAttribI4uiEXT(int arg0, int arg1, int arg2, int arg3, int arg4){ gl.glVertexAttribI4uiEXT(arg0, arg1, arg2, arg3, arg4); }
	public static void glVertexAttribI4uivEXT(int arg0, java.nio.IntBuffer arg1){ gl.glVertexAttribI4uivEXT(arg0, arg1); }
	public static void glVertexAttribI4uivEXT(int arg0, int[] arg1, int arg2){ gl.glVertexAttribI4uivEXT(arg0, arg1, arg2); }
	public static void glVertexAttribI4usvEXT(int arg0, java.nio.ShortBuffer arg1){ gl.glVertexAttribI4usvEXT(arg0, arg1); }
	public static void glVertexAttribI4usvEXT(int arg0, short[] arg1, int arg2){ gl.glVertexAttribI4usvEXT(arg0, arg1, arg2); }
	public static void glVertexAttribIPointerEXT(int arg0, int arg1, int arg2, int arg3, java.nio.Buffer arg4){ gl.glVertexAttribIPointerEXT(arg0, arg1, arg2, arg3, arg4); }
	public static void glVertexAttribPointer(int arg0, int arg1, int arg2, boolean arg3, int arg4, java.nio.Buffer arg5){ gl.glVertexAttribPointer(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glVertexAttribPointer(int arg0, int arg1, int arg2, boolean arg3, int arg4, long arg5){ gl.glVertexAttribPointer(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glVertexAttribPointerARB(int arg0, int arg1, int arg2, boolean arg3, int arg4, java.nio.Buffer arg5){ gl.glVertexAttribPointerARB(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glVertexAttribPointerARB(int arg0, int arg1, int arg2, boolean arg3, int arg4, long arg5){ gl.glVertexAttribPointerARB(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static void glVertexAttribPointerNV(int arg0, int arg1, int arg2, int arg3, java.nio.Buffer arg4){ gl.glVertexAttribPointerNV(arg0, arg1, arg2, arg3, arg4); }
	public static void glVertexAttribPointerNV(int arg0, int arg1, int arg2, int arg3, long arg4){ gl.glVertexAttribPointerNV(arg0, arg1, arg2, arg3, arg4); }
	public static void glVertexAttribs1dvNV(int arg0, int arg1, java.nio.DoubleBuffer arg2){ gl.glVertexAttribs1dvNV(arg0, arg1, arg2); }
	public static void glVertexAttribs1dvNV(int arg0, int arg1, double[] arg2, int arg3){ gl.glVertexAttribs1dvNV(arg0, arg1, arg2, arg3); }
	public static void glVertexAttribs1fvNV(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glVertexAttribs1fvNV(arg0, arg1, arg2); }
	public static void glVertexAttribs1fvNV(int arg0, int arg1, float[] arg2, int arg3){ gl.glVertexAttribs1fvNV(arg0, arg1, arg2, arg3); }
	public static void glVertexAttribs1hvNV(int arg0, int arg1, java.nio.ShortBuffer arg2){ gl.glVertexAttribs1hvNV(arg0, arg1, arg2); }
	public static void glVertexAttribs1hvNV(int arg0, int arg1, short[] arg2, int arg3){ gl.glVertexAttribs1hvNV(arg0, arg1, arg2, arg3); }
	public static void glVertexAttribs1svNV(int arg0, int arg1, java.nio.ShortBuffer arg2){ gl.glVertexAttribs1svNV(arg0, arg1, arg2); }
	public static void glVertexAttribs1svNV(int arg0, int arg1, short[] arg2, int arg3){ gl.glVertexAttribs1svNV(arg0, arg1, arg2, arg3); }
	public static void glVertexAttribs2dvNV(int arg0, int arg1, java.nio.DoubleBuffer arg2){ gl.glVertexAttribs2dvNV(arg0, arg1, arg2); }
	public static void glVertexAttribs2dvNV(int arg0, int arg1, double[] arg2, int arg3){ gl.glVertexAttribs2dvNV(arg0, arg1, arg2, arg3); }
	public static void glVertexAttribs2fvNV(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glVertexAttribs2fvNV(arg0, arg1, arg2); }
	public static void glVertexAttribs2fvNV(int arg0, int arg1, float[] arg2, int arg3){ gl.glVertexAttribs2fvNV(arg0, arg1, arg2, arg3); }
	public static void glVertexAttribs2hvNV(int arg0, int arg1, java.nio.ShortBuffer arg2){ gl.glVertexAttribs2hvNV(arg0, arg1, arg2); }
	public static void glVertexAttribs2hvNV(int arg0, int arg1, short[] arg2, int arg3){ gl.glVertexAttribs2hvNV(arg0, arg1, arg2, arg3); }
	public static void glVertexAttribs2svNV(int arg0, int arg1, java.nio.ShortBuffer arg2){ gl.glVertexAttribs2svNV(arg0, arg1, arg2); }
	public static void glVertexAttribs2svNV(int arg0, int arg1, short[] arg2, int arg3){ gl.glVertexAttribs2svNV(arg0, arg1, arg2, arg3); }
	public static void glVertexAttribs3dvNV(int arg0, int arg1, java.nio.DoubleBuffer arg2){ gl.glVertexAttribs3dvNV(arg0, arg1, arg2); }
	public static void glVertexAttribs3dvNV(int arg0, int arg1, double[] arg2, int arg3){ gl.glVertexAttribs3dvNV(arg0, arg1, arg2, arg3); }
	public static void glVertexAttribs3fvNV(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glVertexAttribs3fvNV(arg0, arg1, arg2); }
	public static void glVertexAttribs3fvNV(int arg0, int arg1, float[] arg2, int arg3){ gl.glVertexAttribs3fvNV(arg0, arg1, arg2, arg3); }
	public static void glVertexAttribs3hvNV(int arg0, int arg1, java.nio.ShortBuffer arg2){ gl.glVertexAttribs3hvNV(arg0, arg1, arg2); }
	public static void glVertexAttribs3hvNV(int arg0, int arg1, short[] arg2, int arg3){ gl.glVertexAttribs3hvNV(arg0, arg1, arg2, arg3); }
	public static void glVertexAttribs3svNV(int arg0, int arg1, java.nio.ShortBuffer arg2){ gl.glVertexAttribs3svNV(arg0, arg1, arg2); }
	public static void glVertexAttribs3svNV(int arg0, int arg1, short[] arg2, int arg3){ gl.glVertexAttribs3svNV(arg0, arg1, arg2, arg3); }
	public static void glVertexAttribs4dvNV(int arg0, int arg1, java.nio.DoubleBuffer arg2){ gl.glVertexAttribs4dvNV(arg0, arg1, arg2); }
	public static void glVertexAttribs4dvNV(int arg0, int arg1, double[] arg2, int arg3){ gl.glVertexAttribs4dvNV(arg0, arg1, arg2, arg3); }
	public static void glVertexAttribs4fvNV(int arg0, int arg1, java.nio.FloatBuffer arg2){ gl.glVertexAttribs4fvNV(arg0, arg1, arg2); }
	public static void glVertexAttribs4fvNV(int arg0, int arg1, float[] arg2, int arg3){ gl.glVertexAttribs4fvNV(arg0, arg1, arg2, arg3); }
	public static void glVertexAttribs4hvNV(int arg0, int arg1, java.nio.ShortBuffer arg2){ gl.glVertexAttribs4hvNV(arg0, arg1, arg2); }
	public static void glVertexAttribs4hvNV(int arg0, int arg1, short[] arg2, int arg3){ gl.glVertexAttribs4hvNV(arg0, arg1, arg2, arg3); }
	public static void glVertexAttribs4svNV(int arg0, int arg1, java.nio.ShortBuffer arg2){ gl.glVertexAttribs4svNV(arg0, arg1, arg2); }
	public static void glVertexAttribs4svNV(int arg0, int arg1, short[] arg2, int arg3){ gl.glVertexAttribs4svNV(arg0, arg1, arg2, arg3); }
	public static void glVertexAttribs4ubvNV(int arg0, int arg1, java.nio.ByteBuffer arg2){ gl.glVertexAttribs4ubvNV(arg0, arg1, arg2); }
	public static void glVertexAttribs4ubvNV(int arg0, int arg1, byte[] arg2, int arg3){ gl.glVertexAttribs4ubvNV(arg0, arg1, arg2, arg3); }
	public static void glVertexBlendARB(int arg0){ gl.glVertexBlendARB(arg0); }
	public static void glVertexBlendEnvfATI(int arg0, float arg1){ gl.glVertexBlendEnvfATI(arg0, arg1); }
	public static void glVertexBlendEnviATI(int arg0, int arg1){ gl.glVertexBlendEnviATI(arg0, arg1); }
	public static void glVertexPointer(int arg0, int arg1, int arg2, java.nio.Buffer arg3){ gl.glVertexPointer(arg0, arg1, arg2, arg3); }
	public static void glVertexPointer(int arg0, int arg1, int arg2, long arg3){ gl.glVertexPointer(arg0, arg1, arg2, arg3); }
	public static void glVertexStream1dATI(int arg0, double arg1){ gl.glVertexStream1dATI(arg0, arg1); }
	public static void glVertexStream1dvATI(int arg0, java.nio.DoubleBuffer arg1){ gl.glVertexStream1dvATI(arg0, arg1); }
	public static void glVertexStream1dvATI(int arg0, double[] arg1, int arg2){ gl.glVertexStream1dvATI(arg0, arg1, arg2); }
	public static void glVertexStream1fATI(int arg0, float arg1){ gl.glVertexStream1fATI(arg0, arg1); }
	public static void glVertexStream1fvATI(int arg0, java.nio.FloatBuffer arg1){ gl.glVertexStream1fvATI(arg0, arg1); }
	public static void glVertexStream1fvATI(int arg0, float[] arg1, int arg2){ gl.glVertexStream1fvATI(arg0, arg1, arg2); }
	public static void glVertexStream1iATI(int arg0, int arg1){ gl.glVertexStream1iATI(arg0, arg1); }
	public static void glVertexStream1ivATI(int arg0, java.nio.IntBuffer arg1){ gl.glVertexStream1ivATI(arg0, arg1); }
	public static void glVertexStream1ivATI(int arg0, int[] arg1, int arg2){ gl.glVertexStream1ivATI(arg0, arg1, arg2); }
	public static void glVertexStream1sATI(int arg0, short arg1){ gl.glVertexStream1sATI(arg0, arg1); }
	public static void glVertexStream1svATI(int arg0, java.nio.ShortBuffer arg1){ gl.glVertexStream1svATI(arg0, arg1); }
	public static void glVertexStream1svATI(int arg0, short[] arg1, int arg2){ gl.glVertexStream1svATI(arg0, arg1, arg2); }
	public static void glVertexStream2dATI(int arg0, double arg1, double arg2){ gl.glVertexStream2dATI(arg0, arg1, arg2); }
	public static void glVertexStream2dvATI(int arg0, java.nio.DoubleBuffer arg1){ gl.glVertexStream2dvATI(arg0, arg1); }
	public static void glVertexStream2dvATI(int arg0, double[] arg1, int arg2){ gl.glVertexStream2dvATI(arg0, arg1, arg2); }
	public static void glVertexStream2fATI(int arg0, float arg1, float arg2){ gl.glVertexStream2fATI(arg0, arg1, arg2); }
	public static void glVertexStream2fvATI(int arg0, java.nio.FloatBuffer arg1){ gl.glVertexStream2fvATI(arg0, arg1); }
	public static void glVertexStream2fvATI(int arg0, float[] arg1, int arg2){ gl.glVertexStream2fvATI(arg0, arg1, arg2); }
	public static void glVertexStream2iATI(int arg0, int arg1, int arg2){ gl.glVertexStream2iATI(arg0, arg1, arg2); }
	public static void glVertexStream2ivATI(int arg0, java.nio.IntBuffer arg1){ gl.glVertexStream2ivATI(arg0, arg1); }
	public static void glVertexStream2ivATI(int arg0, int[] arg1, int arg2){ gl.glVertexStream2ivATI(arg0, arg1, arg2); }
	public static void glVertexStream2sATI(int arg0, short arg1, short arg2){ gl.glVertexStream2sATI(arg0, arg1, arg2); }
	public static void glVertexStream2svATI(int arg0, java.nio.ShortBuffer arg1){ gl.glVertexStream2svATI(arg0, arg1); }
	public static void glVertexStream2svATI(int arg0, short[] arg1, int arg2){ gl.glVertexStream2svATI(arg0, arg1, arg2); }
	public static void glVertexStream3dATI(int arg0, double arg1, double arg2, double arg3){ gl.glVertexStream3dATI(arg0, arg1, arg2, arg3); }
	public static void glVertexStream3dvATI(int arg0, java.nio.DoubleBuffer arg1){ gl.glVertexStream3dvATI(arg0, arg1); }
	public static void glVertexStream3dvATI(int arg0, double[] arg1, int arg2){ gl.glVertexStream3dvATI(arg0, arg1, arg2); }
	public static void glVertexStream3fATI(int arg0, float arg1, float arg2, float arg3){ gl.glVertexStream3fATI(arg0, arg1, arg2, arg3); }
	public static void glVertexStream3fvATI(int arg0, java.nio.FloatBuffer arg1){ gl.glVertexStream3fvATI(arg0, arg1); }
	public static void glVertexStream3fvATI(int arg0, float[] arg1, int arg2){ gl.glVertexStream3fvATI(arg0, arg1, arg2); }
	public static void glVertexStream3iATI(int arg0, int arg1, int arg2, int arg3){ gl.glVertexStream3iATI(arg0, arg1, arg2, arg3); }
	public static void glVertexStream3ivATI(int arg0, java.nio.IntBuffer arg1){ gl.glVertexStream3ivATI(arg0, arg1); }
	public static void glVertexStream3ivATI(int arg0, int[] arg1, int arg2){ gl.glVertexStream3ivATI(arg0, arg1, arg2); }
	public static void glVertexStream3sATI(int arg0, short arg1, short arg2, short arg3){ gl.glVertexStream3sATI(arg0, arg1, arg2, arg3); }
	public static void glVertexStream3svATI(int arg0, java.nio.ShortBuffer arg1){ gl.glVertexStream3svATI(arg0, arg1); }
	public static void glVertexStream3svATI(int arg0, short[] arg1, int arg2){ gl.glVertexStream3svATI(arg0, arg1, arg2); }
	public static void glVertexStream4dATI(int arg0, double arg1, double arg2, double arg3, double arg4){ gl.glVertexStream4dATI(arg0, arg1, arg2, arg3, arg4); }
	public static void glVertexStream4dvATI(int arg0, java.nio.DoubleBuffer arg1){ gl.glVertexStream4dvATI(arg0, arg1); }
	public static void glVertexStream4dvATI(int arg0, double[] arg1, int arg2){ gl.glVertexStream4dvATI(arg0, arg1, arg2); }
	public static void glVertexStream4fATI(int arg0, float arg1, float arg2, float arg3, float arg4){ gl.glVertexStream4fATI(arg0, arg1, arg2, arg3, arg4); }
	public static void glVertexStream4fvATI(int arg0, java.nio.FloatBuffer arg1){ gl.glVertexStream4fvATI(arg0, arg1); }
	public static void glVertexStream4fvATI(int arg0, float[] arg1, int arg2){ gl.glVertexStream4fvATI(arg0, arg1, arg2); }
	public static void glVertexStream4iATI(int arg0, int arg1, int arg2, int arg3, int arg4){ gl.glVertexStream4iATI(arg0, arg1, arg2, arg3, arg4); }
	public static void glVertexStream4ivATI(int arg0, java.nio.IntBuffer arg1){ gl.glVertexStream4ivATI(arg0, arg1); }
	public static void glVertexStream4ivATI(int arg0, int[] arg1, int arg2){ gl.glVertexStream4ivATI(arg0, arg1, arg2); }
	public static void glVertexStream4sATI(int arg0, short arg1, short arg2, short arg3, short arg4){ gl.glVertexStream4sATI(arg0, arg1, arg2, arg3, arg4); }
	public static void glVertexStream4svATI(int arg0, java.nio.ShortBuffer arg1){ gl.glVertexStream4svATI(arg0, arg1); }
	public static void glVertexStream4svATI(int arg0, short[] arg1, int arg2){ gl.glVertexStream4svATI(arg0, arg1, arg2); }
	public static void glVertexWeightPointerEXT(int arg0, int arg1, int arg2, java.nio.Buffer arg3){ gl.glVertexWeightPointerEXT(arg0, arg1, arg2, arg3); }
	public static void glVertexWeightPointerEXT(int arg0, int arg1, int arg2, long arg3){ gl.glVertexWeightPointerEXT(arg0, arg1, arg2, arg3); }
	public static void glVertexWeightfEXT(float arg0){ gl.glVertexWeightfEXT(arg0); }
	public static void glVertexWeightfvEXT(java.nio.FloatBuffer arg0){ gl.glVertexWeightfvEXT(arg0); }
	public static void glVertexWeightfvEXT(float[] arg0, int arg1){ gl.glVertexWeightfvEXT(arg0, arg1); }
	public static void glVertexWeighthNV(short arg0){ gl.glVertexWeighthNV(arg0); }
	public static void glVertexWeighthvNV(java.nio.ShortBuffer arg0){ gl.glVertexWeighthvNV(arg0); }
	public static void glVertexWeighthvNV(short[] arg0, int arg1){ gl.glVertexWeighthvNV(arg0, arg1); }
	public static void glViewport(int arg0, int arg1, int arg2, int arg3){ gl.glViewport(arg0, arg1, arg2, arg3); }
	public static void glWeightPointerARB(int arg0, int arg1, int arg2, java.nio.Buffer arg3){ gl.glWeightPointerARB(arg0, arg1, arg2, arg3); }
	public static void glWeightPointerARB(int arg0, int arg1, int arg2, long arg3){ gl.glWeightPointerARB(arg0, arg1, arg2, arg3); }
	public static void glWeightbvARB(int arg0, java.nio.ByteBuffer arg1){ gl.glWeightbvARB(arg0, arg1); }
	public static void glWeightbvARB(int arg0, byte[] arg1, int arg2){ gl.glWeightbvARB(arg0, arg1, arg2); }
	public static void glWeightdvARB(int arg0, java.nio.DoubleBuffer arg1){ gl.glWeightdvARB(arg0, arg1); }
	public static void glWeightdvARB(int arg0, double[] arg1, int arg2){ gl.glWeightdvARB(arg0, arg1, arg2); }
	public static void glWeightfvARB(int arg0, java.nio.FloatBuffer arg1){ gl.glWeightfvARB(arg0, arg1); }
	public static void glWeightfvARB(int arg0, float[] arg1, int arg2){ gl.glWeightfvARB(arg0, arg1, arg2); }
	public static void glWeightivARB(int arg0, java.nio.IntBuffer arg1){ gl.glWeightivARB(arg0, arg1); }
	public static void glWeightivARB(int arg0, int[] arg1, int arg2){ gl.glWeightivARB(arg0, arg1, arg2); }
	public static void glWeightsvARB(int arg0, java.nio.ShortBuffer arg1){ gl.glWeightsvARB(arg0, arg1); }
	public static void glWeightsvARB(int arg0, short[] arg1, int arg2){ gl.glWeightsvARB(arg0, arg1, arg2); }
	public static void glWeightubvARB(int arg0, java.nio.ByteBuffer arg1){ gl.glWeightubvARB(arg0, arg1); }
	public static void glWeightubvARB(int arg0, byte[] arg1, int arg2){ gl.glWeightubvARB(arg0, arg1, arg2); }
	public static void glWeightuivARB(int arg0, java.nio.IntBuffer arg1){ gl.glWeightuivARB(arg0, arg1); }
	public static void glWeightuivARB(int arg0, int[] arg1, int arg2){ gl.glWeightuivARB(arg0, arg1, arg2); }
	public static void glWeightusvARB(int arg0, java.nio.ShortBuffer arg1){ gl.glWeightusvARB(arg0, arg1); }
	public static void glWeightusvARB(int arg0, short[] arg1, int arg2){ gl.glWeightusvARB(arg0, arg1, arg2); }
	public static void glWindowPos2d(double arg0, double arg1){ gl.glWindowPos2d(arg0, arg1); }
	public static void glWindowPos2dARB(double arg0, double arg1){ gl.glWindowPos2dARB(arg0, arg1); }
	public static void glWindowPos2dMESA(double arg0, double arg1){ gl.glWindowPos2dMESA(arg0, arg1); }
	public static void glWindowPos2dv(java.nio.DoubleBuffer arg0){ gl.glWindowPos2dv(arg0); }
	public static void glWindowPos2dv(double[] arg0, int arg1){ gl.glWindowPos2dv(arg0, arg1); }
	public static void glWindowPos2dvARB(java.nio.DoubleBuffer arg0){ gl.glWindowPos2dvARB(arg0); }
	public static void glWindowPos2dvARB(double[] arg0, int arg1){ gl.glWindowPos2dvARB(arg0, arg1); }
	public static void glWindowPos2dvMESA(java.nio.DoubleBuffer arg0){ gl.glWindowPos2dvMESA(arg0); }
	public static void glWindowPos2dvMESA(double[] arg0, int arg1){ gl.glWindowPos2dvMESA(arg0, arg1); }
	public static void glWindowPos2f(float arg0, float arg1){ gl.glWindowPos2f(arg0, arg1); }
	public static void glWindowPos2fARB(float arg0, float arg1){ gl.glWindowPos2fARB(arg0, arg1); }
	public static void glWindowPos2fMESA(float arg0, float arg1){ gl.glWindowPos2fMESA(arg0, arg1); }
	public static void glWindowPos2fv(java.nio.FloatBuffer arg0){ gl.glWindowPos2fv(arg0); }
	public static void glWindowPos2fv(float[] arg0, int arg1){ gl.glWindowPos2fv(arg0, arg1); }
	public static void glWindowPos2fvARB(java.nio.FloatBuffer arg0){ gl.glWindowPos2fvARB(arg0); }
	public static void glWindowPos2fvARB(float[] arg0, int arg1){ gl.glWindowPos2fvARB(arg0, arg1); }
	public static void glWindowPos2fvMESA(java.nio.FloatBuffer arg0){ gl.glWindowPos2fvMESA(arg0); }
	public static void glWindowPos2fvMESA(float[] arg0, int arg1){ gl.glWindowPos2fvMESA(arg0, arg1); }
	public static void glWindowPos2i(int arg0, int arg1){ gl.glWindowPos2i(arg0, arg1); }
	public static void glWindowPos2iARB(int arg0, int arg1){ gl.glWindowPos2iARB(arg0, arg1); }
	public static void glWindowPos2iMESA(int arg0, int arg1){ gl.glWindowPos2iMESA(arg0, arg1); }
	public static void glWindowPos2iv(java.nio.IntBuffer arg0){ gl.glWindowPos2iv(arg0); }
	public static void glWindowPos2iv(int[] arg0, int arg1){ gl.glWindowPos2iv(arg0, arg1); }
	public static void glWindowPos2ivARB(java.nio.IntBuffer arg0){ gl.glWindowPos2ivARB(arg0); }
	public static void glWindowPos2ivARB(int[] arg0, int arg1){ gl.glWindowPos2ivARB(arg0, arg1); }
	public static void glWindowPos2ivMESA(java.nio.IntBuffer arg0){ gl.glWindowPos2ivMESA(arg0); }
	public static void glWindowPos2ivMESA(int[] arg0, int arg1){ gl.glWindowPos2ivMESA(arg0, arg1); }
	public static void glWindowPos2s(short arg0, short arg1){ gl.glWindowPos2s(arg0, arg1); }
	public static void glWindowPos2sARB(short arg0, short arg1){ gl.glWindowPos2sARB(arg0, arg1); }
	public static void glWindowPos2sMESA(short arg0, short arg1){ gl.glWindowPos2sMESA(arg0, arg1); }
	public static void glWindowPos2sv(java.nio.ShortBuffer arg0){ gl.glWindowPos2sv(arg0); }
	public static void glWindowPos2sv(short[] arg0, int arg1){ gl.glWindowPos2sv(arg0, arg1); }
	public static void glWindowPos2svARB(java.nio.ShortBuffer arg0){ gl.glWindowPos2svARB(arg0); }
	public static void glWindowPos2svARB(short[] arg0, int arg1){ gl.glWindowPos2svARB(arg0, arg1); }
	public static void glWindowPos2svMESA(java.nio.ShortBuffer arg0){ gl.glWindowPos2svMESA(arg0); }
	public static void glWindowPos2svMESA(short[] arg0, int arg1){ gl.glWindowPos2svMESA(arg0, arg1); }
	public static void glWindowPos3d(double arg0, double arg1, double arg2){ gl.glWindowPos3d(arg0, arg1, arg2); }
	public static void glWindowPos3dARB(double arg0, double arg1, double arg2){ gl.glWindowPos3dARB(arg0, arg1, arg2); }
	public static void glWindowPos3dMESA(double arg0, double arg1, double arg2){ gl.glWindowPos3dMESA(arg0, arg1, arg2); }
	public static void glWindowPos3dv(java.nio.DoubleBuffer arg0){ gl.glWindowPos3dv(arg0); }
	public static void glWindowPos3dv(double[] arg0, int arg1){ gl.glWindowPos3dv(arg0, arg1); }
	public static void glWindowPos3dvARB(java.nio.DoubleBuffer arg0){ gl.glWindowPos3dvARB(arg0); }
	public static void glWindowPos3dvARB(double[] arg0, int arg1){ gl.glWindowPos3dvARB(arg0, arg1); }
	public static void glWindowPos3dvMESA(java.nio.DoubleBuffer arg0){ gl.glWindowPos3dvMESA(arg0); }
	public static void glWindowPos3dvMESA(double[] arg0, int arg1){ gl.glWindowPos3dvMESA(arg0, arg1); }
	public static void glWindowPos3f(float arg0, float arg1, float arg2){ gl.glWindowPos3f(arg0, arg1, arg2); }
	public static void glWindowPos3fARB(float arg0, float arg1, float arg2){ gl.glWindowPos3fARB(arg0, arg1, arg2); }
	public static void glWindowPos3fMESA(float arg0, float arg1, float arg2){ gl.glWindowPos3fMESA(arg0, arg1, arg2); }
	public static void glWindowPos3fv(java.nio.FloatBuffer arg0){ gl.glWindowPos3fv(arg0); }
	public static void glWindowPos3fv(float[] arg0, int arg1){ gl.glWindowPos3fv(arg0, arg1); }
	public static void glWindowPos3fvARB(java.nio.FloatBuffer arg0){ gl.glWindowPos3fvARB(arg0); }
	public static void glWindowPos3fvARB(float[] arg0, int arg1){ gl.glWindowPos3fvARB(arg0, arg1); }
	public static void glWindowPos3fvMESA(java.nio.FloatBuffer arg0){ gl.glWindowPos3fvMESA(arg0); }
	public static void glWindowPos3fvMESA(float[] arg0, int arg1){ gl.glWindowPos3fvMESA(arg0, arg1); }
	public static void glWindowPos3i(int arg0, int arg1, int arg2){ gl.glWindowPos3i(arg0, arg1, arg2); }
	public static void glWindowPos3iARB(int arg0, int arg1, int arg2){ gl.glWindowPos3iARB(arg0, arg1, arg2); }
	public static void glWindowPos3iMESA(int arg0, int arg1, int arg2){ gl.glWindowPos3iMESA(arg0, arg1, arg2); }
	public static void glWindowPos3iv(java.nio.IntBuffer arg0){ gl.glWindowPos3iv(arg0); }
	public static void glWindowPos3iv(int[] arg0, int arg1){ gl.glWindowPos3iv(arg0, arg1); }
	public static void glWindowPos3ivARB(java.nio.IntBuffer arg0){ gl.glWindowPos3ivARB(arg0); }
	public static void glWindowPos3ivARB(int[] arg0, int arg1){ gl.glWindowPos3ivARB(arg0, arg1); }
	public static void glWindowPos3ivMESA(java.nio.IntBuffer arg0){ gl.glWindowPos3ivMESA(arg0); }
	public static void glWindowPos3ivMESA(int[] arg0, int arg1){ gl.glWindowPos3ivMESA(arg0, arg1); }
	public static void glWindowPos3s(short arg0, short arg1, short arg2){ gl.glWindowPos3s(arg0, arg1, arg2); }
	public static void glWindowPos3sARB(short arg0, short arg1, short arg2){ gl.glWindowPos3sARB(arg0, arg1, arg2); }
	public static void glWindowPos3sMESA(short arg0, short arg1, short arg2){ gl.glWindowPos3sMESA(arg0, arg1, arg2); }
	public static void glWindowPos3sv(java.nio.ShortBuffer arg0){ gl.glWindowPos3sv(arg0); }
	public static void glWindowPos3sv(short[] arg0, int arg1){ gl.glWindowPos3sv(arg0, arg1); }
	public static void glWindowPos3svARB(java.nio.ShortBuffer arg0){ gl.glWindowPos3svARB(arg0); }
	public static void glWindowPos3svARB(short[] arg0, int arg1){ gl.glWindowPos3svARB(arg0, arg1); }
	public static void glWindowPos3svMESA(java.nio.ShortBuffer arg0){ gl.glWindowPos3svMESA(arg0); }
	public static void glWindowPos3svMESA(short[] arg0, int arg1){ gl.glWindowPos3svMESA(arg0, arg1); }
	public static void glWindowPos4dMESA(double arg0, double arg1, double arg2, double arg3){ gl.glWindowPos4dMESA(arg0, arg1, arg2, arg3); }
	public static void glWindowPos4dvMESA(java.nio.DoubleBuffer arg0){ gl.glWindowPos4dvMESA(arg0); }
	public static void glWindowPos4dvMESA(double[] arg0, int arg1){ gl.glWindowPos4dvMESA(arg0, arg1); }
	public static void glWindowPos4fMESA(float arg0, float arg1, float arg2, float arg3){ gl.glWindowPos4fMESA(arg0, arg1, arg2, arg3); }
	public static void glWindowPos4fvMESA(java.nio.FloatBuffer arg0){ gl.glWindowPos4fvMESA(arg0); }
	public static void glWindowPos4fvMESA(float[] arg0, int arg1){ gl.glWindowPos4fvMESA(arg0, arg1); }
	public static void glWindowPos4iMESA(int arg0, int arg1, int arg2, int arg3){ gl.glWindowPos4iMESA(arg0, arg1, arg2, arg3); }
	public static void glWindowPos4ivMESA(java.nio.IntBuffer arg0){ gl.glWindowPos4ivMESA(arg0); }
	public static void glWindowPos4ivMESA(int[] arg0, int arg1){ gl.glWindowPos4ivMESA(arg0, arg1); }
	public static void glWindowPos4sMESA(short arg0, short arg1, short arg2, short arg3){ gl.glWindowPos4sMESA(arg0, arg1, arg2, arg3); }
	public static void glWindowPos4svMESA(java.nio.ShortBuffer arg0){ gl.glWindowPos4svMESA(arg0); }
	public static void glWindowPos4svMESA(short[] arg0, int arg1){ gl.glWindowPos4svMESA(arg0, arg1); }
	public static void glWriteMaskEXT(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5){ gl.glWriteMaskEXT(arg0, arg1, arg2, arg3, arg4, arg5); }
	public static boolean isFunctionAvailable(java.lang.String arg0){return gl.isFunctionAvailable(arg0); }
	public static boolean isExtensionAvailable(java.lang.String arg0){return gl.isExtensionAvailable(arg0); }
	public static java.nio.ByteBuffer glAllocateMemoryNV(int arg0, float arg1, float arg2, float arg3){return gl.glAllocateMemoryNV(arg0, arg1, arg2, arg3); }
	public static void setSwapInterval(int arg0){ gl.setSwapInterval(arg0); }
	public static java.lang.Object getPlatformGLExtensions(){return gl.getPlatformGLExtensions(); }
	public static java.lang.Object getExtension(java.lang.String arg0){return gl.getExtension(arg0); }
}
