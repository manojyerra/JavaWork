package glLib;

import gameLib.Util;
import static glLib.GLWrap.*;

public class GLVertex
{
	private static GLVertex _ref = null;

	static final int CAPACITY = 50000;
	float[] _vertexArr;
	float[] _colorArr;
	float[] _uvArr;

	int _count;
	int _mode;

	float _r;
	float _g;
	float _b;
	float _a;	
	
	GLVertex()
	{
		_count = 0;
		_mode = 0;
		_r = _g = _b = _a = 255;
	}
	
	public static GLVertex GetInstance()
	{
		if(_ref == null)
			_ref = new GLVertex();
		return _ref;
	}

	public void Init()
	{
		_vertexArr = new float[CAPACITY*3];
		_colorArr = new float[CAPACITY*4];
		_uvArr = new  float[CAPACITY*2];
	
		_r = 255;
		_g = 255;
		_b = 255;
		_a = 255;
	}

	public void glBegin(int mode)
	{
		_mode = mode;
		_count = 0;
	}
	
	public void glColor4ub(int r, int g, int b, int a)
	{
		_r = r*1.0f/255.0f;
		_g = g*1.0f/255.0f;
		_b = b*1.0f/255.0f;
		_a = a*1.0f/255.0f;
	}
	
	public void glColor4f(float r, float g, float b, float a)
	{
		_r = r;
		_g = g;
		_b = b;
		_a = a;
	}
	
	public void glVertex3f(float x, float y, float z)
	{
		_colorArr[_count*4 + 0] = _r;
		_colorArr[_count*4 + 1] = _g;
		_colorArr[_count*4 + 2] = _b;
		_colorArr[_count*4 + 3] = _a;
	
		_vertexArr[_count*3 + 0] = x;
		_vertexArr[_count*3 + 1] = y;
		_vertexArr[_count*3 + 2] = z;
	
		_count++;
	}
	
	public void glTexCoord2f(float u, float v)
	{
		_uvArr[_count*2 + 0] = u;
		_uvArr[_count*2 + 1] = v;
	}


	public void glEnd()
	{
		boolean enableTexture =  glIsEnabled(GL_TEXTURE_2D);
	
		glEnableClientState(GL_VERTEX_ARRAY);
		glEnableClientState(GL_COLOR_ARRAY);
		if(enableTexture)
			glEnableClientState(GL_TEXTURE_COORD_ARRAY);
		
		glColorPointer(4, GL_FLOAT, 0, Util.floatBuffer(_colorArr, _count*4));
		glVertexPointer(3, GL_FLOAT, 0, Util.floatBuffer(_vertexArr, _count*3));
		if(enableTexture)
			glTexCoordPointer (2, GL_FLOAT, 0, Util.floatBuffer(_uvArr, _count*2));
		
		glDrawArrays(_mode,0,_count);
		
		if(enableTexture)
			glDisableClientState(GL_TEXTURE_COORD_ARRAY);
		glDisableClientState(GL_COLOR_ARRAY);
		glDisableClientState(GL_VERTEX_ARRAY);
	
		_count = 0;
	}

	public void DeleteInstance()
	{
		_vertexArr = null;
		_colorArr = null;
		_uvArr = null;
		_ref = null;
	}
}