package glLib;

import static glLib.GLWrap.*;
import java.awt.image.BufferedImage;
import java.nio.ByteBuffer;
import javax.imageio.ImageIO;
import java.io.File;

public class GLTexture
{
	   public static int loadTexture(String imagePath)
	   {
		   try{
		   BufferedImage image = ImageIO.read(new File(imagePath));
		   int imgW = image.getWidth();
		   int imgH = image.getHeight();
		   int bytesPP = 4;
		   if(image.getTransparency() == BufferedImage.OPAQUE)
			   bytesPP = 3;
		   
		   int[] pixels = new int[imgW * imgH];
		   image.getRGB(0, 0, imgW, imgH, pixels, 0, imgW);

		   ByteBuffer byteBuf = ByteBuffer.allocateDirect(image.getWidth() * image.getHeight() * bytesPP);
		   	        
	        for(int y = 0; y < image.getHeight(); y++){
	            for(int x = 0; x < image.getWidth(); x++){
	                int pixel = pixels[y * image.getWidth() + x];
	                byteBuf.put((byte) ((pixel >> 16) & 0xFF));     // Red component
	                byteBuf.put((byte) ((pixel >> 8) & 0xFF));      // Green component
	                byteBuf.put((byte) (pixel & 0xFF));               // Blue component
	                byteBuf.put((byte) ((pixel >> 24) & 0xFF));    // Alpha component. Only for RGBA
	            }
	        }
	        pixels = null;
	        image = null;
	        
	        byteBuf.flip();
	        
		   
			final int[] textureID = new int[1]; 
			glGenTextures(1, textureID, 0);	        
	        glBindTexture(GL_TEXTURE_2D, textureID[0]);
	        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
	        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, imgW, imgH, 0, GL_RGBA, GL_UNSIGNED_BYTE, byteBuf);
	        
	        byteBuf.clear();
	        byteBuf = null;

	        Runtime.getRuntime().gc();
	        return textureID[0];
		   }catch(Exception e){e.printStackTrace();}
		   
		   return 0;
	   }
	
	   public static void DrawTexture(int textureID, int xx, int yy, int ww, int hh)
	   {
			glEnable(GL_TEXTURE_2D);
			glBindTexture(GL_TEXTURE_2D, textureID);
			glBegin(GL_TRIANGLES);		   
			
			float u = 0;
			float v = 0;
			float cw = 1;
			float ch = 1;
			
			glTexCoord2f(u,		(v));	 	glVertex3f((int)(xx),		(int)(yy),		0);
			glTexCoord2f(u+cw,	(v));		glVertex3f((int)(xx+ww),	(int)(yy),		0);
			glTexCoord2f(u,		(v+ch));	glVertex3f((int)(xx),		(int)(yy+hh),	0);
			glTexCoord2f(u+cw,	(v));		glVertex3f((int)(xx+ww),	(int)(yy),		0);
			glTexCoord2f(u,		(v+ch));	glVertex3f((int)(xx),		(int)(yy+hh),	0);
			glTexCoord2f(u+cw,	(v+ch));	glVertex3f((int)(xx+ww),	(int)(yy+hh),	0);
			
			glEnd();
			glDisable(GL_TEXTURE_2D);
	   }
}