import java.awt.*;
import java.awt.event.*;

public class BallMove extends Frame implements MouseListener,WindowListener
{
Graphics g;
double dx,dy,signX,signY,x1=100,x2=100,y1,y2;

 public  void windowOpened(java.awt.event.WindowEvent e){}
 public  void windowClosing(java.awt.event.WindowEvent e){System.exit(0);}
 public  void windowClosed(java.awt.event.WindowEvent e){}
 public  void windowIconified(java.awt.event.WindowEvent e){}
 public  void windowDeiconified(java.awt.event.WindowEvent e){}
 public  void windowActivated(java.awt.event.WindowEvent e){}
 public  void windowDeactivated(java.awt.event.WindowEvent e){}

public static void main(String asdf[])
{
new BallMove();
}//end of main

public BallMove()
{
addWindowListener(this);
setSize(800,600);
setVisible(true);
addMouseListener(this);
for(;;)
{
if(Math.abs(x1-x2)>=3||Math.abs(y1-y2)>=3)
{
paint1();
}

}//end of loop

}//end of constructor


public void paint1()
{
Graphics g=getGraphics();
if(Math.abs(x1-x2)>=3||Math.abs(y1-y2)>=3)
{
g.setColor(Color.red);
g.fillOval((int)x1,(int)y1,20,20);
try{Thread.sleep(1);}catch(Exception e){}
g.setColor(Color.white);
g.fillOval((int)x1,(int)y1,20,20);
x1=(x1+dx);  y1=(y1+dy);
g.setColor(Color.red);  
g.fillOval((int)x1,(int)y1,20,20);  
}
else
{
g.setColor(Color.red);
g.fillOval((int)x1,(int)y1,20,20);
}

}//end of paint



public void mouseClicked(MouseEvent e)
{
x2=e.getX();y2=e.getY();
dx=Math.abs(x2-x1);dy=Math.abs(y2-y1);
if(dx==0){dx=0;dy=dy/(y2-y1);}else
if(dy==0)
{dy=0;dx=dx/(x2-x1);}
else
{
signX=(x2-x1)/dx;	signY=(y2-y1)/dy;
if(dx/dy>1)		{dy=(signY)*(dy/dx);dx=signX; }
	else	{dx=signX*(dx/dy);dy=signY; }

}//end of else


}//end of mouseClicked

public void mouseEntered(MouseEvent e){}
public void mouseExited(MouseEvent e){}
public void mouseReleased(MouseEvent e){}
public void mousePressed(MouseEvent e){}


}//end of class