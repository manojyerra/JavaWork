#include<stdio.h>
#include<conio.h>
#include<graphics.h>
main()
{
int gm,gd=DETECT,o=1,z,sp,q,sco=0;
int i,j=1,tx=90,ty=130,hx=220,hy=130;
int l=0,r=0,u=0,dw=0,kk=0,temp,cr=0;
int hitx[5000],hity[5000],d[5000],n=1,linex[5000],liney[5000],nl=0;
int kb=0,c=0,pr=0;
char ch;

int     phrx=1,phlx=1,ptrx=1,ptlx=1,s=0;
int     phuy=1,phdy=1,ptuy=1,ptdy=1;
int ax[10],ay[10],an=0,bac=2,sna=6,w=9;
clrscr();
printf("\n\n       select  your speed ");
printf("\n        low           -----     1");
printf("\n        below avarage -----     2");
printf("\n        above avarage -----     3");
printf("\n        high          -----     4\n");
scanf("%d",&sp);
if(sp==1){q=20000;}
if(sp==2){q=15000;}
if(sp==3){q=10000;}
if(sp==4){q=5000; }

initgraph(&gd,&gm," ");
clrscr();
colourrec(0,0,650,450,sna);
colourrec(60,60,570,370,bac);
for(i=1;i<=14;i++)
{
colourrec(tx+1,ty+1,tx+w,ty+w,sna);
tx=tx+w+1;
}
tx=80;            i=1;         d[1]=77;

linex[0]=50;              liney[0]=130;
ax[0]=150;ax[1]=150;ax[2]=200;ax[3]=100;ax[4]=250;ax[5]=300;ax[6]=0;
ay[0]=300;ay[1]=200;ay[2]=300;ay[3]=300;ay[4]=150;ay[5]=250;ay[6]=0;
colourrec(ax[an]+1,ay[an]+1,ax[an]+w,ay[an]+w,0);
while(1)
{
for(temp=1;temp<=1;temp++)
{



if(kbhit())
{


kk++;
ch=getch();
if(ch==27){break;}
if(ch==112)
{
outtextxy(250,250,"      PAUSE ");
outtextxy(250,280," Enter any Key to continue ");
getch();
colourrec(220,220,490,320,bac);
}
if((s==77&&ch==75)||(s==75&&ch==77)||(s==80&&ch==72)||(s==72&&ch==80))
{;break;}

if(kb==2){kb=0;}
if(kb==1){kb++;}
c++;
nl++;
linex[nl]=hx;liney[nl]=hy;
hitx[n]=hx;  hity[n]=hy;
if(ch==77){r=1;l=0;u=0;dw=0;}else
if(ch==75){l=1;r=0;u=0;dw=0;}else
if(ch==80){dw=1;r=0;u=0;l=0;}else
if(ch==72){u=1;l=0;r=0;dw=0;}
n++;
if(n==5000){n=1;}
if(r==1){d[n]=77;}else
if(l==1){d[n]=75;}else
if(dw==1){d[n]=80;}else
if(u==1){d[n]=72;}
s=d[n];
}    /*     end of kbhit()         */
}    /*     end of temp  loop      */



if(an==6){an=0;colourrec(ax[an]+1,ay[an]+1,ax[an]+w,ay[an]+w,1);}




if(r==1)
{
hx=hx+w+1;
colourrec(hx+1,hy+1,hx+w,hy+w,sna);
if(ax[an]==hx&&ay[an]==hy)
{
hx=hx+w+1;
colourrec(hx+1,hy+1,hx+w,hy+w,sna);
an++;sco++; if(sco%3==0){q=q-300;}
colourrec(ax[an]+1,ay[an]+1,ax[an]+w,ay[an]+w,1);
}
delay(q);
}else






if(l==1)
{
hx=hx-w-1;
colourrec(hx+1,hy+1,hx+w,hy+w,sna);
if(ax[an]==hx&&ay[an]==hy)
{
hx=hx-w-1;
colourrec(hx+1,hy+1,hx+w,hy+w,sna);
an++;sco++; if(sco%3==0){q=q-300;}
colourrec(ax[an]+1,ay[an]+1,ax[an]+w,ay[an]+w,1);
}
delay(q);
}else







if(u==1)
{
hy=hy-w-1;
colourrec(hx+1,hy+1,hx+w,hy+w,sna);
if(ax[an]==hx&&ay[an]==hy)
{
hy=hy-w-1;
colourrec(hx+1,hy+1,hx+w,hy+w,sna);
an++;sco++; if(sco%3==0){q=q-300;}
colourrec(ax[an]+1,ay[an]+1,ax[an]+w,ay[an]+w,1);
}
delay(q);
}else








if(dw==1)
{
hy=hy+w+1;
colourrec(hx+1,hy+1,hx+w,hy+w,sna);
if(ax[an]==hx&&ay[an]==hy)
{
hy=hy+w+1;
colourrec(hx+1,hy+1,hx+w,hy+w,sna);
an++; sco++;if(sco%3==0){q=q-300;}
colourrec(ax[an]+1,ay[an]+1,ax[an]+w,ay[an]+w,1);
}
delay(q);
}






if(hx==570&&phlx==1){hx=60;phrx=0;kb=1;c=0;}
if(tx==570&&ptlx==1){tx=60;ptrx=0;kb=1;c=0;}
phlx=1;ptlx=1;
if(hx==50&&phrx==1){hx=560;phlx=0;kb=1;c=0;}
if(tx==50&&ptrx==1){tx=560;ptlx=0;kb=1;c=0;}
phrx=1;ptrx=1;





if(hy==370&&phdy==1){hy=60;phuy=0;kb=1;c=0;}
if(ty==370&&ptdy==1){ty=60;ptuy=0;kb=1;c=0;}
phdy=1;ptdy=1;
if(hy==50&&phuy==1){hy=360;phdy=0;kb=1;c=0;}
if(ty==50&&ptuy==1){ty=360;ptdy=0;kb=1;c=0;}
phuy=1;ptuy=1;



if(kk>=1)
{
if( tx==hitx[i] && ty==hity[i] )   {  i++; if(i==6000){i=1;} }


if(d[i]==77)  {    colourrec(tx+1,ty+1,tx+w,ty+w,bac);    tx=tx+w+1;}  else
if(d[i]==75)  {    colourrec(tx+1,ty+1,tx+w,ty+w,bac);    tx=tx-w-1;}  else
if(d[i]==80)  {    colourrec(tx+1,ty+1,tx+w,ty+w,bac);    ty=ty+w+1;}  else
if(d[i]==72)  {    colourrec(tx+1,ty+1,tx+w,ty+w,bac);    ty=ty-w-1;}
}

o=i;
if(kb==0&&c>2&&kk>1)
{
for( ;o<=nl;o++)
{

if(liney[o-1]==liney[o])
{
if(o==i)
{
if((d[i]==77&&hx<tx)||(d[i]==75&&hx>tx)||(d[i]==80&&hy<ty)||(d[i]==72&&hy>ty))
{break;}
}
z=liney[o-1];
if(((hx>=linex[o-1]&&hx<=linex[o])||(hx<=linex[o-1] && hx>=linex[o]))&&z==hy)
{outtextxy(250,280," CRASH ");cr++;}}else

if(linex[o-1]==linex[o])
{
if(o==i)
{
if((d[i]==77&&hx<tx)||(d[i]==75&&hx>tx)||(d[i]==80&&hy<ty)||(d[i]==72&&hy>ty))
{break;}
}
z=linex[o-1];
if(((hy>=liney[o-1]&&hy<=liney[o])||(hy<=liney[o-1] && hy>=liney[o]))&&z==hx)
{outtextxy(250,280," CRASH ");cr++;break;}}

if(o==nl){break;}
}
}
if(cr==1)
{
outtextxy(250,100,"GAME OVER");
printf("\n\n\n\n\n\n\n\n\n\n\n\t\t\t    YOUR SCORE IS  %d\t\t\t\t       ",sco*10);
break;
}

if(ch==27){break;}
colourrec(ax[an]+1,ay[an]+1,ax[an]+w,ay[an]+w,1);

}/*end of while*/

do {
outtextxy(220,250," Press ESC to EXIT ");
ch=getch();
}while(ch!=27);
}  /*  end of main  */


colourrec(int x1,int y1,int x2,int y2,int m)
{int i,j;for(i=x1;i<=x2;i++){for(j=y1;j<=y2;j++){putpixel(i,j,m);}}}

