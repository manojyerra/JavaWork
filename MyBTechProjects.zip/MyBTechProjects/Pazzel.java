import java.awt.*;
import java.awt.event.*;
import java.io.*;
import sun.audio.*;
import javax.swing.JButton;
import javax.swing.*;
import java.util.*;

class Pazzel extends Frame implements ActionListener,WindowListener
{
JButton bt[]=new JButton[16];

int arr1[]={0,3,2,8,13,15,9,6,11,1,14,10,7,4,12,5};
int arr2[]={0,7,8,14,13,12,5,9,3,2,6,10,11,15,4,1};
int arr3[]={0,1,4,14,10,6,2,3,9,5,12,13,15,8,7,11};
int arr4[]={0,5,12,4,7,10,14,1,11,6,9,15,13,8,2,3};

public static void main(String args[]) throws IOException
{
new Pazzel();
}

 public  void windowOpened(java.awt.event.WindowEvent e){}
 public  void windowClosing(java.awt.event.WindowEvent e){System.exit(0);}
 public  void windowClosed(java.awt.event.WindowEvent e){}
 public  void windowIconified(java.awt.event.WindowEvent e){}
 public  void windowDeiconified(java.awt.event.WindowEvent e){}
 public  void windowActivated(java.awt.event.WindowEvent e){}
 public  void windowDeactivated(java.awt.event.WindowEvent e){}


Pazzel()
{

Random random = new Random();
random.setSeed(10);

for(int i=0;i<100;i++)
{
	int rand1 = 1 + random.nextInt(15);
	int rand2 = 1 + random.nextInt(15);

	int temp = arr1[rand1];
	arr1[rand1] = arr1[rand2];
	arr1[rand2] = temp;
}


for(int i=0;i<100;i++)
{
	int rand1 = 1 + random.nextInt(15);
	int rand2 = 1 + random.nextInt(15);

	int temp = arr2[rand1];
	arr2[rand1] = arr2[rand2];
	arr2[rand2] = temp;
}


for(int i=0;i<100;i++)
{
	int rand1 = 1 + random.nextInt(15);
	int rand2 = 1 + random.nextInt(15);

	int temp = arr3[rand1];
	arr3[rand1] = arr3[rand2];
	arr3[rand2] = temp;
}


for(int i=0;i<100;i++)
{
	int rand1 = 1 + random.nextInt(15);
	int rand2 = 1 + random.nextInt(15);

	int temp = arr4[rand1];
	arr4[rand1] = arr4[rand2];
	arr4[rand2] = temp;
}


addWindowListener(this);
try{

FileInputStream fis=new FileInputStream("Number2.java");

int k=fis.read();

FileOutputStream fos=new FileOutputStream("Number2.java");

setLayout(null);
int y=0,x=0;

ImageIcon ic=new ImageIcon("anen.jpg");

if((char)k=='A')
{
for(int i=1;i<16;i++)
{
bt[i]=new JButton(""+arr1[i]);
bt[i].setIcon(ic);
}
k++;
fos.write((char)k);
}else


if((char)k=='B')
{
for(int i=1;i<16;i++){bt[i]=new JButton(""+arr2[i]);}
k++;
fos.write((char)k);
}else


if((char)k=='C')
{
for(int i=1;i<16;i++){bt[i]=new JButton(""+arr3[i]);}
k++;
fos.write((char)k);
}else


if((char)k=='D')
{
for(int i=1;i<16;i++){bt[i]=new JButton(""+arr4[i]);}
k=k-3;
fos.write((char)k);
}


for(int i=1;i<16;i++)
{
bt[i].setBounds(100+x*50,100+y*50,50,50);
bt[i].setFont(new Font("TimesRoman",1,12));
if(i%4==0){y++;x=0;}else
{x++;}
bt[i].setForeground(Color.blue);
add(bt[i]);
bt[i].addActionListener(this);
}

setBounds(100,100,500,500);
setVisible(true);

}catch(IOException e){}
}//end of construtor



Component clickbt;
int  x=0,y=0;
public void actionPerformed(ActionEvent e)
{

clickbt=(Component)e.getSource();
x=clickbt.getX();
y=clickbt.getY();

if(this==getComponentAt(x+50,y)&&(x+50)<300)
{
clickbt.setLocation(x+50,y);
}else
if(this==getComponentAt(x-50,y)&&(x-50)>=100)
{
clickbt.setLocation(x-50,y);
}else
if(this==getComponentAt(x,y-50)&&(y-50)>=100)
{
clickbt.setLocation(x,y-50);
}else
if(this==getComponentAt(x,y+50)&&(y+50)<300)
{
clickbt.setLocation(x,y+50);
}else
{
try{
InputStream is=new FileInputStream("beep.wav");
AudioPlayer.player.start(is);
Thread.sleep(10);
}
catch(Exception exc){}
}

}//end of actionPerformed METHOD

}//end of class 