import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class AllPushBoxGames extends Frame implements ActionListener,WindowListener
{
Button b1,b2;

public static void main(String args[]){new AllPushBoxGames();}


AllPushBoxGames()
{
b1=new Button("New Game");
b2=new Button("     Stage     ");
b1.setFont(new Font("TimesRoman",3,25));
b2.setFont(new Font("TimesRoman",3,25));
b1.setBounds(250,200,125,40);
b2.setBounds(430,200,125,40);
b1.setBackground(Color.blue);
b2.setBackground(Color.blue);
b1.setForeground(Color.white);
b2.setForeground(Color.white);
b1.addActionListener(this);
b2.addActionListener(this);
add(b1);
add(b2);

setLayout(null);
setBounds(0,0,800,600);
setBackground(Color.gray);
setVisible(true);

addWindowListener(this);
}//end of constructor
public void windowActivated(WindowEvent e) {}
public void windowClosed(WindowEvent e){}
public void windowClosing(WindowEvent e){System.exit(0);}
public void windowDeactivated(WindowEvent e) {}
public void windowDeiconified(WindowEvent e ){}
public void windowIconified(WindowEvent e ){}
public void windowOpened(WindowEvent e ){}


public void actionPerformed(ActionEvent e)
{
Level lv=new Level();
Button b=(Button)e.getSource();
if(b==b1)
{
lv.level(1);                 
//setVisible(false);
}else
if(b==b2)
{
String inputValue = JOptionPane.showInputDialog("Enter  Level no (between  1  to 4 ) "); 
int levelNo=Integer.parseInt(inputValue);

//setVisible(false);

lv.level(levelNo);


}//end of if
}//end of actionPerformed

public void paint(Graphics g)
{
g.drawImage(Toolkit.getDefaultToolkit().getImage("push3.jpg"),0,0,800,600,this);
}//end of paint

}//end of class








class Level 
{
static int level=1;
static void level(int go_to_level)
{
if(go_to_level==1)
{
				level=1;
int no_of_boxes1=3;
int no_of_targets1=3;
int boxPlace1[][]={{0,0},{4,4},{6,5},{3,6}};
int targetPlace1[][]={{0,0},{5,2},{6,2},{7,2}};
int manX1=4,manY1=2;
int wallXY1[][]={{0,0},{2,1},{3,1},{4,1},{5,1},{6,1},{7,1},{8,1},{2,2},{8,2},{2,3},{6,3},{7,3},{8,3},{9,3},{1,4},{2,4},{3,4},{9,4},{1,5},{5,5},{7,5},{9,5},{1,6},{5,6},{9,6},{1,7},{5,7},{6,7},{7,7},{8,7},{9,7},{1,8},{2,8},{3,8},{4,8}};
Button box1[]=new Button[no_of_boxes1+1];
Button target1[]=new Button[no_of_targets1+1];
ImageIcon icon1=new ImageIcon("man.gif");

/************************/

Button man1=new SuperButton();

new PushBoxGame(wallXY1,box1,target1,boxPlace1,targetPlace1,man1,Thread.currentThread(),no_of_boxes1,no_of_targets1,manX1,manY1);


} 				 //end of level --  1


else

if(go_to_level==2)
{


				 level=2;


int no_of_boxes2=3;
int no_of_targets2=3;
int boxPlace2[][]={{0,0},{3,3},{4,3},{3,4}};
int targetPlace2[][]={{0,0},{8,4},{8,5},{8,6}};
int manX2=4,manY2=2;
int wallXY2[][]={{0,0},{1,1},{2,1},{3,1},{4,1},{5,1},{1,2},{5,2},{1,3},{5,3},{7,3},{8,3},{9,3},{1,4},{5,4},{7,4},{9,4},{1,5},{2,5},{3,5},{5,5},{6,5},{7,5},{9,5},{2,6},{3,6},{9,6},{2,7},{6,7},{9,7},{2,8},{6,8},{7,8},{8,8},{9,8},{2,9},{3,9},{4,9},{5,9},{6,9}};
Button box2[]=new Button[no_of_boxes2+1];
Button target2[]=new Button[no_of_targets2+1];
ImageIcon icon2=new ImageIcon("man.gif");
Button man2=new SuperButton();

new PushBoxGame(wallXY2,box2,target2,boxPlace2,targetPlace2,man2,Thread.currentThread(),no_of_boxes2,no_of_targets2,manX2,manY2);


}

else


if(go_to_level==3)
{


				level=3;


int no_of_boxes3=3;
int no_of_targets3=3;
int boxPlace3[][]={{0,0},{4,3},{3,6},{6,7}};
int targetPlace3[][]={{0,0},{2,5},{2,6},{2,7}};
int manX3=3,manY3=2;
int wallXY3[][]={{0,0},{2,1},{3,1},{4,1},{5,1},{2,2},{5,2},{6,2},{7,2},{2,3},{7,3},{1,4},{2,4},{3,4},{5,4},{7,4},{8,4},{1,5},{3,5},{5,5},{8,5},{1,6},{6,6},{8,6},{1,7},{8,7},{1,8},{2,8},{3,8},{4,8},{5,8},{6,8},{7,8},{8,8}};
Button box3[]=new Button[no_of_boxes3+1];
Button target3[]=new Button[no_of_targets3+1];
ImageIcon icon3=new ImageIcon("man.gif");
Button man3=new SuperButton();

new PushBoxGame(wallXY3,box3,target3,boxPlace3,targetPlace3,man3,Thread.currentThread(),no_of_boxes3,no_of_targets3,manX3,manY3);



}				//end of  level ---   3


else

if(go_to_level==4)
{


				level=4;


int no_of_boxes4=4;
int no_of_targets4=4;
int boxPlace4[][]={{0,0},{3,4},{5,5},{8,5},{7,6}};
int targetPlace4[][]={{0,0},{3,6},{4,6},{3,7},{4,7}};
int manX4=3,manY4=5;
int wallXY4[][]={{0,0},{2,2},{3,2},{4,2},{5,2},{6,2},{7,2},{8,2},{2,3},{8,3},{9,3},{10,3},{1,4},{2,4},{4,4},{5,4},{6,4},{10,4},{1,5},{10,5},{1,6},{5,6},{9,6},{10,6},{1,7},{2,7},{5,7},{9,7},{2,8},{3,8},{4,8},{5,8},{6,8},{7,8},{8,8},{9,8}};
Button box4[]=new Button[no_of_boxes4+1];
Button target4[]=new Button[no_of_targets4+1];
ImageIcon icon4=new ImageIcon("man.gif");
Button man4=new SuperButton();

new PushBoxGame(wallXY4,box4,target4,boxPlace4,targetPlace4,man4,Thread.currentThread(),no_of_boxes4,no_of_targets4,manX4,manY4);


}  				// end of level ---    4
else

if(go_to_level==5)
{


				level=5;


int no_of_boxes5=4;
int no_of_targets5=4;
int boxPlace5[][]={{0,0},{2,4},{3,5},{8,4},{9,5}};
int targetPlace5[][]={{0,0},{4,5},{5,5},{6,5},{7,5}};
int manX5=8,manY5=6;
int wallXY5[][]={{0,0},{1,2},{2,2},{3,2},{4,2},{7,2},{8,2},{9,2},{10,2},{11,2},{0,3},{1,3},{4,3},{7,3},{11,3},{0,4},{4,4},{5,4},{6,4},{7,4},{11,4},{0,5},{11,5},{0,6},{1,6},{6,6},{10,6},{11,6},{1,7},{2,7},{3,7},{4,7},{5,7},{6,7},{7,7},{8,7},{9,7}};
Button box5[]=new Button[no_of_boxes5+1];
Button target5[]=new Button[no_of_targets5+1];
ImageIcon icon5=new ImageIcon("man.gif");
Button man5=new SuperButton();

new PushBoxGame(wallXY5,box5,target5,boxPlace5,targetPlace5,man5,Thread.currentThread(),no_of_boxes5,no_of_targets5,manX5,manY5);


}  				// end of level ---    5


}		//end of   level method 

}		//end of class



class SuperButton extends Button 
{
public void paint(Graphics g)
{
g.drawImage(Toolkit.getDefaultToolkit().getImage("man.gif"),3,3,31,31,this);
}//end of paint
}//end of class SuperButton





class PushBoxGame extends Frame implements KeyListener,WindowListener,ActionListener
{
Button newGame=new Button("New Game");
int no_of_boxes;
int no_of_targets;
int boxPlace[][];
int targetPlace[][];
int wallXY[][];
Button box[];
Button target[];
Button man;
Thread t;
int manX;
int manY;
Graphics gg;
static Toolkit tool=Toolkit.getDefaultToolkit();


PushBoxGame(int wallXY[][],Button box[],Button target[],int boxPlace[][],int targetPlace[][],Button man,Thread t,int no_of_boxes,int no_of_targets,int manX,int manY)
{
repaint();

this.no_of_boxes=no_of_boxes;
this.no_of_targets=no_of_targets;
this.boxPlace=boxPlace;
this.targetPlace=targetPlace;
this.wallXY=wallXY;
this.box=box;
this.target=target;
this.man=man;
man.setBackground(Color.green);
this.t=t;


setLayout(null);
setBackground(Color.cyan);
setTitle("                                                                   Level  --  "+Level .level);
addWindowListener(this);
newGame.setBounds(250,30,100,30);
newGame.setFont(new Font("TimesRoman",3,18));
newGame.setBackground(Color.black);
newGame.setForeground(Color.white);
add(newGame);
newGame.addActionListener(this);
newGame.addKeyListener(this);

for(int i=1;i<=no_of_boxes;i++)
{
box[i]=new Button("");
box[i].setBackground(Color.blue);
add(box[i]);
}

for(int i=1;i<=no_of_targets;i++)
{
target[i]=new Button("T");
target[i].setFont(new Font("TimesRoman",3,20));
target[i].setForeground(Color.black);
target[i].setBackground(Color.pink);
add(target[i]);
}


for(int i=1;i<=no_of_boxes;i++)
{box[i].setBounds(100+(37*boxPlace[i][0]),50+(37*boxPlace[i][1]),37,37);}


for(int i=1;i<=no_of_targets;i++)
{target[i].setBounds(100+(37*targetPlace[i][0]),50+(37*targetPlace[i][1]),30,30);}


man.setBounds(100+(37*manX),50+(37*manY),37,37);
man.addKeyListener(this);
add(man);

addKeyListener(this);
setBounds(100,25,600,500);
setVisible(true);
//setResizable(false);


}//end of constructor

public void actionPerformed(ActionEvent ae)
{
setVisible(false);
Level.level(Level.level);

}//end of actionPerformed

public void windowActivated(WindowEvent e) {}
public void windowClosed(WindowEvent e){}
public void windowClosing(WindowEvent e){setVisible(false);}
public void windowDeactivated(WindowEvent e) {}
public void windowDeiconified(WindowEvent e ){}
public void windowIconified(WindowEvent e ){}
public void windowOpened(WindowEvent e ){}

public void paint(Graphics g)
{
g.drawImage(Toolkit.getDefaultToolkit().getImage("push3.jpg"),0,0,800,600,this);
this.gg=g;

for(int i=1;i<=(wallXY.length-1);i++)
{
drawWall(wallXY[i][0],wallXY[i][1]);
}

}//end of paint

void drawWall(int i,int j)
{
gg.setColor(Color.gray);
gg.fillRect(100+(37*i),50+(37*j),37,37);
gg.setColor(Color.white);
gg.drawRect(100+(37*i),50+(37*j),36,36);
}//end of method 

int code=0;
int loop=1;
public void keyTyped(KeyEvent e){}
public void keyPressed(KeyEvent e)
{

for(loop=1;loop<=1;loop++)
{


if(e.getKeyCode()==37)
{
if(isWall(man.getX()-37,man.getY())==false)
{
if(isBox(man.getX()-37,man.getY())==false){man.setLocation(man.getX()-37,man.getY());}
else
{
if(isWall(man.getX()-(37+37),man.getY())==false&&isBox(man.getX()-(37+37),man.getY())==false)
{
getComponentAt(man.getX()-37,man.getY()).setLocation(man.getX()-(37+37),man.getY());
man.setLocation(man.getX()-37,man.getY());
}}
}else{tool.beep();}
}
else


if(e.getKeyCode()==38)
{
if(isWall(man.getX(),man.getY()-37)==false)
{
if(isBox(man.getX(),man.getY()-37)==false){man.setLocation(man.getX(),man.getY()-37);}
else
{
if(isWall(man.getX(),man.getY()-(37+37))==false&&isBox(man.getX(),man.getY()-(37+37))==false)
{
getComponentAt(man.getX(),man.getY()-37).setLocation(man.getX(),man.getY()-(37+37));
man.setLocation(man.getX(),man.getY()-37);

}}
}else{tool.beep();}
}
else


if(e.getKeyCode()==39)
{
if(isWall(man.getX()+37,man.getY())==false)
{
if(isBox(man.getX()+37,man.getY())==false){man.setLocation(man.getX()+37,man.getY());}
else
{
if(isWall(man.getX()+(37+37),man.getY())==false&&isBox(man.getX()+(37+37),man.getY())==false)
{
getComponentAt(man.getX()+37,man.getY()).setLocation(man.getX()+(37+37),man.getY());
man.setLocation(man.getX()+37,man.getY());

}}
}else{tool.beep();}
}
else



if(e.getKeyCode()==40)
{

if(isWall(man.getX(),man.getY()+37)==false)
{
if(isBox(man.getX(),man.getY()+37)==false){man.setLocation(man.getX(),man.getY()+37);}
else
{
if(isWall(man.getX(),man.getY()+(37+37))==false&&isBox(man.getX(),man.getY()+(37+37))==false)
{
getComponentAt(man.getX(),man.getY()+37).setLocation(man.getX(),man.getY()+(37+37));
man.setLocation(man.getX(),man.getY()+37);

}}
}else{tool.beep();}
}


int targetPlace[][]={{0,0},{8,4},{8,5},{8,6}};

if(isOver())
{
int conformAgain=1;

do
{
int conform=JOptionPane.showConfirmDialog(null, " Do u want play next level", "", JOptionPane.YES_NO_OPTION);
if(conform==0)
{setVisible(false);
Level.level(++Level.level);
//t.resume();
break;
}
else
{
conformAgain=JOptionPane.showConfirmDialog(null, " Do u want quit ", "", JOptionPane.YES_NO_OPTION);
if(conformAgain==0){System.exit(1);}
}

}while(conformAgain!=0);

System.out.println(" Over  ");


}//  end of  if (is Over )



}//end of loop
}//end of keyTyped method


public void keyReleased(KeyEvent e){}





boolean isWall(int x,int y)
{
try{
for(int i=1;i<=(wallXY.length-1);i++)         
{
if(100+(37*wallXY[i][0])==x&&50+(37*wallXY[i][1])==y)
{
return(true);
}//end of if
}//end of loop
}catch(Exception e){System.out.println("error ");}

return(false);
}		//end of method 



boolean isBox(int x,int y)
{
for(int i=1;i<=no_of_boxes;i++)
{
if(box[i].getX()==x&&box[i].getY()==y)
{
return(true);
}//end of if
}//end of loop
return(false);
}		//end of method 


boolean  isOver()
{
int x=0;
x=0;
for(int i=1;i<=no_of_boxes;i++)
{
for(int j=1;j<=no_of_targets;j++)
{
if(box[i].getX()==target[j].getX()){x=1;}
}
if(x==0){return(false);}
x=0;
}

for(int i=1;i<=no_of_boxes;i++)
{
for(int j=1;j<=no_of_targets;j++)
{
if(box[i].getY()==target[j].getY()){x=1;}
}
if(x==0){return(false);}
x=0;
}

return(true);

}//end of isOver


}//end of class

