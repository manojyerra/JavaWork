import java.io.*;
class  Day
{
public static void main(String[] args) throws IOException
{
int date=0,m=0,year=0,d=0,f=0,g=0,y,i=0,n=1,e=0,loop=0,more=1;
int againd=0,againm=0,againy=0,ly=0;
String con="";
BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
for(more=1;more<=n;more++)
{
int catY=0;
do{
againy=0;
System.out.print("\n\n\n ENTER   YEAR  ");
try{
year=Integer.parseInt(br.readLine().trim());
}catch(NumberFormatException nf)
{
System.out.println(" \nENTERED WRONG DATA \nENTER AGAIN \n");
catY=1;
againy=1;
}
if(year<=0&&catY==0)
{
System.out.println(" \nENTERED WRONG DATA");
System.out.println(" YEAR MUST  BE  GREATER THAN OR EQUALS TO    1 ");
System.out.println(" ENTER AGAIN \n");
againy=1;
}
}while(againy==1);




int catM=0;
do{
againm=0;
System.out.print(" \nENTER   MONTH   ");
try{
m=Integer.parseInt(br.readLine().trim());
}catch(NumberFormatException nf)
{
System.out.println(" \nENTERED WRONG DATA \nENTER AGAIN \n");
catM=1;
againm=1;
}
if(m<=0&&catM==0)
{
System.out.println(" \nENTERED WRONG DATA");
System.out.println(" MONTHS MUST  BE  GREATER THAN OR EQUALS TO    1 ");
System.out.println(" ENTER AGAIN \n");
againm=1;
}else
if(m>12&&catM==0)
{
System.out.println(" \nENTERED WRONG DATA");
System.out.println(" MONTH   MUST  BE  LESS THAN OR EQUALS TO   12 ");
System.out.println(" ENTER AGAIN \n");
againm=1;
}
}while(againm==1);




if(year%4==0&&(year%100!=0||year%400==0))
{
ly=1;
}
else{ly=0;}


int catD=0;
do{
againd=0;
System.out.print("\n\n  ENTER   DATE   ");
try{
date=Integer.parseInt(br.readLine().trim());
}catch(NumberFormatException nf)
{
System.out.println(" \nENTERED WRONG DATA \nENTER AGAIN \n");
catD=1;
againd=1;
}

if(date<=0&&catD==0)
{
System.out.println(" \nENTERED WRONG DATA");
System.out.println(" DATE   MUST  BE  GREATER THAN OR EQUALS TO    1 ");
System.out.println(" ENTER AGAIN\n ");
againd=1;
}else

if(date>31&&catD==0)
{
System.out.println(" \nENTERED WRONG DATA");
System.out.println(" DATE   MUST  BE  LESSTHAN OR EQUALS TO   31 ");
System.out.println(" ENTER AGAIN \n");
againd=1;
}else

if((ly==0&&m==2&&date>28)&&(catD==0))
{
System.out.println(" \nENTERED WRONG DATA");
System.out.println(" IN  THE  NONLEAPYEAR , FEBRUARY  MONTH  DATE  MUST  BE  LESS  THAN OR EQUALS TO  28 ");
System.out.println(" ENTER AGAIN \n");
againd=1;
}else

if((ly==1&&m==2&&date>29)&&(catD==0))
{
System.out.println("\nENTERED WRONG DATA");
System.out.println(" IN  NONLEAPYEAR , FEBRUARY  MONTH  DATE  MUST  BE  LESS  THAN OR EQUALS TO  29 ");
System.out.println(" ENTER AGAIN\n ");
againd=1;
}else

if(((m==4||m==6||m==9||m==11)&&(date>30))&&(catD==0))
{
System.out.println(" \nYOUR ENTERED WRONG DATA");
if(m==4)   {System.out.println("IN	THE   APRIL  MONTH  HAVE  ONLY  30 DAYS ");}
if(m==6)   {System.out.println("IN  THE   JUNE  MONTH  HAVE  ONLY  30 DAYS ");}
if(m==9)   {System.out.println("IN  THE   SEPTEMBER  MONTH  HAVE  ONLY  30 DAYS ");}
if(m==11) {System.out.println("IN  THE   NOVEMBER  MONTH  HAVE  ONLY  30 DAYS ");}
System.out.println(" ENTER AGAIN \n");
againd=1;
}

}while(againd==1);





for(loop=1;loop<=2;loop++)
{
y=year-1; 

if(m==1 ){d=0  ;e=31;}   if(m==2 ){d=31 ;e=28;}  if(m==3 ){d=59 ;e=31;}
if(m==4 ){d=90 ;e=30;}   if(m==5 ){d=120;e=31;}  if(m==6 ){d=151;e=30;}
if(m==7 ){d=181;e=31;}   if(m==8 ){d=212;e=31;}  if(m==9 ){d=243;e=30;}
if(m==10){d=273;e=31;}   if(m==11){d=304;e=30;}  if(m==12){d=334;e=31;}

if(loop==2){date=1;}

f=d+date+y+(y/4)+(y/400)-(y/100);

if((year%4==0)&&(year%100!=0||year%400==0)&&(m>=3)){f=f+1;} g=f%7;
if((year%4==0)&&(year%100!=0||year%400==0)&&(m==2)){e=29;}

if(loop==1){

     if(g==1)System.out.print("\n\n\t\t MON");
else if(g==2)System.out.print("\n\n\t\t TUE");
else if(g==3)System.out.print("\n\n\t\t WED");
else if(g==4)System.out.print("\n\n\t\t THU");
else if(g==5)System.out.print("\n\n\t\t FRI");
else if(g==6)System.out.print("\n\n\t\t SAT");
else if(g==0)System.out.print("\n\n\t\t SUN");     }

if(loop==2){
System.out.print("\n\n");
System.out.print(" S    M    T    W    T    F    S\n\n");
for(i=1;i<g+1;i++)System.out.print("     ");
for(i=1;i<=e;i++)
{
if(i>=10){System.out.print(" "+i+"  ");}
if(i<10){System.out.print(" "+i+"   ");}g++;
if(g==7){System.out.print("\n");g=0;}
}
}	//end of if 

} //for loop

int w=1;
do{
System.out.print("\n\n Do u want to continue   (y/n)  ");
con=br.readLine();
if(con.equals("y")||con.equals("Y")){n++;w=0;}else
if(con.equals("n")||con.equals("N")){w=0;}
}while(w==1);

} //moreloop

} // for end
}// end of class
