import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class ChessGame{public static void main(String args[]){new A();}}//end of class

class Timer extends Thread 
{
static int p1,p2;
void  startTimer(){
System.out.println("before calling start");
start();
System.out.println("after calling start");
}//end of constructor

public void run()
{
while(true)
{
if(A.moveWhite==true)
{try{Thread.sleep(1000);}catch(Exception e){}p1++;
A.timeToPlayer1.setText((p1/3600)+" : "+(p1/60)+" : "+(p1%60));}

if(A.moveWhite==false)
{try{Thread.sleep(1000);}catch(Exception e){}p2++;
A.timeToPlayer2.setText((p2/3600)+" : "+(p2/60)+" : "+(p2%60));}

}//end of while
}//end of run
}//end of Timer class



class A extends Frame implements ActionListener,MouseListener,WindowListener,ComponentListener
{
Toolkit tool=Toolkit.getDefaultToolkit();

Timer t=new Timer();
static Label timeToPlayer1=new Label("");
static Label timeToPlayer2=new Label("");

static boolean moveWhite=true;
static Frame f;
static int coinX=15,coinY=45;
static int startX=0,startY=30,width=60,height=60;
static  Component com;
static int x,y,comX,comY;

static Label illigal=new Label("");
static Button message=new Button("");

static JButton whiteCoins[]=new JButton[10];
static JButton whiteSolgers[]=new JButton[10];
static JButton blackCoins[]=new JButton[10];
static JButton blackSolgers[]=new JButton[10];
public static void main(String args[]){new A();}//end of main

A()
{
setLayout(null);


for(int i=0;i<8;i++)
{
if(i==0){ whiteCoins[i]=new JButton(new ImageIcon("WhiteElephent.jpg"));}else
if(i==1){ whiteCoins[i]=new JButton(new ImageIcon("WhiteHourse.jpg"));}else
if(i==2){ whiteCoins[i]=new JButton(new ImageIcon("WhiteCamel.jpg"));}else
if(i==3){ whiteCoins[i]=new JButton(new ImageIcon("WhiteKing.jpg"));}else
if(i==4){ whiteCoins[i]=new JButton(new ImageIcon("WhiteQueen.jpg"));}else
if(i==5){ whiteCoins[i]=new JButton(new ImageIcon("WhiteCamel.jpg"));}else
if(i==6){ whiteCoins[i]=new JButton(new ImageIcon("WhiteHourse.jpg"));}else
if(i==7){ whiteCoins[i]=new JButton(new ImageIcon("WhiteElephent.jpg"));}
whiteCoins[i].setBounds(coinX+(i*width),coinY+(0*height),30,30);
whiteCoins[i].setBackground(Color.white);
whiteCoins[i].addActionListener(this);
add(whiteCoins[i]);
}			//end of whiteCoins  loop



ImageIcon wSolgerIcon=new ImageIcon("WhiteSolger.jpg");
for(int i=0;i<8;i++)
{
whiteSolgers[i]=new JButton(wSolgerIcon);
whiteSolgers[i].setBounds(coinX+(i*width),coinY+(1*height),24,24);
whiteSolgers[i].setBackground(Color.white);
whiteSolgers[i].addActionListener(this);
add(whiteSolgers[i]);
}			//end of blackSolgers  loop



ImageIcon bSolgerIcon=new ImageIcon("BlackSolger.jpg");
for(int i=0;i<8;i++)
{
blackSolgers[i]=new JButton(bSolgerIcon);
blackSolgers[i].setBounds(coinX+(i*width),coinY+(6*height),24,24);
blackSolgers[i].setBackground(Color.white);
blackSolgers[i].addActionListener(this);
add(blackSolgers[i]);
}			//end of blackSolgers  loop

for(int i=0;i<8;i++)
{
if(i==0){ blackCoins[i]=new JButton(new ImageIcon("BlackElephent.jpg"));}else
if(i==1){ blackCoins[i]=new JButton(new ImageIcon("BlackHourse.jpg"));}else
if(i==2){ blackCoins[i]=new JButton(new ImageIcon("BlackCamel.jpg"));}else
if(i==3){ blackCoins[i]=new JButton(new ImageIcon("BlackKing.jpg"));}else
if(i==4){ blackCoins[i]=new JButton(new ImageIcon("BlackQueen.jpg"));}else
if(i==5){ blackCoins[i]=new JButton(new ImageIcon("BlackCamel.jpg"));}else
if(i==6){ blackCoins[i]=new JButton(new ImageIcon("BlackHourse.jpg"));}else
if(i==7){ blackCoins[i]=new JButton(new ImageIcon("BlackElephent.jpg"));}
blackCoins[i].setBounds(coinX+(i*width),coinY+(7*height),30,30);
blackCoins[i].setBackground(Color.white);
blackCoins[i].addActionListener(this);
add(blackCoins[i]);
}			//end of blackSolgers  loop

timeToPlayer1.setBounds(500,100,80,30);
timeToPlayer2.setBounds(500,420,80,30);
timeToPlayer1.setFont(new Font("TimesRoman",1,20));
timeToPlayer2.setFont(new Font("TimesRoman",1,20));
timeToPlayer1.setForeground(Color.blue);
timeToPlayer2.setForeground(Color.red);


add(timeToPlayer1);
add(timeToPlayer2);

illigal.setBounds(580,230,120,35);
illigal.setFont(new Font("TimesRoman",3,20));
illigal.setBackground(Color.white);
illigal.setForeground(Color.red);
add(illigal);


message.setBounds(500,280,280,35);
message.setFont(new Font("TimesRoman",1,15));
message.setBackground(Color.white);
message.setForeground(Color.red);
add(message);


setBounds(0,0,800,515);
setVisible(true);
setResizable(false);
addMouseListener(this);
addWindowListener(this);

addComponentListener(this);

Object[] player = { "Player 1", "Player 2" };
Object selectedPlayer = JOptionPane.showInputDialog(null, "Who wants to play first ", "Choose Player",JOptionPane.INFORMATION_MESSAGE, null,player,player[0]);

if(selectedPlayer==player[0]){moveWhite=true;}else
if(selectedPlayer==player[1]){moveWhite=false;}

Timer t=new Timer();
t.start();

}//end of constructor

public void componentResized(java.awt.event.ComponentEvent e){}
public void componentMoved(java.awt.event.ComponentEvent e){setLocation(0,0);}
public void componentShown(java.awt.event.ComponentEvent e){}
public void componentHidden(java.awt.event.ComponentEvent e){}


public void windowOpened(WindowEvent e){System.out.println("Opened");}
public void windowClosing(WindowEvent e){System.out.println("Closed");System.exit(0);}
public void windowClosed(WindowEvent e){System.out.println("Closed");}
public void windowIconified(WindowEvent e){System.out.println("Iconified");}
public void windowDeiconified(WindowEvent e){System.out.println("Deiconified");}
public void windowActivated(WindowEvent e){System.out.println("Activated");}
public void windowDeactivated(WindowEvent e){System.out.println("Deactivated");}





public void paint(Graphics g)
{
int k=1;
for(int i=0;i<8;i++)
{
k=i;
for(int j=0;j<8;j++)
{
if(k%2==0){g.setColor(Color.gray);}else{g.setColor(Color.white);}k++;
g.fillRect(startX+(j*width),startY+(i*height),60,60);
}//end of   j th loop 
}//end of   i th loop

g.setColor(Color.gray);	
g.setFont(new Font("TimesRoman",1,20));
g.drawString("Player 1",500,95);
g.drawString("Player 2",500,470);

g.setColor(Color.gray);	
g.fillRect(startX+(8*width),startY+(0*height),3,480);
f=this;


}//end of paint




public void mouseClicked(MouseEvent me)
{
x=me.getX();
y=me.getY();
x=x-x%60;x=x+15;
y=y-30;y=y-y%60;y=y+45;

comX=com.getX();comY=com.getY();
illigal.setText("");message.setLabel("");
if(Legal.isLegalMove(com,x,y,comX,comY))
{
com.setLocation(x,y);
if(moveWhite==true){moveWhite=false;}else
if(moveWhite==false){moveWhite=true;}
}//end  of  isLegalMove 

else{tool.beep();}

}//end of mouseClicked


public void mouseEntered(MouseEvent me){}//end of mouseEntered
public void mousePressed(MouseEvent me){}//end of mouseEntered
public void mouseReleased(MouseEvent me){}//end of mouseEntered
public void mouseExited(MouseEvent me){}//end of mouseEntered

public void actionPerformed(ActionEvent ae){com=(Component)ae.getSource();}//end of actionPerformed



}//end of class








class Legal
{
static Component com;
static int x,y,comX,comY;

public static boolean isLegalMove(Component com,int x,int y,int comX,int comY)
{
Legal.com=com;Legal.x=x;Legal.y=y;Legal.comX=comX;Legal.comY=comY;


if(x>=495)   {A.illigal.setText("Illiegal  Move");A.message.setLabel("Click with in the board");return(false);}
if(IsWhat.isBlackCoin(com)){if(IsWhat.isBlackCoin(A.f.getComponentAt(x,y))){A.illigal.setText("Illiegal  Move");return(false);}}
if(IsWhat.isWhiteCoin(com)){if(IsWhat.isWhiteCoin(A.f.getComponentAt(x,y))){A.illigal.setText("Illiegal  Move");return(false);}}
if((IsWhat.isBlackCoin(com)&&A.moveWhite==false)||(IsWhat.isWhiteCoin(com)&&A.moveWhite==true)){}
else
{if(IsWhat.isWhiteCoin(com)){A.illigal.setText("Illiegal  Move");A.message.setLabel("Black has to move");}
if(IsWhat.isBlackCoin(com)){A.illigal.setText("Illiegal  Move");A.message.setLabel("White has to move");}
return(false);
}

if(IsWhat.isBlackSolger(com))
{
if(PossiblePlc.toBlackSolger(x,y,comX,comY)==false){A.illigal.setText("Illiegal  Move");return(false);}
if(comX==x&&comY+(-1*60)==y)
{if(IsWhat.isCoin(A.f.getComponentAt(x,y)))  {A.illigal.setText("Illiegal  Move");A.message.setLabel("Coin is there");return(false);}}
if( (comX+(-1*60)==x&&comY+(-1*60)==y)   ||   (comX+(1*60)==x &&comY+(-1*60)==y)  )
{
if(IsWhat.isWhiteCoin(A.f.getComponentAt(x,y))){A.f.getComponentAt(x,y).setVisible(false); return(true);  }
else{A.illigal.setText("Illiegal  Move");A.message.setLabel(" Cross Move");return(false);}
}
}//  end of  if( isBlackSolger   )

else

if(IsWhat.isWhiteSolger(com))
{
if(PossiblePlc.toWhiteSolger(x,y,comX,comY)==false){A.illigal.setText("Illiegal  Move	");return(false);}
if(comX==x&&comY+(1*60)==y)
{if(IsWhat.isCoin(A.f.getComponentAt(x,y)))  {A.illigal.setText("Illiegal  Move");A.message.setLabel("Coin is there");return(false);}}
if( (comX+(-60)==x && comY+(1*60)==y)   ||   (comX+(1*60)==x &&comY+(1*60)==y)  )
{
if(IsWhat.isBlackCoin(A.f.getComponentAt(x,y))){A.f.getComponentAt(x,y).setVisible(false); return(true);  }
else{A.illigal.setText("Illiegal  Move");A.message.setLabel(" Cross Move");return(false);}
}
}//  end of  if( isWhiteSolger)

else

if(IsWhat.isHourse(com))
{if(PossiblePlc.toHourse(x,y,comX,comY)==false){A.illigal.setText("Illiegal  Move");return(false);}
if(IsWhat.isCoin(A.f.getComponentAt(x,y))){A.f.getComponentAt(x,y).setVisible(false); return(true);}}

else

if(IsWhat.isElephent(com))
{if(PossiblePlc.toElephent(x,y,comX,comY)==false){A.illigal.setText("Illiegal  Move");return(false);}
if(IsWhat.isCoin(A.f.getComponentAt(x,y))){A.f.getComponentAt(x,y).setVisible(false); return(true);  }}
else

if(IsWhat.isCamel(com))
{if(PossiblePlc.toCamel(x,y,comX,comY)==false){A.illigal.setText("Illiegal  Move");return(false);}
if(IsWhat.isCoin(A.f.getComponentAt(x,y))){A.f.getComponentAt(x,y).setVisible(false); return(true);  }}

else
if(IsWhat.isKing(com))
{if(PossiblePlc.toKing(x,y,comX,comY)==false){A.illigal.setText("Illiegal  Move");return(false);}
if(IsWhat.isCoin(A.f.getComponentAt(x,y))){A.f.getComponentAt(x,y).setVisible(false); return(true);  }}

else

if(IsWhat.isQueen(com))
{if(PossiblePlc.toQueen(x,y,comX,comY)==false){A.illigal.setText("Illiegal  Move");return(false);}
if(IsWhat.isCoin(A.f.getComponentAt(x,y))){A.f.getComponentAt(x,y).setVisible(false); return(true);  }}

return(true);
}//end of method is legal move
}//end of  Legal   class 






class PossiblePlc
{

public static boolean toBlackSolger(int x,int y,int comX,int comY) 
{
if(comY==405)
{
if(comX==x&&comY+(-2*60)==y){if(IsWhat.isCoin(A.f.getComponentAt(x,y))){return(false);}}
if((comX==x&&comY+(-1*60)==y)   ||  (comX==x&&comY+(-2*60)==y)  ||  (comX+(-1*60)==x&&comY+(-1*60)==y)  ||  (comX+(1*60)==x&&comY+(-1*60)==y))
{return(true);}else{return(false);}
}
else 
if((comX==x&&comY+(-1*60)==y)  ||  (comX+(-1*60)==x&&comY+(-1*60)==y)  ||  (comX+(1*60)==x&&comY+(-1*60)==y))
{return(true);}
else
{return(false);}
}//end of  toBlackSolger


public static boolean toWhiteSolger(int x,int y,int comX,int comY) 
{
if((comX==x&&comY+(2*60)==y)){if(IsWhat.isCoin(A.f.getComponentAt(x,y))){return(false);}}
if(comY==105)
{
if((comX==x&&comY+(1*60)==y)   ||  (comX==x&&comY+(2*60)==y)  ||  (comX+(-1*60)==x&&comY+(1*60)==y)  ||  (comX+(1*60)==x&&comY+(1*60)==y))
{return(true);}else{return(false);}
}
else 
if((comX==x&&comY+(1*60)==y)  ||  (comX+(-1*60)==x&&comY+(1*60)==y)  ||  (comX+(1*60)==x&&comY+(1*60)==y))
{return(true);}
else
{return(false);}
}//end of  toWhiteSolger


public static boolean toHourse(int x,int y,int comX,int comY) 
{
if((comX+(1*60)==x&&comY+(2*60)==y)|| (comX+(-1*60)==x&&comY+(2*60)==y)||(comX+(1*60)==x&&comY+(-2*60)==y)||(comX+(-1*60)==x&&comY+(-2*60)==y))
{return(true);}
if((comX+(2*60)==x&&comY+(1*60)==y)|| (comX+(2*60)==x&&comY+(-1*60)==y)||(comX+(-2*60)==x&&comY+(1*60)==y)||(comX+(-2*60)==x&&comY+(-1*60)==y))
{return(true);}
return(false);
}// end of toHourse

static int temp=0,tempX=0,tempY=0;


public static boolean toKing(int x,int y,int comX,int comY) 
{
if((comX+(-1*60)==x&&comY+(-1*60)==y)|| (comX+(0*60)==x&&comY+(-1*60)==y)||(comX+(1*60)==x&&comY+(-1*60)==y)||(comX+(1*60)==x&&comY+(0*60)==y))
{return(true);}
if((comX+(1*60)==x&&comY+(1*60)==y)|| (comX+(0*60)==x&&comY+(1*60)==y)||(comX+(-1*60)==x&&comY+(1*60)==y)||(comX+(-1*60)==x&&comY+(0*60)==y))
{return(true);}
return(false);
}//end of toKing

public static boolean toCamel(int x,int y,int comX,int comY) 
{if((Math.abs(comX-x)==Math.abs(comY-y))){}else{return(false);}
if(comX-x<0&&comY-y>0){if(anyCoinsInPMCross(x,y,comX,comY)){return(false);}}
if(comX-x>0&&comY-y>0){if(anyCoinsInMMCross(x,y,comX,comY)){return(false);}}
if(comY-y<0&&comX-x>0){if(anyCoinsInMPCross(x,y,comX,comY)){return(false);}}
if(comY-y<0&&comX-x<0){if(anyCoinsInPPCross(x,y,comX,comY)){return(false);}}
return(true);
}


public static boolean toQueen(int x,int y,int comX,int comY) 
{
if(   (comX==x||comY==y)||  (Math.abs(comX-x)==Math.abs(comY-y))  ){}else{return(false);}
if(comX==x){if(anyVerticalCoins(comX,comY,x,y)){return(false);}else{return(true);}}
if(comY==y){if(anyHorizantalCoins(comX,comY,x,y)){return(false);}else{return(true);}}
if(comX-x<0&&comY-y>0){if(anyCoinsInPMCross(x,y,comX,comY)){return(false);}}
if(comX-x>0&&comY-y>0){if(anyCoinsInMMCross(x,y,comX,comY)){return(false);}}
if(comY-y<0&&comX-x>0){if(anyCoinsInMPCross(x,y,comX,comY)){return(false);}}
if(comY-y<0&&comX-x<0){if(anyCoinsInPPCross(x,y,comX,comY)){return(false);}}
return(true);
}


public static boolean anyCoinsInPMCross(int x,int y,int comX,int comY)
{
tempX=comX+60;tempY=comY-60;
while(tempX<=x-60)
{
if(IsWhat.isCoin(A.f.getComponentAt(tempX,tempY))){return(true);}
tempX=tempX+60;tempY=tempY-60;
}//end of while
return(false);
}//end of method


public static boolean anyCoinsInMMCross(int x,int y,int comX,int comY)
{
tempX=comX-60;tempY=comY-60;
while(tempX>=x+60)
{
if(IsWhat.isCoin(A.f.getComponentAt(tempX,tempY))){return(true);}
tempX=tempX-60;tempY=tempY-60;
}//end of while
return(false);
}//end of method


public static boolean anyCoinsInMPCross(int x,int y,int comX,int comY)
{
tempY=comY+60;tempX=comX-60;
while(tempY<=y-60)
{
if(IsWhat.isCoin(A.f.getComponentAt(tempX,tempY))){return(true);}
tempY=tempY+60;tempX=tempX-60;
}//end of while
return(false);
}//end of method


public static boolean anyCoinsInPPCross(int x,int y,int comX,int comY)
{
tempY=comY+60;tempX=comX+60;
while(tempY<=y-60)
{
if(IsWhat.isCoin(A.f.getComponentAt(tempX,tempY))){return(true);}
tempY=tempY+60;tempX=tempX+60;
}//end of while
return(false);
}//end of method


public static boolean toElephent(int x,int y,int comX,int comY) 
{
if((comX==x||comY==y)){}else{return(false);}
if(comX==x){if(anyVerticalCoins(comX,comY,x,y)){return(false);}else{return(true);}}
if(comY==y){if(anyHorizantalCoins(comX,comY,x,y)){return(false);}else{return(true);}}
return(true);
}//end of toElephent


public static boolean anyVerticalCoins(int comX,int comY,int x,int y)
{
if(comY-y>0)
{
temp=comY-60;
while(temp>=y+60)
{
if(IsWhat.isCoin(A.f.getComponentAt(x,temp))){return(true);}
temp=temp-60;
}//end of while
return(false);
}//end io if 

if(comY-y<0)
{
temp=comY+60;
while(temp<=y-60)
{
if(IsWhat.isCoin(A.f.getComponentAt(x,temp))){return(true);}
temp=temp+60;
}//end of while
return(false);
}//end of if 

return(false);

}//end of anyVerticalCoins method


public static boolean anyHorizantalCoins(int comX,int comY,int x,int y)
{
if(comX-x>0)
{
temp=comX-60;
while(temp>=x+60)
{
if(IsWhat.isCoin(A.f.getComponentAt(temp,y))){return(true);}
temp=temp-60;
}//end of while
return(false);
}//end io if 

if(comX-x<0)
{
temp=comX+60;
while(temp<=x-60)
{
if(IsWhat.isCoin(A.f.getComponentAt(temp,y))){return(true);}
temp=temp+60;
}//end of while
return(false);
}//end of if 

return(true);
}//end of anyHorizantalCoins method



}//end of   PossiblePlc  class  





class IsWhat
{
public static boolean isCoin(Component com)
{if(isBlackCoin(com)==false&&isWhiteCoin(com)==false){return(false);}else{return(true);}}


public static boolean isBlackSolger(Component com)
{if(com.isVisible()==false){return(false);}
for(int i=0;i<8;i++){if(com==A.blackSolgers[i]){return(true);}}//end of loop
return(false);}//end of isBlackSolger


public static boolean isWhiteSolger(Component com)
{if(com.isVisible()==false){return(false);}
for(int i=0;i<8;i++){if(com==A.whiteSolgers[i]){return(true);}}//end of loop
return(false);}//end of isWhiteSolger


public static boolean isBlackCoin(Component com)
{if(com.isVisible()==false){return(false);}
for(int i=0;i<8;i++){if(com==A.blackSolgers[i]){return(true);}}//end of loop
for(int i=0;i<8;i++){if(com==A.blackCoins[i]){return(true);}}//end of loop
return(false);}//end of isBlackCoin


public static boolean isWhiteCoin(Component com)
{if(com.isVisible()==false){return(false);}
for(int i=0;i<8;i++){if(com==A.whiteSolgers[i]){return(true);}}//end of loop
for(int i=0;i<8;i++){if(com==A.whiteCoins[i]){return(true);}}//end of loop
return(false);}//end of isWhiteCoin


public static boolean isHourse(Component com)
{if(com.isVisible()==false){return(false);}
if(A.whiteCoins[1]==com||A.whiteCoins[6]==com||A.blackCoins[1]==com||A.blackCoins[6]==com){return(true);}
else{return(false);}
}//end of isHourse


public static boolean isCamel(Component com)
{if(com.isVisible()==false){return(false);}
if(A.whiteCoins[2]==com||A.whiteCoins[5]==com||A.blackCoins[2]==com||A.blackCoins[5]==com){return(true);}
else{return(false);}
}//end of isHourse

public static boolean isElephent(Component com)
{if(com.isVisible()==false){return(false);}
if(A.whiteCoins[0]==com||A.whiteCoins[7]==com||A.blackCoins[0]==com||A.blackCoins[7]==com){return(true);}
else{return(false);}
}//end of isHourse

public static boolean isQueen(Component com)
{if(com.isVisible()==false){return(false);}
if(A.whiteCoins[4]==com||A.blackCoins[4]==com){return(true);}
else{return(false);}
}//end of isHourse

public static boolean isKing(Component com)
{if(com.isVisible()==false){return(false);}
if(A.whiteCoins[3]==com||A.blackCoins[3]==com){return(true);}
else{return(false);}
}//end of isHourse


}//end of     IsWhat   class  