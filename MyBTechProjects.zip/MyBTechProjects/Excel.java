 import java.awt.*;
import java.awt.event.*; 
import javax.swing.*;
import java.sql.*;

class Excel extends JFrame implements MouseMotionListener,MouseListener,ItemListener,WindowListener
{
Panel p=new Panel();
Choice ch=new Choice();
JTable jt;
ImageIcon ic=new ImageIcon("T1.gif");
static Statement stmt;
static Connection con;

 public  void windowOpened(java.awt.event.WindowEvent e){}
 public  void windowClosing(java.awt.event.WindowEvent e){System.exit(0);}
 public  void windowClosed(java.awt.event.WindowEvent e){}
 public  void windowIconified(java.awt.event.WindowEvent e){}
 public  void windowDeiconified(java.awt.event.WindowEvent e){}
 public  void windowActivated(java.awt.event.WindowEvent e){}
 public  void windowDeactivated(java.awt.event.WindowEvent e){}

public static void main(String args[]) throws Exception
{ 
try{
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
Connection con=DriverManager.getConnection("jdbc:odbc:manoj","scott","tiger");
stmt=con.createStatement();
}catch(Exception e){}

/*
DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:system1","system","manager");
stmt=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
*/

new Excel();

stmt.close();
con.close();
}//end of main

public Excel() throws Exception
{
addWindowListener(this);
setLayout(null);

jt=new JTable(20,2);
jt.setFont(new Font("TimesRoman",1,15));
jt.setForeground(Color.blue);
jt.setRowHeight(20);
jt.setGridColor(Color.red);
jt.setRowSelectionAllowed(false);
jt.setColumnSelectionAllowed(false);
jt.addMouseListener(this);


ch.setBounds(240,20,220,20);
ch.add("number");
ch.add("varchar(20)");
ch.add("varchar2(20)");
ch.add("char(20)");
ch.add("date");
ch.add("time");
ch.addItemListener(this);

p.setBounds(0,0,480,430);
p.setBackground(Color.red);

int v=ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED;
int h=ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED;
JScrollPane jsp=new JScrollPane(jt,v,h);
jsp.setBackground(Color.green);

p.add(jsp);
p.addMouseListener(this);

Container c=getContentPane();
c.addMouseMotionListener(this);
c.setLayout(null);

c.setBackground(Color.darkGray);

c.add(ch);
c.add(p);
Submission sub=new Submission(c,jt);


setBounds(0,0,800,600);
setVisible(true);
setTitle("Graphical Interation With DataBase ");
setIconImage(Toolkit.getDefaultToolkit().getImage("T1.gif"));


ChoiceClass cc=new ChoiceClass(ch,jt);
//JustFallowOnly jfo=new JustFallowOnly(jt);
//jfo.join();

cc.join();

}//end of constructor

public static Statement getStatementObject()          {return(stmt);}
public static Connection getConnectionObject()      {return(con);}

public void itemStateChanged(ItemEvent e)
{
try{
if((jt.getSelectedColumn()+1)==2){
jt.setValueAt(ch.getSelectedItem(),jt.getSelectedRow(),jt.getSelectedColumn());}
}catch(Exception exc){System.out.println("Error");}
}

Component com;
public void mouseMoved(MouseEvent e){}
public void mouseDragged(MouseEvent e)
{
if(e.getX()>480){try{com.setBounds(0,0,e.getX(),p.getHeight());}catch(Exception exc){}}else
{try{com.setBounds(0,0,p.getWidth(),e.getY());}catch(Exception exc){}}
}

public void mouseClicked(MouseEvent e)
{
if((jt.getSelectedColumn()+1)==2){ch.setLocation(240,20*(jt.getSelectedRow()+1));}
}
public void mouseEntered(MouseEvent e){}
public void mousePressed(MouseEvent e){}
public void mouseReleased(MouseEvent e){}
public void mouseExited(MouseEvent e){}


}//end of class






class ChoiceClass extends Thread
{
Choice ch;
JTable jt;
ChoiceClass(Choice ch,JTable jt)
{
this.ch=ch;
this.jt=jt;
start();
}//end of constructor 
public void run()
{
while(true)
{
if((jt.getSelectedColumn()+1)==2)    {ch.setLocation(240,20*(jt.getSelectedRow()+1));}
try{Thread.sleep(1);}catch(Exception e){}

}//end of while
}//end of run
}//end of class






class JustFallowOnly extends Thread
{
Component com;
JTable jt;
JustFallowOnly(JTable jt)
{
this.jt=jt;
com=jt;
start();
}//end of constructor 
public void run()
{
int rowcount=0,colcount=0,column=0,row=0;
ImageIcon ic=new ImageIcon("T1.gif");


while(true)
{

      while(true)
          {
                  if(jt.getValueAt(row,column)==null)         
                  {
	if(jt.isCellSelected(row,column)==false)
	{
	if(row<jt.getSelectedRow())
	{	
	jt.changeSelection(row,column,false,false);	
	rowcount++;	
	if(rowcount>=3)
{JOptionPane.showMessageDialog(jt," Enter Field Name  at  Cell ["+row+","+column+"]","Field Name",2,ic);}
	}	
	}
                  }else{break;}

          }//end of while

     while(true)
           {
	if(jt.getValueAt(row,column+1)==null)         
	{
	if(jt.isCellSelected(row,column+1)==false)
	{
	if(row<jt.getSelectedRow())
	{
	jt.changeSelection(row,column+1,false,false);
	colcount++;
	if(colcount>=3)
{JOptionPane.showMessageDialog(jt," Select DataType  at  Cell ["+row+","+(column+1)+"]","DataType",1,ic);}
	}
	}
                  }   else     {break;}

          }//end of while

rowcount=0;colcount=0;
row++;
if(row>=19){row=19;}

}//end of while
}//end of run
}//end of class




class Submission implements ActionListener
{
Statement stmt;
ImageIcon ic=new ImageIcon("T1.gif");
static List tablenames;

JButton button;
JButton droptable;

JLabel label;
JLabel tablelist;

JTextField textfield;

Container c;
JTable jt;
Submission(Container c,JTable jt)
{
this.c=c;
this.jt=jt;
stmt=Excel.getStatementObject();

label=new JLabel("Enter Table Name");      
label.setBounds(518,30,118,19);    
label.setFont(new Font("Serif",1,14));     
label.setBackground(new Color(0,0,255));    
label.setForeground(new Color(255,0,0));    
c.add(label);

label=new JLabel("List of  Tables");      
label.setBounds(580,130,130,19);    
label.setFont(new Font("Serif",1,20));     
label.setBackground(new Color(0,0,255));    
label.setForeground(new Color(255,0,0));    
c.add(label);

tablenames=new List();
tablenames.setBounds(555,160,180,300);
tablenames.setBackground(Color.pink);
tablenames.setForeground(Color.blue);
tablenames.setFont(new Font("TimesRoman",0,12));
tablenames.addActionListener(this);

c.add(tablenames);

try{

ResultSet res=stmt.executeQuery("select * from tab");
while(res.next()){tablenames.addItem(res.getString(1));}

}  catch(Exception e){System.out.println("ERROR  :  "+e);}




droptable=new JButton("Drop Table");      
droptable.setBounds(600,474,120,27);    
droptable.setFont(new Font("Serif",1,16));     
//button.setBackground(new Color(255,128,0));    
droptable.setForeground(new Color(0,0,255));    
droptable.addActionListener(this);
c.add(droptable);



button=new JButton("Create Table");      
button.setBounds(610,74,140,27);    
button.setFont(new Font("Serif",1,16));     
//button.setBackground(new Color(255,128,0));    
button.setForeground(new Color(0,0,255));    
button.addActionListener(this);
c.add(button);


textfield=new JTextField("");      
textfield.setBounds(639,30,136,20);    
textfield.setFont(new Font("Serif",0,14));     
textfield.setBackground(new Color(255,175,175));    
textfield.setForeground(new Color(0,0,0));    
c.add(textfield);

}//end of construtor


public void actionPerformed(ActionEvent me)
{
String field="";

if(me.getSource()==button)
{
if(isValidTableName())
{
for(int i=0;i<20;i++)
{
if(jt.getValueAt(i,0)!=null) {field=field+" "+jt.getValueAt(i,0);}else{break;}
if(jt.getValueAt(i,1)!=null){field=field+" "+jt.getValueAt(i,1);}else{break;}
if(jt.getValueAt(i+1,0)!=null){field=field+",";}
}//end of for

boolean ok=true;

try{stmt.executeUpdate("create table "+textfield.getText()+"("+field+")");}
catch(Exception exc)
{JOptionPane.showMessageDialog(null,onlyMessage(exc.getMessage()),"ERROR",1,ic);ok=false;}

if(ok==true)
{
JOptionPane.showMessageDialog(null," TableCreated","Message",1,ic);
tablenames.addItem(textfield.getText());
}
                 //InsertValues inv=new InsertValues();
}// end of if
}//end of source==button

else

if(me.getSource()==droptable)
{
boolean ok1=true;
try{stmt.executeUpdate("drop table "+tablenames.getSelectedItem());}
catch(Exception exc)
{JOptionPane.showMessageDialog(null,onlyMessage(exc.getMessage()),"ERROR",1,ic);ok1=false;}
if(ok1==true)
{
tablenames.remove(tablenames.getSelectedItem());
JOptionPane.showMessageDialog(null,"Table Droped ","Message",1,ic);
}
}

else

if(me.getSource()==tablenames)
{

try{
ResultSet re=stmt.executeQuery("select * from "+tablenames.getSelectedItem());
DisplayTable dt=new DisplayTable(re);
}catch(Exception e)
{JOptionPane.showMessageDialog(null,onlyMessage(e.getMessage()),"manoj",1,ic);}

}//end of if

}//end of public void actionPerformed


boolean isValidTableName()
{

try{
stmt.executeUpdate("create table "+textfield.getText()+"(id number)");
}catch(Exception exc)
{
JOptionPane.showMessageDialog(null,onlyMessage(exc.getMessage()),"EROR",1,ic);
return(false);
}
try{
stmt.executeUpdate("drop table "+textfield.getText());
}catch(Exception e){}

return(true);

} //  end of    method   isValidTableName()

String onlyMessage(String s)
{
String message="";
for(int i=(s.length()-1);i>0;i--)
{
if(s.charAt(i)!=':')
{
message=message+""+s.charAt(i);
}else{break;}

}//end of loop

StringBuffer sb=new StringBuffer(message);

return("SQL Exception :"+sb.reverse().toString());
}//end of method 

}//end of class




class DisplayTable extends JFrame 
{
ResultSet res ;                                          JTable jt;
ResultSetMetaData rsmd;                        int c=0,r=0;

DisplayTable(ResultSet  res) throws Exception 
{
Container con=getContentPane();
this.res =res ;
try{
rsmd=res.getMetaData();
c= rsmd.getColumnCount();
}catch(Exception e){System.out.println("error in class  Display Table");}

String columns[]=new String[c];
String rows[][]=new String[100][c];
for(int i=0;i<c;i++){columns[i]=rsmd.getColumnName(i+1);}
jt=new JTable(rows,columns);
//jt.addCellEditorListener(this);
JScrollPane jsp=new JScrollPane(jt);


try{

int row=0;
while(res.next())
{
for(int i=0;i<c;i++)
{
jt.setValueAt(res.getString(i+1),row,i);
}
row++;
}
System.out.println("C:"+jt.getEditingColumn()+"r="+jt.getEditingRow());

AddCellEditor ase=new AddCellEditor(jt,res);

}catch(Exception e){System.out.println("ERROR MANOJ"+e.getMessage());}


con.add(jsp);

setSize(800,550);
setVisible(true);

}//end of constructor

}//end of class



class AddCellEditor extends Thread 
{
ImageIcon ic=new ImageIcon("T1.gif");
JTable jt;
ResultSet res;
AddCellEditor(JTable jt,ResultSet res)
{
this.jt=jt;
this.res=res;
start();
}//end of constructor

public void run()
{
try{
int editing=0,overedit=0;
int c=0,r=0,tc=0,tr=0;

ResultSetMetaData rsmd=res.getMetaData();
Statement stmt=Excel.getStatementObject();
String comm="";

while(true)
{
c=jt.getEditingColumn(); r=jt.getEditingRow();

if(c!=-1&&r!=-1)
{
String s=""+jt.getValueAt(r,c);
while(true)
{
c=jt.getEditingColumn(); r=jt.getEditingRow();

if(c==-1&&r==-1)
{
try{

System.out.println("Just now left back from  ("+tr+","+tc+")");

int cno=rsmd.getColumnType(tc+1);


if(cno!=1&&cno!=12&&cno!=-1)
{
comm="update "+Submission.tablenames.getSelectedItem()+"  set "+jt.getColumnName(tc)+" = "+jt.getValueAt(tr,tc)+" where rowno ="+tr;
}else
if(cno==1||cno==12||cno==-1)
{
comm="update "+Submission.tablenames.getSelectedItem()+"  set "+jt.getColumnName(tc)+" = '"+jt.getValueAt(tr,tc)+" '  where rowno ="+tr;
}



System.out.println(comm);
System.out.println("Table name : "+Submission.tablenames.getSelectedItem());

stmt.executeUpdate(comm);
}catch(Exception e)
{JOptionPane.showMessageDialog(null,e.getMessage(),"inner ERROR",1,ic);jt.setValueAt(s,tr,tc);}
break;
}//end of    inner   if
tc=c;tr=r;
}//end of    inner while
}//end of if
}//end of while
}catch(Exception e){JOptionPane.showMessageDialog(null,e.getMessage(),"ERROR",1,ic);}
}//end of run
}//end of class