#include<stdio.h>
#include<conio.h>
#include<graphics.h>

int s1,s2,s3,cx=220,cy=445,mh=1,md=0,mu=0,n1=450,n2=450,n3=400,k,
r1x1,r1y1,r1x2,r1y2,
r2x1,r2y1,r2x2,r2y2,
r3x1,r3y1,r3x2,r3y2,
ex=470,ey=20,egg=0,
l=0,x=0;
main()
{
int gm,gd=DETECT,i,j;
char ch;

initgraph(&gd,&gm," ");
clrscr();


for(i=0;i<=650;i++){for(j=0;j<=500;j++){putpixel(i,j,2);}}
outtextxy(230,190,"   EGG GAME ");
outtextxy(230,210,"       PROGRAMMER  Y.MANOJ    ");
outtextxy(230,380," PRESS ENTER TO START THE GAME ");
getch();
clrscr();


for(i=0;i<=650;i++){for(j=0;j<=500;j++){putpixel(i,j,13);}}

for(i=146;i<=450;i++){for(j=0;j<=500;j++){putpixel(i,j,9);}}
outtextxy(5,30,"Press ESC to Exit ");
for(i=1;i<=10;i++)
{
for(j=1;j<=5;j++){circle(ex,ey,j);}
ex=ex+12;
}
ex=470;
change();
while(1)
{
colourrec(r1x1,r1y1,r1x2,r1y2,9);       moveline1(&r1x1,&r1y1,&r1x2,&r1y2,10);
colourrec(cx-10,cy-13,cx+10,cy+12,9);   if(mh==1){movecircleh();}
colourrec(r2x1,r2y1,r2x2,r2y2,9);       moveline2();
if(l==8||l==3||l==10)
{colourrec(r3x1,r3y1,r3x2,r3y2,9);    moveline3();}

if(l==8||l==3||l==10)
{
if(cy>r3y1-10 && cy<r3y1+5 && cx<r3x2+10 && cx>r3x1-10){md=1;mu=0;mh=0;}
}
if(mh==1){
if(kbhit())
{
ch=getch();
if(ch==' '){getch();}else
if(ch=='\r')
{
mu=1;mh=0;md=0;
} else
if(ch==27){break;}
}
}

if(mu==1){movecircleu();}

if(md==0){
if(cy>=r2y1-18 && cy<=r2y1)
{
  if(cx+8>=r2x1 && cx-8<=r2x2)
  {
  mu=0;mh=1;md=0;l++;change();
  if(l==12){break;}
  }
  else {  mu=0;md=1;mh=0; }
}  }

if(md==1)
{
movecircled();
if(cy>=r1y1+15)
{
egg++;
colourrec(ex-5,ey-5,ex+5,ey+5,13);
ex=ex+12;
if(egg==10){break;}
colourrec(cx-10,cy-10,cx+10,cy+10,9);md=0;mh=1;mu=0;cx=r1x1+20;cy=r1y1-10;}
}
}
outtextxy(230,100,"  GAME OVER  ");
printf("\n\n\n\n\n\n\n\n");
printf("                         UR SCORE IS  %d\t\t\t\t                      ",l*10);

getch();
}


movecircleh() {cx=r1x1+15;cy=r1y1-10;  for(k=1;k<=10;k++){ellipse(cx,cy,k,0,k-2,k);}}
movecircled() {cy=cy+4;                for(k=1;k<=10;k++){ellipse(cx,cy,k,0,k-2,k);}}
movecircleu() {cy=cy-4;                for(k=1;k<=10;k++){ellipse(cx,cy,k,0,k-2,k);}}


moveline1(int *x1,int *y1,int *x2,int *y2,int m)
{
   if(*x2<n1-s1)   { *x2=*x2+s1;*x1=*x1+s1;}
   else   {   *x2=*x2-s1;*x1=*x1-s1;n1=n1-s1;
   if(*x1<=153&&*x1>=146)    {n1=450;}
   }
  colourrec(*x1,*y1,*x2,*y2,m);
   delay(3000);
}

moveline2()
{
    if(r2x2<n2-s2)  {r2x2=r2x2+s2;r2x1=r2x1+s2;}
    else      {r2x2=r2x2-s2;r2x1=r2x1-s2;n2=n2-s2;
	if(r2x1<=153&&r2x1>=146){n2=450;}
      }
  colourrec(r2x1,r2y1,r2x2,r2y2,10);
    delay(3000);
}

moveline3()
{
    if(r3x2<n3-s3)  {r3x2=r3x2+s3;r3x1=r3x1+s3;}
    else      {r3x2=r3x2-s3;r3x1=r3x1-s3;n3=n3-s3;
	if(r3x1<=165&&r3x1>=146){n3=450;}
      }
  colourrec(r3x1,r3y1,r3x2,r3y2,12);
    delay(3000);
}




colourrec(int x1,int y1,int x2,int y2,int m)
{int i,j;for(i=x1;i<=x2;i++){for(j=y1-1;j<=y2;j++){putpixel(i,j,m);}}}


change()
{
   if(l<3){
   if(l!=0){ r1x1=r2x1;  r1y1=r2y1;  r1x2=r2x2; r1y2=r2y2;}
   if(l==0)
   {  s1=1;s2=2; r1x1=200;  r1y1=475;  r1x2=230;  r1y2=480;
		 r2x1=280;  r2y1=340;  r2x2=310;  r2y2=345;
   }
   if(l==1) { s1=1;s2=2;r2x1=320;   r2y1=205;   r2x2=350;   r2y2=210;   }
   if(l==2) { s1=2;s2=4;r2x1=300;   r2y1=75;    r2x2=330;   r2y2=80;    }
   }



   if(l>=3&&l<5)
   {
   if(l>3){ r1x1=r2x1;  r1y1=r2y1;  r1x2=r2x2; r1y2=r2y2;}
   if(l==3)
   {
   r3x1=150;r3y1=350;r3x2=170;r3y2=355;
   colourrec(150,0,450,480,9);
	s1=4;s2=1;s3=3; r1x1=200;   r1y1=475;   r1x2=230;   r1y2=480;
	      r2x1=280;   r2y1=240;   r2x2=310;   r2y2=245;
   }
   if(l==4) { s1=1;s2=1;r2x1=300;   r2y1=75;    r2x2=330;   r2y2=80;    }
   }



   if(l>=5&&l<8)
   {
   if(l>5){ r1x1=r2x1;  r1y1=r2y1;  r1x2=r2x2; r1y2=r2y2;}
   if(l==5)
   {
   s1=1;s2=5;
   colourrec(150,0,450,480,9);
	      r1x1=200;   r1y1=475;   r1x2=230;   r1y2=480;
	      r2x1=280;   r2y1=340;   r2x2=310;   r2y2=345;
   }
   if(l==6) { s1=2;s2=4; r2x1=320;   r2y1=205;   r2x2=350;   r2y2=210;   }
   if(l==7) { s1=5;s2=5; r2x1=300;   r2y1=75;    r2x2=330;   r2y2=80;    }
   }


   if(l>=8&&l<10)
   {
   if(l>8){ r1x1=r2x1;  r1y1=r2y1;  r1x2=r2x2; r1y2=r2y2;}
   if(l==8)
   {
   r3x1=150;r3y1=350;r3x2=180;r3y2=355;
   colourrec(150,0,450,480,9);
   s1=2;s2=1;s3=5;
		   r1x1=200;   r1y1=475;   r1x2=230;   r1y2=480;
		   r2x1=280;   r2y1=240;   r2x2=310;   r2y2=245;
   }
   if(l==9)   {s1=1;s2=1;r2x1=300;   r2y1=75;    r2x2=330;   r2y2=80;   }
   }


   if(l>=10&&l<12)
   {
   if(l>10){ r1x1=r2x1;  r1y1=r2y1;  r1x2=r2x2; r1y2=r2y2;}
   if(l==10)
   {
   r3x1=150;r3y1=350;r3x2=180;r3y2=355;
   colourrec(150,0,450,480,9);
   s1=2;s2=2;s3=12; r1x1=200;   r1y1=475;   r1x2=230;   r1y2=480;
			r2x1=280;   r2y1=240;   r2x2=310;   r2y2=245;
   }
   if(l==11)   {s1=1;s2=1;r2x1=300;   r2y1=75;    r2x2=330;   r2y2=80;   }
   }

}


