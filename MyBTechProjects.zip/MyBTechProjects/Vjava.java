import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.Calendar;

class Vjava extends Frame  implements MouseListener,ActionListener,MouseMotionListener,ItemListener,TextListener,KeyListener,WindowListener
{
static int permission=0;
static int framered=255;
static int frameblue=255;
static int framegreen=255;

Result rt;
static String unitext="";
static Checkbox checkbox[]=new Checkbox[11];

Label selectlab;


int ux=26,uy=157;
Label xlab,ylab;
TextField xtf,ytf;
Button movecom,submit;
Choice movenon;

Button createfile,submit2;
Label filecreated,rename,filenamelb;
TextField filenametf;

static int comY=550;
int comW=20;

Label lb[]=new Label[21];

Button slhor,hidden,retrive;
List lthr;

Button bt[]=new Button[21];
Panel p,companel;
Button proper,left,right;


Button color;
Button colorBt[][]=new Button[8][9];
Button wi,hi,wd,hd,st,remove;
Button slow,bavg,aavg,fast,vfast;

Checkbox cb[]=new Checkbox[21];

Choice ch[]=new Choice[21];
Choice fsize,fstyle,fname,comColor;


TextField tf[]=new TextField[21];
TextField setText,index;

TextArea ta[]=new TextArea[21];


List lt[]=new List[21];


Dimension d=new Dimension();
Component com;


public static void main(String args[])
{
Calendar c=Calendar.getInstance();
int month=c.get(Calendar.MONTH);

if(month>=0)
{
permission=1;
new Vjava();

}else
{
/*System.out.print("       "+c.get(Calendar.DATE));
System.out.print("/" +c.get(Calendar.MONTH));
System.out.print("/" +c.get(Calendar.YEAR));*/

System.out.println("\n\n\n\t\tTHE TIME LIMIT IS OVER ");
}



}
 public  void windowOpened(java.awt.event.WindowEvent e){}
 public  void windowClosing(java.awt.event.WindowEvent e){System.exit(0);}
 public  void windowClosed(java.awt.event.WindowEvent e){}
 public  void windowIconified(java.awt.event.WindowEvent e){}
 public  void windowDeiconified(java.awt.event.WindowEvent e){}
 public  void windowActivated(java.awt.event.WindowEvent e){}
 public  void windowDeactivated(java.awt.event.WindowEvent e){}


Vjava()
{

addWindowListener(this);
setLayout(null);

selectlab=new Label("        Select Listeners");      
selectlab.setBounds(619,82,160,20);    
selectlab.setFont(new Font("SansSerif",3,14));     
selectlab.setBackground(new Color(0,0,255));    
selectlab.setForeground(new Color(255,255,0));   add(selectlab);
selectlab.setVisible(false);

for(int i=0;i<11;i=i+1)
{checkbox[i]=new Checkbox();}

checkbox[10]=new Checkbox("MouseMotionListener"); 
checkbox[10].setBounds(639,104,160,14);    
checkbox[10].setFont(new Font("SansSerif",3,14));     
checkbox[10].setBackground(new Color(125,0,175));    
checkbox[10].setForeground(new Color(255,255,0));    
add(checkbox[10]);
checkbox[10].setVisible(false);


checkbox[0]=new Checkbox("MouseListener"); 
checkbox[0].setBounds(639,118,125,14);    
checkbox[0].setFont(new Font("SansSerif",3,14));     
checkbox[0].setBackground(new Color(125,0,175));    
checkbox[0].setForeground(new Color(255,255,0));    
add(checkbox[0]);
checkbox[0].setVisible(false);



checkbox[1]=new Checkbox("KeyListener");      
checkbox[1].setBounds(639,133,125,14);    
checkbox[1].setFont(new Font("SansSerif",3,14));     
checkbox[1].setBackground(new Color(125,0,175));    
checkbox[1].setForeground(new Color(255,255,0));    
add(checkbox[1]);
checkbox[1].setVisible(false);


checkbox[2]=new Checkbox("Window Listener");      
checkbox[2].setBounds(639,148,125,12);    
checkbox[2].setFont(new Font("SansSerif",3,14));     
checkbox[2].setBackground(new Color(125,0,175));    
checkbox[2].setForeground(new Color(255,255,0));    
add(checkbox[2]);
checkbox[2].setVisible(false);


checkbox[3]=new Checkbox("Item Listener");      
checkbox[3].setBounds(640,161,124,14);    
checkbox[3].setFont(new Font("SansSerif",3,14));     
checkbox[3].setBackground(new Color(125,0,175));    
checkbox[3].setForeground(new Color(255,255,0));    
add(checkbox[3]);
checkbox[3].setVisible(false);


checkbox[4]=new Checkbox("Action Listener");  
checkbox[4].setBounds(640,176,125,14);    
checkbox[4].setFont(new Font("SansSerif",3,14));     
checkbox[4].setBackground(new Color(125,0,175));    
checkbox[4].setForeground(new Color(255,255,0));    
add(checkbox[4]);
checkbox[4].setVisible(false);


checkbox[5]=new Checkbox("Text Listener");      
checkbox[5].setBounds(640,191,125,14);    
checkbox[5].setFont(new Font("SansSerif",3,14));     
checkbox[5].setBackground(new Color(125,0,175));    
checkbox[5].setForeground(new Color(255,255,0));    
add(checkbox[5]);
checkbox[5].setVisible(false);


checkbox[6]=new Checkbox("Focus Listener");  
checkbox[6].setBounds(639,222,127,14);    
checkbox[6].setFont(new Font("SansSerif",3,14));     
checkbox[6].setBackground(new Color(125,0,175));    
checkbox[6].setForeground(new Color(128,255,0));    
add(checkbox[6]);
checkbox[6].setVisible(false);


checkbox[7]=new Checkbox("Container Listener");      
checkbox[7].setBounds(639,237,127,15);    
checkbox[7].setFont(new Font("SansSerif",3,14));     
checkbox[7].setBackground(new Color(125,0,175));    
checkbox[7].setForeground(new Color(128,255,0));    
add(checkbox[7]);
checkbox[7].setVisible(false);


checkbox[8]=new Checkbox("Component Listener");      
checkbox[8].setBounds(639,253,127,15);    
checkbox[8].setFont(new Font("SansSerif",3,11));     
checkbox[8].setBackground(new Color(125,0,175));    
checkbox[8].setForeground(new Color(128,255,0));    
add(checkbox[8]);
checkbox[8].setVisible(false);


checkbox[9]=new Checkbox("Adjustment Listener");      
checkbox[9].setBounds(639,206,126,15);    
checkbox[9].setFont(new Font("SansSerif",3,11));     
checkbox[9].setBackground(new Color(125,0,175));    
checkbox[9].setForeground(new Color(255,255,0));    
add(checkbox[9]);
checkbox[9].setVisible(false);


companel =new Panel();
companel.setBounds(15,122,170,420);
companel.setLayout(null);
add(companel);
companel.setBackground(new Color(192,192,192));
companel.setVisible(false);


proper =new Button("Properties");
proper.setBounds(668,520,102,23); 
proper.setFont(new Font("Serif",1,16));  
proper.setBackground(new Color(255,175,175));   
proper.setForeground(new Color(0,0,255));
proper.addActionListener(this);
add(proper);                         

left =new Button("<-----");
left.setBounds(671,105,46,20); 
left.setFont(new Font("Serif",1,16));  
left.setBackground(new Color(255,255,0));   
left.setForeground(new Color(0,0,0));
left.addActionListener(this);
left.setVisible(false);
add(left);                         

right =new Button("----->");
right.setBounds(719,105,46,20); 
right.setFont(new Font("Serif",1,16));  
right.setBackground(new Color(255,255,0));   
right.setForeground(new Color(0,0,0));
right.addActionListener(this);
right.setVisible(false);
add(right);                         



createfile =new Button("Create File");
createfile.setBounds(39-8,337-122,88,17); 
createfile.setFont(new Font("Serif",1,14));  
createfile.setBackground(new Color(255,0,0));   
createfile.setForeground(new Color(0,255,255));
createfile.addActionListener(this);
companel.add(createfile);                         

submit2=new Button("SUBMIT");  
submit2.setBounds(40-8,370-122,95,20); 
submit2.setFont(new Font("Serif",1,14));
submit2.setBackground(new Color(255,175,175));  
submit2.setForeground(new Color(0,0,128));   
submit2.setVisible(false);
submit2.addActionListener(this);
companel.add(submit2);    


filecreated=new Label("File Created ");
//File Created  but the name is Result.java 
filecreated.setBounds(18-8,390-122,157,12);  
filecreated.setFont(new Font("Serif",1,11));  
filecreated.setBackground(new Color(255,255,255)); 
filecreated.setForeground(new Color(255,0,0));
filecreated.setVisible(false);
companel.add(filecreated);                                                                   

rename=new Label("");  
//Rename with the above name
rename.setBounds(17-8,403-122,158,14);   
rename.setFont(new Font("Serif",1,11));  
rename.setBackground(new Color(255,255,255));  
rename.setForeground(new Color(255,0,0));
rename.setVisible(false);
companel.add(rename);   

                                                
filenametf=new TextField("");      
filenametf.setBounds(75-8,354-122,98,16); 
filenametf.setFont(new Font("Arial",1,11)); 
filenametf.setBackground(new Color(255,175,175));
filenametf.setForeground(new Color(255,0,125)); 
filenametf.setVisible(false);
companel.add(filenametf);                                                               



filenamelb=new Label("File Name");      
filenamelb.setBounds(18-8,355-122,56,11);
filenamelb.setFont(new Font("Arial",1,11));
filenamelb.setBackground(new Color(255,255,255));
filenamelb.setForeground(new Color(255,0,0)); 
filenamelb.setVisible(false);
companel.add(filenamelb);                                                               





comColor=new Choice();
comColor.addItem("setBackgroundColor");
comColor.addItem("setForegroundColor");
comColor.addItem("FrameBackgroundColor");
comColor.setBounds(18-8,317-122,145,22);
comColor.setFont(new Font("Arial",Font.BOLD+Font.ITALIC,12));
comColor.setBackground(new Color(0,255,255));
comColor.setForeground(new Color(0,0,255));
companel.add(comColor);

fsize=new Choice();
fsize.addItem("4");fsize.addItem("6");fsize.addItem("8");fsize.addItem("9");fsize.addItem("10");
fsize.addItem("11");fsize.addItem("12");fsize.addItem("14");fsize.addItem("16");fsize.addItem("18");
fsize.addItem("20");fsize.addItem("22");fsize.addItem("24");fsize.addItem("26");fsize.addItem("28");
fsize.addItem("36");fsize.addItem("48");fsize.addItem("72");
fsize.setFont(new Font("Arial",Font.BOLD+Font.ITALIC,12));
fsize.setBackground(new Color(0,255,255));
fsize.setForeground(new Color(0,0,255));
fsize.setBounds(108-8,270-122,46,21);
companel.add(fsize);

fstyle=new Choice();
fstyle.addItem("Regular");fstyle.addItem("Bold");fstyle.addItem("Italic");fstyle.addItem("BoldItalic");
fstyle.setBounds(18-8,270-122,90,21);
fstyle.setFont(new Font("Arial",Font.BOLD+Font.ITALIC,12));
fstyle.setBackground(new Color(0,255,255));
fstyle.setForeground(new Color(0,0,255));
companel.add(fstyle);

fname=new Choice();
fname.addItem("Arial");fname.addItem("Courier");fname.addItem("Helvetica");
fname.addItem("TimesRoman");fname.addItem("SansSerif");
fname.setBounds(17-8,293-122,91,21);
fname.setFont(new Font("Arial",Font.BOLD+Font.ITALIC,12));
fname.setBackground(new Color(0,255,255));
fname.setForeground(new Color(0,0,255));
companel.add(fname);

p=new Panel();
p.setLayout(null);
p.setBounds(18-8,416-122,140,120);
p.setBackground(Color.blue);

int m=0,x=0,y=0;

int r[]=new int[100];     int g[]=new int[100];    int b[]=new int[100];


r[1]=255;g[1]=255;b[1]=255;             r[15]=255;g[15]=0;b[15]=128;        r[29]=50;g[29]=200;b[29]=50;                                 
r[2]=192;g[2]=192;b[2]=192;             r[16]=128;g[16]=255;b[16]=0;        r[30]=200;g[30]=50;b[30]=50;                                 
r[3]=128;g[3]=128;b[3]=128; 	     r[17]=128;g[17]=0;b[17]=255;        r[31]=125;g[31]=175;b[31]=0;                                    
r[4]=192;g[4]=0;b[4]=0;     	     r[18]=0;g[18]=128;b[18]=255;        r[32]=125;g[32]=0;b[32]=175;                                
r[5]=0;g[5]=192;b[5]=0;                      r[19]=0;g[19]=255;b[19]=128;        r[33]=0;g[33]=125;b[33]=175;                             
r[6]=255;g[6]=0;b[6]=0;                      r[20]=175;g[20]=175;b[20]=175;   r[34]=100;g[34]=100;b[34]=0;       
r[7]=255;g[7]=175;b[7]=175;             r[21]=0;g[21]=0;b[21]=192;            r[35]=0;g[35]=100;b[35]=100;                               
r[8]=255;g[8]=200;b[8]=0;                 r[22]=128;g[22]=0;b[22]=0;            r[36]=100;g[36]=0;b[36]=100;                                     
r[9]=255;g[9]=255;b[9]=0;                 r[23]=0;g[23]=128;b[23]=0;            r[37]=255;g[37]=70;b[37]=0;                                                                          
r[10]=50;g[10]=100;b[10]=160;        r[24]=0;g[24]=0;b[24]=128;            r[38]=100;g[38]=175;b[38]=255;                                                                   
r[11]=255;g[11]=0;b[11]=255;          r[25]=200;g[25]=200;b[25]=50;      r[39]=70;g[39]=100;b[39]=140;                                                                         
r[12]=0;g[12]=255;b[12]=255;          r[26]=50;g[26]=200;b[26]=200;      r[40]=150;g[40]=100;b[40]=50;                                                                                                   
r[13]=0;g[13]=0;b[13]=255;              r[27]=200;g[27]=50;b[27]=200;      r[41]=255;g[41]=0;b[41]=90;                                                                    
r[14]=255;g[14]=128;b[14]=0;         r[28]=236;g[28]=233;b[28]=216;         r[42]=0;g[42]=0;b[42]=0;                                                                        




 for(int i=1;i<=6;i++)
{
x=0;
for(int j=1;j<=7;j++)
{
m++;
colorBt[i][j]=new Button(" ");
colorBt[i][j].setBackground(new Color(r[m],g[m],b[m]));
colorBt[i][j].setBounds(x,y,20,20);
colorBt[i][j].addActionListener(this);
p.add(colorBt[i][j]);
x=x+20;
}
y=y+20;
} 
p.setVisible(false);
companel.add(p);


for(int i=1;i<=20;i++)
{
add(lb[i]=new Label("Add Label"+i));
lb[i].setBounds(114,comY,90,comW);
lb[i].setBackground(new Color(0,0,255));
lb[i].setForeground(new Color(255,255,0));
lb[i].setFont(new Font("Serif",Font.BOLD+Font.ITALIC,16));
lb[i].addKeyListener(this);
lb[i].addMouseListener(this);
}


for(int i=1;i<=20;i++)
{
add(bt[i]=new Button("Add Button"+i));
bt[i].setBounds(8,comY,102,comW);
bt[i].setForeground(new Color(0,0,255));
bt[i].setFont(new Font("Serif",Font.BOLD+Font.ITALIC,16));
bt[i].addActionListener(this);
bt[i].addKeyListener(this);
bt[i].addMouseListener(this);
}

for(int i=1;i<=20;i++)
{
add(cb[i]=new Checkbox("Add Checkbox"+i));
cb[i].setBounds(211,comY,125,comW);
cb[i].addItemListener(this);
cb[i].setBackground(new Color(125,0,175));
cb[i].setForeground(new Color(255,255,255));
cb[i].setFont(new Font("Serif",Font.BOLD+Font.ITALIC,16));
cb[i].addKeyListener(this);
cb[i].addMouseListener(this);
}

for(int i=1;i<=20;i++)
{
add(ch[i]=new Choice());
ch[i].setBounds(459,comY,108,21);
ch[i].addItemListener(this);
ch[i].add("Add Choice"+i);
ch[i].setBackground(new Color(0,255,255));
ch[i].setForeground(new Color(0,0,255));
ch[i].setFont(new Font("Arial",Font.BOLD+Font.ITALIC,12));
ch[i].addKeyListener(this);
ch[i].addMouseListener(this);
}



for(int i=1;i<=20;i++)
{
add(tf[i]=new TextField("Add TextField"+i));
tf[i].setBounds(340,comY,114,comW);
tf[i].addActionListener(this);
tf[i].setBackground(new Color(255,175,175));
tf[i].setForeground(new Color(255,0,128));
tf[i].setFont(new Font("Serif",Font.BOLD+Font.ITALIC,16));
tf[i].addKeyListener(this);
tf[i].addMouseListener(this);
}


for(int i=1;i<=20;i++)
{
add(ta[i]=new TextArea("Add TextArea"+i+"\t"));
ta[i].setBounds(670,comY,121,38);
ta[i].addTextListener(this);
ta[i].setBackground(new Color(0,255,25));
ta[i].setForeground(new Color(50,50,200));
ta[i].setFont(new Font("Serif",Font.BOLD+Font.ITALIC,14));
ta[i].addKeyListener(this);
ta[i].addMouseListener(this);
}


for(int i=1;i<=20;i++)
{
add(lt[i]=new List(5));
lt[i].setBounds(569,comY,98,comW);
lt[i].addActionListener(this);
lt[i].setBackground(new Color(255,0,90));
lt[i].setForeground(new Color(0,255,255));
lt[i].add("Add List"+i);
lt[i].setFont(new Font("Serif",Font.BOLD+Font.ITALIC,16));
lt[i].addKeyListener(this);
lt[i].addMouseListener(this);
}


add(slow=new Button("1"));
slow.setBounds(18-8,152-122,15,19);
slow.setForeground(new Color(0,0,255));
slow.setFont(new Font("Arial",Font.BOLD,12));
slow.addActionListener(this);
companel.add(slow);

add(bavg=new Button("2"));
bavg.setBounds(33-8,148-122,15,23);
bavg.setForeground(new Color(0,0,255));
bavg.setFont(new Font("Arial",Font.BOLD,12));
bavg.addActionListener(this);
companel.add(bavg);


add(aavg=new Button("4"));
aavg.setBounds(48-8,143-122,15,28);
aavg.setForeground(new Color(0,0,255));
aavg.setFont(new Font("Arial",Font.BOLD,12));
aavg.addActionListener(this);
companel.add(aavg);


add(fast=new Button("8"));
fast.setBounds(64-8,139-122,17,32);
fast.setForeground(new Color(0,0,255));
fast.setFont(new Font("Arial",Font.BOLD,12));
fast.addActionListener(this);
companel.add(fast);


add(vfast=new Button("16"));
vfast.setBounds(82-8,134-122,20,37);
vfast.setForeground(new Color(0,0,255));
vfast.setFont(new Font("Arial",Font.BOLD,12));
vfast.addActionListener(this);
companel.add(vfast);


add(wi=new Button("----->"));
wi.setBounds(139-8,170-122,37,16);
wi.setBackground(new Color(255,200,0));
wi.setForeground(new Color(0,0,255));
wi.setFont(new Font("Arial",Font.BOLD,12));
wi.addActionListener(this);
companel.add(wi);


add(hi=new Button(" \\/ "));
hi.setBounds(130-8,187-122,15,32);
hi.setBackground(new Color(0,255,125));
hi.setForeground(new Color(0,0,255));
hi.setFont(new Font("Arial",Font.BOLD,12));
hi.addActionListener(this);
companel.add(hi);


add(wd=new Button("<------"));
wd.setBackground(new Color(255,200,0));
wd.setForeground(new Color(0,0,255));
wd.setFont(new Font("Arial",Font.BOLD,12));
wd.setBounds(101-8,170-122,36,16);
wd.addActionListener(this);
companel.add(wd);


add(hd=new Button("/\\"));
hd.setBounds(131-8,135-122,14,34);
hd.setBackground(new Color(255,0,0));
hd.setForeground(new Color(255,255,0));
hd.setFont(new Font("Arial",Font.BOLD,12));
hd.addActionListener(this);
companel.add(hd);



add(setText=new TextField("Your Text  Here"));
setText.setBounds(19-8,221-122,154,20);
setText.setFont(new Font("Serif",Font.BOLD+Font.ITALIC,16));
setText.setBackground(new Color(255,200,0));
setText.setForeground(new Color(255,0,0));
setText.addActionListener(this);
companel.add(setText);


add(index=new TextField("1"));
index.setBounds(19-8,198-122,38,20);
index.setFont(new Font("Serif",Font.BOLD+Font.ITALIC,16));
index.setBackground(new Color(255,200,0));
index.setForeground(new Color(255,0,0));
index.addActionListener(this);
companel.add(index);



add(st=new Button("Add Text"));
st.setBounds(16-8,241-122,78,24);
st.setFont(new Font("Serif",Font.BOLD+Font.ITALIC,16));
st.setBackground(new Color(255,0,255));
st.setForeground(new Color(255,255,0));
st.addActionListener(this);
companel.add(st);


color=new Button("Color");
color.setBounds(37-8,419-122,102,20);
color.setFont(new Font("Serif",Font.BOLD+Font.ITALIC,16));
color.setBackground(new Color(255,0,255));
color.setForeground(new Color(255,255,0));
color.addActionListener(this);
add(color);
companel.add(color);



add(remove=new Button("Remove."));
remove.setBounds(97-8,241-122,74,24);
remove.setFont(new Font("Serif",Font.BOLD+Font.ITALIC,16));
remove.setBackground(new Color(255,0,255));
remove.setForeground(new Color(255,255,0));
remove.addActionListener(this);
companel.add(remove);


try{
if(permission==1)
{
rt=new Result(bt,tf,lt,ch,cb,ta,lb);
}
}catch(Exception e){}



setSize(800,600);
setVisible(true);
setTitle("Created   by  Y.Manoj ,  B'Tech  2nd year ,  ASIFIA college of  Engg.. ,  IBP,  HYD. ");
addMouseMotionListener(this);
addKeyListener(this);
addMouseListener(this);
}// end of constructor


Component com2;

public void keyTyped(KeyEvent me)
{
int code=me.getKeyCode();
if(code==27)
{
p.setVisible(false);
companel.setVisible(false);
left.setVisible(false);
right.setVisible(false);
filenamelb.setVisible(false);
filenametf.setVisible(false);
rename.setVisible(false);
submit2.setVisible(false);
filecreated.setVisible(false);
checkbox[0].setVisible(false);
checkbox[1].setVisible(false);
checkbox[2].setVisible(false);
checkbox[3].setVisible(false);
checkbox[4].setVisible(false);
checkbox[5].setVisible(false);
checkbox[6].setVisible(false);
checkbox[7].setVisible(false);
checkbox[8].setVisible(false);
checkbox[9].setVisible(false);
checkbox[10].setVisible(false);
selectlab.setVisible(false);
}

} // end of keyTyped

int keySpeed=4;

public void keyPressed(KeyEvent me)
{
int code=me.getKeyCode();

if(code==33)
{
keySpeed=16;
}else
if(code==35)
{
keySpeed=4;
}else
if(code==34)
{
keySpeed=1;
}else
if(code==37)
{
com.setBounds(com.getX(),com.getY(),com.getWidth()-keySpeed,com.getHeight());
//System.out.println("KEY_LEFT ");
}else
if(code==38)
{
com.setBounds(com.getX(),com.getY(),com.getWidth(),com.getHeight()-keySpeed);
//System.out.println("KEY_UP");
}else
if(code==39)
{
com.setBounds(com.getX(),com.getY(),com.getWidth()+keySpeed,com.getHeight());
//System.out.println("KEY_RIGHT");
}else
if(code==40)
{
com.setBounds(com.getX(),com.getY(),com.getWidth(),com.getHeight()+keySpeed);
//System.out.println("KEY_DOWN");
}else
if(code==100)
{
com.setBounds(com.getX()-keySpeed,com.getY(),com.getWidth(),com.getHeight());
//System.out.println("KEY_LEFT ");
}else
if(code==104)
{
com.setBounds(com.getX(),com.getY()-keySpeed,com.getWidth(),com.getHeight());
//System.out.println("KEY_UP");
}else
if(code==102)
{
com.setBounds(com.getX()+keySpeed,com.getY(),com.getWidth(),com.getHeight());
//System.out.println("KEY_RIGHT");
}else
if(code==98)
{
com.setBounds(com.getX(),com.getY()+keySpeed,com.getWidth(),com.getHeight());
//System.out.println("KEY_DOWN");
}else
if(code==97)
{
com.setBounds(com.getX()-keySpeed,com.getY()+keySpeed,com.getWidth(),com.getHeight());
//System.out.println("KEY_LEFT ");
}else
if(code==99)
{
com.setBounds(com.getX()+keySpeed,com.getY()+keySpeed,com.getWidth(),com.getHeight());
//System.out.println("KEY_UP");
}else
if(code==105)
{
com.setBounds(com.getX()+keySpeed,com.getY()-keySpeed,com.getWidth(),com.getHeight());
//System.out.println("KEY_RIGHT");
}else
if(code==103)
{
com.setBounds(com.getX()-keySpeed,com.getY()-keySpeed,com.getWidth(),com.getHeight());
//System.out.println("KEY_DOWN");
}
} // end of keyPressed

public void keyReleased(KeyEvent me){}





public void mouseEntered(MouseEvent  me){}

Component component;
public void mouseClicked(MouseEvent  e)
{
component=(Component)e.getSource();

if(component!=this)
{
com=(Component)e.getSource();
}

if(component==this)
{
p.setVisible(false);
companel.setVisible(false);
left.setVisible(false);
right.setVisible(false);
filenamelb.setVisible(false);
filenametf.setVisible(false);
rename.setVisible(false);
submit2.setVisible(false);
filecreated.setVisible(false);
checkbox[0].setVisible(false);
checkbox[1].setVisible(false);
checkbox[2].setVisible(false);
checkbox[3].setVisible(false);
checkbox[4].setVisible(false);
checkbox[5].setVisible(false);
checkbox[6].setVisible(false);
checkbox[7].setVisible(false);
checkbox[8].setVisible(false);
checkbox[9].setVisible(false);
checkbox[10].setVisible(false);
selectlab.setVisible(false);
}
}

public void mousePressed(MouseEvent  me){}
public void mouseReleased(MouseEvent  me){}
public void mouseExited(MouseEvent  me){}

int speed=1;

public void actionPerformed(ActionEvent  ae)
{
String s=ae.getActionCommand();
com2=(Component)ae.getSource();

if(com2==proper)
{
companel.setVisible(true);
left.setVisible(true);
right.setVisible(true);
}else
if(com2==left)
{
companel.setBounds(15,122,170,420);
}else
if(com2==right)
{
companel.setBounds(604,129,170,420);
}else


if(com2==slow){speed=1;}else            
if(com2==bavg){speed=2;}else          
if(com2==aavg){speed=4;}else          
if(com2==fast){speed=8;}else             
if(com2==vfast){speed=16;}else        
     
if(com2==wi)
{d=com.getSize();com.setSize(d.width+speed,d.height);}
else
                                
if(com2==hi)
{d=com.getSize();com.setSize(d.width,d.height+speed);}
else

if(com2==wd)
{d=com.getSize();com.setSize(d.width-speed,d.height);}
else

if(com2==hd)
{d=com.getSize();com.setSize(d.width,d.height-speed);}
else

if(com2==color)
{
p.setVisible(true);
}else



if(s.equals(" "))
{
Button bttn=(Button)ae.getSource();

for(int i=1;i<=6;i++)
{
for(int j=1;j<=7;j++)
{
if(colorBt[i][j]==bttn)
{
if(comColor.getSelectedIndex()==0){com.setBackground(colorBt[i][j].getBackground());}
else
if(comColor.getSelectedIndex()==1){com.setForeground(colorBt[i][j].getBackground());}
else
{
setBackground(colorBt[i][j].getBackground());
framered=colorBt[i][j].getBackground().getRed();
frameblue=colorBt[i][j].getBackground().getBlue();
framegreen=colorBt[i][j].getBackground().getGreen();
}
break;
}
}
}
}

else




if(com2==st)             //  Add Text
{
int exc=0;

com.setFont(new Font(fname.getSelectedItem(),fstyle.getSelectedIndex(),Integer.parseInt(fsize.getSelectedItem())));

try
{
Button b=(Button)com;
b.setLabel(setText.getText());

exc=0;}
catch(Exception e){exc=1;}

if(exc==1)
{
try{TextField tff=(TextField)com;tff.setText(setText.getText());exc=0;}
catch(Exception e){exc=1;}
}
if(exc==1)
{
try{Checkbox cbb=(Checkbox)com;cbb.setLabel(setText.getText());exc=0;}
catch(Exception e){exc=1;}
}
if(exc==1)
{
try{Label lbb=(Label)com;lbb.setText(setText.getText());exc=0;}
catch(Exception e){exc=1;}
}
if(exc==1)
{
try{List lta=(List)com;lta.add(setText.getText(),Integer.parseInt(index.getText())-1);exc=0;}
catch(Exception e){exc=1;}
}
if(exc==1)
{
try{Choice cha=(Choice)com;cha.insert(setText.getText(),Integer.parseInt(index.getText())-1);exc=0;}
catch(Exception e){exc=1;}
}
}

else
if(com2==createfile)
{

filenamelb.setVisible(true);
filenametf.setVisible(true);
checkbox[0].setVisible(true);
checkbox[1].setVisible(true);
checkbox[2].setVisible(true);
checkbox[3].setVisible(true);
checkbox[4].setVisible(true);
checkbox[5].setVisible(true);
checkbox[6].setVisible(true);
checkbox[7].setVisible(true);
checkbox[8].setVisible(true);
checkbox[9].setVisible(true);
checkbox[10].setVisible(true);
selectlab.setVisible(true);
submit2.setVisible(true);
}

else
if(com2==submit2)
{
unitext=filenametf.getText();
filecreated.setVisible(true);
rename.setVisible(true);
try{
if(permission==1)
{

Result.first="";
Result.declaration="";
Result.memory="";
Result.listeners="";

rt.result();
}

}catch(Exception e){}
}
else




if(com2==remove)
{
int exc2=0;

try{
List ltr=(List)com;
ltr.remove(Integer.parseInt(index.getText())-1);
exc2=0;
}
catch(Exception e){exc2=1;}
if(exc2==1)
{
try{Choice chr=(Choice)com;chr.remove(Integer.parseInt(index.getText())-1);}
catch(Exception e){}
}
}







}//end of constructor







int rx=0,ry=0;
public void paint(Graphics g)
{
g.drawString("Point "+rx+" , "+ry,rx,ry);
}





public void mouseMoved(MouseEvent  me)
{
rx=me.getX();
ry=me.getY();

repaint();
}
public void mouseDragged(MouseEvent  me)
{
d=com.getSize();
com.setLocation(me.getX(),me.getY());

}


public void itemStateChanged(ItemEvent ie)
{
com=(Component)ie.getSource();
}

public void textValueChanged(TextEvent te)
{
try{
com=(Component)te.getSource();
}catch(Exception e){}
}

}
























class Result extends Frame 
{
static String first="";
static String declaration="";
static String memory="";
static String listeners="";
static int labcou=0;
static String labelstr="";
static int tfcou=0;
static String textfieldstr="";
static int cbcou=0;
static String checkboxstr="";
static int ltcou=0;
static String liststr="";
static int chcou=0;
static String choicestr="";
static int tacou=0;
static String textareastr="";
static int btncou=0;
static String buttonstr="";
Button bt[];
TextField tf[];
List lt[];
Choice ch[];
Checkbox cb[];
TextArea ta[];
Label lb[];
int changebt,changetf,comY=33,comH=20;


Result(Button bt[],TextField tf[],List lt[],Choice ch[],Checkbox cb[],TextArea ta[],Label lb[])throws IOException
{
this.bt=bt;
this.tf=tf;
this.lt=lt;
this.ch=ch;
this.cb=cb;
this.ta=ta;
this.lb=lb;
setSize(750,550);
setVisible(true);
}   //end of constructor


/*FileOutputStream fos=new FileOutputStream("Result.java");
DataOutputStream dos=new DataOutputStream(fos);
FileWriter fw=new FileWriter("Result.java");
BufferedWriter bw=new BufferedWriter(fw);*/




public void result()
{


repaint();

String al="",tl="";

first+="import java.awt.*;\nimport java.awt.event.*;\nimport javax.swing.*;\npublic class  "+Vjava.unitext+" extends JFrame";


if(btncou!=0)
{
declaration+="\nJButton button[]=new JButton["+btncou+"];";
memory+="\nfor(int i=0;i<"+btncou+";i=i+1)\n{\nbutton[i]=new JButton();\n}\n  ";
}

if(labcou!=0)
{
declaration+="\nJLabel label[]=new JLabel["+labcou+"];";
memory+="\nfor(int i=0;i<"+labcou+";i=i+1)\n{\nlabel[i]=new JLabel();\n}\n";
}

if(tfcou!=0)
{
declaration+="\nJTextField textfield[]=new JTextField["+tfcou+"];";
memory+="\nfor(int i=0;i<"+tfcou+";i=i+1)\n{\ntextfield[i]=new JTextField();\n}\n  ";
}

if(cbcou!=0)
{
declaration+="\nCheckbox checkbox[]=new Checkbox["+cbcou+"];";
memory+="\nfor(int i=0;i<"+cbcou+";i=i+1)\n{\ncheckbox[i]=new Checkbox();\n}\n  ";
}


if(tacou!=0)
{
declaration+="\nJTextArea textarea[]=new JTextArea["+tacou+"];";
memory+="\nfor(int i=0;i<"+tacou+";i=i+1)\n{\ntextarea[i]=new JTextArea();\n}\n  ";
}


if(chcou!=0)
{
declaration+="\nChoice choice[]=new Choice["+chcou+"];";
memory+="\nfor(int i=0;i<"+chcou+";i=i+1)\n{\nchoice[i]=new Choice();\n}\n  ";
}

if(ltcou!=0)
{
declaration+="\nList list[]=new List["+ltcou+"];";
memory+="\nfor(int i=0;i<"+ltcou+";i=i+1)\n{\nlist[i]=new List();\n}\n  ";
}
int cama=0;

for(int i=0;i<10;i++)
{
if(Vjava.checkbox[i].getState()==true)
{
first+="  implements ";
break;
}
}



if(Vjava.checkbox[0].getState()==true)
{
first+="  MouseListener";
listeners+="\n\n\npublic void mouseClicked(MouseEvent me){}";
listeners+="\npublic void mousePressed(MouseEvent me){}";
listeners+="\npublic void mouseReleased(MouseEvent me){}";
listeners+="\npublic void mouseEntered(MouseEvent me){}";
listeners+="\npublic void mouseExited(MouseEvent me){}";
cama=1;
}

if(Vjava.checkbox[10].getState()==true)
{
if(cama==1){first+=",MouseMotionListener";}else{first+="MouseMotionListener";}
listeners+="\n\n\npublic void mouseMoved(MouseEvent me){}";
listeners+="\npublic void mouseDragged(MouseEvent me){}";
cama=1;
}



if(Vjava.checkbox[1].getState()==true)
{
if(cama==1){first+=",KeyListener";}else{first+="KeyListener";}
listeners+="\n\n\npublic void keyTyped(KeyEvent me){}";
listeners+="\npublic void keyPressed(KeyEvent me){}";
listeners+="\npublic void keyReleased(KeyEvent me){}";
cama=1;
}

if(Vjava.checkbox[2].getState()==true)
{
if(cama==1){first+=",WindowListener";}else{first+="WindowListener";}
listeners+="\n\n\npublic void windowClosing(WindowEvent me){}";
listeners+="\npublic void windowClosed(WindowEvent me){}";
listeners+="\npublic void windowOpened(WindowEvent me){}";
listeners+="\npublic void windowIconified(WindowEvent me){}";
listeners+="\npublic void windowDeiconified(WindowEvent me){}";
listeners+="\npublic void windowActivated(WindowEvent me){}";
listeners+="\npublic void windowDeactivated(WindowEvent me){}";
cama=1;
}

if(Vjava.checkbox[3].getState()==true)
{
if(cama==1){first+=",ItemListener";}else{first+="ItemListener";}
listeners+="\n\n\npublic void itemStateChanged(ItemEvent me){}";
cama=1;
}

if(Vjava.checkbox[4].getState()==true)
{
if(cama==1){first+=",ActionListener";}else{first+="ActionListener";}
listeners+="\n\n\npublic void actionPerformed(ActionEvent me){}";
cama=1;
}

if(Vjava.checkbox[5].getState()==true)
{
if(cama==1){first+=",TextListener";}else{first+="TextListener";}
listeners+="\n\n\npublic void textValueChanged(TextEvent me){}";
cama=1;
}

if(Vjava.checkbox[6].getState()==true)
{
if(cama==1){first+=",FocusListener";}else{first+="FocusListener";}
listeners+="\n\n\npublic void focusGained(FocusEvent me){}";
listeners+="\npublic void focusLost(FocusEvent me){}";
cama=1;
}


if(Vjava.checkbox[7].getState()==true)
{
if(cama==1){first+=",ContainerListener";}else{first+="ContainerListener";}
listeners+="\n\n\npublic void componentAdded(ContainerEvent ce){}";
listeners+="\npublic void componentRemoved(ContainerEvent ce){}";
cama=1;
}


if(Vjava.checkbox[8].getState()==true)
{
if(cama==1){first+=",ComponentListener";}else{first+="ComponentListener";}
listeners+="\n\n\npublic void componentResized(ComponentEvent me){}";
listeners+="\npublic void componentMoved(ComponentEvent ce){}";
listeners+="\npublic void componentShown(ComponentEvent ce){}";
listeners+="\npublic void componentHidden(ComponentEvent ce){}";
}

if(Vjava.checkbox[9].getState()==true)
{
if(cama==1){first+=",AdjustmentListener";}else{first+="AdjustmentListener";}
listeners+="\n\n\npublic void adjustmentValueChanged(AdjustmentEvent ae){}";
cama=1;
}


first+="\n{";

String h="";

first+=declaration;
first+="\npublic static void main(String args[])\n{\nnew "+Vjava.unitext+"();\n}\n\n";

first+="\n"+Vjava.unitext+"()";
first+="\n{";
first+="\nsetLayout(null);";
first+=memory;
first+=labelstr;
first+=buttonstr;
first+=checkboxstr;
first+=textfieldstr;
first+=textareastr;
first+=liststr;
first+=choicestr;
first+="\n\n\nContainer c=getContentPane();\nc.setBackground(new Color("+Vjava.framered+","+Vjava.framegreen+","+Vjava.frameblue+"));\nsetSize(500,500);\nsetVisible(true);\n}";
first+=listeners+"\n}";

try{
FileOutputStream fos=new FileOutputStream(Vjava.unitext+".java");
DataOutputStream dos=new DataOutputStream(fos);
FileWriter fw=new FileWriter(Vjava.unitext+".java");
BufferedWriter bw=new BufferedWriter(fw);



StringBufferInputStream sb=new StringBufferInputStream(first);
DataInputStream dis=new DataInputStream(sb);


while((h=dis.readLine())!=null)
{
bw.flush();
bw.write(h,0,h.length());
bw.flush();
bw.newLine();
}
}catch(Exception e){}

}                                                            //end of result() 








int paintone=1;
public void paint(Graphics g)
{
int yy=45;
Dimension d=new Dimension();
Font f;
Color bg,fg;
comY=Vjava.comY;

labelstr="";
buttonstr="";
checkboxstr="";
textfieldstr="";
textareastr="";
liststr="";
choicestr="";

labcou=0;
tfcou=0;
cbcou=0;
ltcou=0;
chcou=0;
tacou=0;
btncou=0;



if(paintone==1)
{
g.setColor(new Color(0,0,255));
g.setFont(new Font("Serif",Font.BOLD+Font.ITALIC,72));
g.drawString("Manoj  Creations",110,185);
paintone++;
}








for(int i=1;i<=20;i++)
{
d=lb[i].getSize();
if(lb[i].getX()==114&&lb[i].getY()==comY&&d.width==90&&d.height==comH){changebt=0;}else{changebt=1;}

if(changebt==1)
{
f=lb[i].getFont();
bg=lb[i].getBackground();
fg=lb[i].getForeground();

g.drawString(lb[i].getText()+"   setBounds ( "+lb[i].getX()+","+lb[i].getY()+","+d.width+","+d.height+")      Font("+f.getFontName()+"  ,"+f.getSize()+");  BackColor("+bg.getRed()+","+bg.getGreen()+","+bg.getBlue()+")  ForeColor("+fg.getRed()+","+fg.getGreen()+","+fg.getBlue()+")",20,yy+=20);




labelstr+="\n\n\nlabel["+labcou+"]=new JLabel(\""+lb[i].getText()+"\");      ";
labelstr+="\nlabel["+labcou+"].setBounds("+lb[i].getX()+","+lb[i].getY()+","+d.width+","+d.height+");    "; 
labelstr+="\nlabel["+labcou+"].setFont(new Font(\"Serif\",3,"+f.getSize()+"));     "; 
labelstr+= "\nlabel["+labcou+"].setBackground(new Color("+bg.getRed()+","+bg.getGreen()+","+bg.getBlue()+"));    "; 
labelstr+=   "\nlabel["+labcou+"].setForeground(new Color("+fg.getRed()+","+fg.getGreen()+","+fg.getBlue()+"));    ";
labelstr+=   "\nadd(label["+labcou+"]);";
labcou++;
}

}//end of loop










yy+=25;
for(int i=1;i<=20;i++)
{
d=bt[i].getSize();
if(bt[i].getX()==8&&bt[i].getY()==comY&&d.width==102&&d.height==comH){changebt=0;}else{changebt=1;}
if(changebt==1)
{
f=bt[i].getFont();
bg=bt[i].getBackground();
fg=bt[i].getForeground();
g.drawString(bt[i].getLabel()+"   setBounds ( "+bt[i].getX()+","+bt[i].getY()+","+d.width+","+d.height+")  Font("+f.getFontName()+"  ,"+f.getSize()+")  BackColor("+bg.getRed()+","+bg.getGreen()+","+bg.getBlue()+")  ForeColor("+fg.getRed()+","+fg.getGreen()+","+fg.getBlue()+")",20,yy+=20);




buttonstr+="\n\n\n\nbutton["+btncou+"]=new JButton(\""+bt[i].getLabel()+"\");      ";
buttonstr+=   "\nbutton["+btncou+"].setBounds("+bt[i].getX()+","+bt[i].getY()+","+d.width+","+d.height+");    "; 
buttonstr+=   "\nbutton["+btncou+"].setFont(new Font(\"Serif\",3,"+f.getSize()+"));     "; 
buttonstr+=   "\nbutton["+btncou+"].setBackground(new Color("+bg.getRed()+","+bg.getGreen()+","+bg.getBlue()+"));    "; 
buttonstr+=   "\nbutton["+btncou+"].setForeground(new Color("+fg.getRed()+","+fg.getGreen()+","+fg.getBlue()+"));    ";
buttonstr+=   "\nadd(button["+btncou+"]);";
btncou++;

}
}//end of loop












yy+=25;

for(int i=1;i<=20;i++)
{
d=tf[i].getSize();
if(tf[i].getX()==340&&tf[i].getY()==comY&&d.width==114&&d.height==comH){changetf=0;}else{changetf=1;}
if(changetf==1)
{
f=tf[i].getFont();
bg=tf[i].getBackground();
fg=tf[i].getForeground();
g.drawString(tf[i].getText()+"  setBounds ( "+tf[i].getX()+","+tf[i].getY()+","+d.width+","+d.height+")   Font("+f.getFontName()+"  ,"+f.getSize()+")  BackColor("+bg.getRed()+","+bg.getGreen()+","+bg.getBlue()+")  ForeColor("+fg.getRed()+","+fg.getGreen()+","+fg.getBlue()+")",20,yy+=20);



textfieldstr+="\n\n\n\ntextfield["+tfcou+"]=new JTextField(\""+tf[i].getText()+"\");      ";
textfieldstr+=   "\ntextfield["+tfcou+"].setBounds("+tf[i].getX()+","+tf[i].getY()+","+d.width+","+d.height+");    "; 
textfieldstr+=   "\ntextfield["+tfcou+"].setFont(new Font(\"Serif\",3,"+f.getSize()+"));     "; 
textfieldstr+=   "\ntextfield["+tfcou+"].setBackground(new Color("+bg.getRed()+","+bg.getGreen()+","+bg.getBlue()+"));    "; 
textfieldstr+=   "\ntextfield["+tfcou+"].setForeground(new Color("+fg.getRed()+","+fg.getGreen()+","+fg.getBlue()+"));    ";
textfieldstr+=   "\nadd(textfield["+tfcou+"]);";
tfcou++;

}
}//end of loop





















yy+=25;

for(int i=1;i<=20;i++)
{
d=lt[i].getSize();
if(lt[i].getX()==569&&lt[i].getY()==comY&&d.width==98&&d.height==comH){changetf=0;}else{changetf=1;}
if(changetf==1)
{
 f=lt[i].getFont();
bg=lt[i].getBackground();
fg=lt[i].getForeground();
g.drawString(lt[i].getItem(0)+"   setBounds ( "+lt[i].getX()+","+lt[i].getY()+","+d.width+","+d.height+")   Font("+f.getFontName()+"  ,"+f.getSize()+")  BackColor("+bg.getRed()+","+bg.getGreen()+","+bg.getBlue()+")  ForeColor("+fg.getRed()+","+fg.getGreen()+","+fg.getBlue()+")",20,yy+=20);


liststr+="\n\n\n\nlist["+ltcou+"]=new List();      ";
liststr+=   "\nlist["+ltcou+"].setBounds("+lt[i].getX()+","+lt[i].getY()+","+d.width+","+d.height+");    "; 
liststr+=   "\nlist["+ltcou+"].setFont(new Font(\"Serif\",3,"+f.getSize()+"));     "; 
liststr+=   "\nlist["+ltcou+"].setBackground(new Color("+bg.getRed()+","+bg.getGreen()+","+bg.getBlue()+"));    "; 
liststr+=   "\nlist["+ltcou+"].setForeground(new Color("+fg.getRed()+","+fg.getGreen()+","+fg.getBlue()+"));    ";
liststr+=   "\nadd(list["+ltcou+"]);";
for(int j=0;j<lt[i].getItemCount();j++)
{
liststr+="\nlist["+ltcou+"].add(\""+ lt[i].getItem(j)+"\");";
}

ltcou++;

}

}//end of loop

















yy+=25;

for(int i=1;i<=20;i++)
{
d=ch[i].getSize();
if(ch[i].getX()==459&&ch[i].getY()==comY&&d.width==108&&d.height==21){changetf=0;}else{changetf=1;}
if(changetf==1)
{
f=ch[i].getFont();
bg=ch[i].getBackground();
fg=ch[i].getForeground();
g.drawString(ch[i].getItem(0)+"  setBounds ( "+ch[i].getX()+","+ch[i].getY()+","+d.width+","+d.height+")   Font("+f.getFontName()+"  ,"+f.getSize()+")  BackColor("+bg.getRed()+","+bg.getGreen()+","+bg.getBlue()+")  ForeColor("+fg.getRed()+","+fg.getGreen()+","+fg.getBlue()+")",20,yy+=20);


choicestr+="\n\n\n\nchoice["+chcou+"]=new Choice();    ";
choicestr+=   "\nchoice["+chcou+"].setBounds("+ch[i].getX()+","+ch[i].getY()+","+d.width+","+d.height+");    "; 
choicestr+=   "\nchoice["+chcou+"].setFont(new Font(\"Serif\",3,"+f.getSize()+"));     "; 
choicestr+=   "\nchoice["+chcou+"].setBackground(new Color("+bg.getRed()+","+bg.getGreen()+","+bg.getBlue()+"));    "; 
choicestr+=   "\nchoice["+chcou+"].setForeground(new Color("+fg.getRed()+","+fg.getGreen()+","+fg.getBlue()+"));    ";
choicestr+=   "\nadd(choice["+chcou+"]);";
for(int j=0;j<ch[i].getItemCount();j++)
{
choicestr+="\nchoice["+chcou+"].add(\""+ ch[i].getItem(j)+"\");";
}

chcou++;

}

}//end of loop











yy+=25;

for(int i=1;i<=20;i++)
{
d=cb[i].getSize();
if(cb[i].getX()==211&&cb[i].getY()==comY&&d.width==125&&d.height==comH){changetf=0;}else{changetf=1;}
if(changetf==1)
{
 f=cb[i].getFont();
 bg=cb[i].getBackground();
 fg=cb[i].getForeground();
g.drawString(cb[i].getLabel()+"  Bounds( "+cb[i].getX()+","+cb[i].getY()+","+d.width+","+d.height+");  Font("+f.getFontName()+"  ,"+f.getSize()+") ,state:"+cb[i].getState()+";  BackColor("+bg.getRed()+","+bg.getGreen()+","+bg.getBlue()+")  ForeColor("+fg.getRed()+","+fg.getGreen()+","+fg.getBlue()+")",20,yy+=20);



checkboxstr+="\n\n\n\ncheckbox["+cbcou+"]=new Checkbox(\""+cb[i].getLabel()+"\");      ";
checkboxstr+=   "\ncheckbox["+cbcou+"].setBounds("+cb[i].getX()+","+cb[i].getY()+","+d.width+","+d.height+");    "; 
checkboxstr+=   "\ncheckbox["+cbcou+"].setFont(new Font(\"Serif\",3,"+f.getSize()+"));     "; 
checkboxstr+=   "\ncheckbox["+cbcou+"].setBackground(new Color("+bg.getRed()+","+bg.getGreen()+","+bg.getBlue()+"));    "; 
checkboxstr+=   "\ncheckbox["+cbcou+"].setForeground(new Color("+fg.getRed()+","+fg.getGreen()+","+fg.getBlue()+"));    ";
checkboxstr+=   "\nadd(checkbox["+cbcou+"]);";
cbcou++;

}

}//end of loop











yy+=25;

for(int i=1;i<=20;i++)
{
d=ta[i].getSize();
if(ta[i].getX()==670&&ta[i].getY()==comY&&d.width==121&&d.height==38){changetf=0;}else{changetf=1;}


if(changetf==1)
{
int s=0;String s1="",              s2="";                s1=ta[i].getText();

for(s=0;s<20;s++){  if(s1.length()==s) {break;}   s2=s2+""+s1.charAt(s);  }

if(s==20){s2=s2+"......";}

f=ta[i].getFont();
bg=ta[i].getBackground();
fg=ta[i].getForeground();
g.drawString(s2+"    Bounds("+ta[i].getX()+","+ta[i].getY()+","+d.width+","+d.height+");  Font("+f.getFontName()+" ,"+f.getSize()+")   BackColor("+bg.getRed()+","+bg.getGreen()+","+bg.getBlue()+")  ForeColor("+fg.getRed()+","+fg.getGreen()+","+fg.getBlue()+")",10,yy+=20);


textareastr+="\n\n\n\ntextarea["+tacou+"]=new JTextArea(\""+ta[i].getText()+"\");";
textareastr+=   "\ntextarea["+tacou+"].setBounds("+ta[i].getX()+","+ta[i].getY()+","+d.width+","+d.height+");    "; 
textareastr+=   "\ntextarea["+tacou+"].setFont(new Font(\"Serif\",3,"+f.getSize()+"));     "; 
textareastr+=   "\ntextarea["+tacou+"].setBackground(new Color("+bg.getRed()+","+bg.getGreen()+","+bg.getBlue()+"));    "; 
textareastr+=   "\ntextarea["+tacou+"].setForeground(new Color("+fg.getRed()+","+fg.getGreen()+","+fg.getBlue()+"));    ";
textareastr+=   "\nadd(textarea["+tacou+"]);";
tacou++;
}


}//end of loop

}








}//end of class


