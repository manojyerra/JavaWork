import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class SuperButton extends Button
{
SuperButton(String str){}
public void paint(Graphics g)
{
g.drawImage(Toolkit.getDefaultToolkit().getImage("fire.jpg"),0,0,150,25,this);
}//end of paint
}// end of SuperButton class



class DXBallGame extends Frame  implements MouseMotionListener,MouseListener,WindowListener
{
ImageIcon ic1=new ImageIcon("man.gif");
JButton man=new JButton(ic1);    boolean manb=false;      boolean yetman=false;
ImageIcon ic2=new ImageIcon("ball.gif");
JButton ball=new JButton(ic2);    boolean ballb=false;      boolean yetball=false;
ImageIcon ic3=new ImageIcon("nero.gif");
JButton nero=new JButton(ic3);    boolean nerob=false;      boolean yetnero=false;
ImageIcon ic4=new ImageIcon("fox.gif");
JButton fox=new JButton(ic4);    boolean foxb=false;      boolean yetfox=false;
Toolkit tool=Toolkit.getDefaultToolkit();
Button peaces[]=new Button[5];



double per;int n=51;
boolean chaceLose=true;
Graphics g;int re=0;
int falseCount=0;
String str="";
Component com;
boolean chanceLose=true;
double cx=0.0,cy=0.0;
double x1=355,y1=484;
double incX=1.0,incY=-1.0;
Button bar=new SuperButton("");
Thread t;
Button brics[]=new Button[150];

 public  void windowOpened(java.awt.event.WindowEvent e){}
 public  void windowClosing(java.awt.event.WindowEvent e){System.exit(0);}
 public  void windowClosed(java.awt.event.WindowEvent e){}
 public  void windowIconified(java.awt.event.WindowEvent e){}
 public  void windowDeiconified(java.awt.event.WindowEvent e){}
 public  void windowActivated(java.awt.event.WindowEvent e){}
 public  void windowDeactivated(java.awt.event.WindowEvent e){}

public static void main(String asdf[]){new DXBallGame();}//end of main

DXBallGame()
{
setBackground(Color.green);
addWindowListener(this);
int px=50,py=50;
for(int i=1;i<=4;i++)
{
peaces[i]=new Button("");
if(i==1){  peaces[i].setBounds(px+5,py+2,25,10);}else
if(i==2){peaces[i].setBounds(px+35,py+2,25,10);}else
if(i==3){peaces[i].setBounds(px+5,py+14,25,10);}else
if(i==4){peaces[i].setBounds(px+35,py+14,25,10);}
peaces[i].setVisible(false);
peaces[i].setBackground(Color.black);
peaces[i].setForeground(Color.white);
add(peaces[i]);
}




t=Thread.currentThread();
addMouseMotionListener(this);
addMouseListener(this);
setLayout(null);

/*
Window w=new Window(this);
w.reshape(0,0,800,600);
w.show();
*/	

setBounds(0,0,800,570);
setVisible(true);
setTitle("                                                                                 Score  :   "+score);

//setBackground(Color.green);

int y=120,x=0,color=1;

for(int i=1;i<n;i++)
{
brics[i]=new Button();
if((color++)%2==0){brics[i].setBackground(Color.magenta);}
else{brics[i].setBackground(Color.red);}
brics[i].setBounds(50+(70*x++),y,70,25);
if(i%10==0){y=y+25;x=0;color--;}
}

man.setBounds(50+70*(2-1),120+(1*25),40,40);	man.setVisible(false);		add(man);
ball.setBounds(50+70*(6-1),120+(1*25),40,40);	ball.setVisible(false);		add(ball);
nero.setBounds(50+70*(8-1),120+(2*25),40,40);	nero.setVisible(false);	add(nero);
fox.setBounds(50+70*(7-1),120+(4*25),40,40);	fox.setVisible(false);		add(fox);

brics[1].setVisible(false);
brics[2].setVisible(false);
brics[3].setVisible(false);
brics[8].setVisible(false);
brics[11].setVisible(false);
brics[31].setVisible(false);
brics[41].setVisible(false);
brics[42].setVisible(false);
brics[43].setVisible(false);
brics[9].setVisible(false);
brics[10].setVisible(false);
brics[20].setVisible(false);
brics[40].setVisible(false);
brics[48].setVisible(false);
brics[49].setVisible(false);
brics[50].setVisible(false);
falseCount=16;


for(int i=1;i<n;i++){add(brics[i]);}


bar.setBounds(300,500,110,17);
//bar.setBackground(Color.gray);
bar.setBackground(Color.red);
add(bar);
t.suspend();
for(int i=1;i==1;)
{
re=1;repaint((int)(cx+x1),(int)(cy+y1),16,16);
cx=cx+incX;   	cy=cy+incY;
re=0;repaint((int)(cx+x1),(int)(cy+y1),16,16);
try{Thread.sleep(3);}catch(Exception e){}
aboutBric();

if(manb==true)
{man.setLocation(man.getX(),man.getY()+3);if(man.getY()>=500){manb=false;man.setVisible(false);}}
if(ballb==true)
{ball.setLocation(ball.getX(),ball.getY()+3);if(ball.getY()>=500){ballb=false;ball.setVisible(false);}}
if(nerob==true)
{nero.setLocation(nero.getX(),nero.getY()+3);if(nero.getY()>=500){nerob=false;nero.setVisible(false);}}
if(foxb==true)
{fox.setLocation(fox.getX(),fox.getY()+3);if(fox.getY()>=500){foxb=false;fox.setVisible(false);}}



if((x1+cx)>=780){incX=-incX;}else
if((y1+cy)<=30){incY=-incY;}else
if((x1+cx)<=0){incX=-incX;}else
if((y1+cy+16)>=500)
{
if(checkChance()){incY=-incY;}
else
{
try{Thread.sleep(1200);}catch(Exception e){}
re=1;repaint((int)(cx+x1),(int)(cy+y1),16,16);
incX=1;incY=-1;cx=0.0;cy=0.0;x1=355;y1=484;bar.setLocation(300,500);
re=0;repaint((int)(cx+x1),(int)(cy+y1),16,16);
chanceLose=true;
Thread.currentThread().suspend();


}
}

}//end of loop
}//end of constructor


boolean checkChance()
{if(x1+cx+8>(bar.getX()-15)&&x1+cx+8<(bar.getX()+125)){return(true);}else{return(false);}}//end of method


public void paint(Graphics g)
{
//g.drawImage(Toolkit.getDefaultToolkit().getImage("push3.jpg"),0,0,800,600,this);
if(re==1){
g.setColor(Color.green);g.fillOval((int)Math.round(x1+cx),(int)Math.round(y1+cy),0,0);
}else
if(re==0){g.setColor(Color.blue);g.fillOval((int)Math.round(x1+cx),(int)Math.round(y1+cy),16,16);
               g.setColor(Color.yellow);g.fillOval((int)Math.round(x1+cx+4),(int)Math.round(y1+cy+4),8,8);}
else        {g.setFont(new Font("TimesRoman",1,30));g.drawString("Game Over",300,250);}

}//end of paint

int score=0;

void breaks(int px,int py)
{
setTitle("                                                                                 Score  :   "+score);

score=score+10;

for(int i=1;i<=4;i++)
{
if(i==1){peaces[i].setLocation(px+5,py+2);}else
if(i==2){peaces[i].setLocation(px+35,py+2);}else
if(i==3){peaces[i].setLocation(px+5,py+14);}else
if(i==4){peaces[i].setLocation(px+35,py+14);}
peaces[i].setVisible(true);
}
try{Thread.sleep(35);}catch(Exception e){}
for(int i=1;i<=4;i++)
{
if(i==1){peaces[i].setLocation(px+5,py+2);}else
if(i==2){peaces[i].setLocation(px+35,py+2);}else
if(i==3){peaces[i].setLocation(px+5,py+14);}else
if(i==4){peaces[i].setLocation(px+35,py+14);}
peaces[i].setVisible(false);
}
}




boolean aboutBric()
{
com=getComponentAt((int)(x1+cx+8),(int)(y1+cy));
if(brics[12].isVisible()==false && yetman==false){man.setVisible(true);manb=true;yetman=true;}//end of if
if(brics[16].isVisible()==false && yetball==false){ball.setVisible(true);ballb=true;yetball=true;}//end of if
if(brics[28].isVisible()==false && yetnero==false){nero.setVisible(true);nerob=true;yetnero=true;}//end of if
if(brics[47].isVisible()==false && yetfox==false){fox.setVisible(true);foxb=true;yetfox=true;}//end of if


if(com!=this)
{
if(com!=bar&&com.isVisible()==true)
{tool.beep();com.setVisible(false);
breaks(com.getX(),com.getY());
incY=-incY;falseCount++;return(true);}
}

com=getComponentAt((int)(x1+cx),(int)(y1+cy+8));

if(com!=this)
{
if(com!=bar&&com.isVisible()==true)
{tool.beep();com.setVisible(false);
breaks(com.getX(),com.getY());
incX=-incX;falseCount++;return(true);}
}


com=getComponentAt((int)(x1+cx+16),(int)(y1+cy+8));


if(com!=this)
{
if(com!=bar&&com.isVisible()==true)
{tool.beep();com.setVisible(false);
breaks(com.getX(),com.getY());
incX=-incX;falseCount++;return(true);}
}

com=getComponentAt((int)(x1+cx+8),(int)(y1+cy+16));

if(com!=this)
{
if(com!=bar&&com.isVisible()==true)
{tool.beep();com.setVisible(false);
breaks(com.getX(),com.getY());
incY=-incY;falseCount++;return(true);}
}


if(falseCount==n-1){bar.setVisible(false);re=2;repaint();Thread.currentThread().suspend();}

return(false);
}//end of method


public void mouseMoved(MouseEvent e)
{
if(chanceLose==false)
{
if(e.getX()>50&&e.getX()<750){bar.setLocation(e.getX()-55,500);}
}
}//end of Moved
public void mouseDragged(MouseEvent e){System.out.println("coming");}//end of Dragged
public void mouseEntered(MouseEvent e){}
public void mouseClicked(MouseEvent e)
{
if(chanceLose==true)
{
t.resume();chanceLose=false;
}
}//end of mouseClicked
public void mousePressed(MouseEvent e){}
public void mouseReleased(MouseEvent e){}
public void mouseExited(MouseEvent e){}


}//end of class

