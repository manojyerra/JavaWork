import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import java.util.Random;

public class SuperSudokuOne extends Frame implements ActionListener,KeyListener,MouseMotionListener
{
int totalCount=0,noOfLoops=20;
BufferedWriter bw;
FileWriter fw;
TextField tf[][]=new TextField[20][20];
Button b=new Button("Result");
Button clr=new Button("Clear");
Button clrAns=new Button("ClearAnswers");
Button open=new Button("Open");
Button save=new Button("Save");
List lst=new List();

public void keyTyped(KeyEvent ke){}//end of keyTyped
public void keyPressed(KeyEvent ke){}//end of keyTyped
int fcx=1,fcy=1;

Random rn=new Random();
int rnx=0,rny=0;
String pNo="";
int countPick=0;

public boolean canPick(int i,int j)
{
int ti=0,ty=0,r,c;
r=i;c=j;

try{
for(int iii=1;iii<=16;iii++){arr[iii]=0;}
for(int k=1;k<=16;k++){
if(tf[i][k].getText().trim().equals("")==false){
arr[get(tf[i][k].getText().trim())]=get(tf[i][k].getText().trim());
}//end of if condition
}//end of k th loop 


for(int k=1;k<=16;k++){
if(tf[k][j].getText().trim().equals("")==false){
arr[get(tf[k][j].getText().trim())]=get(tf[k][j].getText().trim());
}//end of if condition
}//end of k th loop 

if(r%4==0){r=r-3;}else{r=r-(r%4-1);}
if(c%4==0){c=c-3;}else{c=c-(c%4-1);}

for(int a=r;a<=r+3;a++){
for(int b=c;b<=c+3;b++){
if(tf[a][b].getText().trim().equals("")==false)
{arr[get(tf[a][b].getText().trim())]=get(tf[a][b].getText().trim());}//end of if condition
}//end of j th loop
}//end of i th loop 

}catch(Exception e){}


countPick=0;
for(int k=1;k<=16;k++)
{
if(arr[k]==0){countPick++;}
}//end of k th loop
if(countPick==1){return(true);}else{return(false);}
}//end of canPick()

int serial=345;



public void keyReleased(KeyEvent ke)
{
int code=ke.getKeyCode();
if(code==38){--fcx;if(fcx>=1){tf[fcx][fcy].requestFocus();}else{fcx=1;}}else
if(code==37){--fcy;if(fcy>=1){tf[fcx][fcy].requestFocus();}else{fcy=1;}}else
if(code==40){++fcx;if(fcx<=16){tf[fcx][fcy].requestFocus();}else{fcx=16;}}else
if(code==39){++fcy;if(fcy<=16){tf[fcx][fcy].requestFocus();}else{fcy=16;}}else
if(code==17)
{
int inc=0;
for(int files=1;files<lst.getItemCount();files++)
{

lst.select(files);
actionPerformed(new ActionEvent(open,1,"Open"));
for(int one_to_8=1;one_to_8<16;one_to_8++)
{
for(int i=1;i<=16;i++){for(int j=1;j<=16;j++)
{
if(tf[i][j].getText().equals("")==false)
{
inc=get(tf[i][j].getText());
inc=inc+one_to_8;
if(inc>16){inc=inc-15;}
tf[i][j].setText(set(inc));
}//end of if condition
}}//end of i,j th loops

for(int onefile=1;onefile<10;onefile++)
{
actionPerformed(new ActionEvent(open,1,"Open"));
dummy();
for(int i=1;i<=16;i++){for(int j=1;j<=16;j++){tf[i][j].setBackground(Color.white);tf[i][j].setForeground(Color.black);}}
normalPick();
int totalno=0;
if((totalno=completePick())<256)
{
serial++;
setTitle(""+(serial-83));
gnSave(totalno+"_"+lst.getSelectedItem()+"_"+serial);}//end of if(completePick())}//end of if
}//end of  onefile th loop


}//end of one_to_8 th loop
}//end of files th loop
}//end of if(code==17)

}//end of keyTyped


public void gnSave(String name)
{
String saveStr=name;
try{
fw=new FileWriter(saveStr+".ssdk");
bw=new BufferedWriter(fw);
for(int i=1;i<=16;i++){
for(int j=1;j<=16;j++)
{
if(tf[i][j].getText().trim().equals("")){bw.flush();bw.write("-",0,1);bw.newLine();}else
{bw.flush();bw.write(tf[i][j].getText().trim(),0,1);bw.newLine();}
}//end of j th loop
}//end of i th loop
bw.flush();
lst.add(saveStr);
}catch(Exception exce){}
}//end of gnSave()




public int completePick()
{
int returnCount=0;
for(int i=1;i<=16;i++){
for(int j=1;j<=16;j++){

if(tf[i][j].getText().equals("")==false)
{
pNo=tf[i][j].getText();	tf[i][j].setText("");		dummy();
if(isEnd()==false)	{tf[i][j].setText(pNo);}//end of  if(checkForEnd()==false)
actionPerformed(new ActionEvent(clrAns,1,"ClearAnswer"));
}//end of if(tf[i][j].getText().equals("")==false)


if(tf[j][i].getText().equals("")==false)
{
pNo=tf[j][i].getText();	tf[j][i].setText("");		dummy();
if(isEnd()==false)	{tf[j][i].setText(pNo);}//end of  if(checkForEnd()==false)
actionPerformed(new ActionEvent(clrAns,1,"ClearAnswer"));
}//end of if(tf[i][j].getText().equals("")==false)


if(tf[17-i][17-j].getText().equals("")==false)
{
pNo=tf[17-i][17-j].getText();	tf[17-i][17-j].setText("");		dummy();
if(isEnd()==false)	{tf[17-i][17-j].setText(pNo);}//end of  if(checkForEnd()==false)
actionPerformed(new ActionEvent(clrAns,1,"ClearAnswer"));
}//end of if(tf[i][j].getText().equals("")==false)

}//end of i th loop
}//end of j th loop

for(int i=1;i<=16;i++){for(int j=1;j<=16;j++){if(tf[i][j].getText().equals("")==false){returnCount++;}}}
return(returnCount);
}//end of completePick()


public void normalPick()
{
for(int i=0;i<400;i++)
{
rnx=Math.abs(rn.nextInt()%17);		rny=Math.abs(rn.nextInt()%17);
if(rnx!=0&&rny!=0&&tf[rnx][rny].getText().equals("")==false)
{
pNo=tf[rnx][rny].getText().trim();	tf[rnx][rny].setText("");
if(canPick(rnx,rny)==false){	tf[rnx][rny].setText(""+pNo);	  }//end of else
}//end of if(rnx!=0&&rny!=0)
}//end of loop

for(int i=1;i<=16;i++){
for(int j=1;j<=16;j++){
if(tf[i][j].getText().equals("")==false)
{
pNo=tf[i][j].getText().trim();	tf[i][j].setText("");
if(canPick(i,j)==false)		{tf[i][j].setText(set(get(pNo)));  }
}//end of  if(tf[i][j].getText().equals("")==false) 
}//end of j th loop
}//end of i th loop

}//end of normalPick()





public static void main(String args[]) throws Exception  {new SuperSudokuOne();}//end of main

int arr[]=new int[20];
int res[][][]=new int[20][20][20];
int op,count=0,count2=0,count1=0,countOP3=0,ii,jj,aa;


public void finalOP()
{
int r=0,c=0;
for(int k=1;k<=16;k++)
{
if(k==1){r=1;c=1;}   if(k==2){r=1;c=5;}   if(k==3){r=1;c=9;} if(k==4){r=1;c=13;}  
if(k==5){r=5;c=1;}   if(k==6){r=5;c=5;}   if(k==7){r=5;c=9;} if(k==8){r=5;c=13;}  
if(k==9){r=9;c=1;}   if(k==10){r=9;c=5;}  if(k==11){r=9;c=9;}if(k==12){r=9;c=13;}   
if(k==13){r=13;c=1;} if(k==14){r=13;c=5;}if(k==15){r=13;c=9;}if(k==16){r=13;c=13;}   

for(int i=r;i<=r+3;i++)
{
for(int j=c;j<=c+3;j++)
{
for(int a=1;a<=16;a++)
{
if(res[i][j][a]!=0)
{
op=res[i][j][a];
count=0;
for(int ii=r;ii<=r+3;ii++)
{
for(int jj=c;jj<=c+3;jj++)
{
for(int aa=1;aa<=16;aa++)
{
if(res[i][j][a]!=0)
{
if(op==res[ii][jj][aa]){count++;}   if(count>1){break;}
}//end of if (inner)
}//end of aa th loop
if(count>1){break;}
}//end of jj th loop
if(count>1){break;}
}//end of ii th loop 

if(count==1){
tf[i][j].setForeground(foreColor);
tf[i][j].setBackground(backColor);
tf[i][j].setText(set(op));
}

}//end of if condition
}//end of a th loop
}//end of j th loop
}//end of i th loop 
}//end of k th loop
}//end of finalOP method 








public void finalOP2()
{
int r=0,c=0,op=0;

for(int i=1;i<=16;i++)
{
for(int j=1;j<=16;j++)
{
for(int a=1;a<=16;a++)
{
if(res[i][j][a]!=0)
{
op=res[i][j][a];count1=0;

for( jj=1;jj<=16;jj++)
{
for( aa=1;aa<=16;aa++)
{
if(op==res[i][jj][aa]){count1++; if(count1>1){break;}}
}//end of aa th loop
 if(count1>1){break;}
}//end of jj th loop

if(count1==1){
tf[i][j].setForeground(foreColor);
tf[i][j].setBackground(backColor);
tf[i][j].setText(set(op));
}//end of if(count1==1)

}//end of if condition
}//end of a th loop
}//end of j th loop
}//end of i th loop
}//end of finalOP method 







public void finalOP3()
{
int r=0,c=0,op=0;

for(int j=1;j<=16;j++)
{
for(int i=1;i<=16;i++)
{
for(int a=1;a<=16;a++)
{
if(res[i][j][a]!=0)
{
op=res[i][j][a];countOP3=0;

for( ii=1;ii<=16;ii++)
{
for( aa=1;aa<=16;aa++)
{
if(op==res[ii][j][aa]){countOP3++; if(countOP3>1){break;}}
}//end of aa th loop
 if(countOP3>1){break;}
}//end of ii th loop



if(countOP3==1){
tf[i][j].setForeground(foreColor);
tf[i][j].setBackground(backColor);
tf[i][j].setText(set(op));
}


}//end of if condition
}//end of a th loop
}//end of j th loop
}//end of i th loop
}//end of finalOP method 





int option2[][][]=new int[20][20][3];

public void twoOptions()
{
int twise=0,first=0,second=0;
for(int x=1;x<=16;x++)
{
for(int y=1;y<=16;y++)
{
twise=0;first=0;second=0;
for(int z=1;z<=16;z++)
{

if(res[x][y][z]!=0&&tf[x][y].getText().trim().equals(""))
{
if(first==0){first=z;}else{second=z;}
twise++;
}//end of if condition
if(twise==2){option2[x][y][1]=first;option2[x][y][2]=second;}
}//end of z th loop
}//end of y th loop 
}//end of x th loop
}//end of method twoOptions


public void actionPerformed(ActionEvent e)
{
foreColor=Color.red;
backColor=Color.yellow;
msg="";
setTitle("Sudoku Game  by Y.Manoj  ");



if(e.getSource()==save)
{
String saveStr= JOptionPane.showInputDialog("Enter File Name ");
try{
fw=new FileWriter(saveStr+".ssdk");
bw=new BufferedWriter(fw);
for(int i=1;i<=16;i++){
for(int j=1;j<=16;j++)
{
if(tf[i][j].getText().trim().equals("")){bw.flush();bw.write("-",0,1);bw.newLine();}else
{bw.flush();bw.write(tf[i][j].getText().trim(),0,1);bw.newLine();}
}//end of j th loop
}//end of i th loop
bw.flush();
lst.add(saveStr);
}catch(Exception exce){}
}//end of if(e.getSource()==save)

if(e.getSource()==open)
{
String text="";
try{
BufferedReader br1=new BufferedReader(new FileReader(lst.getSelectedItem()+".ssdk"));
for(int i=1;i<=16;i++){
for(int j=1;j<=16;j++){
tf[i][j].setText("");tf[i][j].setBackground(Color.white);tf[i][j].setForeground(Color.black);
}//end of i th loop
}//end of i th loop

for(int i=1;i<=16;i++){
for(int j=1;j<=16;j++)
{
text=br1.readLine();
if(text.equals("-")==false){tf[i][j].setText(text);}
}//end of i th loop
}//end of i th loop
}catch(Exception exce){}
}//end if(e.getSource()==open)


if(e.getSource()==lst)
{
String text="";
try{
System.out.println(lst.getSelectedItem()+".ssdk");
BufferedReader br2=new BufferedReader(new FileReader(lst.getSelectedItem()+".ssdk"));
System.out.println("okok");

for(int i=1;i<=16;i++){
for(int j=1;j<=16;j++){
tf[i][j].setText("");tf[i][j].setBackground(Color.white);tf[i][j].setForeground(Color.black);
}//end of j th loop
}//end of i th loop

for(int i=1;i<=16;i++){
for(int j=1;j<=16;j++)
{
text=br2.readLine();
if(text.equals("-")==false){tf[i][j].setText(text);}
}//end of j th loop
}//end of i th loop
}catch(Exception exce){System.out.println("Exception"+exce);}
}//end if(e.getSource()==lst)



if(e.getSource()==clr)
{
totalCount=0;
for(int i=1;i<=16;i++)
{
for(int j=1;j<=16;j++)
{
tf[i][j].setText("");tf[i][j].setForeground(Color.black);
tf[i][j].setBackground(Color.white);
}//end j th of loop
}//end i th of loop
}//end of if condition  (e.getSource()==clr)

if(e.getSource()==clrAns)
{
totalCount=0;
for(int i=1;i<=16;i++)
{
for(int j=1;j<=16;j++)
{
if(tf[i][j].getForeground().getRGB()==(Color.red).getRGB()||tf[i][j].getBackground().getRGB()==(Color.yellow).getRGB())
{
tf[i][j].setText("");tf[i][j].setForeground(Color.black);
tf[i][j].setBackground(Color.white);
}//end of if condition
}//end j th of loop
}//end i th of loop
}//end of if condition  (e.getSource()==clrAns)


if(e.getSource()==b)
{
totalCount=0;prvCount=0;curCount=0;
dummy();
int first=0,second=0,twise=0;
int one1=0,two2=0,three3=0,thrice=0;
int resCon[][][]=new int[20][20][20];

for(int i=1;i<=16;i++)
{
for(int j=1;j<=16;j++)
{
for(int k=1;k<=16;k++)
{
resCon[i][j][k]=res[i][j][k];
}//end of k th loop
}//end of j th loop
}//end of i th loop

twoOptions();


if(checkForEnd()==false)
{
setTitle("Invalid Sudoku by Y.Manoj (Which is manually not possible)");
for(int i=1;i<=16;i++)
{
for(int j=1;j<=16;j++)
{
if(tf[i][j].getText().trim().equals("")==false)
{
tf[i][j].setForeground(Color.black);
}//end    of    if(tf[i][j].getText().trim().equals("")==false)
}//end of i th loop
}//end of j th loop


for(int x=1;x<=16;x++)
{
for(int y=1;y<=16;y++)
{
twise=0;first=0;second=0;
for(int z=1;z<=16;z++)
{
if(resCon[x][y][z]!=0&&tf[x][y].getText().trim().equals(""))
{
if(first==0){first=z;}
else
{second=z;}
twise++;
}//end of if condition
}//end of z th loop


if(twise==2)
{
if(checkForEnd()==false)
{
tf[x][y].setForeground(Color.red);
tf[x][y].setBackground(Color.yellow);
tf[x][y].setText(set(first));
totalCount=0;prvCount=0;curCount=0;
clearRes();
dummy();


if(checkForEnd()==false)
{
storeFirst();
clearExcOne();
}//end of if (checkForEnd()==false)
}//end of if (checkForEnd()==false)

if(checkForEnd()==false)
{
tf[x][y].setForeground(Color.red);
tf[x][y].setBackground(Color.yellow);
tf[x][y].setText(set(second));
totalCount=0;prvCount=0;curCount=0;
clearRes();for(int arrloop=1;arrloop<=16;arrloop++){arr[arrloop]=0;}
dummy();

if(checkForEnd()==false)
{
foreColor=Color.red;	                backColor=Color.yellow;
storeSecond();  equalInTrail(); 
clearExcOne();
}//end of if (checkForEnd()==false)
}//end of if (checkForEnd()==false)
}//end of if (twise==2)

}//end of y th loop 
}//end of x th loop 
}//end of if condition


if(checkForEnd()==false)
{
for(int x=1;x<=16;x++)
{
for(int y=1;y<=16;y++)
{
thrice=0;one1=0;two2=0;three3=0;
for(int z=1;z<=16;z++)
{
if(resCon[x][y][z]!=0&&tf[x][y].getText().trim().equals(""))
{
if(one1==0){one1=z;}
else
if(two2==0){two2=z;}
else
{three3=z;}
thrice++;
}//end of if condition
}//end of z th loop


if(thrice==3)
{
if(checkForEnd()==false)
{
tf[x][y].setForeground(Color.red);
tf[x][y].setBackground(Color.yellow);
tf[x][y].setText(set(one1));
totalCount=0;prvCount=0;curCount=0;
clearRes();
dummy();
if(checkForEnd()==false)
{storeFirst();
clearExcOne();
}//end of if (checkForEnd()==false)
}//end of if (checkForEnd()==false)

if(checkForEnd()==false)
{
tf[x][y].setForeground(Color.red);
tf[x][y].setBackground(Color.yellow);
tf[x][y].setText(set(two2));
totalCount=0;prvCount=0;curCount=0;
clearRes();
dummy();
if(checkForEnd()==false)
{storeSecond();
clearExcOne();
}//end of if (checkForEnd()==false)
}//end of if (checkForEnd()==false)


if(checkForEnd()==false)
{
tf[x][y].setForeground(Color.red);
tf[x][y].setBackground(Color.yellow);
tf[x][y].setText(set(three3));
totalCount=0;prvCount=0;curCount=0;
clearRes();for(int arrloop=1;arrloop<=16;arrloop++){arr[arrloop]=0;}
dummy();
if(checkForEnd()==false)
{
storeThird();  equalInTrailFor3();
clearExcOne();
}//end of if (checkForEnd()==false)
}//end of if (checkForEnd()==false)

}//end of if (three==3)

}//end of y th loop 
}//end of x th loop 
}//end of if(checkForEnd()==false)  for  trail  3 

}//end of if condition (e.getSource()==b)



if(checkForEnd()&&e.getSource()==b)
{
setTitle("Manoj's idea got Solution Successfully");
msg="Yahooo..! Manoj's idea got Solution Successfully";
JOptionPane.showMessageDialog(null,msg,"Result",JOptionPane.INFORMATION_MESSAGE);
System.out.println("Solution has Ended Successfully");
}//end of if(checkForEnd())  condition 
else
if(e.getSource()==b)
{
msg="Solution is not possible";
JOptionPane.showMessageDialog(null,msg,"Result",JOptionPane.INFORMATION_MESSAGE);
System.out.println(" Solution is not possible  according to Manoj ");
}


}//end of actionPerformed 





int strFir[][]=new int[20][20];
int strSec[][]=new int[20][20];
public void storeFirst()
{
for(int i=1;i<=16;i++){for(int j=1;j<=16;j++){strFir[i][j]=0;}}
for(int i=1;i<=16;i++){
for(int j=1;j<=16;j++)
{
if(tf[i][j].getForeground().getRGB()==Color.red.getRGB() && tf[i][j].getText().trim().equals("")==false)
{
strFir[i][j]=get(tf[i][j].getText().trim());
}
}}

}//end of method storeFirst()







public void storeSecond()
{
for(int i=1;i<=16;i++){for(int j=1;j<=16;j++){strSec[i][j]=0;}}
for(int i=1;i<=16;i++){
for(int j=1;j<=16;j++){

if(tf[i][j].getForeground().getRGB()==Color.red.getRGB() && tf[i][j].getText().trim().equals("")==false)
{strSec[i][j]=get(tf[i][j].getText().trim());}
}}

}//end of method storeSecond()









int strThi[][]=new int[20][20];
public void storeThird()
{
for(int i=1;i<=16;i++){for(int j=1;j<=16;j++){strThi[i][j]=0;}}
for(int i=1;i<=16;i++){
for(int j=1;j<=16;j++){

if(tf[i][j].getForeground().getRGB()==Color.red.getRGB() && tf[i][j].getText().trim().equals("")==false)
{strThi[i][j]=get(tf[i][j].getText().trim());}
}}
}//end of method storeThird()



public void equalInTrail()
{
for(int i=1;i<=16;i++){
for(int j=1;j<=16;j++){
if(strFir[i][j]!=0&&strSec[i][j]!=0)
{
if(strFir[i][j]==strSec[i][j])
{
tf[i][j].setForeground(Color.pink);
tf[i][j].setText(set(strSec[i][j]));
}//end of if(strFir[i][j]==strSec[i][j])
}//end of if(strFir[i][j]!=0&&strSec[i][j]!=0)
}}
}//end of method equalaInTrail


public void equalInTrailFor3()
{
for(int i=1;i<=16;i++){
for(int j=1;j<=16;j++){
if(strFir[i][j]!=0&&strSec[i][j]!=0&&strThi[i][j]!=0)
{
if(strFir[i][j]==strSec[i][j]&&strSec[i][j]==strThi[i][j])
{
tf[i][j].setForeground(Color.pink);
tf[i][j].setText(set(strSec[i][j]));
}//end of if(strFir[i][j]==strSec[i][j])
}//end of if(strFir[i][j]!=0&&strSec[i][j]!=0)
}}
}//end of method equalaInTrail




public void clearExcOne()
{
totalCount=0;
for(int i=1;i<=16;i++)
{
for(int j=1;j<=16;j++)
{
if(tf[i][j].getForeground().getRed()==255&&tf[i][j].getForeground().getGreen()==0&&tf[i][j].getForeground().getBlue()==0)
{
tf[i][j].setText("");tf[i][j].setForeground(Color.black);
tf[i][j].setBackground(Color.white);
}//end of if condition
}//end j th of loop
}//end i th of loop
}//end of method clearExcOne




String msg="";

public void clearRes()
{
for(int one=1;one<=16;one++){
for(int two=1;two<=16;two++){
for(int three=1;three<=16;three++){
res[one][two][three]=0;
}}}//end of loops
}//end of method clearRes()








public void dummy()
{
clearRes();

for(int i=1;i<=16;i++)
{
for(int j=1;j<=16;j++)
{
if(tf[i][j].getText().trim().equals(""))
{
try{
rowFill(i);
blockFill(i,j);
colFill(j,i);
}catch(Exception exc){}
}//end of if condition 
}//end of  j th  loop 
}//end of  i th  loop 


finalOP();
finalOP2();
finalOP3();
totalCount++;
System.out.println("\n\ntotal Count = "+totalCount+"\n\n");

if(curCount==prvCount&&curCount!=0&&prvCount!=0){totalCount=noOfLoops;}
prvCount=curCount;


if(checkForEnd()){totalCount=noOfLoops;}//end of inner if condition
else
if(totalCount<noOfLoops ){dummy();}

}//end of dummy method


public boolean isEnd()
{
for(int loop1=1;loop1<=16;loop1++)
{
for(int loop2=1;loop2<=16;loop2++)
{
if(tf[loop1][loop2].getText().equals("") ){return(false);}
}//end of loop1 th loop 
}//end of loop2 th loo
return(true);
}//end of method()







int prvCount=0,curCount=0;

public boolean checkForEnd()
{
boolean boo=true;
curCount=0;

for(int loop1=1;loop1<=16;loop1++)
{
for(int loop2=1;loop2<=16;loop2++)
{
if( tf[loop1][loop2].getText().trim().equals("") ){curCount++;boo=false;}
}//end of loop1 th loop 
}//end of loop2 th loop 

if(boo==true)
{
boo=clearCheck();
}//end of if(boo==true)
return(boo);
}//end of method checkForEnd()





public boolean  clearCheck()
{
int r_c[]=new int[20];
int val=0;
for(int loop1=1;loop1<=16;loop1++)
{
for(int temp=1;temp<=16;temp++){r_c[temp]=0;}
for(int loop2=1;loop2<=16;loop2++)
{
val=get(tf[loop1][loop2].getText().trim());
r_c[val]=val;
}//end of loop2 th loop 
for(int temp=1;temp<=16;temp++){if(r_c[temp]==0){return(false);}}
}//end of loop1 th loop 

for(int loop2=1;loop2<=16;loop2++)
{
for(int temp=1;temp<=16;temp++){r_c[temp]=0;}
for(int loop1=1;loop1<=16;loop1++)
{
val=get(tf[loop1][loop2].getText().trim());
r_c[val]=val;
}//end of loop1 th loop 
for(int temp=1;temp<=16;temp++){if(r_c[temp]==0){return(false);}}
}//end of loop2 th loop 
return(true);
}//end of method clearCheck()



public void rowFill(int i) throws Exception
{
for(int iii=1;iii<=16;iii++){arr[iii]=0;}
for(int k=1;k<=16;k++)
{
if(tf[i][k].getText().trim().equals("")==false)
{
arr[get(tf[i][k].getText().trim())]=get(tf[i][k].getText().trim());
}//end of if condition
}//end of k th loop 
}//end of rowFill method 





public void blockFill(int r,int c) throws Exception
{
if(r%4==0){r=r-3;}else{r=r-(r%4-1);}
if(c%4==0){c=c-3;}else{c=c-(c%4-1);}

for(int i=r;i<=r+3;i++)
{
for(int j=c;j<=c+3;j++)
{
if(tf[i][j].getText().trim().equals("")==false)

{arr[get(tf[i][j].getText().trim())]=get(tf[i][j].getText().trim());}//end of if condition

}//end of j th loop
}//end of i th loop 
}//end of blockFill method 






String str="";



public void colFill(int j,int i)  throws Exception
{
for(int k=1;k<=16;k++)
{
if(tf[k][j].getText().trim().equals("")==false)
{
arr[get(tf[k][j].getText().trim())]=get(tf[k][j].getText().trim());
}//end of if condition
}//end of k th loop 
int op2=0;

for(int a=1;a<=16;a++)
{
if(arr[a]==0)
{
res[i][j][a]=a;
count2++;
op2=a;
}
}
if(count2==1)
{
tf[i][j].setForeground(foreColor);
tf[i][j].setBackground(backColor);
tf[i][j].setText(set(op2));
}
count2=0;
}//end of colFill method 

Color foreColor=Color.red;
Color backColor=Color.yellow;


public void mouseMoved(MouseEvent me){}//end of mouseMoved()
public void mouseDragged(MouseEvent me)
{
p.setLocation(me.getX(),me.getY());
}//end of mouseMoved()

class WindowCloser extends WindowAdapter
{public void windowClosing(WindowEvent we){System.exit(1);}}//end of inner class

Panel p=new Panel();
public SuperSudokuOne() throws Exception
{
int disX=0,disY=0,yaxe=420,xaxe=110;
setLayout(null);
addMouseMotionListener(this);

addWindowListener(new WindowCloser());

lst.setBounds(425,0,150,450);
lst.addActionListener(this);
lst.setBackground(Color.white);
p.add(lst);


File temp=new File("temp.txt");
if(temp.exists()==false){temp.createNewFile();}
String absPath=temp.getAbsolutePath();
String path="";

for(int i=0;i<(absPath.indexOf("temp.txt")-1);i++)
{
path=path+""+absPath.charAt(i);
}//end of  i th loop


File allFiles=new File(path);
allFiles.mkdir();
String allNames[]=allFiles.list();
String path1="";


for(int i=0;i<allNames.length;i++)
{
if(allNames[i].endsWith(".ssdk"))
{
path1="";
for(int j=0;j<(allNames[i].indexOf(".ssdk"));j++)
{path1=path1+""+allNames[i].charAt(j);}//end of  i th loop
lst.add(path1);
}//end of if(allNames[i].endsWith(".ssdk")) 
}//end of i th for loop 




p.setBounds(150,80,575,450);
p.setBackground(Color.magenta);
p.setLayout(null);
add(p);

open.setBounds(xaxe+161,yaxe,60,25);
open.addActionListener(this);
p.add(open);

save.setBounds(xaxe+245,yaxe,60,25);
save.addActionListener(this);
p.add(save);

b.setBounds(xaxe-30,yaxe,50,25);
b.addActionListener(this);
p.add(b);

clr.setBounds(xaxe-100,yaxe,50,25);
clr.addActionListener(this);
p.add(clr);

clrAns.setBounds(xaxe+40,yaxe,100,25);
clrAns.addActionListener(this);
p.add(clrAns);

for(int i=1;i<=16;i++)
{
for(int j=1;j<=16;j++)
{
tf[i][j]=new TextField();
tf[i][j].addKeyListener(this);
tf[i][j].setBounds(5+(disX)+((j-1)*25)  ,  5+(disY)+((i-1)*25),25,25);
tf[i][j].setFont(new Font("TimesRoman",1,14));
p.add(tf[i][j]);
if(j%4==0){disX=disX+5;}
}
disX=0;
if(i%4==0){disY=disY+4;}
}

setBounds(0,0,800,600);
setVisible(true);
setTitle(" Sudoku Game  by Y.Manoj  ");
setBackground(Color.cyan);
}//end of constructor


public int get(String str)
{
if(str.equals("a")||str.equals("A")){return(11);}else
if(str.equals("b")||str.equals("B")){return(12);}else
if(str.equals("c")||str.equals("C")){return(13);}else
if(str.equals("d")||str.equals("D")){return(14);}else
if(str.equals("e")||str.equals("E")){return(15);}else
if(str.equals("f")||str.equals("F")){return(16);}else
{return(  (Integer.parseInt(str)+1)   );}
}//end of get method 

public String set(int no)
{
if(no<=10){return(""+(no-1));}else
if(no==11){return("A");}else
if(no==12){return("B");}else
if(no==13){return("C");}else
if(no==14){return("D");}else
if(no==15){return("E");}else
{return("F");}
}//end of set method 
}//end of class