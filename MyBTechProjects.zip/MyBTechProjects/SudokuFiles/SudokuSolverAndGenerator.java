import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import java.util.Random;

public class SudokuSolverAndGenerator extends Frame implements ActionListener,KeyListener,MouseMotionListener,TextListener
{
int exHardNo=2,hardNo=3;
Color colo;
int hardQ[][][]={
{
{0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,8,0,0,0,0},
{0,0,0,0,0,2,0,6,0,0},
{0,0,3,0,0,0,0,0,5,0},
{0,6,0,0,0,0,0,0,0,2},
{0,0,0,2,9,0,1,7,0,0},
{0,0,0,0,0,0,0,5,9,0},
{0,0,0,1,0,6,0,2,0,0},
{0,0,9,7,5,0,0,0,0,8},
{0,0,0,0,0,0,0,0,0,7}
}
,
{
{0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,8,0,0,0,0,0},
{0,5,0,0,0,0,0,2,0,6},
{0,0,0,4,3,0,0,7,0,0},
{0,0,6,0,0,3,0,0,0,0},
{0,0,0,0,6,0,0,0,9,2},
{0,0,1,0,0,4,0,0,0,0},
{0,0,8,0,0,1,0,0,3,0},
{0,0,0,0,0,0,0,0,5,9},
{0,0,0,1,0,0,7,0,0,0}
}
,
{
{0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,9,0,0,0,1,0},
{0,0,0,8,0,3,0,0,0,0},
{0,0,0,0,0,8,0,0,0,7},
{0,0,0,6,0,0,0,0,9,5},
{0,0,0,4,0,0,3,2,0,0},
{0,0,0,0,0,4,1,0,0,0},
{0,0,1,0,0,7,0,8,0,0},
{0,0,8,2,0,0,0,6,4,0},
{0,0,0,0,0,0,0,0,0,0}
}
};




int question[][][]={ 
{
{0,0,0,0,0,0,0,0,0,0},
{0,8,1,9,3,7,4,2,6,5},
{0,7,4,6,5,2,1,8,9,3},
{0,5,2,3,8,9,6,4,1,7},
{0,1,7,8,6,4,3,9,5,2},
{0,9,3,2,7,8,5,1,4,6},
{0,4,6,5,2,1,9,3,7,8},
{0,3,5,4,1,6,8,7,2,9},
{0,2,8,1,9,5,7,6,3,4},
{0,6,9,7,4,3,2,5,8,1}
}
, 

{
{0,0,0,0,0,0,0,0,0,0},
{0,3,5,7,6,4,9,2,8,1},
{0,6,2,9,1,8,3,7,5,4},
{0,1,4,8,7,5,2,9,6,3},
{0,5,7,4,2,1,8,3,9,6},
{0,2,8,1,3,9,6,5,4,7},
{0,9,6,3,4,7,5,1,2,8},
{0,8,9,6,5,3,7,4,1,2},
{0,4,3,5,8,2,1,6,7,9},
{0,7,1,2,9,6,4,8,3,5}
}



};
	


int totalCount=0,noOfLoops=17;
BufferedWriter bw;
FileWriter fw;

TextField tf[][]=new TextField[10][10];
long timestart=0;
long timeend=0;


int tfa[][]=new int[10][10];
int tffc[][]=new int[10][10];
int tfbc[][]=new int[10][10];

int red=1,white=2,yellow=3,black=4,pink=5,fColor=0,bColor=0;


Button b=new Button("Result");
Button clr=new Button("Clear");
Button clrAns=new Button("ClearAnswers");
Button open=new Button("Open");
Button save=new Button("Save");
Button gn=new Button("Generate");
Button hint=new Button("Hint");
Button delete=new Button("Delete");
Button rename=new Button("Rename");

Choice level=new Choice();

List lst=new List();

public void keyTyped(KeyEvent ke){}//end of keyTyped
public void keyPressed(KeyEvent ke){}//end of keyTyped
int fcx=1,fcy=1;

Random rn=new Random();
int rnx=0,rny=0;
int pNo;
int countPick=0;
int serial=0;
ChangeAnswer ca=new ChangeAnswer();

public boolean canPick(int i,int j)
{int ti=0,ty=0,r,c;
r=i;c=j;
try{	for(int iii=1;iii<=9;iii++){arr[iii]=0;}
for(int k=1;k<=9;k++){if(tfa[i][k]!=0){arr[tfa[i][k]]=tfa[i][k];}}//end k th loop 
for(int k=1;k<=9;k++){if(tfa[k][j]!=0){arr[tfa[k][j]]=tfa[k][j];}}//end k th loop 
if(r%3==0){r=r-2;}else{r=r-(r%3-1);}	if(c%3==0){c=c-2;}else{c=c-(c%3-1);}
for(int a=r;a<=r+2;a++){
for(int b=c;b<=c+2;b++){
if(tfa[a][b]!=0){arr[tfa[a][b]]=tfa[a][b];}//end of if condition
}}//end of i,j th loops 
}catch(Exception e){}
countPick=0;
for(int k=1;k<=9;k++){if(arr[k]==0){countPick++;}}//end of k th loop
if(countPick==1){return(true);}else{return(false);}
}//end of canPick()

public void initialize()
{
for(int i=1;i<=9;i++)
{for(int j=1;j<=9;j++)
{
tfa[i][j]=0;tffc[i][j]=black;tfbc[i][j]=white;
tf[i][j].setText("");
tf[i][j].setBackground(Color.white);
tf[i][j].setForeground(Color.black);
}}
}//end of initialize() method





int arrNo=0;
public void generate(int rangeStart,int rangeEnd)
{
initialize();
if(level.getSelectedItem().equals("VeryHard"))
{
arrNo=Math.abs(rn.nextInt()%hardNo);
for(int i=1;i<=9;i++){for(int j=1;j<=9;j++){tfa[i][j]=hardQ[arrNo][i][j];}}
tfa=ca.getAnswer(tfa);
serial++;
for(int i=1;i<=9;i++){for(int j=1;j<=9;j++){if(tfa[i][j]!=0){tf[i][j].setText(""+tfa[i][j]);}}}
}
else
{
int totalno=0;
do{
arrNo=Math.abs(rn.nextInt()%exHardNo);
for(int i=1;i<=9;i++){for(int j=1;j<=9;j++){tfa[i][j]=question[arrNo][i][j];}}
normalPick();	totalno=0;
totalno=completePick();
if(totalno<=rangeEnd)
{
tfa=ca.getAnswer(tfa);
serial++;
for(int i=1;i<=9;i++){for(int j=1;j<=9;j++){if(tfa[i][j]!=0){tf[i][j].setText(""+tfa[i][j]);}}}
}//end of if condition
}while(totalno>rangeEnd);
}

}//end of method generate()






TextField box; int xaxe,yaxe;

public void textValueChanged(TextEvent te)
{
box=(TextField)te.getSource();
String msg="";
boolean error=false;
if(box.getText().equals("")==false)
{
int from1to9=1;
try{from1to9=Integer.parseInt(box.getText());}catch(Exception exc){error=true;}
if(error==false){if(from1to9<1||from1to9>9){error=true;}}

if(error==false)
{getXY(box);
if(rowCheck(xaxe,yaxe,from1to9)==false){msg="In row "+from1to9+" is already came";  error=true;  }
}//end of if(error==false)

if(error==false)
{
if(colCheck(xaxe,yaxe,from1to9)==false){msg="In coloumn "+from1to9+" is already came";  error=true;}
}//end of if(error==false)

if(error==false)
{
if(blockCheck(xaxe,yaxe,from1to9)==false){msg="In block "+from1to9+" is already came";  error=true;}
}//end of if(error==false)

if(error==true)
{
Color r=box.getBackground();
box.setBackground(Color.red);
if(msg.equals(""))
{
JOptionPane.showMessageDialog(null,"Invalid Entrie(Check spaces and <1 or >9 number may Entered) ","Invalid Entrie",JOptionPane.INFORMATION_MESSAGE);
}
else
{
JOptionPane.showMessageDialog(null,"Invalid Entrie  "+msg,"Invalid Entrie",JOptionPane.INFORMATION_MESSAGE);
}
box.setBackground(r);
box.setText("");
}//end of if(error==true)


}//end of if(box.getText().equals("")==false)
}//end of textValueChanged()

public boolean getXY(Object box)
{
for(int i=1;i<=9;i++)
{
for(int j=1;j<=9;j++)
{
if(box==tf[i][j]){xaxe=i;yaxe=j;return(false);}
}//end of j th loop
}//end of i th loop
return(false);
}//end of method getXY()

public boolean rowCheck(int x,int y,int z)
{
for(int i=1;i<=9;i++)
{
if(tf[x][i].getText().equals("")==false)
{
if(Integer.parseInt(tf[x][i].getText())==z&&y!=i){return(false);}
}
}//end of i th loop
return(true);
}//end of rowCheck()


public boolean colCheck(int x,int y,int z)
{
for(int i=1;i<=9;i++)
{
if(tf[i][y].getText().equals("")==false)
{
if(Integer.parseInt(tf[i][y].getText())==z&&x!=i){return(false);}
}
}//end of i th loop
return(true);
}//end of colCheck()



public boolean blockCheck(int r,int c,int z)
{
int realR=r,realC=c;
if(r%3==0){r=r-2;}else{r=r-(r%3-1);}
if(c%3==0){c=c-2;}else{c=c-(c%3-1);}

for(int i=r;i<=r+2;i++)
{
for(int j=c;j<=c+2;j++)
{
if(tf[i][j].getText().equals("")==false)
{
if(Integer.parseInt(tf[i][j].getText())==z&&realR!=i&&realC!=j){return(false);}
}
}//end of j th loop
}//end of i th loop 
return(true);
}//end of blockCheck() method 






public void keyReleased(KeyEvent ke)
{
int code=ke.getKeyCode();
if(code==38){--fcx;if(fcx>=1){tf[fcx][fcy].requestFocus();}else{fcx=1;}}else
if(code==37){--fcy;if(fcy>=1){tf[fcx][fcy].requestFocus();}else{fcy=1;}}else
if(code==40){++fcx;if(fcx<=9){tf[fcx][fcy].requestFocus();}else{fcx=9;}}else
if(code==39){++fcy;if(fcy<=9){tf[fcx][fcy].requestFocus();}else{fcy=9;}}


}//end of keyTyped

public void gnSave(String name)
{
String saveStr=name;
try{
fw=new FileWriter(saveStr+".sdk");
bw=new BufferedWriter(fw);
for(int i=1;i<=9;i++){
for(int j=1;j<=9;j++)
{
if(tfa[i][j]==0){bw.flush();bw.write("0",0,1);bw.newLine();}else
{bw.flush();bw.write(""+tfa[i][j],0,1);bw.newLine();}
}//end of j th loop
}//end of i th loop
bw.flush();
setTitle("                      "+serial+" sudokus are created ");
}catch(Exception exce){}
}//end of gnSave()






public int completePick()
{
int returnCount=0;
int noCount=0;
boolean loopend=false;
for(int i=1;i<=9;i++){
if(loopend==true){break;}
for(int j=1;j<=9;j++){

noCount=0;
for(int ii=1;ii<=9;ii++){for(int jj=1;jj<=9;jj++){if(tfa[ii][jj]!=0){noCount++;}}}

/*
if(level.getSelectedItem().equals("VeryEasy")){if(noCount>=33&&noCount<=36){loopend=true;  break;}}else
if(level.getSelectedItem().equals("Easy")){if(noCount>=30&&noCount<=33){loopend=true;  break; }}else
if(level.getSelectedItem().equals("Medium")){if(noCount>=27&&noCount<=30){loopend=true;   break; }}
*/

if(level.getSelectedItem().equals("VeryEasy")){if(noCount<=36){loopend=true;  break;}}else
if(level.getSelectedItem().equals("Easy")){if(noCount<=33){loopend=true;  break; }}else
if(level.getSelectedItem().equals("Medium")){if(noCount<=30){loopend=true;   break; }}



if(tfa[i][j]!=0)
{pNo=tfa[i][j];	tfa[i][j]=0;	dummy();
if(isEnd()==false)	{tfa[i][j]=pNo;}//end of  if(checkForEnd()==false)
gnClrAns();
}//end of if(tf[i][j].getText().equals("")==false)

if(tfa[j][i]!=0)
{
pNo=tfa[j][i];	tfa[j][i]=0;		dummy();
if(isEnd()==false)	{tfa[j][i]=pNo;}	      //end of  if(checkForEnd()==false)
gnClrAns();
}//end of if(tf[i][j].getText().equals("")==false)

if(tfa[10-i][10-j]!=0)
{
pNo=tfa[10-i][10-j];	tfa[10-i][10-j]=0;		dummy();
if(isEnd()==false)	{tfa[10-i][10-j]=pNo;}         //end of  if(checkForEnd()==false)
gnClrAns();
}//end of if(tf[i][j].getText().equals("")==false)

}//end of i th loop


}//end of j th loop

for(int i=1;i<=9;i++){for(int j=1;j<=9;j++){if(tfa[i][j]!=0){returnCount++;}}}

return(returnCount);
}//end of completePick()




public void normalPick()
{
for(int i=0;i<400;i++)
{
rnx=Math.abs(rn.nextInt()%10);		rny=Math.abs(rn.nextInt()%10);
if(rnx!=0&&rny!=0&&tfa[rnx][rny]!=0)
{
pNo=tfa[rnx][rny];	             tfa[rnx][rny]=0;
if(canPick(rnx,rny)==false){    tfa[rnx][rny]=pNo;  }

}//end of if(rnx!=0&&rny!=0)
}//end of loop

for(int i=1;i<10;i++){
for(int j=1;j<10;j++){
if(tfa[i][j]!=0)
{
pNo=tfa[i][j];			tfa[i][j]=0;
if(canPick(i,j)==false)		{tfa[i][j]=pNo;  }
}//end of  if(tf[i][j].getText().equals("")==false) 
}//end of j th loop
}//end of i th loop

}//end of normalPick()





public void gnClrAns()
{
totalCount=0;
for(int i=1;i<=9;i++){
for(int j=1;j<=9;j++){
if(tffc[i][j]==red)
{tfa[i][j]=0;	tffc[i][j]=black;}//end of if condition
}//end j th of loop
}//end i th of loop
}//end of gnClrAns() method



public void gnOpen()
{
String text="";
try{
BufferedReader br1=new BufferedReader(new FileReader(lst.getSelectedItem()+".sdk"));
for(int i=1;i<=9;i++){
for(int j=1;j<=9;j++){
tfa[i][j]=0;tffc[i][j]=black;
}//end of i th loop
}//end of i th loop
for(int i=1;i<=9;i++){
for(int j=1;j<=9;j++){
text=br1.readLine();
if(text.equals("0")==false){tfa[i][j]=Integer.parseInt(text);}
}//end of i th loop
}//end of i th loop
}catch(Exception exce){}
}//end of gnOpen() method


public static void main(String args[]) throws Exception  {new SudokuSolverAndGenerator();}//end of main

int arr[]=new int[10];
int res[][][]=new int[10][10][10];
int op,count=0,count2=0,count1=0,countOP3=0,ii,jj,aa;


public void finalOP()
{int r=0,c=0;
for(int k=1;k<=9;k++){
if(k==1){r=1;c=1;}   if(k==2){r=1;c=4;}   if(k==3){r=1;c=7;}  
if(k==4){r=4;c=1;}   if(k==5){r=4;c=4;}   if(k==6){r=4;c=7;} 
if(k==7){r=7;c=1;}   if(k==8){r=7;c=4;}   if(k==9){r=7;c=7;}   

for(int i=r;i<=r+2;i++){
for(int j=c;j<=c+2;j++){
for(int a=1;a<=9;a++){
if(res[i][j][a]!=0){
op=res[i][j][a];
count=0;
for(int ii=r;ii<=r+2;ii++){
for(int jj=c;jj<=c+2;jj++){
for(int aa=1;aa<=9;aa++){
if(res[i][j][a]!=0){
if(op==res[ii][jj][aa]){count++;}   if(count>1){break;}
}//end of if (inner)
}//end of aa th loop
if(count>1){break;}
}//end of jj th loop
if(count>1){break;}
}//end of ii th loop 

if(count==1)
{
tffc[i][j]=red;
tfbc[i][j]=yellow;
tfa[i][j]=op;

if(hintboo==true)
{
if(tf[i][j].getText().equals(""))
{
tf[i][j].setBackground(Color.red);
hintInBlockWise(op,i,j);

/*
JOptionPane.showMessageDialog(null,"Block wise you can fill "+op+" in ("+i+","+j+") cell ","Result",JOptionPane.INFORMATION_MESSAGE);
*/

}
tf[i][j].setBackground(Color.white);
hintboo=false;
}//end of if(hintboo==true)
}

}//end of if condition
}//end of a th loop
}//end of j th loop
}//end of i th loop 
}//end of k th loop
}//end of finalOP method 






public void finalOP2()
{
int r=0,c=0,op=0;
for(int i=1;i<=9;i++){
for(int j=1;j<=9;j++){
for(int a=1;a<=9;a++){
if(res[i][j][a]!=0)
{
op=res[i][j][a];count1=0;
for( jj=1;jj<=9;jj++){
for( aa=1;aa<=9;aa++){
if(op==res[i][jj][aa]){count1++; if(count1>1){break;}}
}//end of aa th loop
 if(count1>1){break;}
}//end of jj th loop


if(count1==1){

if(hintboo==true)
{
if(tf[i][j].getText().equals(""))
{
tf[i][j].setBackground(Color.red);
hintInRowWise(op,i,j);
}
tf[i][j].setBackground(Color.white);
hintboo=false;
}//end of if(hintboo==true)

tffc[i][j]=red;
tfbc[i][j]=yellow;
tfa[i][j]=op;
//System.out.println(i+" , "+ j +" = "+ op);
}

}//end of if condition
}//end of a th loop
}//end of j th loop
}//end of i th loop
}//end of finalOP method 







public void finalOP3()
{
int r=0,c=0,op=0;

for(int j=1;j<=9;j++)
{
for(int i=1;i<=9;i++)
{
for(int a=1;a<=9;a++)
{
if(res[i][j][a]!=0)
{
op=res[i][j][a];countOP3=0;

for( ii=1;ii<=9;ii++)
{
for( aa=1;aa<=9;aa++)
{
if(op==res[ii][j][aa]){countOP3++; if(countOP3>1){break;}}
}//end of aa th loop
 if(countOP3>1){break;}
}//end of ii th loop



if(countOP3==1)
{
if(hintboo==true)
{
if(tf[i][j].getText().equals(""))
{
tf[i][j].setBackground(Color.red);
hintInColWise(op,i,j);

/*
JOptionPane.showMessageDialog(null,"Coloumn wise you can fill "+op+"  in  ("+i+","+j+") cell ","Result",JOptionPane.INFORMATION_MESSAGE);
*/

}

tf[i][j].setBackground(Color.white);
hintboo=false;
}//end of if(hintboo==true)

//System.out.println(i+" , "+ j +" = "+ op);
tffc[i][j]=red;
tfbc[i][j]=yellow;
tfa[i][j]=op;
}


}//end of if condition
}//end of a th loop
}//end of j th loop
}//end of i th loop
}//end of finalOP method 



int option2[][][]=new int[10][10][3];

public void twoOptions()
{
int twise=0,first=0,second=0;
for(int x=1;x<=9;x++)
{
for(int y=1;y<=9;y++)
{
twise=0;first=0;second=0;
for(int z=1;z<=9;z++)
{

if(res[x][y][z]!=0&&tfa[x][y]==0)
{
if(first==0){first=z;}else{second=z;}
twise++;
}//end of if condition
if(twise==2){option2[x][y][1]=first;option2[x][y][2]=second;}
}//end of z th loop
}//end of y th loop 
}//end of x th loop
}//end of method twoOptions

boolean hintboo=false;

public void actionPerformed(ActionEvent e)
{
foreColor=Color.red;
backColor=Color.yellow;
msg="";
repaint();
setTitle("Sudoku Game  by Y.Manoj  ");

if(e.getSource()==save)
{
String saveStr= JOptionPane.showInputDialog("Enter File Name ");
try{
fw=new FileWriter("SudokuPuzzels\\"+saveStr+".sdk");
bw=new BufferedWriter(fw);
for(int i=1;i<=9;i++){
for(int j=1;j<=9;j++)
{
if(tf[i][j].getText().trim().equals("")){bw.flush();bw.write("0",0,1);bw.newLine();}else
{bw.flush();bw.write(""+tf[i][j].getText().trim(),0,1);bw.newLine();}
}//end of j th loop
}//end of i th loop
bw.flush();
lst.add(saveStr);
}catch(Exception exce){}
}//end of if(e.getSource()==save)

if(e.getSource()==open)
{
String text="";
try{
File f=new File("SudokuPuzzels");
f.mkdir();
BufferedReader br1=new BufferedReader(new FileReader(f.getAbsolutePath()+"\\"+lst.getSelectedItem()+".sdk"));



for(int i=1;i<=9;i++){
for(int j=1;j<=9;j++){
tf[i][j].setText("");tf[i][j].setBackground(Color.white);tf[i][j].setForeground(Color.black);
tfa[i][j]=0;tffc[i][j]=black;tfbc[i][j]=white;
}//end of i th loop
}//end of i th loop

for(int i=1;i<=9;i++){
for(int j=1;j<=9;j++)
{
text=br1.readLine();
if(text.equals("0")==false){tf[i][j].setText(text);tfa[i][j]=Integer.parseInt(text);}
}//end of i th loop
}//end of i th loop
}catch(Exception exce){System.out.println("File error ");}
}//end if(e.getSource()==open)


if(e.getSource()==lst)
{
String text="";
try{
File f=new File("SudokuPuzzels");
f.mkdir();
BufferedReader br2=new BufferedReader(new FileReader(f.getAbsolutePath()+"\\"+lst.getSelectedItem()+".sdk"));

for(int i=1;i<=9;i++){
for(int j=1;j<=9;j++){
tf[i][j].setText("");tf[i][j].setBackground(Color.white);tf[i][j].setForeground(Color.black);
tfa[i][j]=0;tffc[i][j]=black;tfbc[i][j]=white;
}//end of j th loop
}//end of i th loop

for(int i=1;i<=9;i++){
for(int j=1;j<=9;j++)
{
text=br2.readLine();
if(text.equals("0")==false){tf[i][j].setText(text);tfa[i][j]=Integer.parseInt(text);}
}//end of j th loop
}//end of i th loop
}catch(Exception exce){System.out.println("Exception"+exce);}
}//end if(e.getSource()==lst)



if(e.getSource()==clr)
{
totalCount=0;
for(int i=1;i<=9;i++)
{
for(int j=1;j<=9;j++)
{
tf[i][j].setText("");tf[i][j].setForeground(Color.black);
tf[i][j].setBackground(Color.white);
tfa[i][j]=0;tffc[i][j]=black;tfbc[i][j]=white;
}//end j th of loop
}//end i th of loop
}//end of if condition  (e.getSource()==clr)




if(e.getSource()==clrAns)
{
totalCount=0;
for(int i=1;i<=9;i++)
{
for(int j=1;j<=9;j++)
{
tffc[i][j]=black;tfbc[i][j]=white; 
if(tf[i][j].getBackground().getRGB()!=Color.white.getRGB())
{
tf[i][j].setText("");tf[i][j].setForeground(Color.black);
tf[i][j].setBackground(Color.white);
tfa[i][j]=0;tffc[i][j]=black;tfbc[i][j]=white;
}//end of if condition
}//end j th of loop
}//end i th of loop
}//end of if condition  (e.getSource()==clrAns)

if(e.getSource()==gn)
{
if(level.getSelectedItem().equals("VeryEasy")){generate(33,36);}else
if(level.getSelectedItem().equals("Easy")){generate(30,33);}else
if(level.getSelectedItem().equals("Medium")){generate(27,30);}else
if(level.getSelectedItem().equals("Hard")){generate(24,27);}else
if(level.getSelectedItem().equals("VeryHard")){generate(21,24);}
}//end of  if(e.getSource()==gn)

if(e.getSource()==delete)
{
File f=new File("SudokuPuzzels");
f.mkdir();
File f2=new File(f.getAbsolutePath()+"\\"+lst.getSelectedItem()+".sdk");

if(f2.delete())
{lst.remove(lst.getSelectedItem());}
else
{
JOptionPane.showMessageDialog(null,lst.getSelectedItem()+" is unable to delete ","Result",JOptionPane.INFORMATION_MESSAGE);
}

}//end of  if(e.getSource()==delete)



if(e.getSource()==rename)
{
File f=new File("SudokuPuzzels");
f.mkdir();
File f2=new File(f.getAbsolutePath()+"\\"+lst.getSelectedItem()+".sdk");

String str= JOptionPane.showInputDialog("Enter File Name ");

if(f2.renameTo(new File(f.getAbsolutePath()+"\\"+str+".sdk"))    )
{
lst.replaceItem(str,lst.getSelectedIndex());
}
else
{
JOptionPane.showMessageDialog(null,lst.getSelectedItem()+" is unable to rename ","Result",JOptionPane.INFORMATION_MESSAGE);
}

}//end of  if(e.getSource()==rename)







if(e.getSource()==hint)
{
hintboo=true;
for(int i=1;i<=9;i++)
{
for(int j=1;j<=9;j++)
{
if(tf[i][j].getForeground().getRGB()==Color.red.getRGB()){tffc[i][j]=red;}else
if(tf[i][j].getForeground().getRGB()==Color.pink.getRGB()){tffc[i][j]=pink;}else
if(tf[i][j].getForeground().getRGB()==Color.black.getRGB()){tffc[i][j]=black;}
if(tf[i][j].getBackground().getRGB()==Color.yellow.getRGB()){tfbc[i][j]=yellow;}else
if(tf[i][j].getBackground().getRGB()==Color.white.getRGB()){tfbc[i][j]=white;}
if(tf[i][j].getText().trim().equals("")==false){tfa[i][j]=Integer.parseInt(tf[i][j].getText().trim());}
else{tfa[i][j]=0;}
}// end of j th loop
}//end of i th loop
dummy();


if(hintboo==true) { JOptionPane.showMessageDialog(null,"Manually Not possible ,No Hints available  ","Result",JOptionPane.INFORMATION_MESSAGE); } 
hintboo=false;
}//end of if(e.getSource()==hint)


if(e.getSource()==b)
{
timestart=System.currentTimeMillis();
totalCount=0;prvCount=0;curCount=0;

for(int i=1;i<=9;i++)
{
for(int j=1;j<=9;j++)
{
if(tf[i][j].getForeground().getRGB()==Color.red.getRGB()){tffc[i][j]=red;}else
if(tf[i][j].getForeground().getRGB()==Color.pink.getRGB()){tffc[i][j]=pink;}else
if(tf[i][j].getForeground().getRGB()==Color.black.getRGB()){tffc[i][j]=black;}
if(tf[i][j].getBackground().getRGB()==Color.yellow.getRGB()){tfbc[i][j]=yellow;}else
if(tf[i][j].getBackground().getRGB()==Color.white.getRGB()){tfbc[i][j]=white;}

if(tf[i][j].getText().trim().equals("")==false){tfa[i][j]=Integer.parseInt(tf[i][j].getText().trim());}
else{tfa[i][j]=0;}

}// end of j th loop
}//end of i th loop


dummy();
int first=0,second=0,twise=0;
int one1=0,two2=0,three3=0,thrice=0;
int resCon[][][]=new int[10][10][10];

for(int i=1;i<=9;i++)
{
for(int j=1;j<=9;j++)
{
for(int k=1;k<=9;k++)
{
resCon[i][j][k]=res[i][j][k];
}//end of k th loop
}//end of j th loop
}//end of i th loop

twoOptions();


if(checkForEnd()==false)
{
setTitle("Invalid Sudoku by Y.Manoj (Which is manually not possible)");
for(int i=1;i<=9;i++)
{
for(int j=1;j<=9;j++)
{
if(tfa[i][j]!=0)
{
tffc[i][j]=black;
//tf[i][j].setForeground(Color.black);
}//end    of    if(tf[i][j].getText().trim().equals("")==false)
}//end of i th loop
}//end of j th loop


for(int x=1;x<=9;x++)
{
for(int y=1;y<=9;y++)
{
twise=0;first=0;second=0;
for(int z=1;z<=9;z++)
{
if(resCon[x][y][z]!=0&&tfa[x][y]==0)
{
if(first==0){first=z;}
else
{second=z;}
twise++;
}//end of if condition

}//end of z th loop

if(twise==2)
{
//System.out.println("First =  "+first+" ,  Second  =  "+second);

if(checkForEnd()==false)
{
tfa[x][y]=first;
tffc[x][y]=red;
tfbc[x][y]=yellow;

//tf[x][y].setForeground(Color.red);
//tf[x][y].setBackground(Color.yellow);
//tf[x][y].setText(""+first);

totalCount=0;prvCount=0;curCount=0;
clearRes();
dummy();


if(checkForEnd()==false)
{
storeFirst();
clearExcOne();
}//end of if (checkForEnd()==false)
}//end of if (checkForEnd()==false)

if(checkForEnd()==false)
{
tfa[x][y]=second;
tffc[x][y]=red;
tfbc[x][y]=yellow;

//tf[x][y].setForeground(Color.red);
//tf[x][y].setBackground(Color.yellow);
//tf[x][y].setText(""+second);

totalCount=0;prvCount=0;curCount=0;
clearRes();for(int arrloop=1;arrloop<=9;arrloop++){arr[arrloop]=0;}
dummy();

if(checkForEnd()==false)
{
foreColor=Color.red;	                backColor=Color.yellow;
storeSecond();  equalInTrail(); 
clearExcOne();
}//end of if (checkForEnd()==false)
}//end of if (checkForEnd()==false)
}//end of if (twise==2)

}//end of y th loop 
}//end of x th loop 
}//end of if condition


if(checkForEnd()==false)
{
for(int x=1;x<=9;x++)
{
for(int y=1;y<=9;y++)
{
thrice=0;one1=0;two2=0;three3=0;
for(int z=1;z<=9;z++)
{
if(resCon[x][y][z]!=0&&tfa[x][y]==0)
{
if(one1==0){one1=z;}
else
if(two2==0){two2=z;}
else
{three3=z;}
thrice++;
}//end of if condition
}//end of z th loop


if(thrice==3)
{
if(checkForEnd()==false)
{
tfa[x][y]=one1;
tffc[x][y]=red;
tfbc[x][y]=yellow;

//tf[x][y].setForeground(Color.red);
//tf[x][y].setBackground(Color.yellow);
//tf[x][y].setText(""+one1);

totalCount=0;prvCount=0;curCount=0;
clearRes();
dummy();
if(checkForEnd()==false)
{storeFirst();
clearExcOne();
}//end of if (checkForEnd()==false)
}//end of if (checkForEnd()==false)

if(checkForEnd()==false)
{
tfa[x][y]=two2;
tffc[x][y]=red;
tfbc[x][y]=yellow;

//tf[x][y].setForeground(Color.red);
//tf[x][y].setBackground(Color.yellow);
//tf[x][y].setText(""+two2);

totalCount=0;prvCount=0;curCount=0;
clearRes();
dummy();
if(checkForEnd()==false)
{storeSecond();
clearExcOne();
}//end of if (checkForEnd()==false)
}//end of if (checkForEnd()==false)


if(checkForEnd()==false)
{
tfa[x][y]=three3;
tffc[x][y]=red;
tfbc[x][y]=yellow;

//tf[x][y].setForeground(Color.red);
//tf[x][y].setBackground(Color.yellow);
//tf[x][y].setText(""+three3);
totalCount=0;prvCount=0;curCount=0;
clearRes();for(int arrloop=1;arrloop<=9;arrloop++){arr[arrloop]=0;}
dummy();
if(checkForEnd()==false)
{
storeThird();  equalInTrailFor3();
clearExcOne();
}//end of if (checkForEnd()==false)
}//end of if (checkForEnd()==false)

}//end of if (three==3)

}//end of y th loop 
}//end of x th loop 
}//end of if(checkForEnd()==false)  for  trail  3 

}//end of if condition (e.getSource()==b)



if(checkForEnd()&&e.getSource()==b)
{
ans();
setTitle("Manoj's idea got Solution Successfully");
msg="Got Solution Successfully ";
timeend=System.currentTimeMillis();
JOptionPane.showMessageDialog(null,msg+"time="+(timeend-timestart),"Result",JOptionPane.INFORMATION_MESSAGE);
System.out.println("Solution has Ended Successfully");
}//end of if(checkForEnd())  condition 
else
if(e.getSource()==b)
{
JOptionPane.showMessageDialog(null,"Invalid sudoku (or) For getting solution more than 3 trails are need ","Result",JOptionPane.INFORMATION_MESSAGE);
msg="Solution is not possible";
timeend=System.currentTimeMillis();
//JOptionPane.showMessageDialog(null,msg+"time="+(timeend-timestart),"Result",JOptionPane.INFORMATION_MESSAGE);
System.out.println(" Solution is not possible  according to Manoj ");
}

}//end of actionPerformed 


public void ans()
{
for(int i=1;i<=9;i++)
{
for(int j=1;j<=9;j++)
{
if(tfa[i][j]!=0)
{
tf[i][j].setText(""+tfa[i][j]);

if(tffc[i][j]==red){tf[i][j].setForeground(Color.red);}else
if(tffc[i][j]==pink){tf[i][j].setForeground(Color.pink);}else
{tf[i][j].setForeground(Color.black);}

if(tfbc[i][j]==yellow){tf[i][j].setBackground(Color.yellow);}else
{tf[i][j].setBackground(Color.white);}


}//end of if condition
}//end of j th loop
}//end of i th loop
}//end of ans method




int strFir[][]=new int[10][10];
int strSec[][]=new int[10][10];
public void storeFirst()
{
for(int i=1;i<=9;i++){for(int j=1;j<=9;j++){strFir[i][j]=0;}}
for(int i=1;i<=9;i++){
for(int j=1;j<=9;j++)
{
/*
if(tf[i][j].getForeground().getRGB()==Color.red.getRGB() && tf[i][j].getText().trim().equals("")==false)
{strFir[i][j]=Integer.parseInt(tf[i][j].getText().trim());}
*/
if(tffc[i][j]==red && tfa[i][j]!=0)
{strFir[i][j]=tfa[i][j];}


}}
}//end of method storeFirst()







public void storeSecond()
{
for(int i=1;i<=9;i++){for(int j=1;j<=9;j++){strSec[i][j]=0;}}
for(int i=1;i<=9;i++){
for(int j=1;j<=9;j++){

/*
if(tf[i][j].getForeground().getRGB()==Color.red.getRGB() && tf[i][j].getText().trim().equals("")==false)
{strSec[i][j]=Integer.parseInt(tf[i][j].getText().trim());}
*/

if(tffc[i][j]==red && tfa[i][j]!=0)
{strSec[i][j]=tfa[i][j];}


}}

}//end of method storeSecond()









int strThi[][]=new int[10][10];
public void storeThird()
{
for(int i=1;i<=9;i++){for(int j=1;j<=9;j++){strThi[i][j]=0;}}
for(int i=1;i<=9;i++){
for(int j=1;j<=9;j++){
/*
if(tf[i][j].getForeground().getRGB()==Color.red.getRGB() && tf[i][j].getText().trim().equals("")==false)
{strThi[i][j]=Integer.parseInt(tf[i][j].getText().trim());}
*/

if(tffc[i][j]==red && tfa[i][j]!=0)
{strThi[i][j]=tfa[i][j];}

}}
}//end of method storeThird()



public void equalInTrail()
{
for(int i=1;i<=9;i++){
for(int j=1;j<=9;j++){
if(strFir[i][j]!=0&&strSec[i][j]!=0)
{
if(strFir[i][j]==strSec[i][j])
{
//	tf[i][j].setForeground(Color.pink);	tf[i][j].setText(""+strSec[i][j]);

tffc[i][j]=pink;tfa[i][j]=strSec[i][j];

}//end of if(strFir[i][j]==strSec[i][j])
}//end of if(strFir[i][j]!=0&&strSec[i][j]!=0)
}}
}//end of method equalaInTrail


public void equalInTrailFor3()
{
for(int i=1;i<=9;i++){
for(int j=1;j<=9;j++){
if(strFir[i][j]!=0&&strSec[i][j]!=0&&strThi[i][j]!=0)
{
if(strFir[i][j]==strSec[i][j]&&strSec[i][j]==strThi[i][j])
{
//	tf[i][j].setForeground(Color.pink);		tf[i][j].setText(""+strSec[i][j]);
tffc[i][j]=pink;tfa[i][j]=strSec[i][j];
}//end of if(strFir[i][j]==strSec[i][j])
}//end of if(strFir[i][j]!=0&&strSec[i][j]!=0)
}}
}//end of method equalaInTrail




public void clearExcOne()
{
totalCount=0;

for(int i=1;i<=9;i++)
{

for(int j=1;j<=9;j++)
{
if(tffc[i][j]==red)
{
tfa[i][j]=0;tffc[i][j]=black;tfbc[i][j]=white;
}//end of if condition

}//end j th of loop
}//end i th of loop
}//end of method clearExcOne




String msg="";

public void clearRes()
{
for(int one=1;one<=9;one++){
for(int two=1;two<=9;two++){
for(int three=1;three<=9;three++){
res[one][two][three]=0;
}}}//end of loops
}//end of method clearRes()








public void dummy()
{
clearRes();

for(int i=1;i<=9;i++)
{
for(int j=1;j<=9;j++)
{
if(tfa[i][j]==0)
{
try{
rowFill(i);
blockFill(i,j);
colFill(j,i);
}catch(Exception exc){}
}//end of if condition 
}//end of  j th  loop 
}//end of  i th  loop 


finalOP();
finalOP2();
finalOP3();
totalCount++;
//System.out.println("\n\ntotal Count = "+totalCount+"\n\n");

if(curCount==prvCount&&curCount!=0&&prvCount!=0){totalCount=noOfLoops;}
prvCount=curCount;


if(checkForEnd()){totalCount=noOfLoops;}//end of inner if condition
else
if(totalCount<noOfLoops ){dummy();}

}//end of dummy method

public boolean isEnd()
{
for(int loop1=1;loop1<=9;loop1++)
{
for(int loop2=1;loop2<=9;loop2++)
{
if(tfa[loop1][loop2]==0 ){return(false);}
}//end of loop1 th loop 
}//end of loop2 th loo
return(true);
}//end of method()



int prvCount=0,curCount=0;

public boolean checkForEnd()
{
boolean boo=true;
curCount=0;

for(int loop1=1;loop1<=9;loop1++)
{
for(int loop2=1;loop2<=9;loop2++)
{
if( tfa[loop1][loop2]==0 ){curCount++;boo=false;}
}//end of loop1 th loop 
}//end of loop2 th loop 

if(boo==true)
{
boo=clearCheck();
}//end of if(boo==true)
return(boo);
}//end of method checkForEnd()



public boolean  clearCheck()
{
int r_c[]=new int[10];
int val=0;

for(int loop1=1;loop1<=9;loop1++)
{
for(int temp=1;temp<=9;temp++){r_c[temp]=0;}
for(int loop2=1;loop2<=9;loop2++)
{
val=tfa[loop1][loop2];
r_c[val]=val;
}//end of loop2 th loop 
for(int temp=1;temp<=9;temp++){if(r_c[temp]==0){return(false);}}
}//end of loop1 th loop 


for(int loop2=1;loop2<=9;loop2++)
{
for(int temp=1;temp<=9;temp++){r_c[temp]=0;}
for(int loop1=1;loop1<=9;loop1++)
{
val=tfa[loop1][loop2];
r_c[val]=val;
}//end of loop1 th loop 
for(int temp=1;temp<=9;temp++){if(r_c[temp]==0){return(false);}}
}//end of loop2 th loop 


int r=0,c=0;
for(int k=1;k<=9;k++)
{
if(k==1){r=1;c=1;}   if(k==2){r=1;c=4;}   if(k==3){r=1;c=7;}  
if(k==4){r=4;c=1;}   if(k==5){r=4;c=4;}   if(k==6){r=4;c=7;} 
if(k==7){r=7;c=1;}   if(k==8){r=7;c=4;}   if(k==9){r=7;c=7;}   
for(int temp=1;temp<=9;temp++){r_c[temp]=0;}
for(int loop1=r;loop1<=r+2;loop1++)
{
for(int loop2=c;loop2<=c+2;loop2++)
{
val=tfa[loop1][loop2];
r_c[val]=val;
}//end of loop2 th loop
}//end of loop1 th loop
for(int temp=1;temp<=9;temp++){if(r_c[temp]==0){return(false);}}
}//end of k th loop

return(true);
}//end of method clearCheck()



public void blockFill(int r,int c) throws Exception
{
if(r%3==0){r=r-2;}else{r=r-(r%3-1);}
if(c%3==0){c=c-2;}else{c=c-(c%3-1);}

for(int i=r;i<=r+2;i++)
{
for(int j=c;j<=c+2;j++)
{
if(tfa[i][j]!=0)
{arr[tfa[i][j]]=tfa[i][j];}//end of if condition
}//end of j th loop
}//end of i th loop 
}//end of blockFill method 



public void rowFill(int i) throws Exception
{
for(int iii=1;iii<=9;iii++){arr[iii]=0;}
for(int k=1;k<=9;k++)
{
if(tfa[i][k]!=0)
{
arr[tfa[i][k]]=tfa[i][k];
}//end of if condition
}//end of k th loop 
}//end of rowFill method 

String str="";



public void colFill(int j,int i)  throws Exception
{
for(int k=1;k<=9;k++)
{
if(tfa[k][j]!=0)
{
arr[tfa[k][j]]=tfa[k][j];
}//end of if condition
}//end of k th loop 
int op2=0;

for(int a=1;a<=9;a++)
{
if(arr[a]==0)
{
res[i][j][a]=a;
count2++;
op2=a;
}
}

if(count2==1)
{
tfa[i][j]=op2;
tffc[i][j]=red;
tfbc[i][j]=yellow;


if(hintboo==true)
{
if(tf[i][j].getText().equals(""))
{
tf[i][j].setBackground(Color.red);

JOptionPane.showMessageDialog(null,"You  can fill "+op2+" in ("+i+","+j+") cell ","Result",JOptionPane.INFORMATION_MESSAGE);}
tf[i][j].setBackground(Color.white);

hintboo=false;
}//end of if(hintboo==true)
//System.out.println(i+" , "+ j +" = "+ op2);

}

count2=0;
}//end of colFill method 

Color foreColor=Color.red;
Color backColor=Color.yellow;

public void mouseMoved(MouseEvent me){}//end of mouseMoved()
public void mouseDragged(MouseEvent me){p.setLocation(me.getX(),me.getY());}//end of mouseMoved()
class WindowCloser extends WindowAdapter
{public void windowClosing(WindowEvent we){System.exit(1);}}//end of inner class


Panel p=new SuperPanel();
public SudokuSolverAndGenerator() throws Exception
{
int disX=0,disY=0,yaxe=289,xaxe=5;
setLayout(null);
//addMouseMotionListener(this);
p.setBounds(5,25,450,315);
//p.setBackground(Color.gray);
p.setLayout(null);
add(p);

addWindowListener(new WindowCloser());

lst.setBounds(295,0,150,250);
lst.addActionListener(this);
lst.setBackground(Color.white);
p.add(lst);


File allFiles=new File("SudokuPuzzels");
allFiles.mkdir();
String allNames[]=allFiles.list();
String path1="";

for(int i=0;i<allNames.length;i++)
{
if(allNames[i].endsWith(".sdk"))
{
path1="";
for(int j=0;j<(allNames[i].indexOf(".sdk"));j++)
{path1=path1+""+allNames[i].charAt(j);}//end of  i th loop
lst.add(path1);
}//end of if(allNames[i].endsWith(".sdk")) 
}//end of i th for loop 





/*
File temp=new File("temp.txt");
if(temp.exists()==false){temp.createNewFile();}
String absPath=temp.getAbsolutePath();
String path="";

for(int i=0;i<(absPath.indexOf("temp.txt")-1);i++)
{
path=path+""+absPath.charAt(i);
}//end of  i th loop


File allFiles=new File(path);
allFiles.mkdir();
String allNames[]=allFiles.list();
String path1="";

for(int i=0;i<allNames.length;i++)
{
if(allNames[i].endsWith(".sdk"))
{
path1="";
for(int j=0;j<(allNames[i].indexOf(".sdk"));j++)
{path1=path1+""+allNames[i].charAt(j);}//end of  i th loop
lst.add(path1);
}//end of if(allNames[i].endsWith(".sdk")) 
}//end of i th for loop 

*/


b.setBounds(xaxe+42,yaxe,50,25);
b.addActionListener(this);
p.add(b);
p.setBackground(new Color(255,220,240));


clr.setBounds(xaxe,yaxe,40,25);
clr.addActionListener(this);
p.add(clr);


clrAns.setBounds(xaxe+94,yaxe,85,25);
clrAns.addActionListener(this);
p.add(clrAns);


open.setBounds(xaxe+181,yaxe,35,25);
open.addActionListener(this);
p.add(open);



save.setBounds(xaxe+220,yaxe,35,25);
save.addActionListener(this);
p.add(save);


hint.setBounds(xaxe+260,yaxe,40,25);
hint.addActionListener(this);
p.add(hint);


gn.setBounds(xaxe+305,yaxe,60,25);
gn.addActionListener(this);
p.add(gn);


level.setBounds(xaxe+368,yaxe,75,25);
level.add("VeryEasy");
level.add("Easy");
level.add("Medium");
level.add("Hard");
level.add("VeryHard");
p.add(level);

rename.setLabel("Rename");
rename.setBounds(xaxe+368,yaxe-35,75,25);
rename.addActionListener(this);
p.add(rename);

delete.setLabel("Delete");
delete.setBounds(xaxe+290,yaxe-35,75,25);
delete.addActionListener(this);
p.add(delete);



for(int i=1;i<=9;i++)
{
for(int j=1;j<=9;j++)
{
tf[i][j]=new TextField();
tf[i][j].addKeyListener(this);
tf[i][j].addTextListener(this);
tf[i][j].setBounds(5+(disX)+((j-1)*30)  ,  5+(disY)+((i-1)*30),30,30);
tf[i][j].setFont(new Font("TimesRoman",0,19));
p.add(tf[i][j]);
if(j%3==0){disX=disX+5;}
}
disX=0;
if(i%3==0){disY=disY+4;}
}

setBounds(0,0,460,345);
setResizable(false);
setLocation(170,50);
setVisible(true);
setTitle(" Sudoku Game  by Y.Manoj  ");
//setBackground(Color.cyan);


//System.out.println(""+b.getBackground().getRed());
//System.out.println(""+b.getBackground().getGreen());
//System.out.println(""+b.getBackground().getBlue());

}//end of constructor



public void hintInRowWise(int ans,int row,int col)
{
String msg="";
Object[] options = { "OK", "HOW" };
int  no=JOptionPane.showOptionDialog(null, "Row wise you can fill "+ans+"  in  ("+row+","+col+") cell ", "                            Hint ",JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,null, options,options[0]);

if(no==1)
{
if(row==1){msg="           In   "+row+" st  row \n ";}else
if(row==2){msg="           In   "+row+" nd  row \n ";}else
if(row==3){msg="           In   "+row+" rd  row \n ";}else
if(row>3)  {msg="           In   "+row+" th  row \n ";}

for(int i=1;i<=9;i++)
{
if(i!=col)
{
if(tfa[row][i]==0)
{

if(blockCheckForDis(row,i,ans))
{
int bn=blockNumber(i,col);
if(bn==1){msg=msg+"\n"+blockNumber(row,i)+" st    block have "+ans+" , so no chance to fill in cell "+i+" ";}else
if(bn==2){msg=msg+"\n"+blockNumber(row,i)+" nd   block have "+ans+" , so no chance to fill in cell "+i+" ";}else
if(bn==3){msg=msg+"\n"+blockNumber(row,i)+" rd   block have "+ans+" , so no chance to fill in cell "+i+" ";}else
if(bn>3)  {msg=msg+"\n"+blockNumber(row,i)+" th    block have "+ans+",  so no chance to fill in cell "+i+" ";}
}
else
if(coloumnCheck(i,ans)){msg=msg+"\n In  coloumn  "+i+"  already  have "+ans+"";}


}//end of if(tfa[row][i]==0)
else
{msg=msg+"\n In  cell "+i+" is already filled with "+tfa[row][i]+"";}
}//end of if()
}//end of i th loop
msg=msg+"\n\n So there is only chance to fill "+ans+" in ( "+row+" , "+col+" ) cell ";

JOptionPane.showMessageDialog(null,msg," Discription  ",JOptionPane.INFORMATION_MESSAGE);
}// end of if condition if(no==1)

}//end of method hintInRowWise()



public void hintInColWise(int ans,int row,int col)
{
String msg="";
Object[] options = { "OK", "HOW" };
int  no=JOptionPane.showOptionDialog(null, "Coloumn wise you can fill "+ans+"  in  ("+row+","+col+") cell ", "                            Hint ",JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,null, options,options[0]);

if(no==1)
{
if(col==1){msg="           In   "+col+" st  coloumn \n ";}else
if(col==2){msg="           In   "+col+" nd  coloumn \n ";}else
if(col==3){msg="           In   "+col+" rd  coloumn \n ";}else
if(col>3)  {msg="           In   "+col+" th  coloumn \n ";}

for(int i=1;i<=9;i++)
{
if(i!=row)
{
if(tfa[i][col]==0)
{

if(blockCheckForDis(i,col,ans))
{
int bn=blockNumber(i,col);
if(bn==1){msg=msg+"\n"+blockNumber(i,col)+" st   block  have "+ans+" , so  no chance to fill in  cell "+i+"";}else
if(bn==2){msg=msg+"\n"+blockNumber(i,col)+" nd  block  have "+ans+" , so  no chance to fill in  cell "+i+"";}else
if(bn==3){msg=msg+"\n"+blockNumber(i,col)+" rd  block  have "+ans+" , so  no chance to fill in  cell "+i+"";}else
if(bn>3)  {msg=msg+"\n"+blockNumber(i,col)+" th   block  have "+ans+", so  no chance to fill in  cell "+i+"";}
}
else
if(rowCheck(i,ans)){msg=msg+"\n In  row "+i+"  already  have "+ans+"";}
}//end of if(tfa[i][col]==0)
else{msg=msg+"\n In  cell "+i+" is already filled with "+tfa[i][col]+"";}
}//end of if()
}//end of i th loop

msg=msg+"\n\n So there is only chance to fill "+ans+" in ( "+row+" , "+col+" ) cell ";
JOptionPane.showMessageDialog(null,msg," Discription  ",JOptionPane.INFORMATION_MESSAGE);
}// end of if condition if(no==1)
}//end of method hintInRowWise()



public void hintInBlockWise(int ans,int row,int col)
{
String msg="";
Object[] options = { "OK", "HOW" };
int  no=JOptionPane.showOptionDialog(null, "Coloumn wise you can fill "+ans+"  in  ("+row+","+col+") cell ", "                            Hint ",JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,null, options,options[0]);

int r=row,c=col;
if(r%3==0){r=r-2;}else{r=r-(r%3-1);}
if(c%3==0){c=c-2;}else{c=c-(c%3-1);}
int bn=blockNumber(row,col);

if(no==1)
{
if(bn==1){msg="           In   "+bn+" st  block\n ";}else
if(bn==2){msg="           In   "+bn+" nd block\n ";}else
if(bn==3){msg="           In   "+bn+" rd  block\n ";}else
if(bn>3)  {msg="           In   "+bn+" th  block\n ";}


for(int i=r;i<=r+2;i++)
{
for(int j=c;j<=c+2;j++)
{
if((i!=row||j!=col))
{
if(tfa[i][j]==0)
{
if(rowCheck(i,ans)){msg=msg+"\n In ( "+i+" , "+j+" ) cell has no chance to fill "+ans+" , because in row : "+i+" has already "+ans+" ";}else
if(coloumnCheck(j,ans)){msg=msg+"\n In ( "+i+" , "+j+" ) cell has no chance to fill "+ans+" , because in coloumn : "+j+" has already "+ans+"";}
}
else
{
msg=msg+"\n In  cell ( "+i+" , "+j+" ) is already filled with "+tfa[i][j]+"";
}


}//end of if()
}//end of j th loop
}//end of i th loop


msg=msg+"\n\n So there is only chance to fill "+ans+" in ( "+row+" , "+col+" ) cell ";
JOptionPane.showMessageDialog(null,msg," Discription  ",JOptionPane.INFORMATION_MESSAGE);
}// end of if condition if(no==1)
}//end of method hintInBlockWise()



public boolean coloumnCheck(int col,int ans)
{
for(int i=1;i<=9;i++){if(tfa[i][col]==ans&&tf[i][col].getText().equals("")==false)
{return(true);}}	     return(false);
}//end of coloumnCheck() method

public boolean rowCheck(int row,int ans)
{
for(int i=1;i<=9;i++){if(tfa[row][i]==ans&&tf[row][i].getText().equals("")==false)
{return(true);}}	     return(false);
}//end of coloumnCheck() method

public boolean blockCheckForDis(int row,int col,int ans)
{
if(row%3==0){row=row-2;}else{row=row-(row%3-1);}
if(col%3==0){col=col-2;}else{col=col-(col%3-1);}
for(int i=row;i<=row+2;i++){for(int j=col;j<=col+2;j++){if(tfa[i][j]==ans&&tf[i][j].getText().equals("")==false)
{return(true);}}}
return(false);
}//end of coloumnCheck() method

public int blockNumber(int row,int col)
{
if(row%3==0){row=row-2;}else{row=row-(row%3-1);}
if(col%3==0){col=col-2;}else{col=col-(col%3-1);}
return(  (row+(col/3))  );
}

}//end of class










class SuperPanel extends Panel
{
public void paint(Graphics g)
{
g.drawImage(Toolkit.getDefaultToolkit().getImage("back.jpg"),0,0,500,500,this);
}//end of paint
}


class SuperButton extends Button
{
public SuperButton(String str){super(str);}
public void paint(Graphics g)
{
g.drawImage(Toolkit.getDefaultToolkit().getImage("back.jpg"),0,0,100,100,this);
}//end of paint
}






class ChangeAnswer
{
int q[][]=new int[10][10];      Random r=new Random();
int rno=1;
public int[][] getAnswer(int tfa[][])	{    for(int i=1;i<=9;i++){for(int j=1;j<=9;j++){q[i][j]=tfa[i][j];}}     return(result());}

public int[][] result()
{
increment();
crossExchange();
blockExchange();
rowColoumnExchange();
return(q);
}//end of result method

public void increment()
{
do{rno=r.nextInt()%10;}while(rno==0);
rno =Math.abs(rno);
for(int i=1;i<=9;i++){
for(int j=1;j<=9;j++){
if(q[i][j]!=0) {
q[i][j]=q[i][j]+rno;       if(q[i][j]>9){q[i][j]=q[i][j]-9;}    }
}}//end of i , j th loops
}//end of increment method

int crossTemp=0;
public void crossExchange()
{
do{rno=r.nextInt()%3;}while(rno==0);
rno =Math.abs(rno);
//System.out.println("rno = "+ rno);

for(int i=1;i<=9;i++){
for(int j=1;j<=10-i;j++){
if(rno==1)   {    crossTemp=q[i][j];    q[i][j]=q[j][i];              q[j][i]=crossTemp;   }else
if(rno==2)   {    crossTemp=q[i][j];    q[i][j]=q[10-j][10-i];   q[10-j][10-i]=crossTemp;   }
}}

}//end of method  crossExchange()

int orderTemp=0;
public void orderExchange()
{
do{rno=r.nextInt()%3;}while(rno==0);	rno =Math.abs(rno);

for(int i=1;i<=9;i++){
for(int j=1;j<=4;j++){
if(rno==1)   {    orderTemp=q[i][j];    q[i][j]=q[i][10-j];              q[i][10-j]=orderTemp;   }else
if(rno==2)   {    orderTemp=q[i][j];    q[i][j]=q[j][10-i];              q[j][10-i]=orderTemp;   }
}}
}//end of method  orderExchange()





int blockTemp[][]=new int[10][10];
int bt1=0,bt2=0,bt3=0;

public void blockExchange()
{
for(int i=1;i<=9;i++){    for(int j=1;j<=9;j++)      {   blockTemp[i][j]=q[i][j];   }   }

do{bt1=r.nextInt()%4;     bt1 =Math.abs(bt1);   }while(bt1==0);			
do{bt2=r.nextInt()%4;     bt2 =Math.abs(bt2);   }while(bt2==0||bt2==bt1);      		 
do{bt3=r.nextInt()%4;     bt3 =Math.abs(bt3);   }while(bt3==0||bt3==bt1||bt3==bt2);	 
//System.out.println(bt1+" , "+bt2+" , "+bt3 );

bt1=(bt1-1)*3;	bt2=(bt2-1)*3;	bt3=(bt3-1)*3;

for(int k=1;k<=3;k++){
for(int i=1;i<=3;i++){
for(int j=1;j<=9;j++){
if(k==1){q[i+0][j]=blockTemp[bt1+i][j];}else
if(k==2){q[i+3][j]=blockTemp[bt2+i][j];}else
if(k==3){q[i+6][j]=blockTemp[bt3+i][j];}
}// end of i th loop
}//end of j th loop
}//end of k th loop


for(int i=1;i<=9;i++){    for(int j=1;j<=9;j++)      {   blockTemp[i][j]=q[i][j];   }   }

do{bt1=r.nextInt()%4;     bt1 =Math.abs(bt1);   }while(bt1==0);			
do{bt2=r.nextInt()%4;     bt2 =Math.abs(bt2);   }while(bt2==0||bt2==bt1);      		 
do{bt3=r.nextInt()%4;     bt3 =Math.abs(bt3);   }while(bt3==0||bt3==bt1||bt3==bt2);	 
//System.out.println(bt1+" , "+bt2+" , "+bt3 );

bt1=(bt1-1)*3;	bt2=(bt2-1)*3;	bt3=(bt3-1)*3;

for(int k=1;k<=3;k++){
for(int i=1;i<=3;i++){
for(int j=1;j<=9;j++){
if(k==1){q[j][i+0]=blockTemp[j][bt1+i];}else
if(k==2){q[j][i+3]=blockTemp[j][bt2+i];}else
if(k==3){q[j][i+6]=blockTemp[j][bt3+i];}
}// end of i th loop
}//end of j th loop
}//end of k th loop

}//end of blockExchange() method 



public void rowColoumnExchange()
{

for(int i=1;i<=9;i++){    for(int j=1;j<=9;j++)      {   blockTemp[i][j]=q[i][j];   }   }

for(int k=1;k<=3;k++)
{
do{bt1=r.nextInt()%4;     bt1 =Math.abs(bt1);   }while(bt1==0);			
do{bt2=r.nextInt()%4;     bt2 =Math.abs(bt2);   }while(bt2==0||bt2==bt1);      		 
do{bt3=r.nextInt()%4;     bt3 =Math.abs(bt3);   }while(bt3==0||bt3==bt1||bt3==bt2);	 
//bt1=(bt1-1);	bt2=(bt2-1);	bt3=(bt3-1);
for(int i=1;i<=3;i++)
{
for(int j=1;j<=9;j++)
{
if(k==1)
{
if(i==1){q[i+0][j]=blockTemp[bt1][j];}else
if(i==2){q[i+0][j]=blockTemp[bt2][j];}else
if(i==3){q[i+0][j]=blockTemp[bt3][j];}
}else
if(k==2)
{
if(i==1){q[i+3][j]=blockTemp[bt1+3][j];}else
if(i==2){q[i+3][j]=blockTemp[bt2+3][j];}else
if(i==3){q[i+3][j]=blockTemp[bt3+3][j];}
}else
if(k==3)
{
if(i==1){q[i+6][j]=blockTemp[bt1+6][j];}else
if(i==2){q[i+6][j]=blockTemp[bt2+6][j];}else
if(i==3){q[i+6][j]=blockTemp[bt3+6][j];}
}
}// end of i th loop
}//end of j th loop
}//end of k th loop





for(int i=1;i<=9;i++){    for(int j=1;j<=9;j++)      {   blockTemp[i][j]=q[i][j];   }   }

for(int k=1;k<=3;k++)
{
do{bt1=r.nextInt()%4;     bt1 =Math.abs(bt1);   }while(bt1==0);			
do{bt2=r.nextInt()%4;     bt2 =Math.abs(bt2);   }while(bt2==0||bt2==bt1);      		 
do{bt3=r.nextInt()%4;     bt3 =Math.abs(bt3);   }while(bt3==0||bt3==bt1||bt3==bt2);	 

for(int i=1;i<=3;i++)
{
for(int j=1;j<=9;j++)
{
if(k==1)
{
if(i==1){q[j][i+0]=blockTemp[j][bt1];}else
if(i==2){q[j][i+0]=blockTemp[j][bt2];}else
if(i==3){q[j][i+0]=blockTemp[j][bt3];}
}else
if(k==2)
{
if(i==1){q[j][i+3]=blockTemp[j][bt1+3];}else
if(i==2){q[j][i+3]=blockTemp[j][bt2+3];}else
if(i==3){q[j][i+3]=blockTemp[j][bt3+3];}
}else
if(k==3)
{
if(i==1){q[j][i+6]=blockTemp[j][bt1+6];}else
if(i==2){q[j][i+6]=blockTemp[j][bt2+6];}else
if(i==3){q[j][i+6]=blockTemp[j][bt3+6];}
}
}// end of i th loop
}//end of j th loop
}//end of k 

}//end of rowColoumnExchange()

}//end of class                                       

