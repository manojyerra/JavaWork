import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;



class SuperLabel extends Label
{
SuperLabel(String str)
{
}

public void paint(Graphics g)
{
g.drawImage(Toolkit.getDefaultToolkit().getImage("label.jpg"),0,0,400,400,this);
}//end of paint
}//end of class



class Verbs extends Frame implements KeyListener,ActionListener,WindowListener
{
java.util.Random random=new java.util.Random();
Checkbox cb[]=new Checkbox[26];
Checkbox options[]=new Checkbox[4];
Label scoreLabel=new Label(" ");


int char_per=26;
int no_per=300;
boolean btest=false,banswers=false;
int t_a_b[]=new int[1000];
int t_no[]=new int[1000];
int random_1=0,random_2=0;


Button go=new Button("GO");
List list=new List ();

Label border=new SuperLabel("");
Label border1=new SuperLabel("");
Label border2=new SuperLabel("");

Label chanceInfo=new Label("");
Label tf=new Label("");

int no_of_chances=10;

int start=40,score=0;
int i=start,end=400,initialSpeed=300,incresedSpeed=0;
int speed=initialSpeed;
int no=0,be_no=0;
String s="";
int code;char ch;
int cat=0;


int strlength=no_per;
int no_char=char_per;

String str[][]=new String[no_char][strlength];

Button b=new Button("a a");
Label word=new Label("a a");


FileWriter fw;
BufferedWriter bw;


public static void main(String args[])throws IOException {new Verbs();}//end of main

 public  void windowOpened(java.awt.event.WindowEvent e){}
 public  void windowClosing(java.awt.event.WindowEvent e){System.exit(0);}
 public  void windowClosed(java.awt.event.WindowEvent e){}
 public  void windowIconified(java.awt.event.WindowEvent e){}
 public  void windowDeiconified(java.awt.event.WindowEvent e){}
 public  void windowActivated(java.awt.event.WindowEvent e){}
 public  void windowDeactivated(java.awt.event.WindowEvent e){}

public Verbs() throws IOException
{
addWindowListener(this);
fw=new FileWriter("f:/HardTerms.txt",true);
bw=new BufferedWriter(fw);

CheckboxGroup cg=new CheckboxGroup();

char c=65;

for(int i=0;i<26;i++)
{
cb[i]=new Checkbox(""+c);
cb[i].setBackground(Color.yellow);
cb[i].setBounds(50,20+((i+1)*20),50,15);
cb[i].addKeyListener(this);
cb[i].setState(true);
add(cb[i]);
c++;
}


for(int i=0;i<4;i++)
{
options[i]=new Checkbox("",cg,true);

if(i==0){options[i].setBounds(300,490,250,25);}else
if(i==3){options[i].setBounds(300,550,250,25);}else

if(i==2){options[i].setBounds(450,520,250,25);}else
if(i==1){options[i].setBounds(130,520,250,25);}


//{options[i].setBounds(150,460+((i+1)*40),250,25);}

options[i].setFont(new Font("TimesRoman",1,15));
options[i].setForeground(Color.red);
options[i].setVisible(false);
options[i].addKeyListener(this);
add(options[i]);
}

scoreLabel.setBounds(220,450,400,20);
scoreLabel.setFont(new Font("TimesRoman",1,20));
scoreLabel.setVisible(false);
scoreLabel.setForeground(Color.blue);
add(scoreLabel);

go.setFont(new Font("TimesRoman",0,20));
go.setBounds(615,470,100,30);
go.setBackground(Color.red);
go.setForeground(Color.white);
go.setVisible(false);
go.addActionListener(this);
go.addKeyListener(this);
add(go);

list.setFont(new Font("TimesRoman",0,20));
list.setBounds(620,50,175,230);
list.setBackground(Color.red);
list.setForeground(Color.white);
list.addKeyListener(this);
list.addItem("Next(Press 'ESC' )");
list.addItem("Test (ctrl + t)");
list.addItem("Test In Reverse");
list.addItem("Result (ctrl + r)");
list.addItem("Normal (ctrl + n)");
list.addItem("IncreaseSpeed");
list.addItem("DecreaseSpeed");
list.addItem("IncreaseFontSize");
list.addItem("DecreaseFontSize");
list.addActionListener(this);

add(list);

b.setFont(new Font("TimesRoman",0,20));
b.setBounds(240,50,360,30);
b.setBackground(Color.red);
b.setForeground(Color.white);
b.addKeyListener(this);
add(b);

word.setFont(new Font("TimesRoman",0,20));
word.setBackground(Color.pink);
word.setBounds(240,450,360,20);
add(word);

tf.setBounds(240,470,360,18);
tf.setFont(new Font("TimesRoman",0,20));
tf.addKeyListener(this);
tf.setBackground(Color.yellow);
add(tf);

border.setBounds(240,430,360,20);
border.setBackground(Color.green);
add(border);

border1.setBounds(220,200,20,250);
border1.setBackground(Color.green);
add(border1);

border2.setBounds(600,200,20,250);
border2.setBackground(Color.green);
add(border2);

chanceInfo.setBounds(150,150,450,45);
chanceInfo.setBackground(Color.white);
chanceInfo.setVisible(false);
chanceInfo.setFont(new Font("TimesRoman",0,25));
add(chanceInfo);


setTitle("                                                                               SCORE : "+score);
for(int j=0;j<no_char;j++)
{
for(int i=0;i<strlength;i++)
{
str[j][i]=new String("");
}//end of loop
}//end of loop



str[0][0]="a a";
str[0][1]="abandon Vadellipettu(T)";
str[0][2]="abbey ashramam(T)";
str[0][3]="abdomen uddaram(T)";
str[0][4]="abide jeevinchu(T)";
str[0][5]="abolish nilipiveyuta(T)";
str[0][6]="abound nindivunna(T)";
str[0][7]="abridge kunchinchu(T)";
str[0][8]="absorb grahinchu(T)";
str[0][9]="absurd namaaleni(T)";
str[0][10]="abundant aparimitham(T)";
str[0][11]="abuse thittu(T)";
str[0][12]="accent nokkichepuuta(T)";
str[0][13]="accuse neramumopu(T)";
str[0][14]="ache bhadha(T)";
str[0][15]="acquire sampadhinchu(T)";
str[0][16]="adequate chalinantha(T)";
str[0][17]="ago munupu(T)";
str[0][18]="aid sahayamu(T)";
str[0][19]="ally friend";
str[0][20]="alms bikshamu(T)";
str[0][21]="aloud gattiga(T)";
str[0][22]="alter marpu(T)";
str[0][23]="although aienapatiki(T)";
str[0][24]="amass collect";
str[0][25]="ample aparimithamu(T)";
str[0][26]="ancestor forefather";
str[0][27]="ancient veryold";
str[0][28]="anthem keerthana(T)";
str[0][29]="anxious vicharamu(T)";
str[0][30]="ape tokalenikothi(T)";
str[0][31]="apology excuse";
str[0][32]="approval accept";
str[0][33]="arch vampu(T)";
str[0][34]="apt cheyadhagina(T)";
str[0][35]="arrival raaka(T)";
str[0][36]="artery bloodvessel";
str[0][37]="article thing";
str[0][38]="ascend ekkuta(T)";
str[0][39]="assertion findout";
str[0][40]="ash budidha(T)";
str[0][41]="ashore thiramunaku(T)";
str[0][42]="aspire desire";
str[0][43]="assess viluvakattu(T)";
str[0][44]="ass donkey";
str[0][45]="assent accept";
str[0][46]="asset property";
str[0][47]="assist help";
str[0][48]="assistant helper";
str[0][49]="assurance confidance";
str[0][50]="assure confirm";
str[0][51]="astonish surprise";
str[0][52]="auction velamu(T)";
str[0][53]="augth anything";
str[0][54]="avail makeuse";
str[0][55]="avenge takerevenge";
str[0][56]="avent prevent";
str[0][57]="awe respectfulfear";
str[0][58]="awakwrd vikaramaina(T)";
str[0][59]="alley NarrowWithWallsOnBothSides";




str[1][0]="b b";
str[1][1]="babe baby";
str[1][2]="back rear";
str[1][3]="badge symbol";
str[1][4]="baggage luggage";
str[1][5]="ballad FockSong";
str[1][6]="ballot vote";
str[1][7]="bamboo vedhuru(T)";
str[1][8]="ban prohibition";
str[1][9]="band groupofmen";
str[1][10]="bandit decoit";
str[1][11]="bang loudNoise";
str[1][12]="banian innerwear";
str[1][13]="banyan marrichettu(T)";
str[1][14]="banish bahishkarana(T)";
str[1][15]="banquest feast";
str[1][16]="bar obstruction";
str[1][17]="barbarian uncivilisedperson";
str[1][18]="barber haircutter";
str[1][19]="bard poet";
str[1][20]="bare uncovered";
str[1][21]="bargain beramu(T)";
str[1][22]="bark soundofdog";
str[1][23]="barrage anakatta(T)";
str[1][24]="barricade rakshanagoda(T)";
str[1][25]="barrier obstrutor";
str[1][26]="barrister lawyer";
str[1][27]="basket butta";
str[1][28]="bat gabiilamu";
str[1][29]="bath snanamu(T)";
str[1][30]="battle fight";
str[1][31]="bay akathamu(T)";
str[1][32]="bazaar bazaar";
str[1][33]="bead pusa(T)";
str[1][34]="beak MouthOfBird";
str[1][35]="beaker GlassWithBeak";
str[1][36]="beam largewood";
str[1][37]="bean chikkudu(T)";
str[1][38]="bear carry,elugubanti(T)";
str[1][39]="beard gaddamu(T)";
str[1][40]="beast wildanimal";
str[1][41]="beat defeat,kottuta(T)";
str[1][42]="beckon siga(T)";
str[1][43]="bee thenetiga(T)";
str[1][44]="beef FleshOfCow";
str[1][45]="befall happen";
str[1][46]="befit fitness";
str[1][47]="beg adukkonu(T)";
str[1][48]="beguile cheat";
str[1][49]="behead cutofhead";
str[1][50]="behold takenotice";
str[1][51]="being creature";
str[1][52]="belly abdomen";
str[1][53]="beneath under";
str[1][54]="benediction blessing";
str[1][55]="beseech request";
str[1][56]="beset surround";
str[1][57]="besides moreover";
str[1][58]="bestow give";
str[1][59]="bet pandem(T)";
str[1][60]="betel thamalapaku(T)";
str[1][61]="betimes InProperTime";
str[1][62]="bewail dhukinchu(T)";
str[1][63]="bewilder kalathaparuchu(T)";
str[1][64]="beyond avathalivypu(T)";
str[1][65]="bliss delight";
str[1][66]="block stop";
str[1][67]="blockade bandhinchuta(T)";
str[1][68]="blood-shed  murder";
str[1][69]="bloom blossomofflower";
str[1][70]="blot maraka(T)";
str[1][71]="blouse jacket";
str[1][72]="blow vudhuta(T)";
str[1][73]="bluff Cheat";
str[1][74]="blunder BigMistake";
str[1][75]="blunt NotSharp";
str[1][76]="blush FeelShy";
str[1][77]="boar wildpig";
str[1][78]="boart ekkuta(T)";
str[1][79]="boarding houseOfFood";
str[1][80]="boast goppalucheppu(T)";
str[1][81]="bold brave";
str[1][82]="bolt gadiya(T)";
str[1][83]="bonafied genuine";
str[1][84]="bond promisorynote";
str[1][85]="boon varamu";
str[1][86]="boost giveapushup";
str[1][87]="booty robbedmoney";
str[1][88]="bore tireout";
str[1][89]="botany scienceofplants";
str[1][90]="bother worry";
str[1][91]="bottle sisa";
str[1][92]="bough komma";
str[1][93]="bounce jump";
str[1][94]="bow arch";
str[1][95]="bowl basin";
str[1][96]="brass etthadi";
str[1][97]="breach break";
str[1][98]="breadth width";
str[1][99]="bread jaathi";
str[1][100]="breeze gentlewind";
str[1][101]="bribe lanchamu";
str[1][102]="bride vadhuvu";
str[1][103]="bride-groom varudu";
str[1][104]="brief short";
str[1][105]="brigade batchofsoldier";
str[1][106]="brim edge";
str[1][107]="brinjal vankaya";
str[1][108]="brink edge";
str[1][109]="brisk active";
str[1][110]="broadcast soundoutbyradio";
str[1][111]="broaden widen";
str[1][112]="bronze kanchu";
str[1][113]="brook smallstream";
str[1][114]="brow archovereye";
str[1][115]="brute wildanimal";
str[1][116]="bubble budaga";
str[1][117]="bud unopenedflower";
str[1][118]="budge kaduluta";
str[1][119]="buffoon joker";
str[1][120]="bug nalli";
str[1][121]="bugle soundinstrument";
str[1][122]="bulletin report";
str[1][123]="bullion goldmetal";
str[1][124]="bund gattu";
str[1][125]="bungle spoilthework";
str[1][126]="burst break";
str[1][127]="bury pudchuta";
str[1][128]="bustle excitedactivity";
str[1][129]="butcher whokillsanimal";
str[1][130]="bygone past";





str[2][0]="cab CrariageForHire";
str[2][1]="cabbage AKindOfGreenFlower";
str[2][2]="cabin ASmallRoom";
str[2][3]="cabinet WoodenShelfWithDoor";
str[2][4]="cadet StudentAtMilitaryCollege";
str[2][5]="cadre ClassOfOfficers";
str[2][6]="cage FrameWorkForKeepingBirds";
str[2][7]="calamity Disaster,Danger";
str[2][8]="calf TheYoungOneOfACow";
str[2][9]="calling Occupation,Profession";
str[2][10]="camp ShortStay,TemporaryQuarters";
str[2][11]="campaign MiltaryActivities";
str[2][12]="camphor Karpuramu(T)";
str[2][13]="can MetalVesselForHoldingLiquids";
str[2][14]="canel Channel(ArtificialWaterWay)";
str[2][15]="cane RodForPunishment";
str[2][16]="canon Principle(Rule,Law)";
str[2][17]="cannon LargeGun,Phirangi(T)";
str[2][18]="canopy Pandhiri(T)";
str[2][19]="canteen RefreshmentRoom";
str[2][20]="cantonment MilitaryStation";
str[2][21]="canvas ThickCloth";
str[2][22]="canvass AskForVotes";
str[2][23]="capable Able";
str[2][24]="cape Agramu(T)";
str[2][25]="captive Prisoner";
str[2][26]="captivate Attract";
str[2][27]="capture Pattukonu(T)";
str[2][28]="caravan GroupOfMerchants";
str[2][29]="carbuncle Rachapundu(T)";
str[2][30]="carcass DeadBodyOfAnimal";
str[2][31]="cardamom Alakakaaya(T)";
str[2][32]="cargo LoadOfGoods";
str[2][33]="carpet WovenCoveringForFloor";
str[2][34]="carriage Vehicle(WithFourWheels)";
str[2][35]="carrier OneWhoCarries";
str[2][36]="cart VehicleDrawnByHorse(Or)Ox";
str[2][37]="cartridge Bullet";
str[2][38]="carve Chekkuta(T)";
str[2][39]="case AnEvent";
str[2][40]="cashewnut JeediPappu(T)";
str[2][41]="cask ACylindricalContainerThatHoldsLiquids";
str[2][42]="casket ASmallBox";
str[2][43]="cast ThrowAway,SetOfActors";
str[2][44]="caste ADivisionInSociety";
str[2][45]="castle Fort";
str[2][46]="castor-oil Amudhamu(T)";
str[2][47]="casuality AMishap , Accident";
str[2][48]="catalogue List";
str[2][49]="catastrophe GreatDestruction,Suffering";
str[2][50]="catagorical Unconditional,Clear";
str[2][51]="caterpillar GongaliPurugu(T)";
str[2][52]="cathedral CheifChurch";
str[2][53]="cattel DomesticAnimals(Likecow,bull etc)";
str[2][54]="caution Waring";
str[2][55]="cave Den";
str[2][56]="cease Stop";
str[2][57]="celebrities FamousPersons";
str[2][58]="cell ASmallRoom,Battery";
str[2][59]="cellulr LivingOraganisms ";
str[2][60]="cemetery BurialGround";
str[2][61]="censure Critisice";
str[2][62]="census CountingOfPeople";
str[2][63]="cent Hundred";
str[2][64]="ceremony RegiousFormality";
str[2][65]="certain Someone";
str[2][66]="cess Tax";
str[2][67]="chant Sing";
str[2][68]="chaos TotalConfusion";
str[2][69]="chap Person";
str[2][70]="char BurnIntoCharCoal ";
str[2][71]="charcoal BurntWood";
str[2][72]="chariot radhamu(T)";
str[2][73]="charity Generousity";
str[2][74]="charm Attract ";
str[2][75]="charter AWrittenRecordGrantingCertainRights";
str[2][76]="chaste Pure(or)Holy  ";
str[2][77]="chatter AnIdleTalk";
str[2][78]="cheat Deceive,Mosamu(T)";
str[2][79]="check PutInControl";
str[2][80]="cheer Happpiness";
str[2][81]="cheese Junnnu(T)";
str[2][82]="chemist ADealerInMedicnes";
str[2][83]="cherish RememberWithJoy";
str[2][84]="chew Sappparinchuta(T)";
str[2][85]="chide ScoldMildly";
str[2][86]="chill Cold";
str[2][87]="chin Gadddam(T)";
str[2][88]="chisel Vuli(T)";
str[2][89]="chit Slip,Cheeti(T)";
str[2][90]="chivalry BraveAct";
str[2][91]="choke MakeAPersonUnableToBreathe";
str[2][92]="chord Jya";
str[2][93]="chorus GroupSong ";
str[2][94]="choultry APlaceForBoarding,Lodging,AnInn";
str[2][95]="chronic Disease(LastingForALongTime)";
str[2][96]="chronology InTheOrderOfTime";
str[2][97]="churn MixWithChurner";
str[2][98]="circulate Spread";
str[2][99]="circumstance StateCondition";
str[2][100]="cite GiveAsAnExample";
str[2][101]="citizen RightfulResident";
str[2][102]="civic RelatedToCity";
str[2][103]="civil Polite";
str[2][104]="civilization Nagarikatha(T)";
str[2][105]="clad WearTheClothes(DresssedInCloth)";
str[2][106]="claim Right";
str[2][107]="clan Tribe(OR)ALargeFamilyGroup";
str[2][108]="clap Applaud,Chappatlu ";
str[2][109]="clarify MakeClear ";
str[2][110]="clash DashAganist";
str[2][111]="clause PartOfSentence ";
str[2][112]="claw Bird(ABentNailOfABeast)";
str[2][113]="clay SoftSoil(or)SoftEarth";
str[2][114]="cliff  SteepRock(BigRock)";
str[2][115]="climate Weather";
str[2][116]="climb GoUp";
str[2][117]="cling HoldOn";
str[2][118]="clot FormIntoLump";
str[2][119]="clothe PutOnDresss(WearTheDress)";
str[2][120]="clove Spice,Lavangamu(T)";
str[2][121]="clown Jocker(PersonWhoMakesPeopleLaugh)";
str[2][122]="clumsy awkward";
str[2][123]="clutch HoldStongly";
str[2][124]="coach Four-WheeledCarriage,Instructor";
str[2][125]="coalition kalayika";
str[2][126]="coarse Rough,NotFine";
str[2][127]="coast LandBoardingTheSea";
str[2][128]="coax Bujjaginchu(T)";
str[2][129]="cobbler MenderOfShoes";
str[2][130]="cobweb NestOfSpider";
str[2][131]="cock MaleOfBirds,Kodipunju(T)";
str[2][132]="cod OneTypeOfFish";
str[2][133]="coffin BoxToBuryTheDeadBody";
str[2][134]="coherent EasyToUnderstand";
str[2][135]="coincide Agree";
str[2][136]="coir CoconutFibre";
str[2][137]="coke BurntCoal";
str[2][138]="collapse FallDownToPieces";
str[2][139]="colleagues PersonsWhoWorksInSameCompany";
str[2][140]="collide Dash";
str[2][141]="colonel AnOfficerInArmy";
str[2][142]="column TallPiller";
str[2][143]="combat Fight";
str[2][144]="comely PleasentToLookAt";
str[2][145]="comet RelatedToStars(ThokaChukka(t))";
str[2][146]="comic RasingMirth";
str[2][147]="commemorate HonourTheMemoreOf";
str[2][148]="commence Begin";
str[2][149]="commend Praise";
str[2][150]="commerce Trade(Business)";
str[2][151]="commit DoSomethingWrong";
str[2][152]="commitment Promise";
str[2][153]="commodity UseFulThing";
str[2][154]="community caste(ADivisionInSociety)";
str[2][155]="compact Closely Fitted";
str[2][156]="companion PersonWhoGoesWith";
str[2][157]="compasses MathematicalInstrument";
str[2][158]="compassion Pity";
str[2][159]="compel Force(Compulsory)";
str[2][160]="compensate MakeUpTheLose";
str[2][161]="compete TakeAPartInContest";
str[2][162]="comply ActInAccordanceWith";
str[2][163]="comprehend Understand";
str[2][164]="compress PressTightly";
str[2][165]="comprise Included";
str[2][166]="compulsion Forceble";
str[2][167]="comrade Ally,Friend";
str[2][168]="conceal Hide";
str[2][169]="concede Agree,Grant";
str[2][170]="concern RelatedMatter";
str[2][171]="concession Rebate";
str[2][172]="concise compact";
str[2][173]="conclude Finish,BringToEnd";
str[2][174]="conclusion End,Decision";
str[2][175]="concur Agree,approval";
str[2][176]="comdemn Punish,Damn";
str[2][177]="condense compress";
str[2][178]="condone Forgive,excuse" ;
str[2][179]="condole ExpressSorrow";
str[2][180]="conduct ShowTheWay(or)Manage";
str[2][181]="cone Pyramid";
str[2][182]="confer Grant,Give";
str[2][183]="confess AcceptTheWrong";
str[2][184]="confidential KeptInSecret";
str[2][185]="confine Blockade,imprison";
str[2][186]="confiscate TakeOverTheProperty";
str[2][187]="conflict Fight,Variance";
str[2][188]="conform AgreeWith";
str[2][189]="confront AttackDirectly";
str[2][190]="congest makeHigh";
str[2][191]="congress AnAssembly";
str[2][192]="conquer Win";
str[2][193]="conquest Victory";
str[2][194]="conscience SenseOfRightAndWrong";
str[2][195]="conscious Knowing,AwareOf";
str[2][196]="consecutive ComingOneByOne";
str[2][197]="concent Agree";
str[2][198]="consequence HappeningWithResult";
str[2][199]="concervative OpposedToChange";
str[2][200]="considerable MuchImportence";
str[2][201]="consistent InAgreementWith";
str[2][202]="console ShowSympathy";
str[2][203]="consolidate MakeSolid";
str[2][204]="conspecuous SeenEasily,KnownEasily";
str[2][205]="conspire PlanSecretly";
str[2][206]="constellation GroupOfStars";
str[2][207]="constitute SetUp";
str[2][208]="consume Using";
str[2][209]="contagion Infection";
str[2][210]="contemporary OfTheSamePeriod";
str[2][211]="contempt Disrespect,Scorm";
str[2][212]="content Satisfied";
str[2][213]="contents ThatWhichIsInside";
str[2][214]="contest FightFor";
str[2][215]="context Circumstances,Situation";
str[2][216]="continent Kandamu(T)";
str[2][217]="continual OccuringRepetedlyAllTheTimes";
str[2][218]="contract AnAgreement";
str[2][219]="contradict Deny,Opposed";
str[2][220]="contrary Opposite";
str[2][221]="contrast ShowDifference";
str[2][222]="contribute GiveDonation";
str[2][223]="controversy ProlangedArgument";
str[2][224]="convene Assemble,CallAMeetingOf";
str[2][225]="convent AHouseOfNuns";
str[2][226]="convention Tradition";
str[2][227]="conversation converse,Talking";
str[2][228]="canvey Carry";
str[2][229]="convince MakeOneBelieve";
str[2][230]="coolie AHiredServent,Worker,Labourer";
str[2][231]="convocation AFunctionWhereDegreesOfConferredOnStudents";
str[2][232]="co-ordinate PutIntoProperRelation";
str[2][233]="coral Pagadamu(T)";
str[2][234]="cord String,Thread";
str[2][235]="cordial sincere,hearty";
str[2][236]="core InnerPart";
str[2][237]="";
str[2][238]="";
str[2][239]="";



str[3][0]="d d";
str[3][1]="daffodills DilightfulSmile";
str[3][2]="dagger ADoubleEdgedSword";
str[3][3]="dairy APlaceForMakingMilk";
str[3][4]="dais Stage(or)Plotform";
str[3][5]="dale Valley";
str[3][6]="damn Condemn,Accuse";
str[3][7]="damp Wet";
str[3][8]="damsel ABeautifulUnmarriedWoman ";
str[3][9]="dangle HangleLoosely";
str[3][10]="darken MakeDark";
str[3][11]="dawn Day-break";
str[3][12]="daze Confuse";
str[3][13]="dazzle BlindWithLight";
str[3][14]="deaden BeNumb,NotShart,Blunt";
str[3][15]="deadly Fatal(or)dangerous";
str[3][16]="deal ShareOut(or)DoBusssiness,Manage";
str[3][17]="dearth Scarcity";
str[3][18]="debar Prevent";
str[3][19]="debate Discussion";
str[3][20]="debit MoneyDue,Barrow";
str[3][21]="debtor OneWhoOwes,WhoTakesMoneyAsDebit";
str[3][22]="decade PeriodOfTenYears";
str[3][23]="decamp GoAwaySecretely";
str[3][24]="decay Rot(or)GradualWaste";
str[3][25]="deceased DeadPerson";
str[3][26]="deceive Cheat";
str[3][27]="decent Respectable";
str[3][28]="decisive Final";
str[3][29]="deck OpenPartOfShip(or)Decorate(V)";
str[3][30]="decorum ProperBehaviour";
str[3][31]="decree OrderOfTheCourt";
str[3][32]="deduct TakeAway";
str[3][33]="deed Act,Document ";
str[3][34]="deem Consider";
str[3][35]="deepen MakeDeep";
str[3][36]="deer AKindOfStag,Ginka(T)";
str[3][37]="defect Fault";
str[3][38]="defection LeaveOnePartyAndJoinOther";
str[3][39]="defence Protection";
str[3][40]="defend Protect";
str[3][41]="defendent OneWhoShowAsACulpritInACase";
str[3][42]="defer PutOff(or)Postpone";
str[3][43]="deficit AmountToBeAdjustedInTheBudget";
str[3][44]="definite Exact";
str[3][45]="defunct OutOfUse";
str[3][46]="defy ResistOpenly";
str[3][47]="degenerate HavingLostTheRequiredQualities";
str[3][48]="deity God(OR)Goddess";
str[3][49]="delegate Representative";
str[3][50]="deliberate Intentional";
str[3][51]="delicious Tasty";
str[3][52]="demand ClaimAnAmount(Or)Anything";
str[3][53]="demarcate FixTheLimits";
str[3][54]="demolish PulllDown";
str[3][55]="demonstrate ProveByEXample ";
str[3][56]="dense Thick";
str[3][57]="deny Refuse";
str[3][58]="dependable Realiable";
str[3][59]="";
str[3][61]="deplore ShowSorrow,Console,Regret";
str[3][62]="depose Dethrone,TakeAnOath";
str[3][63]="depot AStoreHouse";
str[3][64]="depreciate LessonTheValueOf";
str[3][65]="depress Dampen,PullDownToLowLevel";
str[3][66]="deprive TakeAwayFrom";
str[3][67]="depute AppointAsRepresentative";
str[3][68]="derail GoOffTheRails";
str[3][69]="descendant AHeir(or)ASuccessor ";
str[3][70]="desert SandlyPlace";
str[3][71]="deserve BeWorthyOf(or)BeEntintled";
str[3][72]="despair LossOfHope";
str[3][73]="desperate ReadyToDoAythingOutOfHopeless";
str[3][74]="despatch SendQuickly";
str[3][75]="despot Dictator(or)RulerWIthUnlimitedPowers";
str[3][76]="destiny Fate";
str[3][77]="destitute PersonWithoutMinimumNecessities";
str[3][78]="detach Seperate";
str[3][79]="detect Findout";
str[3][80]="detective FindOutTheCriminals";
str[3][81]="detain KeepUnderArrest";
str[3][82]="determination Resolution";
str[3][83]="detest HateStrongly";
str[3][84]="dethrone Depose(or)RemoveFromTheThrone";
str[3][85]="detonate Explode";
str[3][86]="detract TakeAwayFrom";
str[3][87]="detriment Harm(or)Damage";
str[3][88]="devalue LessenTheValue";
str[3][89]="devastate RuinThePlace(or)Land";
str[3][90]="deviate Deviation(or)GoOutOfTheLine";
str[3][91]="devise Plan";
str[3][92]="devote Dedicate";
str[3][93]="devotee ATrueFollower";
str[3][94]="devotion SelfSurrrender";
str[3][95]="devour Swallow";
str[3][96]="dew Manchu(T)";
str[3][97]="dexterity Skill";
str[3][98]="dictator RulerWithUnlimitedPowers";
str[3][99]="diet DailyFood";
str[3][100]="dig TurnUpTheEarth";
str[3][101]="digest AssimilateFood";
str[3][102]="dignity Honour(or)RespectableMannerorStyle";
str[3][103]="dilemma DoubtfulSituation";
str[3][104]="diligent HardWorking";
str[3][105]="dilute MakeWeaker(or)Thinner";
str[3][106]="diminish Makeless";
str[3][107]="din Noise";
str[3][108]="dine EatFood";
str[3][109]="dip Plung(or)PutIntoWater";
str[3][110]="diplomacy POliticalWisdom";
str[3][111]="disable MakeUseless";
str[3][112]="disarm DepriveOfArms";
str[3][113]="disaster Misfortune";
str[3][114]="disburse PayMoney";
str[3][115]="discard Giveup";
str[3][116]="disclose Order(or)MakeKnown";
str[3][117]="discontent Dissatisfaction";
str[3][118]="discourse Lecture (or)Talk";
str[3][119]="discredit LOssOfGoodnName(or)Slur";
str[3][120]="discrepency difference";
str[3][121]="discreminate TreatDifferently";
str[3][122]="disease Illness";
str[3][123]="disgrace LossOfRespect";
str[3][124]="disguice FalseAppearence";
str[3][125]="disgust FeelingOfDislike";
str[3][126]="dish Plate( or)FoodServedInADish";
str[3][127]="dishearten Discourage";
str[3][128]="dishonor Disresept";
str[3][129]="dislocate Disturb";
str[3][130]="dismal Sad(or)Dark";
str[3][131]="dismantle Pullldown";
str[3][132]="dismay Discouragement";
str[3][133]="dispatch Quickness";
str[3][134]="disparity Inequality";
str[3][135]="dispel DriveAway";
str[3][136]="dispensary APlaseWhereMedicinesArePrepared";
str[3][137]="dispense DoWithout";
str[3][138]="dispensable NotNecessary";
str[3][139]="disperse GoAReSendInDiffrentDirection";
str[3][140]="displace PutOutOfPlkace ";
str[3][141]="displease CauseAnger";
str[3][142]="dispose Settle";
str[3][143]="dispute Quarrel";
str[3][144]="disrupt Break";
str[3][145]="disregard PayNoAttention(or)AlashyamCheyu";
str[3][146]="dissent GiveDifferentOpinion ";
str[3][147]="dissservice Injury";
str[3][148]="disssipate GoApart";
str[3][149]="dissolve TurnASolidIntoLiquid";
str[3][150]="dissuade AdviseAgainast";
str[3][151]="distil VapouriseAndCondense";
str[3][152]="distint ClearSeperateFromDifferent";
str[3][153]="distinction Eminance(or)Difference";
str[3][154]="distinguish Differrentiate";
str[3][155]="distort TwistTheShape";
str[3][156]="distract DrawAwayAttention";
str[3][157]="distress GreatPain(or)Sorrow ";
str[3][158]="distrust LackOfTrust";
str[3][159]="disunite Seperate";
str[3][161]="disuse StateOfNotBeingInUse";
str[3][162]="ditch ATrench(or)NarrowChannelToCarryAwayWater";
str[3][163]="dive Plunge(or)FallIntoWaterWithHeadDown";
str[3][164]="";
str[3][165]="";
str[3][166]="";
str[3][167]="";
str[3][168]="";
str[3][169]="";
str[3][170]="";
str[3][171]="";
str[3][172]="";
str[3][173]="";
str[3][174]="";
str[3][175]="";
str[3][176]="";
str[3][177]="";
str[3][178]="";
str[3][179]="";
str[3][180]="";
str[3][181]="";
str[3][182]="";
str[3][183]="";
str[3][184]="";
str[3][185]="";
str[3][186]="";
str[3][187]="";
str[3][188]="";
str[3][189]="";
str[3][190]="";
str[3][191]="";
str[3][192]="";
str[3][193]="";
str[3][194]="";
str[3][195]="";
str[3][196]="";
str[3][197]="";
str[3][198]="";
str[3][199]="";


str[4][0]="eager ShowingStrongDesire";
str[4][1]="earl Noble";
str[4][2]="earmark SetApartForAParticularPurpose";
str[4][3]="earnest Desirous,Serious,Sincere,AnAdvance";
str[4][4]="earthen MadeOfClay";
str[4][5]="ebb TheRetiringOfTide,TheFlowingOutOfTheTide,Decline";
str[4][6]="eccentric OfPeculiarBehaviour";
str[4][7]="ecology ScienceDealingWithTheWeatherAndAtmosphere";
str[4][8]="ecstasy ExtremeDelight,JoyOf SpiritualUplift,Ecstatic";
str[4][9]="edifice ImposingBuilding";
str[4][10]="electrocute GetKilledByElectricShock";
str[4][11]="elegy APoemOnTheDeathOfAPerson,SongOrPoemOfSorrowForTheDead";
str[4][12]="elevate LiftHigh,Raise,EnlivenTheSpirits";
str[4][13]="elicit DrawOut";
str[4][14]="elite PeopleOf Rankm,TheBestOf People(Or)Things";
str[4][15]="elocution TheArtOfSpeaking,Ortory";
str[4][16]="elope RunAwayWithTheLover";
str[4][17]="elucidate ClearExplanation";
str[4][18]="elude EscapeFromBeingCaught ";
str[4][19]="emancipate SetFreeFromBondage,ProvideFreedom";
str[4][20]="embarkment ABigBund";
str[4][21]="embellish MakeBeautifulWithOrnaments,DecorateOrAdornWithOrnaments";
str[4][22]="embitter CauseBitterness,MakeBitter(UnHappy)";
str[4][23]="embody Include,GiveShape";
str[4][24]="emboss Engrave,Etch,Depict";
str[4][25]="embrace Hug,TakeIntoArms";
str[4][26]="emissary PersonSentToDeliverAMessage";
str[4][27]="emoluments TypesOfIncomeFromEmployment";
str[4][28]="emphasize Stress,SayOrSpeakToGiveForceOrImortance";
str[4][29]="enchant Charm,DrawAsIfByMagic";
str[4][30]="encroach GoBeyondIntoOther'sR ight";
str[4][31]="encumber BeInTheWayOf,Obstruct";
str[4][32]="encyclopaedia ABigVolumeContainsInformationAboutEverything,A Big Knowledge Bank";
str[4][33]="endow ProvideWith Property,Furnish";
str[4][34]="enduring Lasting";
str[4][35]="endorse Approve,Assign";
str[4][36]="enemy Foe";
str[4][37]="engross TakeUpAllTheAttentionOfMind";
str[4][38]="enjoin Command";
str[4][39]="enlist Enroll,Recruit";
str[4][40]="enmasse AllTogether";
str[4][41]="entreat RequestEarnestly or Sincerely";
str[4][42]="enumerate CountOneByone";
str[4][43]="enunciate ExplainClearly";
str[4][44]="enviable ealous";
str[4][45]="ephemeral Temporary,ExistingForAShortTime";
str[4][46]="epidemic SpreadingAmongPeople,DiseaseSpreadingByTouch";
str[4][47]="epilogue Conclusion,LastPartOfAPoemOrPlay";
str[4][48]="epoch AnEra";
str[4][49]="equator TheLongestOfLatitudes";
str[4][50]="era HistoricalPeriod";
str[4][51]="ere Before";
str[4][52]="erelong InAShortTime";
str[4][53]="err CommitAMistake,BeWrong";
str[4][54]="errand PurposefulJourney";
str[4][55]="erroneous Wrong,Incorrect";
str[4][56]="erudite HighlyLearned,Scholarly";
str[4][57]="erupt BreakOut";
str[4][58]="escort Attendant,PersonWhoFollowForProtection";
str[4][59]="espionage PracticeOf Spying";
str[4][60]="eternal Everlasting,HavingNoBeginningOrEnd";
str[4][61]="etiquitte RulesOfFormalEhaviour";
str[4][62]="evacuate MakeEmpty,Leave,Withdraw From";
str[4][63]="evade KeepAwayFrom,GetAwayFrom";
str[4][64]="eventual likelyToHappenAsAResult";
str[4][65]="evict SendOut";
str[4][66]="evince Show";
str[4][67]="evolve DevelopGradually,OpenOut";
str[4][68]="ewe FemaleSheep";
str[4][69]="exaggerate StateInAHyperbolicWay,MakeOrDescribeBeyondTheTruth";
str[4][70]="exalt LiftUp,SpeakHighOf";
str[4][71]="excavate TakeOutByDigging";
str[4][72]="exclaim Shout,SayInWonder";
str[4][73]="excursion A JourneyForPleasure";
str[4][74]="exemplary WhichServesAsAnExamplesOrAsAWarning";
str[4][75]="exemplify ExplainByGivingExamples";
str[4][76]="exert MakeAnEffortToBringIntoUse";
str[4][77]="exhale GiveOutBreath,BreathOut";
str[4][78]="exhort Warn,GiveAdvice";
str[4][79]="exigency Urgency,GreatNeed";
str[4][80]="expel SendOutByForce,TurnOut";
str[4][81]="exponent Interpreter";
str[4][81]="extol Praise,Applaud";



str[9][0]="j j";
str[9][1]="jack Sailor,SweetFruit,PlayingCard";
str[9][2]="jackal Fox(AWildBeastOfDogFamily)";
str[9][3]="jade HardGreenStoneUsedInOrnaments";
str[9][4]="jaded TiredOut";
str[9][5]="jag RockWithASharpProjection";
str[9][6]="jagged RockWithUnevenEdges";
str[9][7]="jaguar AWildAnimalOfTheTypeOfATiger";
str[9][8]="jaggery AProductOfSweetMetirialFromSugarcane";
str[9][9]="jar Shock,AWaterPot";
str[9][10]="jargon UnUnderstandableLanguage";
str[9][11]="jasmine ASweetSmillingWhiteFlower";
str[9][12]="jaundice DiseaseCausedByStoppageOfBile";
str[9][13]="javelin LightSpearForthrowingInSports";
str[9][14]="jaw TheBoneOfMouth";
str[9][15]="jealous Envious,FeelingILL";
str[9][16]="jeer Scoff,LaughRudely";
str[9][17]="jelly SweetFoodSubstance";
str[9][18]="jeopardize PutIntoDanger";
str[9][19]="jerk PushSuddenly";
str[9][20]="jerkin SmallCloseFittedJacket";
str[9][21]="jest Joke,Fun";
str[9][22]="jester Buffon,Clown";
str[9][23]="jesuit AMemberOfSocietyOfJesus(Catholic)";
str[9][24]="jet AFormOfCoal";
str[9][25]="jew Hebrew";
str[9][26]="jewel Ornament";
str[9][27]="jingle TinkleLikeABell";
str[9][28]="jockey ProfessionalRiderInHoursRaces";
str[9][29]="jocular Humorous";
str[9][30]="joiner Carpenter";
str[9][31]="joint-stock CapitalFormedByGroupMen";
str[9][32]="jolly Merry";
str[9][33]="jolt ShakeWithSuddenJerks";
str[9][34]="jostle PushOneAgainstAnother";
str[9][35]="jot ASmallParticle";
str[9][36]="jottings ContentsThatAreWritten";
str[9][37]="journals DaillyOrPeriodicalPublications";
str[9][38]="journalism WorkOfWritting,Editing,PublishingAPaper";
str[9][39]="jovial merry,FullOfFunAndGoodHumour";
str[9][40]="jubilant TriumPhant,Rejoice";
str[9][41]="jubilation GreatJoy";
str[9][42]="jubilee AnOccationOf Rejoicing";
str[9][43]="judiciol RelatingToLaw(or)CourtOfJustice";
str[9][44]="judiciary  ";
str[9][45]="judicious ShowinggGoodSense";
str[9][46]="juggle PlayTricks(or)Juggler";
str[9][47]="jumble Mix";
str[9][48]="jumper ADrillingInstrument";
str[9][49]="juncture MumentStateOfAffairs ";
str[9][50]="jungle Forest";
str[9][51]="jurisdiction ExtentOfAuthority";
str[9][52]="jury WhoGivesVerdictInACaseBeforeACourt";
str[9][53]="jute FibrousPlant";
str[9][54]="juvenile Youthful,OfYoung";



str[10][0]="";
str[10][1]="";
str[10][3]="";
str[10][3]="";
str[10][4]="";
str[10][5]="";
str[10][6]="";
str[10][7]="";
str[10][8]="";
str[10][9]="";
str[10][10]="";
str[10][11]="";
str[10][12]="";
str[10][13]="";
str[10][14]="";
str[10][15]="";
str[10][16]="";
str[10][17]="";
str[10][18]="";
str[10][19]="";
str[10][20]="";
str[10][21]="";
str[10][22]="";
str[10][23]="";
str[10][24]="";
str[10][25]="";
str[10][26]="";
str[10][27]="";
str[10][28]="";
str[10][29]="";
str[10][30]="";
str[10][31]="";
str[10][32]="";
str[10][33]="";
str[10][34]="";
str[10][35]="";
str[10][36]="";
str[10][37]="";
str[10][38]="";
str[10][39]="";
str[10][40]="";
str[10][41]="";
str[10][42]="";
str[10][43]="";
str[10][44]="";
str[10][45]="";
str[10][46]="";
str[10][47]="";
str[10][48]="";
str[10][49]="";
str[10][50]="";



addKeyListener(this);
setLayout(null);

setBounds(0,0,800,600);
setVisible(true);
setBackground(Color.green);



int checkScore=0,checkTotal=-10;
int optionNo=0,no1=0,be_no1=0,no2=0,be_no2=0,no3=0,be_no3=0,no4=0,be_no4=0;
String subStr="";
String supStr="";

long startTime=System.currentTimeMillis(),timer,se,mi,ho,pse=1000,pmi=60000,pho=3600000;
Label labelTimer=new Label("U  R  Sended Time :  00:00:00");
labelTimer.setBounds(650,400,150,30);
add(labelTimer);

for(i=start;i<=(end+50);i=i+10)
{
timer=System.currentTimeMillis()-startTime;   se=(timer/pse)%60;   mi=(timer/pmi)%60;   ho=timer/pho;
labelTimer.setText(" Timer  "+ho+" : "+mi+" : "+se);


b.setLocation(240,i);		try{Thread.sleep(speed);}catch(Exception e){}

if(i>=end)
{
tf.setText("");	s="";


if(banswers==false)
{

do{
no=(int)(Math.abs(random.nextInt())%(no_per));
be_no=(int)(Math.abs(random.nextInt())%(char_per));
}while(str[be_no][no].equals("")||cb[be_no].getState()==false);

}//end of if(banswers==false)

if(btest==true)
{

do{
no1=(int)(Math.abs(random.nextInt())%(no_per));
be_no1=(int)(Math.abs(random.nextInt())%(char_per));
}while(str[be_no1][no1].equals("")||cb[be_no1].getState()==false);

do{
no2=(int)(Math.abs(random.nextInt())%(no_per));
be_no2=(int)(Math.abs(random.nextInt())%(char_per));
}while(str[be_no2][no2].equals("")||cb[be_no2].getState()==false);

do{
no3=(int)(Math.abs(random.nextInt())%(no_per));
be_no3=(int)(Math.abs(random.nextInt())%(char_per));
}while(str[be_no3][no3].equals("")||cb[be_no3].getState()==false);

do{
no4=(int)(Math.abs(random.nextInt())%(no_per));
be_no4=(int)(Math.abs(random.nextInt())%(char_per));
}while(str[be_no4][no4].equals("")||cb[be_no4].getState()==false);



optionNo=(int)(Math.abs(random.nextInt())%(4));
supStr=supToken(str[be_no][no]);
options[optionNo].setLabel(""+supStr);


if(optionNo!=0){supStr=supToken(str[be_no1][no1]);options[0].setLabel(""+supStr);}
if(optionNo!=1){supStr=supToken(str[be_no2][no2]);options[1].setLabel(""+supStr);}
if(optionNo!=2){supStr=supToken(str[be_no3][no3]);options[2].setLabel(""+supStr);}
if(optionNo!=3){supStr=supToken(str[be_no4][no4]);options[3].setLabel(""+supStr);}

}//end of if(btest==true)



if(btest==false)
{ 
options[0].setVisible(false);options[1].setVisible(false);options[2].setVisible(false);options[3].setVisible(false);
scoreLabel.setVisible(false);
checkScore=0;
checkTotal=0;
}


if(btest==true)
{ 
random_1++;
t_a_b[random_1]=be_no;		
t_no[random_1]=no;			
subStr=token(str[be_no][no]);
b.setLabel(subStr);word.setText(subStr);

options[0].setVisible(true);options[1].setVisible(true);options[2].setVisible(true);options[3].setVisible(true);
scoreLabel.setVisible(true);



}//end    of    if (btest==true)

else

if(banswers==true)
{
random_2++;
if(random_2 <=  random_1)	{be_no=t_a_b[random_2];		no=t_no[random_2];	}
else			{random_2=0;random_1=0;btest=true;banswers=false;}
}//end of if (banswers==true)


i=start;
if(btest==false)		{b.setLabel(str[be_no][no]);word.setText(str[be_no][no]);}

speed=initialSpeed;

}//end if 

if(btest==true&&i<390)
{
if(options[optionNo].getLabel().equals(tf.getText())){i=390;options[optionNo].setState(true);}
}


if(i==390&&btest==true)
{

if(options[optionNo].getState()==true){checkScore=checkScore+10;}
else
{

bw.flush();
bw.write(str[be_no][no],0,str[be_no][no].length());
bw.newLine();

//System.out.println("jkkj");


scoreLabel.setBackground(Color.red);
options[optionNo].setBackground(Color.yellow);
try{Thread.sleep(3500);}catch(Exception e){}
scoreLabel.setBackground(Color.white);
options[optionNo].setBackground(Color.white);
}

checkTotal=checkTotal+10;
scoreLabel.setText("Score  :    "+checkScore+"  /  "+checkTotal);
options[0].setState(false);options[1].setState(false);options[2].setState(false);options[3].setState(false);

}


}//end of loop
fw.close();
bw.close();
}//end of constructor

public String token(String str)
{
if(reverse==true){return(ActualSupToken(str));}else
{return(Actualtoken(str));}
}//end of method

String tokenStr="";
public String Actualtoken(String str)
{
tokenStr="";
for(int i=0;str.charAt(i)!=' ';i++)  {    tokenStr=tokenStr+str.charAt(i);   }
return(tokenStr);
}

public String supToken(String str)
{
if(reverse==true){return(Actualtoken(str));}else
{return(ActualSupToken(str));}
}//end of method

int space=0;
String supTokenStr="";
public String ActualSupToken(String str)
{
supTokenStr="";

for(space=0;str.charAt(space)!=' ';space++){}
for(;space<str.length();space++)  {  supTokenStr=supTokenStr+str.charAt(space);  }
return(supTokenStr);
}













int preAsci=0,postAsci=0;
int asci=0;
public void keyReleased(KeyEvent e)
{
postAsci=e.getKeyCode();
if(postAsci==27||postAsci==96){i=390;}

ch=e.getKeyChar();
if(e.getKeyCode()==18)
{
try{
bw.flush();
bw.write(str[be_no][no],0,str[be_no][no].length());
bw.newLine();}catch(Exception e1){}
}

if(preAsci==84&&postAsci==17){btest=true;   banswers=false;random_2=0;random_1=0;}
if(preAsci==82&&postAsci==17){btest=false;  banswers=true;random_2=0;}
if(preAsci==78&&postAsci==17){btest=false;  banswers=false;random_2=0;random_1=0;}

//System.out.print(""+e.getKeyCode());

if(str[be_no][no].startsWith(""+s+ch)  )
{   
s=s+ch;tf.setText(s);
if(str[be_no][no].equals(tf.getText()))    {  whenEqual(1);  } 
}

else
{
tf.setText(s);
Toolkit.getDefaultToolkit().beep();
}

//System.out.println(" Code = "+e.getKeyCode());

if(e.getKeyCode()==38){options[0].setState(true);}else
if(e.getKeyCode()==37){options[1].setState(true);}else
if(e.getKeyCode()==39){options[2].setState(true);}else
if(e.getKeyCode()==40){options[3].setState(true);}

preAsci=postAsci;

}//end of keyReleased






















public void whenEqual(int option)
{
tf.setText("");
cat=0;
s="";

do{
no=(int)(Math.abs(random.nextInt())%(no_per));
be_no=(int)(Math.abs(random.nextInt())%(char_per));
}while(str[be_no][no].equals(""));

i=start;
b.setLabel(str[be_no][no]);word.setText(str[be_no][no]);


if(speed>incresedSpeed){speed=speed-incresedSpeed;}
score=score+10;
setTitle("                                                                               SCORE : "+score);	
}






public void keyPressed(KeyEvent e){}
public void keyTyped(KeyEvent e){}
public void paint(Graphics g)
{g.drawImage(Toolkit.getDefaultToolkit().getImage("push3.jpg"),0,0,800,600,this);}














int font=22;
public void actionPerformed(ActionEvent e)
{

if(e.getSource()==list)
{
if(list.getSelectedItem().equals("Next(Press 'ESC' )")){i=390;}else
if(list.getSelectedItem().equals("Test (ctrl + t)")){btest=true;banswers=false;random_2=0;random_1=0;reverse=false;}else
if(list.getSelectedItem().equals("Test In Reverse")){btest=true;banswers=false;random_2=0;random_1=0;reverse=true;}else
if(list.getSelectedItem().equals("Result (ctrl + r)")){btest=false;  banswers=true;random_2=0;}else
if(list.getSelectedItem().equals("Normal (ctrl + n)")){btest=false;  banswers=false;random_2=0;random_1=0;}else
if(list.getSelectedItem().equals("IncreaseSpeed")){if(speed>100){speed=speed-50;initialSpeed=speed;}}else
if(list.getSelectedItem().equals("DecreaseSpeed")){if(speed<5000){speed=speed+50;initialSpeed=speed;}}else
if(list.getSelectedItem().equals("IncreaseFontSize"))
{
font=font+2;
b.setFont(new Font("TimesRoman",0,font));
word.setFont(new Font("TimesRoman",0,font));
//go.setFont(new Font("TimesRoman",0,font));
//list.setFont(new Font("TimesRoman",0,font));
border.setFont(new Font("TimesRoman",0,font));
border1.setFont(new Font("TimesRoman",0,font));
border2.setFont(new Font("TimesRoman",0,font));
tf.setFont(new Font("TimesRoman",0,font));
}
else
if(list.getSelectedItem().equals("DecreaseFontSize"))
{
font=font-2;
b.setFont(new Font("TimesRoman",0,font));
word.setFont(new Font("TimesRoman",0,font));
//go.setFont(new Font("TimesRoman",0,font));
//list.setFont(new Font("TimesRoman",0,font));
border.setFont(new Font("TimesRoman",0,font));
border1.setFont(new Font("TimesRoman",0,font));
border2.setFont(new Font("TimesRoman",0,font));
tf.setFont(new Font("TimesRoman",0,font));
}


}//end of if(e.getSource==go)
}//end of actionPerformed

boolean reverse=false;
/*
public void itemStateChanged(ItemEvent e)
{
actionPerformed(new ActionEvent(go,1,"GO"));
System.out.println("sdgf");
}
*/

}//end of class 